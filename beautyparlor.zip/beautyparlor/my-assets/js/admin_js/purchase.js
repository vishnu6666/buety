function addPurchaseInputField(t) {

    if (count == limits) alert("You have reached the limit of adding " + count + " inputs");
    else {
        var a = "product_name" + count,
            e = document.createElement("tr");
        e.innerHTML = "<td><input type='text' name='product_name' onkeypress='purchase_productList(" + count + ");' class='form-control productSelection' placeholder='Product Code' id='" + a + "' required><input type='hidden' class='autocomplete_hidden_value  product_id_" + count + "' name='product_id[]' id='SchoolHiddenId'/></td><td><input type='text' name='product_mrp[]' id='product_mrp_" + count + "'  class='form-control text-right product_mrp" + count + "' placeholder='MRP'  required /></td><td class='text-right'><input type='text' name='product_quantity[]' id='total_qntt_" + count + "' onkeyup='quantity_calculate(" + count + "); stockLimit(" + count + ");' class='total_qntt" + count + " form-control text-right' value='1'/></td><td><input type='text' name='product_rate[]'  id='price_item_" + count + "' class='price_item" + count + " form-control text-right' required/></td><td><input class='total_price" + count + " text-right form-control' type='text' name='total_price[]' id='total_price_" + count + "' /></td><td><input type='hidden' id='total_cgst_" + count + "' class='total_cgst' /><input type='hidden' id='total_sgst_" + count + "' class='total_sgst' /><input type='hidden' id='all_tax_" + count + "' class='total_tax'/><button style='text-align: right;' class='btn btn-danger' type='button' value='Delete' onclick='deleteRow(this)'>Delete</button></td>", document.getElementById(t).appendChild(e), document.getElementById(a).focus(), count++
        
        
    }
}
function addPurchaseInputField2(t) {

    if (count == limits) alert("You have reached the limit of adding " + count + " inputs");
    else {
        var a = "product_name" + count,
            e = document.createElement("tr");
        e.innerHTML = "<td><input type='text' name='product_name' onkeypress='purchase_productList(" + count + ");' class='form-control productSelection' placeholder='Product Code' id='" + a + "' required><input type='hidden' class='autocomplete_hidden_value  product_id_" + count + "' name='row_product_id[]' id='SchoolHiddenId'/></td><td class='text-right'><input type='text' name='product_quantity[]' id='total_qntt_" + count + "' onkeyup='quantity_calculate(" + count + "); stockLimit(" + count + ");' class='total_qntt" + count + " form-control text-right' value='1'/></td><td><input type='text' name='product_rate[]'  id='price_item_" + count + "' class='price_item" + count + " form-control text-right' required/></td><td><input class='total_price" + count + " text-right form-control' type='text' name='total_price[]' id='total_price_" + count + "' /></td><td><input type='hidden' id='total_cgst_" + count + "' class='total_cgst' /><input type='hidden' id='total_sgst_" + count + "' class='total_sgst' /><input type='hidden' id='all_tax_" + count + "' class='total_tax'/><button style='text-align: right;' class='btn btn-danger' type='button' value='Delete' onclick='deleteRow(this)'>Delete</button></td>", document.getElementById(t).appendChild(e), document.getElementById(a).focus(), count++
        
        
    }
}
function editPurchaseInputField(t) {
    if (count == limits) alert("You have reached the limit of adding " + count + " inputs");
    else {
        var a = "product_name" + count,
            e = document.createElement("tr");
        e.innerHTML = "<td><input type='text' name='product_name' onkeypress='purchase_productList(" + count + ");' class='form-control productSelection' placeholder='Product Code' id='" + a + "' required><input type='hidden' class='autocomplete_hidden_value  product_id_" + count + "' name='product_id[]' id='SchoolHiddenId'/></td><td class='text-right'><input type='text' name='batch_no[]' id='batch_no_" + count + "'  class='form-control text-right batch_no" + count + "'  /></td><td><input type='text' name='expire_date[]' id='expire_date_" + count + "' class='form-control text-right datepicker expiry_date" + count + "'  /></td><td><input type='text' name='product_mrp[]' id='product_mrp_" + count + "'  class='form-control text-right product_mrp" + count + "' placeholder='MRP'  required /></td><td class='text-right'><input type='text' name='product_quantity[]' id='total_qntt_" + count + "' onkeyup='quantity_calculate(" + count + "); stockLimit(" + count + ");' class='total_qntt" + count + " form-control text-right' value='1'/></td><td><input type='text' name='product_free[]' id='total_freeqntt_" + count + "'  class='form-control text-right total_freeqntt" + count + "' placeholder='Free'  /></td><td><input type='text' name='product_cgst[]' value='0.00' id='cgst_" + count + "' class='cgst" + count + " form-control text-right' /></td><td><input type='text' name='product_sgst[]'  value='0.00' id='sgst_" + count + "' class='sgst" + count + " form-control text-right' /></td><td><input type='text' name='product_discount[]' onkeyup='quantity_calculate(" + count + ");stockLimit(" + count + ");' id='discount_" + count + "' class='form-control text-right' value='0' min='1' /></td><td><input type='text' name='product_rate[]'  id='price_item_" + count + "' class='price_item" + count + " form-control text-right' required/></td><td><input class='text-right form-control taxable" + count + "' type='text' name='total_taxable[]' id='taxable_" + count + "'   /></td><td><input class='total_price" + count + " text-right form-control' type='text' name='total_price[]' id='total_price_" + count + "' /></td><td><input type='hidden' id='total_cgst_" + count + "' class='total_cgst' /><input type='hidden' id='total_sgst_" + count + "' class='total_sgst' /><input type='hidden' id='all_tax_" + count + "' class='total_tax'/><button style='text-align: right;' class='btn btn-danger' type='button' value='Delete' onclick='deleteRow(this)'>Delete</button></td>", document.getElementById(t).appendChild(e), document.getElementById(a).focus(), count++
        
       
    }
}

function quantity_calculate(t) {
    var a = $("#total_qntt_" + t).val(),
        e = $("#price_item_" + t).val(),
        o = $("#discount_" + t).val(),
        l = $("#total_tax_" + t).val();
        //tx = $("#taxable_" + t).val();
        pcg =0;
        psg = 0;
        cgst = 0;
        sgst = 0; 
        
		cg = $("#cgst_" + t).val(); 
        sg = $("#sgst_" + t).val(); 
       
        
    if (a > 0) {
        var n = a * e;
		 if(cg > 0){
           var cgst = (n * cg) / 100;
        }
        if(sg > 0){
           var sgst = (n * sg) / 100;  
        }  
        //$("#total_cgst_" + t).val(cgst);
        //$("#total_sgst_" + t).val(sgst);
        $("#taxable_" + t).val(n);
        $("#total_price_" + t).val(n + cgst + sgst);
        //var c = a * l;
        //$("#all_tax_" + t).val(c)
    } 
    if (o > 0) {	  
		
        n = a * e;
        var ot = (n * o ) / 100;
        var fn = n - ot;
        
		if(cg > 0){
           cgst = (fn * cg) / 100;
        }
        if(sg > 0){
           sgst = (fn * sg) / 100;  
        }   
		var nn = fn + cgst + sgst ;
		$("#taxable_" + t).val(fn);
        $("#total_price_" + t).val(nn);
        //$("#total_price_" + t).val(fn), $("#total_tax_" + t).val(l), $("#total_cgst_" + t).val(cgst), $("#total_sgst_" + t).val(sgst)
    } else if (0 > o) {
		n = (a * e); 
	   if(cg > 0){
           cgst = (n * cg) / 100;
        }
        if(sg > 0){
           sgst = (n * sg) / 100;  
        }  
         nn = n + cgst + sgst;
		$("#taxable_" + t).val(n);
        $("#total_price_" + t).val(nn);
        
        //$("#total_price_" + t).val(nn), $("#total_tax_" + t).val(l), $("#total_cgst_" + t).val(cgst), $("#total_sgst_" + t).val(sgst)
    }
    calculateSum();
}


function calculateSum() {
    var t = 0,
        a = 0,
        e = 0,
        o = 0;
        
        
    $(".total_price").each(function() {
        t += parseFloat(this.value);
    }),  e = t, $("#grandTotal").val(+e);
    

}


function stockLimit(t) {
    var a = $("#total_qntt_" + t).val(),
        e = $(".product_id_" + t).val(),
        o = $(".baseUrl").val();
    $.ajax({
        type: "POST",
        url: o + "Cinvoice/product_stock_check",
        data: {
            product_id: e
        },
        cache: !1,
        success: function(e) {
            if (a > Number(e)) {
                var o = "You can purchase maximum " + e + " Items";
                alert(o), $("#qty_item_" + t).val("0"), $("#total_qntt_" + t).val("0"), $("#total_price_" + t).val("0")
            }
        }
    })
}

function stockLimitAjax(t) {
    var a = $("#total_qntt_" + t).val(),
        e = $(".product_id_" + t).val(),
        o = $(".baseUrl").val();
    $.ajax({
        type: "POST",
        url: o + "Cinvoice/product_stock_check",
        data: {
            product_id: e
        },
        cache: !1,
        success: function(e) {
            if (a > Number(e)) {
                var o = "You can purchase maximum " + e + " Items";
                alert(o), $("#qty_item_" + t).val("0"), $("#total_qntt_" + t).val("0"), $("#total_price_" + t).val("0.00"), calculateSum()
            }
        }
    })
}

function deleteRow(t) {
    var a = $("#normalinvoice > tbody > tr").length;
    if (1 == a) alert("There only one row you can't delete.");
    else {
        var e = t.parentNode.parentNode;
        e.parentNode.removeChild(e), calculateSum()
    }
}
var count = $("#pcount" ).val(),
    limits = 500;