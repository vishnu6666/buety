<?php
$cache_file = "product.json";
    header('Content-Type: text/javascript; charset=utf8');
?>
var productList = <?php echo file_get_contents($cache_file); ?> ;

APchange = function(event, ui){
	$(this).data("autocomplete").menu.activeMenu.children(":first-child").trigger("click");
}
    function purchase_productList(cName) {
		var mrpClass = 'product_mrp'+cName;
       	var ptrClass = 'ptr'+cName;
       	var btcClass = 'batch_no'+cName;
       	var costClass = 'price_item'+cName;
        var cgstClass = 'cgst'+cName;
        var sgstClass = 'sgst'+cName;                
		var total_tax_price = 'total_tax_'+cName;
		var total_quantity = 'total_quantity_'+cName;
		var product_purchash_detail_id  = 		'prid_'+cName;
	
        $( ".productSelection" ).autocomplete(
		{
            source: productList,
			delay:300,
			focus: function(event, ui) {
				$(this).parent().find(".autocomplete_hidden_value").val(ui.item.value);
				$(this).val(ui.item.label);
				return false;
			},
			select: function(event, ui) {
				$(this).parent().find(".autocomplete_hidden_value").val(ui.item.value);
				$(this).val(ui.item.label);
				
				var id=ui.item.value;
				var dataString = 'product_id='+ id;
				var base_url = $('.baseUrl').val();

				
				$.ajax
				   ({
						type: "POST",
						url: base_url+"Cproduct/retrieve_product_purchase_data",
						data: dataString,
						cache: false,
						success: function(data)
						{
			
							var obj = jQuery.parseJSON(data);
							
							$('.'+mrpClass).val(obj.price);
						//	$('.'+priceClass).val(obj.price);
							$('.'+costClass).val(obj.supplier_price);
							$('.'+cgstClass).val(obj.cgst_per);
							$('.'+sgstClass).val(obj.sgst_per);
						//	$('.'+cgstClass).val(obj.tax);
                        //  $('.'+sgstClass).val(obj.sgst);
					//		$('.'+total_tax_price).val(parseFloat(obj.tax) + parseFloat(obj.sgst));
					        $('.'+total_quantity).val(obj.quantity);
							$('.'+product_purchash_detail_id).val(obj.prid);
						
							quantity_calculate(cName);
							
						} 
					});
				
				$(this).unbind("change");
				return false;
			}
		});
		$( ".productSelection" ).focus(function(){
			$(this).change(APchange);
		
		});
    }