<!-- Product Purchase js -->
<script src="<?php echo base_url()?>my-assets/js/admin_js/json/product_purchase.js.php" ></script>
<!-- Purchase js -->
<script src="<?php echo base_url()?>my-assets/js/admin_js/purchase.js" type="text/javascript"></script>

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script> 
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.min.js"></script>
<link rel="stylesheet" type="text/css" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" />
<script type="text/javascript"> 
 $(document).ready(function(){          
      var supplier_id=$('#supplier_sss').val(); 
     
 $("#product_name").autocomplete({    
        
        source:base_url+'Cinvoice/retrieve_product_data2/'.supplier_id, 
        minLength:1       
   }); 
 });        
</script>

<!-- Add New Purchase Start -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1><?php echo display('add_purchase') ?></h1>
            <small><?php echo display('add_new_purchase') ?></small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
                <li><a href="#"><?php echo display('purchase') ?></a></li>
                <li class="active"><?php echo display('add_purchase') ?></li>
            </ol>
        </div>
    </section>

    <section class="content">
        <!-- Alert Message -->
        <?php
            $message = $this->session->userdata('message');
            if (isset($message)) {
        ?>
        <div class="alert alert-info alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('message');
            }
            $error_message = $this->session->userdata('error_message');
            if (isset($error_message)) {
        ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $error_message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('error_message');
            }
        ?>

        <!-- Purchase report -->
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4><?php echo display('add_purchase') ?></h4>
                        </div>
                    </div>

                    <div class="panel-body">
                    <?php echo form_open_multipart('Cpurchase/insert_purchase')?>
                        

                        <div class="row">
                            <div class="col-sm-6">
                               <div class="form-group row">
                                    <label for="supplier_sss" class="col-sm-3 col-form-label"><?php echo display('supplier') ?>
                                        
                                    </label>
                                    <div class="col-sm-6">
                                        <!-- js-example-basic-single -->
                                        <select name="supplier_id" id="supplier_sss" class="form-control "> 
                                            <option value=""><?php echo display('select_one') ?></option>
                                            {all_supplier}
                                            <option value="{supplier_id}">{supplier_name}</option>
                                            {/all_supplier}
                                        </select>
                                    </div>
                                    <div class="col-sm-3">
                                        <a href="<?php echo base_url('Csupplier'); ?>"><?php echo display('add_supplier') ?></a>
                                    </div>
                                </div> 
                            </div>

                             <div class="col-sm-6">
                                <div class="form-group row">
                                    <label for="date" class="col-sm-4 col-form-label"><?php echo display('purchase_date') ?>
                                        <i class="text-danger">*</i>
                                    </label>
                                    <div class="col-sm-8">
                                        <?php $date = date('Y-m-d'); ?>
                                        <input type="text" tabindex="3" class="form-control datepicker" name="purchase_date" value="<?php echo $date; ?>" id="date" required />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group row">
                                    <label for="invoice_no" class="col-sm-3 col-form-label"><?php echo display('invoice_no') ?>
                                       
                                    </label>
                                    <div class="col-sm-9">
                                        <input type="text" tabindex="3" class="form-control" name="chalan_no" placeholder="<?php echo display('invoice_no') ?>" id="invoice_no" />
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-6">
                               <div class="form-group row">
                                    <label for="adress" class="col-sm-4 col-form-label"><?php echo display('details') ?>
                                    </label>
                                    <div class="col-sm-8">
                                        <textarea class="form-control" tabindex="1" id="adress" name="purchase_details" placeholder=" <?php echo display('details') ?>" rows="1"></textarea>
                                    </div>
                                </div> 
                            </div>
                        </div>
						
						
						   <div class="row">
                           			  <div class="col-sm-6">
                               <div class="form-group row">
                                    <label for="image" class="col-sm-4 col-form-label"><?php echo display('image') ?> </label>
                                    <div class="col-sm-8">
                                        <input type="file" name="invoice_image" class="form-control" id="invoice_image">
                                    </div>
                                </div> 
                            </div>
							</div>
							
							<div class="row">
                       			  <div class="col-sm-6"><a href="<?php echo base_url('Cproduct'); ?>">Add Product</a></div> 
                            </div>

                      
						
				
	
                        <div class="table-responsive" style="margin-top: 10px">
                            <table class="table table-bordered table-hover" id="purchaseTable">
                                <thead>
                                    <tr>
                                        <th class="text-center"><?php echo display('item_information') ?></th>
										 <th class="text-center"><?php echo 'Batch No' ?> </th>
										  <th class="text-center"><?php echo ' ExpireDate ' ?>  <i class="text-danger">*</i></th>
                                        <th class="text-center"><?php echo display('quantity') ?> </th>
										<th class="text-center"><?php echo 'Free' ?> </th>
										<th class="text-center"><?php echo 'CGST(%)' ?> </th>
										<th class="text-center"><?php echo 'SGST(%)' ?> </th>
                                        <th class="text-center"><?php echo 'Cost Price' ?></th>
                                        <th class="text-center"><?php echo display('total') ?></th>
                                        <th class="text-center"><?php echo display('action') ?></th>
                                    </tr>
                                </thead>
                                <tbody id="addPurchaseItem">
                                    <tr>
                                        <td class="span3 supplier">
                                            <input type="text" name="product_name"  class="form-control productSelection" placeholder='<?php echo 'Product Code' ?>' required="" id="product_name" >
                                            <input type="hidden" class="autocomplete_hidden_value product_id_1" name="product_id[]" id="SchoolHiddenId"/>                       <input type="hidden" class="baseUrl" value="<?php echo base_url();?>" />
							
			
                                        </td>
										 <td class="text-right">
                                            <input type="text" name="batch_no[]" id="batch_no_1"  class="form-control text-right" placeholder="<?php echo 'Batch No' ?>"  />
                                        </td>
									    <td class="text-right">
                                            <input type="text" name="expire_date[]" id="expire_date_1"  class="form-control text-right datepicker" placeholder="DD/MM/YYYY"  />                  </td>
                                        <td class="text-right">
                                            <input type="text" name="product_quantity[]" id="total_qntt_1"  onchange="quantity_calculate(1)" class="form-control text-right" placeholder="<?php echo display('quantity') ?>" min="0" required />
                                        </td>
										<td class="text-right">
                                            <input type="text" name="product_free[]" id="total_freeqntt_1"  onchange="quantity_calculate(1)" class="form-control text-right" placeholder="<?php echo 'Free' ?>"  />  </td>
                                     
										<td>
                                            <input type="text" name="product_cgst[]"  id="cgst_1" class="text-right form-control" placeholder="CGST"  />
                                        </td>
										<td>
                                             <input type="text" name="product_sgst[]"  id="sgst_1" class="text-right form-control" placeholder="SGST"  />
                                        </td>
										   <td>
                                           <input type="text" name="product_rate[]"  id="price_item1" class="text-right form-control" placeholder="<?php echo display('rate') ?>" required />                 </td>
                                        <td class="text-right">
                                            <input class="text-right form-control" type="text" name="total_price[]" id="total_price_1" value="0.00" tabindex="-1"  />                  </td>
                                        <td>
                                            <button style="text-align: right;" class="btn btn-danger" type="button" value="Delete" onclick="deleteRow(this)">Delete</button>
                                        </td>
                                    </tr>
                                </tbody>
                                <tfoot>
                                    <tr>
									<td></td>
                                    <td><input type="button" id="add-invoice-item" class="btn btn-info" name="add-invoice-item"  onClick="addPurchaseInputField('addPurchaseItem');" value="<?php echo display('add_new_item') ?>" /></td>
                                    <td><input type="hidden" name="baseUrl" class="baseUrl" value="<?php echo base_url();?>"/></td>
                                    <td style="text-align:right;" colspan="5"><b><?php echo display('grand_total') ?>:</b></td>
                                    <td class="text-right"><input type="text" id="grandTotal"  class="text-right form-control" name="grand_total_price" required tabindex="-1" value="0.00"  /></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>

                        <div class="form-group row">
                            <div class="col-sm-6">
                                <input type="submit" id="add-purchase" class="btn btn-primary btn-large" name="add-purchase" value="<?php echo display('submit') ?>" />
                                <input type="submit" value="<?php echo display('submit_and_add_another') ?>" name="add-purchase-another" class="btn btn-large btn-success" id="add-purchase-another">
                            </div>
                        </div>
                    <?php echo form_close()?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<!-- Purchase Report End -->

<!-- JS -->
<script type="text/javascript">

   function quantity_calculate(t) {
    var a = $("#total_qntt_" + t).val(),
        e = $("#price_item_" + t).val(),
        o = $("#discount_" + t).val(),
        l = $("#total_tax_" + t).val();
    if (a > 0) {
        var n = a * e;
        $("#total_price_" + t).val(n);
        var c = a * l;
        $("#all_tax_" + t).val(c)
    } else {
        var n = a * e;
        $("#total_price_" + t).val(n), $("#all_tax_" + t).val(l)
    }
    if (o > 0) {
        var n = a * e - o;
        $("#total_price_" + t).val(n), $("#total_tax_" + t).val(l)
    } else if (0 > o) {
        var n = a * e;
        $("#total_price_" + t).val(n), $("#total_tax_" + t).val(l)
    }
    calculateSum()
}

function calculateSum() {
    var t = 0,
        a = 0,
        e = 0,
        o = 0;
    $(".total_tax").each(function() {
        isNaN(this.value) || 0 == this.value.length || (a += parseFloat(this.value))
    }), $("#total_tax_ammount").val(a.toFixed(0)), $(".total_price").each(function() {
        isNaN(this.value) || 0 == this.value.length || (t += parseFloat(this.value))
    }), o = a.toFixed(0), e = t.toFixed(0), $("#grandTotal").val(+o + +e)
}

    //Product select by ajax start
    $('body').on('change','#supplier_sss',function(event){
        event.preventDefault(); 
        var supplier_id=$('#supplier_sss').val();
        var csrf_test_name=  $("[name=csrf_test_name]").val();
        $.ajax({
            url: '<?php echo base_url('Cpurchase/product_search_by_supplier')?>',
            type: 'post',
            data: {supplier_id:supplier_id,csrf_test_name:csrf_test_name}, 
            success: function (msg){
                $(".supplier").html(msg);
            },
            error: function (xhr, desc, err){
                 alert('failed');
            }
        });        
    });
    //Product select by ajax end

    //Product selection start
    $('body').on('change', '.productSelection', function(){
        var product_id = $(this).val();  
        var supplier_id=$('#supplier_sss').val(); 
        var base_url = $('.baseUrl').val(); 
        var target = $(this).parent().next().next().next().next().next().next().next().children();
        var csrf_test_name=  $("[name=csrf_test_name]").val();
        
        $.ajax
        ({
            url: base_url+"Cinvoice/retrieve_product_data",
            data: {product_id:product_id,csrf_test_name:csrf_test_name},
            type: "post",
            success: function(data)
            { 
               obj = JSON.parse(data);
			   
			  var obj = jQuery.parseJSON(data);
		       target.val(obj.supplier_price);    
            } 
        });
    });
    //Product selection end
</script>


