<!-- Product Purchase js -->
<script src="<?php echo base_url()?>my-assets/js/admin_js/json/product_purchase.js.php" ></script>
<!-- Purchase js -->
<script src="<?php echo base_url()?>my-assets/js/admin_js/purchase.js" type="text/javascript"></script>
<!-- Add New Purchase Start -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1><?php echo 'Add Purchase Return' ?></h1>
            <small><?php echo 'Add Purchase Return' ?></small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
                <li><a href="#"><?php echo display('purchase') ?></a></li>
                <li class="active"><?php echo 'Add Purchase Return' ?></li>
            </ol>
        </div>
    </section>

    <section class="content">
        <!-- Alert Message -->
        <?php
            $message = $this->session->userdata('message');
            if (isset($message)) {
        ?>
        <div class="alert alert-info alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('message');
            }
            $error_message = $this->session->userdata('error_message');
            if (isset($error_message)) {
        ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $error_message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('error_message');
            }
        ?>

        <!-- Purchase report -->
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4><?php echo 'Add Purchase Return' ?></h4>
                        </div>
                    </div>

                    <div class="panel-body">
                    <?php echo form_open_multipart('Cpurchase/insert_purchase_return')?>
                        

                        <div class="row">
                            <div class="col-sm-6">
                               <div class="form-group row">
                                    <label for="supplier_sss" class="col-sm-3 col-form-label"><?php echo display('supplier') ?> <i class="text-danger">*</i>
                                        
                                    </label>
                                    <div class="col-sm-6">
                                        <!-- js-example-basic-single -->
                                        <select name="supplier_id" id="supplier_sss" class="form-control" required > 
                                            <option value=""><?php echo display('select_one') ?></option>
                                            {all_supplier}
                                            <option value="{supplier_id}">{supplier_name}</option>
                                            {/all_supplier}
                                        </select>
                                    </div>
                             
                                </div> 
                            </div>

                             <div class="col-sm-6">
                                <div class="form-group row">
                                   
                                </div>
                            </div>
                        </div>	
                        <div class="table-responsive" style="margin-top: 10px">
                            <table class="table table-bordered table-hover" id="purchaseTable">
                                <thead>
                                    <tr>
                                        <th class="text-center"><?php echo display('item_information') ?></th>
										
                                        <th class="text-center"><?php echo display('quantity') ?> </th>
										
                                        <th class="text-center"><?php echo display('rate') ?></th>
                                        <th class="text-center"><?php echo display('total') ?></th>
                                       
                                    </tr>
                                </thead>
                                <tbody id="addPurchaseItem">
                                    <tr>
                                        <td class="span3 supplier">
                                           <select name="product_id[]"  class="productSelection js-example-basic-single form-control" id="product_id">
										<option value=" "><?php echo display('select_one') ?></option>
										{all_products}
										<option value="{product_id}">{product_name}</option>
										{/all_products}
										</select>
                                        </td>
										
									
                                        <td class="text-right">
                                            <input type="text" name="product_quantity[]" id="total_qntt_1"  onchange="quantity_calculate(1)" class="form-control text-right" placeholder="<?php echo display('quantity') ?>" min="0" required />
                                        </td>
										
                                        <td>
                                            <input type="text" name="product_rate[]"  id="price_item_1" class="price_item1 text-right form-control" placeholder="<?php echo display('rate') ?>" required />
                                        </td>
                                        <td class="text-right">
                                            <input class="total_price text-right form-control" type="text" name="total_price[]" id="total_price_1" value="0.00" tabindex="-1" readonly="readonly" />
                                        </td>
                                      
                                    </tr>
                                </tbody>
                                <tfoot>
                                    <tr>
								
                                        <td>
                                           
                                        </td>
                                        <td>
                                            <input type="hidden" name="baseUrl" class="baseUrl" value="<?php echo base_url();?>"/>
                                        </td>
                                        <td style="text-align:right;" ><b><?php echo display('grand_total') ?>:</b></td>
                                        <td class="text-right">
                                            <input type="text" id="grandTotal"  class="text-right form-control" name="grand_total_price" tabindex="-1" value="0.00" readonly="readonly" />
                                        </td>
                                    </tr>
                                    <tr>
								
                                        <td>
                                           
                                        </td>
                                        <td>
                                           
                                        </td>
                                        <td style="text-align:right;" ><b><?php echo 'Return Reason' ?>:</b></td>
                                        <td class="text-right">
                                             <select class="form-control" name="return_reason" id="return_reason" required>
															   <option value="">Select Return Reason</option>
                                                                <option value="Return Due to Expiry">Return Due to Expiry</option>
                                                                <option value="Due to Not Moving">Due to Not Moving</option>
																<option value="Other">Others</option>                                                     
                                                            </select>
                                        </td>
                                    </tr>
									
                                </tfoot>
                            </table>
                        </div>

                        <div class="form-group row">
                            <div class="col-sm-6">
                                <input type="submit" id="add-purchase" class="btn btn-primary btn-large" name="add-return-purchase" value="<?php echo display('submit') ?>" />
                              
                            </div>
                        </div>
                    <?php echo form_close()?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<!-- Purchase Report End -->

<!-- JS -->
<script type="text/javascript">

   function quantity_calculate(t) {
    var a = $("#total_qntt_" + t).val(),
        e = $("#price_item_" + t).val(),
        o = $("#discount_" + t).val(),
        l = $("#total_tax_" + t).val();
    if (a > 0) {
        var n = a * e;
        $("#total_price_" + t).val(n);
        var c = a * l;
        $("#all_tax_" + t).val(c)
    } else {
        var n = a * e;
        $("#total_price_" + t).val(n), $("#all_tax_" + t).val(l)
    }
    if (o > 0) {
        var n = a * e - o;
        $("#total_price_" + t).val(n), $("#total_tax_" + t).val(l)
    } else if (0 > o) {
        var n = a * e;
        $("#total_price_" + t).val(n), $("#total_tax_" + t).val(l)
    }
    calculateSum()
}

function calculateSum() {
    var t = 0,
        a = 0,
        e = 0,
        o = 0;
    $(".total_tax").each(function() {
        isNaN(this.value) || 0 == this.value.length || (a += parseFloat(this.value))
    }), $("#total_tax_ammount").val(a.toFixed(0)), $(".total_price").each(function() {
        isNaN(this.value) || 0 == this.value.length || (t += parseFloat(this.value))
    }), o = a.toFixed(0), e = t.toFixed(0), $("#grandTotal").val(+o + +e)
}

    //Product select by ajax start
    $('body').on('change','#supplier_sss',function(event){
        event.preventDefault(); 
        var supplier_id=$('#supplier_sss').val();
        var csrf_test_name=  $("[name=csrf_test_name]").val();
        $.ajax({
            url: '<?php echo base_url('Cpurchase/purchase_product_search_by_supplier')?>',
            type: 'post',
            data: {supplier_id:supplier_id,csrf_test_name:csrf_test_name}, 
            success: function (msg){
                $("#addPurchaseItem").html(msg);
            },
            error: function (xhr, desc, err){
                 alert('failed');
            }
        });        
    });
    //Product select by ajax end

    //Product selection start
    $('body').on('change', '.productSelection', function(){
        var product_id = $(this).val();  
        var base_url = $('.baseUrl').val(); 
        var target = $(this).parent().parent().children().next().next().children();
        var csrf_test_name=  $("[name=csrf_test_name]").val();
        $.ajax
        ({
            url: base_url+"Cinvoice/retrieve_product_data",
            data: {product_id:product_id,csrf_test_name:csrf_test_name},
            type: "post",
            success: function(data)
            { 
               obj = JSON.parse(data);
			   
			  var obj = jQuery.parseJSON(data);
						
			   
               target.val(obj.supplier_price);    
            } 
        });
    });
    //Product selection end
</script>


