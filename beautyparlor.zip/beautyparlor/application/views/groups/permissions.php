<!-- Bank List Start -->
<div class="content-wrapper">
	<section class="content-header">
	    <div class="header-icon">
	        <i class="pe-7s-note2"></i>
	    </div>
	    <div class="header-title">
	        <h1><?php echo 'Group Permissions'; ?></h1>
	        <small><?php echo 'Please set group permissions below'; ?></small>
	        <ol class="breadcrumb">
	            <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
	            <li><a href="#"><?php echo 'Groups'; ?></a></li>
	            <li class="active"><?php echo 'Group Permissions'; ?></li>
	        </ol>
	    </div>
	</section>

	<section class="content">

		<!-- Alert Message -->
	    <?php
	        $message = $this->session->userdata('message');
	        if (isset($message)) {
	    ?>
	    <div class="alert alert-info alert-dismissable">
	        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	        <?php echo $message ?>                    
	    </div>
	    <?php 
	        $this->session->unset_userdata('message');
	        }
	        $error_message = $this->session->userdata('error_message');
	        if (isset($error_message)) {
	    ?>
	    <div class="alert alert-danger alert-dismissable">
	        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	        <?php echo $error_message ?>                    
	    </div>
	    <?php 
	        $this->session->unset_userdata('error_message');
	        }
	    ?>

		<!-- Bank List -->
		<div class="row">
		    <div class="col-sm-12">
		        <div class="panel panel-bd lobidrag">
		            <div class="panel-heading">
		                <div class="panel-title">
		                    <h4><?php echo 'Group Permissions'; ?> </h4>
		                </div>
		            </div>
					 <?php echo form_open_multipart('Cgroups/create_permissions/',array('class' => 'form-vertical','id' => 'insert_deposit' ))?>

                               <input type="hidden" name="id" value="{id}"/>
		            <div class="panel-body">
		                <div class="table-responsive">
                                    <table class="table table-bordered table-hover table-striped">

                                <thead>
                              
                                <tr>
                                    <th rowspan="2" class="text-center">Module Name </th>
                                    <th colspan="5" class="text-center">Permissions</th>
                                </tr>
                                <tr>
                                    <th class="text-center">View</th>
                                    <th class="text-center">Add</th>
                                    <th class="text-center">Edit</th>
                                    <th class="text-center">Delete</th>
                                    
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>Invoice</td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="invoice-index" <?php echo $p[0]['invoice-index'] ? "checked" : ''; ?> >
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="invoice-add" <?php echo $p[0]['invoice-add'] ? "checked" : ''; ?>>
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="invoice-edit" <?php echo $p[0]['invoice-edit'] ? "checked" : ''; ?>>
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="invoice-delete" <?php echo $p[0]['invoice-delete'] ? "checked" : ''; ?>>
                                    </td>
                                  
                                </tr>

                                <tr>
                                    <td>Advanced Invoice</td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="advancedinvoice-index" <?php echo $p[0]['advancedinvoice-index'] ? "checked" : ''; ?>>
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="advancedinvoice-add" <?php echo $p[0]['advancedinvoice-add'] ? "checked" : ''; ?> >
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="advancedinvoice-edit" <?php echo $p[0]['advancedinvoice-edit'] ? "checked" : ''; ?> >
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="advancedinvoice-delete"  <?php echo $p[0]['advancedinvoice-delete'] ? "checked" : ''; ?>>
                                    </td>
                                  
                                </tr>

                                <tr>
                                    <td>Products</td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="product-index" <?php echo $p[0]['product-index'] ? "checked" : ''; ?>>
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="product-add" <?php echo $p[0]['product-add'] ? "checked" : ''; ?> >
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="product-edit" <?php echo $p[0]['product-edit'] ? "checked" : ''; ?>>
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="product-delete" <?php echo $p[0]['product-delete'] ? "checked" : ''; ?>>
                                    </td>
                                   
                                </tr>
                               
                                <tr>
                                    <td>Customer</td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="customer-index" <?php echo $p[0]['customer-index'] ? "checked" : ''; ?>>
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="customer-add" <?php echo $p[0]['customer-add'] ? "checked" : ''; ?>>
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="customer-edit" <?php echo $p[0]['customer-edit'] ? "checked" : ''; ?>>
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="customer-delete" <?php echo $p[0]['customer-delete'] ? "checked" : ''; ?>>
                                    </td>
                                  
                                </tr>

                                <tr>
                                    <td>Category</td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="category-index" <?php echo $p[0]['category-index'] ? "checked" : ''; ?>>
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="category-add" <?php echo $p[0]['category-add'] ? "checked" : ''; ?>>
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="category-edit" <?php echo $p[0]['category-edit'] ? "checked" : ''; ?>>
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="category-delete" <?php echo $p[0]['category-delete'] ? "checked" : ''; ?>>
                                    </td>
                                    </td>
                                   
                                </tr>

                                <tr>
                                    <td>Supplier</td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="supplier-index" <?php echo $p[0]['supplier-index'] ? "checked" : ''; ?>>
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="supplier-add" <?php echo $p[0]['supplier-add'] ? "checked" : ''; ?>>
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="supplier-edit" <?php echo $p[0]['supplier-edit'] ? "checked" : ''; ?>>
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="supplier-delete" <?php echo $p[0]['supplier-delete'] ? "checked" : ''; ?>>
                                    </td>
                                    
                                </tr>

                                <tr>
                                    <td>Purchase</td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="purchase-index" <?php echo $p[0]['purchase-index'] ? "checked" : ''; ?>>
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="purchase-add" <?php echo $p[0]['purchase-add'] ? "checked" : ''; ?>>
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="purchase-edit" <?php echo $p[0]['purchase-edit'] ? "checked" : ''; ?>>
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="purchase-delete" <?php echo $p[0]['purchase-delete'] ? "checked" : ''; ?>>
                                    </td>
                                    
                                </tr>

                                <tr>
                                    <td>Search</td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="search-customer" <?php echo $p[0]['search-customer'] ? "checked" : ''; ?> >
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="search-invoice" <?php echo $p[0]['search-invoice'] ? "checked" : ''; ?> >
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="search-purchase"  <?php echo $p[0]['search-purchase'] ? "checked" : ''; ?> >
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="stock-report" <?php echo $p[0]['stock-report'] ? "checked" : ''; ?> >
                                    </td>
                                   
                                </tr>
								<tr>
                                    <td>Accounts</td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="accounts-index" <?php echo $p[0]['accounts-index'] ? "checked" : ''; ?> >
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="accounts-add" <?php echo $p[0]['accounts-add'] ? "checked" : ''; ?> >
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="accounts-edit" <?php echo $p[0]['accounts-edit'] ? "checked" : ''; ?> >
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="accounts-delete" <?php echo $p[0]['accounts-delete'] ? "checked" : ''; ?> >
                                    </td>
                                   
                                </tr>
								<tr>
                                    <td>Tax</td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="accounts-tax-index" <?php echo $p[0]['accounts-tax-index'] ? "checked" : ''; ?> >
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="accounts-tax-add" <?php echo $p[0]['accounts-tax-add'] ? "checked" : ''; ?> >
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="accounts-tax-edit" <?php echo $p[0]['accounts-tax-edit'] ? "checked" : ''; ?> >
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="accounts-tax-delete" <?php echo $p[0]['accounts-tax-delete'] ? "checked" : ''; ?> >
                                    </td>
                                   
                                </tr>
								<tr>
                                    <td>Bank</td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="bank-index" <?php echo $p[0]['bank-index'] ? "checked" : ''; ?> >
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="bank-add" <?php echo $p[0]['bank-add'] ? "checked" : ''; ?> >
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="bank-edit" <?php echo $p[0]['bank-edit'] ? "checked" : ''; ?> >
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" value="1" class="checkbox" name="bank-delete" <?php echo $p[0]['bank-delete'] ? "checked" : ''; ?> >
                                    </td>
                                   
                                </tr>
								

                                <tr>
                                    <td>Reports</td>
                                    <td colspan="4"><table class="table table-bordered table-hover table-striped"><tr>
									    <td>
                                        <span style="inline-block">
                                            <input type="checkbox" value="1" class="checkbox" id="reports-index" name="reports-index" <?php echo $p[0]['reports-index'] ? "checked" : ''; ?> >
                                            <label for="product_quantity_alerts" class="padding05">Today Reports</label>
                                        </span></td><td>
                                        <span style="inline-block">
                                            <input type="checkbox" value="1" class="checkbox" id="reports-sales" name="reports-expiry_alerts" <?php echo $p[0]['reports-sales'] ? "checked" : ''; ?> >
                                            <label for="reports-sales" class="padding05">Sales Report</label>
                                        </span></td><td>
                                        <span style="inline-block">
                                            <input type="checkbox" value="1" class="checkbox" id="reports-purchase"
                                            name="reports-purchase" <?php echo $p[0]['reports-purchase'] ? "checked" : ''; ?>><label for="products" class="padding05">Purchase Report</label>
                                        </span></td><td>
                                        <span style="inline-block">
                                            <input type="checkbox" value="1" class="checkbox" id="reports-sales-product-wise" name="reports-sales-product-wise" <?php echo $p[0]['reports-sales-product-wise'] ? "checked" : ''; ?> >
                                            <label for="daily_sales" class="padding05">Sales Reports (Product Wise)</label>
                                        </span></td></tr><tr>
									   <td>
                                        <span style="inline-block">
                                            <input type="checkbox" value="1" class="checkbox" id="reports-profit" name="reports-profit" <?php echo $p[0]['reports-profit'] ? "checked" : ''; ?> >
                                            <label for="monthly_sales" class="padding05">Profit Report</label>
                                        </span></td><td></td><td></td><td></td></tr></table>
                                       
                                    </td>
                                </tr>
                               <tr>
                                    <td>Misc</td>
                                    <td colspan="4"><table class="table table-bordered table-hover table-striped"><tr>
									    <td>
                                        <span style="inline-block">
                                            <input type="checkbox" value="1" class="checkbox" id="pos-invoice" name="pos-invoice" <?php echo $p[0]['pos-invoice'] ? "checked" : ''; ?>>
                                            <label for="product_quantity_alerts" class="padding05">POS Invoice</label>
                                        </span></td><td>
                                        <span style="inline-block">
                                            <input type="checkbox" value="1" class="checkbox" id="customer-credit" name="customer-credit" <?php echo $p[0]['customer-credit'] ? "checked" : ''; ?>>
                                            <label for="Product_expiry_alerts" class="padding05">Customer Credit</label>
                                        </span></td><td>
                                        <span style="inline-block">
                                            <input type="checkbox" value="1" class="customer-paid" id="customer-paid"
                                            name="reports-products" <?php echo $p[0]['customer-paid'] ? "checked" : ''; ?>><label for="products" class="padding05">Customer Paid</label>
                                        </span></td><td>
                                        <span style="inline-block">
                                            <input type="checkbox" value="1" class="checkbox" id="search-customer" name="search-customer" <?php echo $p[0]['search-customer'] ? "checked" : ''; ?> >
                                            <label for="daily_sales" class="padding05">Search Customer</label>
                                        </span></td></tr><tr>
									   <td>
                                        <span style="inline-block">
                                            <input type="checkbox" value="1" class="checkbox" id="search-invoice" name="search-invoice" <?php echo $p[0]['search-invoice'] ? "checked" : ''; ?>>
                                            <label for="monthly_sales" class="padding05">Search Invoice</label>
                                        </span></td><td><span style="inline-block">
                                            <input type="checkbox" value="1" class="checkbox" id="search-purchase" name="search-purchase" <?php echo $p[0]['search-purchase'] ? "checked" : ''; ?>>
                                            <label for="monthly_sales" class="padding05">Search Purchase</label>
                                        </span></td><td><span style="inline-block">
                                            <input type="checkbox" value="1" class="checkbox" id="accounts-income" name="accounts-income" <?php echo $p[0]['accounts-income'] ? "checked" : ''; ?> >
                                            <label for="monthly_sales" class="padding05">Accounts Income</label>
                                        </span></td><td><span style="inline-block">
                                            <input type="checkbox" value="1" class="checkbox" id="accounts-expense" name="accounts-expense" <?php echo $p[0]['accounts-expense'] ? "checked" : ''; ?> >
                                            <label for="monthly_sales" class="padding05">Accounts Expense</label>
                                        </span></td></tr>
										
										<tr>
									   <td>
                                        <span style="inline-block">
                                            <input type="checkbox" value="1" class="checkbox" id="accounts-summery" name="accounts-summery" <?php echo $p[0]['accounts-summery'] ? "checked" : ''; ?> >
                                            <label for="monthly_sales" class="padding05">Accounts Summery</label>
                                        </span></td><td><span style="inline-block">
                                            <input type="checkbox" value="1" class="checkbox" id="accounts-cheque-manager" name="accounts-cheque-manager" <?php echo $p[0]['accounts-cheque-manager'] ? "checked" : ''; ?> >
                                            <label for="monthly_sales" class="padding05">Accounts Cheque Manager</label>
                                        </span></td><td><span style="inline-block">
                                            <input type="checkbox" value="1" class="checkbox" id="accounts-closing" name="accounts-closing" <?php echo $p[0]['accounts-closing'] ? "checked" : ''; ?> >
                                            <label for="monthly_sales" class="padding05">Accounts Closing</label>
                                        </span></td><td><span style="inline-block">
                                            <input type="checkbox" value="1" class="checkbox" id="accounts-closing-report" name="accounts-closing-report" <?php echo $p[0]['accounts-closing-report'] ? "checked" : ''; ?>>
                                            <label for="monthly_sales" class="padding05">Accounts Closing Report</label>
                                        </span></td></tr>
										</table>
                                       
                                    </td>
                                </tr>
                             
                             

                                </tbody>
                            </table>	
							          
		                </div>
						 <div class="form-group row">
                            <label for="example-text-input" class="col-sm-4 col-form-label"></label>
                            <div class="col-sm-6">
                                <input type="submit" id="add-permission" class="btn btn-success" name="add-permission" value="<?php echo display('save') ?>" />
                            </div>
                        </div>	        
		            </div>
					  <?php echo form_close()?>
		        </div>
		    </div>
		</div>
	</section>
</div>
<!-- Bank List End -->

