<!-- Add New Invoice Start -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1><?php echo 'Add Wholesale Inovice'; ?></h1>
            <small><?php echo 'Add Wholesale Inovice'; ?></small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo 'Home'; ?></a></li>
                <li><a href="#"><?php echo 'Wholesale Inovice'; ?></a></li>
                <li class="active"><?php echo 'Add Wholesale Inovice'; ?></li>
            </ol>
        </div>
    </section>

    <section class="content">
        <!--Add Invoice -->
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4><?php echo 'Add Wholesale Inovice' ?></h4>
                        </div>
                    </div>
                    <?php echo form_open_multipart('Cadvancedinvoice/insert_advancedinvoice',array('class' => 'form-vertical', 'id' => 'insert_advancedinvoice','name' => 'insert_advancedinvoice'))?>
                    <div class="panel-body">
                        <div class="table-responsive" style="margin-top: 10px">
                            <table class="table table-bordered table-hover" id="normalinvoice">
                                <thead>
                                    <tr>
                                        <th class="text-left" colspan="7"><?php echo 'RAJ PHARMA' ?></th>
                                    
                                        <th class="text-right" colspan="7"><?php echo 'Tax Invoice' ?></th>
                                    </tr>
                                    <tr>
                                        <th colspan="5" style="vertical-align: top;" valign="top">{company_info}
                                              <address style="margin-top:0px">
                                                  <strong>{company_name}</strong><br>
	                                               {address}<br>
	                                           </address>
	                                           {/company_info}</th>
                                        <th colspan="4" style="vertical-align: top;" valign="top"><div><?php echo 'Invoice No' ?>: {advancedinvoice_no}</div>
									                    <div>Inv <?php echo display('date') ?>: {final_date}</div></th>
                                        <th colspan="5" style="vertical-align: top;" valign="top"><address style="margin-top:10px">
                                            <strong>To, {customer_name} </strong><br>
                                            <abbr><?php echo display('address') ?>:</abbr>
                                            <?php if ($customer_address) { ?>{customer_address}
		                                    <?php } ?>
	                                        <br>
	                                        <abbr><?php echo display('mobile') ?>:</abbr>
	                                        <?php
		                                        if ($customer_mobile) {
		                                     ?>
	                                         {customer_mobile}
	                                        <?php
	                                        }if ($customer_email) {
	                                        ?>
	                                        <br>
	                                        <abbr><?php echo display('email') ?>:</abbr> 
	                                       {customer_email}
	                                   	<?php
	                               		}
	                                   ?>
	                                     {company_info}	                                
	                                <?php echo 'PAN No:' ?>: {pan_no} <?php echo 'GST No' ?>: {gst_no} <?php echo 'DL No' ?><br>20 GJ ADC 127332<br>21 GJ ADC 127333<br>
									20B GJ ADC 127334<br>21 GJ ADC 127335                             
                                   {/company_info}
	                                </address> 
	                               </th>
                                    </tr>
                                    <tr>
                                        <th rowspan="2" class="text-center"><?php echo 'Sr.' ?></th>
                                        <th rowspan="2" class="text-center"><?php echo 'Description of Goods' ?></th>
                                        <th rowspan="2" class="text-center"><?php echo 'Batch' ?></th>
                                        <th rowspan="2" class="text-center"><?php echo 'Exp' ?></th>
                                        <th rowspan="2" class="text-center"><?php echo 'MRP' ?></th>
                                        <th rowspan="2" class="text-center"><?php echo 'Qty/Fr' ?></th>
                                        <th rowspan="2" class="text-center"><?php echo 'PTR' ?></th>
                                        <th rowspan="2" class="text-center"><?php echo 'NetRate' ?> </th>
                                        <th rowspan="2" class="text-center"><?php echo 'Disc(%)' ?> </th>
                                        
                                        <th colspan="2" class="text-center">SGST</th>
                                        <th colspan="2" class="text-center">CGST</th>
                                        <th rowspan="2" class="text-center">Amount</th>
                                    </tr>
                                    <tr>
                                        <th  class="text-center" ><?php echo 'Rate' ?> </th>
                                        <th  class="text-center"><?php echo 'Value' ?> </th>
                                        <th  class="text-center" ><?php echo 'Rate' ?> </th>
                                        <th  class="text-center"><?php echo 'Value' ?> </th>
                                        </tr>
                                      
                                </thead>
                                <tbody id="addinvoiceItem">
                                    {advancedinvoice_all_data}
										<tr>
										     <td>{sl}</td> 
											 <td>{product_name}</td>
											 <td>{batch_no}</td>
											 <td>{expire_date}</td>
											 <td>{rate}</td>
											 <td>{quantity}/{free_qty}</td>
	                                         <td>{ptr}</td>
	                                         <td>{netrate}</td>
											 <td>{discount}</td>
										
											 <td>{cgst_per} </td>	
											 <td>{cgst}</td>
											 <td>{sgst_per} </td>	
											 <td>{sgst}</td>
	                                        <td><?php echo (($position==0)?"$currency {total_price}":"{total_price} $currency") ?></td>
	                                    </tr>
	                                    {/advancedinvoice_all_data}
                                </tbody>
                                <tfoot>
                                      <tr>
                                        <td></td>
										 <td></td>
										 <td></td>
										 <td></td>
										 <td></td>
										 <td></td>
										 <td></td>
										 <td></td>
										 <td></td>
										 <td></td>
										  <td>{total_cgst}</td>
										  <td></td>
										  	 <td>{total_sgst}</td>
										
                                        <td  class="text-right">
                                           {total_amount}
                                        </td>

                                    </tr>
									 
                                   
                                
								
									 
									</tfoot>
                            </table>
                        </div>
                    </div>
                    <?php echo form_close()?>
                </div>
            </div>
        </div>
    </section>
</div>
<!-- Invoice Report End -->