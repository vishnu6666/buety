<?php
    $CI =& get_instance();
    $CI->load->model('Web_settings');
    $Web_settings = $CI->Web_settings->retrieve_setting_editdata();
?>

<!-- Printable area start -->
<script type="text/javascript">
function printDiv(divName) {
    var printContents = document.getElementById(divName).innerHTML;
    var originalContents = document.body.innerHTML;
    document.body.innerHTML = printContents;
	// document.body.style.marginTop="-45px";
    window.print();
    document.body.innerHTML = originalContents;
}
</script>
<!-- Printable area end -->

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1>Tax <?php echo display('invoice_details') ?></h1>
            <small>Tax <?php echo display('invoice_details') ?></small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
                <li><a href="#"><?php echo display('invoice') ?></a></li>
                <li class="active">Tax <?php echo display('invoice_details') ?></li>
            </ol>
        </div>
    </section>
    <!-- Main content -->
    <section class="content">
        <!-- Alert Message -->
	    <?php
	        $message = $this->session->userdata('message');
	        if (isset($message)) {
	    ?>
	    <div class="alert alert-info alert-dismissable">
	        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	        <?php echo $message ?>                    
	    </div>
	    <?php 
	        $this->session->unset_userdata('message');
	        }
	        $error_message = $this->session->userdata('error_message');
	        if (isset($error_message)) {
	    ?>
	    <div class="alert alert-danger alert-dismissable">
	        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	        <?php echo $error_message ?>                    
	    </div>
	    <?php 
	        $this->session->unset_userdata('error_message');
	        }
	    ?>
        <!--Add Invoice -->
        <div class="row">
            <div class="col-sm-6">
                <div class="panel panel-bd lobidrag" style="width:440px;">
                   
                    <?php echo form_open_multipart('Cadvancedinvoice/insert_advancedinvoice',array('class' => 'form-vertical', 'id' => 'insert_advancedinvoice','name' => 'insert_advancedinvoice'))?>
                     <div id="printableArea">
                    <style>
	body
	{
		font-size: 8px;
		
	}
	hr {
    margin-top: 0px;
    margin-bottom: 0px;
   
}
	.table > tbody > tr > td, .table > tbody > tr > th, .table > tfoot > tr > td, .table > tfoot > tr > th, .table > thead > tr > td, .table > thead > tr > th {
    border-top: 1px solid #ddd;
    line-height: 1.42857;
    padding: 2px;
    vertical-align: top;
}
</style>
                    <div class="panel-body">
                        <div class="table-responsive" style="margin-top: 10px">
                            <table class="table table-bordered table-hover" id="normalinvoice">
                                <thead>
                                    <tr>
                                        <th class="text-left" colspan="5"><?php echo 'Priya Beautyparlor' ?></th>
                                    
                                        <th class="text-right" colspan="5"><?php echo 'Tax Invoice' ?></th>
                                    </tr>
                                    <tr>
                                        <th colspan="4" style="vertical-align: top;" valign="top">{company_info}
                                              <address style="margin-top:0px">
                                                  <strong>{company_name}</strong><br>
	                                               {address}<br>
	                                           </address>
	                                           <?php echo 'D.L. No:' ?> 20GJADC127332, 21GJADC127333<br>
	                                           <?php echo 'GST No' ?>: {gst_no} &nbsp;&nbsp;&nbsp;&nbsp;  <br><?php echo 'PAN No:' ?>: {pan_no}                        
                                               {/company_info}</th>
                                        <th  style="vertical-align: top;" valign="top"><div><?php echo 'Invoice No' ?>: {advancedinvoice_no}</div>
                                        <div><?php echo 'Mode' ?>: {payment_method}</div>
									                    <div>Inv <?php echo display('date') ?>: {final_date}</div></th>
                                        <th colspan="4" style="vertical-align: top;" valign="top"><address style="margin-top:10px">
                                            <strong>To, {customer_name} </strong><br>
                                            <abbr><?php echo display('address') ?>:</abbr>
                                            <?php if ($customer_address) { ?>{customer_address}
		                                    <?php } ?>
	                                        <br>
	                                        <abbr><?php echo display('mobile') ?>:</abbr>
	                                        <?php
		                                        if ($customer_mobile) {
		                                     ?>
	                                         {customer_mobile}
	                                        <?php
	                                        }if ($customer_email) {
	                                        ?>
	                                        <br>
	                                        <abbr><?php echo display('email') ?>:</abbr> 
	                                     
	                                       {customer_email}
	                                   	<?php
	                               		}
	                                   ?><br>
	                                     <?php echo 'D.L. No:' ?> {customer_drug_license}<br>
	                                     <?php echo 'GST No' ?>: {customer_gst_no} &nbsp;&nbsp;&nbsp;&nbsp; <br> <?php echo 'PAN No:' ?>{customer_pan_no} 
	                                </address> 
	                               </th>
                                    </tr>
                                    <tr>
                                        <th  class="text-center"><?php echo 'Sr.' ?></th>
                                        <th  class="text-center"><?php echo 'Description of Goods' ?></th>                                    
                                        <th  class="text-center"><?php echo 'Qty' ?></th>
                                        <th  class="text-center"><?php echo 'Rate' ?></th>                                        
                                        <th  class="text-center"><?php echo 'Disc(%)' ?></th>                                      
                                        <th  class="text-center">SGST</th>
                                        <th  class="text-center">CGST</th>
                                        <th  class="text-center">Amount</th>
                                    </tr>
                                   
                                      
                                </thead>
                                <tbody id="addinvoiceItem">
                                    {advancedinvoice_all_data}
										<tr>
										     <td>{sl}</td> 
											 <td>{product_name}</td>
											 <td>{quantity}</td>
											 <td>{rate}</td>                                  
											 <td>{discount}</td>									
											
											 <td>{cgst}</td>											 
											 <td>{sgst}</td>
	                                        <td><?php echo (($position==0)?"$currency {total_price}":"{total_price} $currency") ?></td>
	                                    </tr>
	                                    {/advancedinvoice_all_data}
	                                    <tr>
	                                         <td>&nbsp;</td>
										 <td></td>
										 <td></td>
										 <td></td>
										 <td></td>
										 	 <td></td>
										 <td></td>
										 <td></td>
										 
									
	                                    </tr>
                                </tbody>
                                <tfoot>
                                      <tr>
                                     
										 <td></td>
										 <td></td>
										 <td></td>
										 
										  <td>{tot_taxable}</td>
<td></td>
										  <td>{total_cgst}</td>
										  	 <td>{total_sgst}</td>
										
                                        <td  class="text-right">
                                           {total_amount}
                                        </td>

                                    </tr>
                                    <tr>
                                       
										 <td></td>
										 <td></td>
										 <td></td>
										 <td></td>
										  <td></td>

									
										  	 <td colspan="2"><strong>Net Amount</strong></td>
										
                                        <td  class="text-right">
                                           {total_amount}
                                        </td>

                                    </tr>
									 
                                   
                                
								
									 
									</tfoot>
                            </table>
                            
                             <div  style="float:right;margin-top: 20px;font-weight: bold;">
											For, Priya Beautyparlor
										</div>
                        </div>
                    </div>
                    </div>
                    <?php echo form_close()?>
                     <div class="panel-footer text-left">
                     	<a  class="btn btn-danger" href="<?php echo base_url('Cinvoice');?>"><?php echo display('cancel') ?></a>
						<a  class="btn btn-info" href="#" onclick="printDiv('printableArea')"><span class="fa fa-print"></span></a>
						
                    </div>
                </div>
            </div>
        </div>
    </section> <!-- /.content -->
</div> <!-- /.content-wrapper -->



