<!-- Customer js php -->
<script src="<?php echo base_url()?>my-assets/js/admin_js/json/customer.js.php" ></script>
<!-- Product invoice js -->
<script src="<?php echo base_url()?>my-assets/js/admin_js/json/product_invoice.js.php" ></script>
<!-- Invoice js -->
<script src="<?php echo base_url()?>my-assets/js/admin_js/invoice.js" type="text/javascript"></script>

<!-- Add new invoice start -->
<style>
	#bank_info_hide
	{
		display:none;
	}
    #payment_from_2
    {
        display:none;
    }
</style>

<!-- Customer type change by javascript start -->
<script type="text/javascript">
	function bank_info_show(payment_type)
	{
	    if(payment_type.value=="1"){
	        document.getElementById("bank_info_hide").style.display="none";
	    }
	    else{ 
	        document.getElementById("bank_info_hide").style.display="block";  
	    }
	}
    //Customer old/new    
    function active_customer(status)
    {
	    if(status=="payment_from_2"){
	        document.getElementById("payment_from_2").style.display="none";
	        document.getElementById("payment_from_1").style.display="block";
	        document.getElementById("myRadioButton_2").checked = false;
	        document.getElementById("myRadioButton_1").checked = true;
	    }
	    else{
	        document.getElementById("payment_from_1").style.display="none";
	        document.getElementById("payment_from_2").style.display="block";
	        document.getElementById("myRadioButton_2").checked = false;
	        document.getElementById("myRadioButton_1").checked = true;
	    }
    }
    //Payment method toggle 
    $(document).ready(function(){
        $(".payment_button").click(function(){
            $(".payment_method").toggle();
        });
    });
</script>
<!-- Customer type change by javascript end -->

<!-- Add New Invoice Start -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1><?php echo 'Edit Tax Inovice'; ?></h1>
            <small><?php echo 'Edit Tax Inovice'; ?></small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo 'Home'; ?></a></li>
                <li><a href="#"><?php echo 'Tax Inovice'; ?></a></li>
                <li class="active"><?php echo 'Edit Tax Inovice'; ?></li>
            </ol>
        </div>
    </section>

    <section class="content">
        <!-- Alert Message -->
        <?php
            $message = $this->session->userdata('message');
            if (isset($message)) {
        ?>
        <div class="alert alert-info alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('message');
            }
            $error_message = $this->session->userdata('error_message');
            if (isset($error_message)) {
        ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $error_message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('error_message');
            }
        ?>
        <!--Add Invoice -->
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4><?php echo 'Edit Tax Inovice' ?></h4>
                        </div>
                    </div>
                    <?php echo form_open_multipart('Cadvancedinvoice/update_advancedinvoice',array('class' => 'form-vertical', 'id' => 'insert_advancedinvoice','name' => 'insert_advancedinvoice'))?>
                    <div class="panel-body">
                      <div class="row">
                        	<div class="col-sm-6">
                                <div class="form-group row">
                                    <label for="date" class="col-sm-4 col-form-label"><?php echo display('date') ?> <i class="text-danger">*</i></label>
                                    <div class="col-sm-8">
                                       <?php date_default_timezone_set("Asia/Dhaka"); $date = date('Y-m-d'); ?>
                                        <input class="form-control datepicker" type="text" size="50" name="advancedinvoice_date" id="date" required  value="{date}" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">

                            <div class="col-sm-8" >
                               <div class="form-group row">
                                    <label for="customer_name_others" class="col-sm-3 col-form-label"><?php echo display('payee_name') ?> <i class="text-danger">*</i></label>
                                    <div class="col-sm-6">
                                       <input  autofill="off" type="text"  size="100" name="customer_name_others" placeholder='<?php echo display('payee_name') ?>' id="customer_name_others" value="{customer_name}"  class="form-control" />
                                       <input   type="hidden"  name="customer_id" id="customer_id" value="{customer_id}"  />
                                    </div>

                                    <div  class="col-sm-3">
                                
                                    </div>
                                </div>

                                
                            </div>
                        </div>

                       
                       

                        <div class="table-responsive" style="margin-top: 10px">
                            <table class="table table-bordered table-hover" id="normalinvoice">
                                <thead>
                                    <tr>
                                        <th class="text-center"><?php echo 'Item Name' ?> <i class="text-danger">*</i></th>
					<th class="text-center"><?php echo display('quantity') ?> <i class="text-danger">*</i></th>
                                        <th class="text-center"><?php echo 'Price' ?> <i class="text-danger">*</i></th>
                                        <th class="text-center"><?php echo display('discount') ?> </th>
                                        <th class="text-center"><?php echo display('total') ?> <i class="text-danger">*</i></th>
                                        <th class="text-center"><?php echo display('action') ?></th>
                                    </tr>
                                </thead>
                                <tbody id="addinvoiceItem">
				       {advancedinvoice_all_data}
                                    <tr>
                                        <td>
                                            <input   type="hidden"  name="advancedinvoice_details_id[]" id="advancedinvoice_details_id" value="{advancedinvoice_details_id}"  />
                                            <input type="text" name="product_name" onkeypress="invoice_productList({sl});" value="{product_name}"  class="form-control productSelection" placeholder='<?php echo 'Item Name' ?>' required="" id="product_name" >
                                           <input type="hidden" class="product_id_{sl} autocomplete_hidden_value" name="product_id[]" value="{product_id}" id="SchoolHiddenId"/>     <input type="hidden" name="advancedinvoice_id" id="advancedinvoice_id" value="{advancedinvoice_id}"/>            
                                        </td>
									
                                        <td width="150">
                                           <input type="text" name="product_quantity[]" onkeyup="quantity_calculate2({sl});" value="{quantity}" id="total_qntt_{sl}" class="form-control text-right" min="1" />
                                        </td>
                                        <td width="150">
                                        	<input type="text" name="product_rate[]" value="{rate}" id="price_item_{sl}" class="price_item{sl} form-control text-right" readonly="readonly" /><input type="hidden" name="product_tax[]" readonly="" value="{cgst}" id="tax_item_{sl}" class="tax_item{sl} form-control text-right" /><input type="hidden" name="product_sgst[]" readonly="" value="{sgst}" id="sgst_item_{sl}" class="sgst_item{sl} form-control text-right" />
                                        	<input type="hidden" name="cgst_per[]"  value="{cgst_per}" id="cgst_per_{sl}" class="cgst_per{sl} form-control text-right" />
                                          <input type="hidden" name="sgst_per[]"  value="{sgst_per}" id="sgst_per_{sl}" class="sgst_per{sl} form-control text-right" />
                                        </td>
					 <td width="150">	<input type="text" name="discount[]" onkeyup="quantity_calculate2({sl}); stockLimit({sl});" id="discount_{sl}" class="form-control text-right" placeholder="Discount" value="{discount}"/>
                                        </td>                                        
                                        <td width="150">
                                          <input class="total_price form-control text-right" type="text" name="total_price[]" id="total_price_{sl}" value="{total_price}" readonly="readonly" />
											<input type="hidden" name="invoice_details_id[]" id="invoice_details_id" value="{invoice_details_id}"/>
                                        </td>
                                         <td>
                                            <!-- Tax calculate start-->
                                            <input type="hidden" id="total_tax_{sl}" class="total_tax_{sl}" value="" />
                                            <input type="hidden" id="total_cgst_{sl}" class="total_cgst" value="{cgst}" />
                                            <input type="hidden" id="total_sgst_{sl}" class="total_sgst" value="{sgst}" />
                                            <input type="hidden" id="all_tax_{sl}" class="total_tax" />
                                            <!-- Tax calculate end -->
                                            <button style="text-align: right;" class="btn btn-danger" type="button" value="<?php echo display('delete')?>" onclick="deleteRow(this)"><?php echo display('delete')?></button>
                                        </td>
                                    </tr>
									{/advancedinvoice_all_data}
                                </tbody>
                                <tfoot>
                                       <tr>
                                        <td style="text-align:right;" colspan="4"><b><?php echo 'CGST'; ?>:</b></td>
                                        <td class="text-right">
                                             <input type="text" id="total_cgst_ammount" tabindex="-1" class="form-control text-right" name="total_cgst" value="{total_cgst}" readonly="readonly" />
                                            <input type="hidden" id="total_tax_ammount"  class="form-control text-right" name="total_tax" tabindex="-1" value="{total_tax}" readonly="readonly" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="text-align:right;" colspan="4"><b><?php echo 'SGST' ?>:</b></td>
                                        <td class="text-right">
                                             <input type="text" id="total_sgst_ammount" tabindex="-1" class="form-control text-right" name="total_sgst" value="{total_sgst}" readonly="readonly" />
                                        </td>
                                    </tr>
                                 
                                    <tr> 
                                        <td  class="text-right" colspan="2">
                                           
                                        </td>
                                       
<td colspan="2" style="text-align:right;"><b><?php echo display('grand_total') ?>:</b></td><td>     <input type="text" id="grandTotal" tabindex="-1" class="form-control text-right" name="grand_total_price" value="{total_amount}" readonly="readonly" /></td>
                                        
                                    </tr>
                                    <tr>
                                        <td align="center">

                                     
                                            <input type="hidden" name="baseUrl" class="baseUrl" value="<?php echo base_url();?>"/>          
                                           
                                        </td>
                                       <td colspan="3"  style="text-align:right;"><b><?php echo display('paid_ammount') ?>:</b></td>
                                        <td class="text-right">    <input type="text" id="paidAmount" 
                                            onkeyup="invoice_paidamount();"  tabindex="-1" class="form-control text-right" name="paid_amount" value="{paid_amount}" />
                                        </td>
                                      
                                    </tr>
                                    <tr>
                                        <td align="center"><input type="submit" id="add-invoice" class="btn btn-success" name="add-invoice" value="<?php echo display('save_and_paid') ?>" />
                                            
                                        </td>                       

                                       
 <td style="text-align:right;" colspan="3"><b><?php echo display('due') ?>:</b></td>
                                        <td class="text-right">   <input type="text" id="dueAmmount" class="form-control text-right" name="due_amount" value="{due_amount}" readonly="readonly"/>
                                        </td>
                                       

                                    </tr></tfoot>
                            </table>
                        </div>
                    </div>
                    <?php echo form_close()?>
                </div>
            </div>
        </div>
    </section>
</div>
<!-- Invoice Report End -->