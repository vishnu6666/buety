<!-- Bank List Start -->
<div class="content-wrapper">
	<section class="content-header">
	    <div class="header-icon">
	        <i class="pe-7s-note2"></i>
	    </div>
	    <div class="header-title">
	        <h1>Salary</h1>
	        <small>Salary list</small>
	        <ol class="breadcrumb">
	            <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
	            <li><a href="#">Salary</a></li>
	            <li class="active">Salary list</li>
	        </ol>
	    </div>
	</section>

	<section class="content">

		<!-- Alert Message -->
	    <?php
	        $message = $this->session->userdata('message');
	        if (isset($message)) {
	    ?>
	    <div class="alert alert-info alert-dismissable">
	        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	        <?php echo $message ?>                    
	    </div>
	    <?php 
	        $this->session->unset_userdata('message');
	        }
	        $error_message = $this->session->userdata('error_message');
	        if (isset($error_message)) {
	    ?>
	    <div class="alert alert-danger alert-dismissable">
	        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	        <?php echo $error_message ?>                    
	    </div>
	    <?php 
	        $this->session->unset_userdata('error_message');
	        }
	    ?>

		<!-- Bank List -->
		<div class="row">
		    <div class="col-sm-12">
		        <div class="panel panel-bd lobidrag">
		            <div class="panel-heading">
		                <div class="panel-title">
		                    <h4>Salary list </h4>
		                </div>
		            </div>
		            <div class="panel-body">
		                <div class="table-responsive">
		                    <table id="dataTableExample2" class="table table-bordered table-striped table-hover">
			           			<thead>
									<tr>
										<th><?php echo display('sl') ?></th>
										<th>Name</th>
										<th>Date</th>
										<th>Late Coming</th>
										<th>Over Time</th>
										<th>Half Day</th>
										<th>Leave</th>
										<th>Monthly Salary</th>
										<th>Net Salary</th>
										<th><?php echo display('action') ?></th>
									</tr>
								</thead>
								<tbody>
								<?php
									if ($salary_data) {
								?>
								{salary_data}
									<tr>
										<td>{sl}</td>
										<td>{name}</td>
										<td>{date}</td>
										<td>{late_coming}</td>
										<td>{over_times}</td>
										<td>{half_day}</td>
										<td>{leave}</td>
										<td>{monthly_salary}</td>
										<td>{net_salary}</td>
										<td>
										<?php echo form_open()?>
											<a href="<?php echo base_url().'Csalary/view_salary_statment/{user_id}'; ?>" class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="left" title="" data-original-title="<?php echo "View Details"; ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a>
										<?php echo form_close()?>
										</td>
									</tr>
								{/salary_data}
								<?php
									}
								?>
								</tbody>
		                    </table>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
	</section>
</div>
<!-- Bank List End -->

