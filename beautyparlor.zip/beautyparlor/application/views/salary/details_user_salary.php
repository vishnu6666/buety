<!-- Bank List Start -->
<div class="content-wrapper">
	<section class="content-header">
	    <div class="header-icon">
	        <i class="pe-7s-note2"></i>
	    </div>
	    <div class="header-title">
	        <h1>Salary Details</h1>
	        <small>Salary Details</small>
	        <ol class="breadcrumb">
	            <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
	            <li><a href="#">Salary Details</a></li>
	            <li class="active">Salary Details</li>
	        </ol>
	    </div>
	</section>

	<section class="content">

		<!-- Alert Message -->
	    <?php
	        $message = $this->session->userdata('message');
	        if (isset($message)) {
	    ?>
	    <div class="alert alert-info alert-dismissable">
	        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	        <?php echo $message ?>                    
	    </div>
	    <?php 
	        $this->session->unset_userdata('message');
	        }
	        $error_message = $this->session->userdata('error_message');
	        if (isset($error_message)) {
	    ?>
	    <div class="alert alert-danger alert-dismissable">
	        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	        <?php echo $error_message ?>                    
	    </div>
	    <?php 
	        $this->session->unset_userdata('error_message');
	        }
	    ?>

		<!-- Bank List -->
		<div class="row">
		    <div class="col-sm-12">
		        <div class="panel panel-bd lobidrag">
		            <div class="panel-heading">
		                <div class="panel-title">
		                    <h4>Salary Details </h4>
		                </div>
		            </div>
		            <div class="panel-body">
		                <div class="table-responsive">
		                    <table id="dataTableExample2" class="table table-bordered table-striped table-hover">
			           			<div class="container-fluid">
								  <div class="row">
								    <div class="col-sm-12" style="background-color:lavender;"><h3><b>Staff name:&nbsp;&nbsp;&nbsp;{name}</b></h2></div>
			
								  </div>
								</div>
								<div class="container-fluid">
								  <div class="row">
								    <div class="col-sm-4" ><h3><b>Salary:&nbsp;&nbsp;&nbsp;{monthly_salary}</b></h2></div>
								    <div class="col-sm-8" ><h3><b>&nbsp;&nbsp;&nbsp;</b></h2></div>
								    <div class="col-sm-4" ><h3><b>Leave:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{leave}</b></h2></div>
								    <div class="col-sm-8" ><h3><b>Amount:&nbsp;&nbsp;&nbsp;{balance_deduct_for_leave} </b></h2></div>
								    <div class="col-sm-4" ><h3><b>Half Day:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{half_day}</b></h2></div>
								    <div class="col-sm-8" ><h3><b>Amount:&nbsp;&nbsp;&nbsp;{balance_deduct_for_halfday}</b></h2></div>
								    <div class="col-sm-4" ><h3><b>Late Coming:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{late_coming}</b></h2></div>
								    <div class="col-sm-8" ><h3><b>Amount:&nbsp;&nbsp;&nbsp;{balance_deduct_for_latecomming}</b></h2></div>
								    <div class="col-sm-4" ><h3><b>Over Time:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{over_times}</b></h2></div>
								    <div class="col-sm-8" ><h3><b>Amount:&nbsp;&nbsp;&nbsp;{overtime_total} </b></h2></div>
								    <div class="col-sm-12" ><h3><b>Payable Final Salary:&nbsp;&nbsp;&nbsp;{net_salary}</b></h2></div>
								    <div class="col-sm-12" ><?php echo form_open()?>
											<a href="<?php echo base_url().'Csalary/manage_salary'; ?>" class="btn btn-primary btn-lg active" role="button" aria-pressed="true">Go Back</a>
										<?php echo form_close()?></div>


								  </div>
								</div>
		                    </table>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
	</section>
</div>
<!-- Bank List End -->

