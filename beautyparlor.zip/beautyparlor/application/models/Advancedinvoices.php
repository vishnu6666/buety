<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Advancedinvoices extends CI_Model {
	public function __construct()
	{
		parent::__construct();
		$this->load->library('auth');
		$this->load->library('lcustomer');
		$this->load->library('session');
		$this->load->model('Customers');
		$this->auth->check_admin_auth();
	}
	//Count advancedinvoice
	public function count_advancedinvoice()
	{
		return $this->db->count_all("advancedinvoice");
	}
	//advancedinvoice List
	public function advancedinvoice_list($company_id)
	{
		$this->db->select('a.*,b.customer_name');
		$this->db->from('advancedinvoice a');
		$this->db->join('customer_information b','b.customer_id = a.customer_id');
                if($company_id > 0){
                $this->db->where('a.company_id',$company_id);
                }
		$this->db->order_by('a.invoice','desc');
		$this->db->limit('500');
		$query = $this->db->get();

		if ($query->num_rows() > 0) {

			return $query->result_array();	
		}

		return false;
	}

   public function wholesale_return_list()
	{
		$this->db->select('a.*,b.customer_name');
		$this->db->from('wholesale_return_details a');
		$this->db->join('customer_information b','b.customer_id = a.customer_id');
		//$this->db->order_by('a.invoice','desc');
		$this->db->limit('500');
		$query = $this->db->get();

		if ($query->num_rows() > 0) {

			return $query->result_array();	
		}

		return false;
	}

	//advancedinvoice Search Item
	public function search_inovoice_item($customer_id)
	{
		$this->db->select('a.*,b.customer_name');
		$this->db->from('advancedinvoice a');
		$this->db->join('customer_information b','b.customer_id = a.customer_id');
		$this->db->where('b.customer_id',$customer_id);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}

	//POS advancedinvoice entry
	public function pos_advancedinvoice_setup($product_model){
		$product_information = $this->db->select('*')
						->from('product_information')
						->where('product_model',$product_model)
						->get()
						->row();
						
		if (isset($product_information->product_id)) {

			$this->db->select('SUM(a.quantity) as total_purchase');
			$this->db->from('product_purchase_details a');
			$this->db->where('a.product_id',$product_information->product_id);
			$total_purchase = $this->db->get()->row();

			$this->db->select('SUM(b.quantity) as total_sale');
			$this->db->from('advancedinvoice_details b');
			$this->db->where('b.product_id',$product_information->product_id);
			$total_sale = $this->db->get()->row();

			
			$data2 = (object)array(
				'total_product' => ($total_purchase->total_purchase - $total_sale->total_sale), 
				'supplier_price' => $product_information->supplier_price, 
				'price' => $product_information->price, 
				'supplier_id' => $product_information->supplier_id, 
				'tax' => $product_information->tax, 
				'product_id' => $product_information->product_id, 
				'product_name' => $product_information->product_name, 
				);

			return $data2;
		}else{
			return false;
		}
	}
	//POS customer setup
	public function pos_customer_setup(){
		$query= $this->db->select('*')
						->from('customer_information')
						->where('customer_name','Walking Customer')
						->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}

	//Count advancedinvoice
	public function wholesale_return_entry()
	{

     	$advancedinvoice_id = $this->input->post('advancedinvoice_id');
		$query = $this->db->query("select total_amount,customer_id from advancedinvoice where advancedinvoice_id='".$advancedinvoice_id."'");  
		$res=$query->result_array();
		$customer_id = $res[0]['customer_id'];
		$total_amount_in_stock = $res[0]['total_amount'];
		$total_amount_stock = $total_amount_in_stock - $this->input->post('grand_total_price');
		
		$this->db->query("UPDATE advancedinvoice SET total_amount ='".$total_amount_stock."'  where advancedinvoice_id='".$advancedinvoice_id."'");     
		$this->db->query("UPDATE customer_ledger SET amount ='".$total_amount_stock."'  where invoice_no='".$advancedinvoice_id."'");  			
	    
		
		$p_id = $this->input->post('product_id');	
		$rate = $this->input->post('product_rate');
		$quantity = $this->input->post('product_quantity');
		$discount = $this->input->post('discount');			
		$t_price = $this->input->post('total_price');
		
	
		
		for ($i=0, $n=count($p_id); $i < $n; $i++) {
			$product_quantity = $quantity[$i];			
			$product_rate = $rate[$i];
			$product_discount = $discount[$i];
			
			$product_id = $p_id[$i];
			$total_price = $t_price[$i];
						
			$data1 = array(				
				'advancedinvoice_id' =>	$this->input->post('advancedinvoice_id'),
				'customer_id'        => $customer_id,
				
				'product_id'		 =>	$product_id,
				'quantity'			 =>	$product_quantity,
			    'rate'				 =>	$product_rate,
				'discount'		     =>	$product_discount,			
				'total_price'		 =>	$total_price,			
				'total_amount'		 =>	$this->input->post('grand_total_price'),			
				'return_reason'		 =>	$this->input->post('return_reason')
			);
			$this->db->insert('wholesale_return_details',$data1);
			
			$query2 = $this->db->query("select quantity, rate, total_price from advancedinvoice_details where product_id='".$product_id."' and advancedinvoice_id='".$advancedinvoice_id."'");  
		    $res2=$query2->result_array();
		
            $quantity_in_stock =  $res2[0]['quantity'];
			$rate_in_stock = $res2[0]['rate'];
			$total_amount_in_stock = $res2[0]['total_price'];
		    
			$quantity2=$quantity_in_stock-$product_quantity;
			$total_amount2= $total_amount_in_stock -$total_price;
			$data2 = array(			
				'quantity'			=>	$quantity2,				
				'total_price'		=>	$total_amount2,				
			);		
			
			$this->db->where('advancedinvoice_id',$advancedinvoice_id);
			$this->db->where('product_id',$product_id);
			$this->db->update('advancedinvoice_details',$data2); 			
			
		}
		return true;
	}
	public function advancedinvoice_entry()
	{
	

		$advancedinvoice_id = $this->generator(10);
		$advancedinvoice_id = strtoupper($advancedinvoice_id);
		
		$product_id = $this->input->post('product_id');
		if ($product_id == null) {
			$this->session->set_userdata(array('error_message'=>display('please_select_product')));
			redirect('Cadvancedinvoice/pos_advancedinvoice');
		}

		if (($this->input->post('customer_name_others') == null) && ($this->input->post('customer_id') == null )) {
			$this->session->set_userdata(array('error_message'=>display('please_select_customer')));
			redirect(base_url().'Cadvancedinvoice');
		}

		
//Customer data Existence Check.
		if($this->input->post('customer_id')==""){

			$customer_id=$this->auth->generator(15);
		  	//Customer  basic information adding.
			$data=array(
				'customer_id' 	=> $customer_id,
                                'company_id' 	=> $this->session->userdata('company_id'),
				'customer_name' => $this->input->post('customer_name_others'),
				'customer_address' 		=>$this->input->post('customer_name_others_address'),
				'customer_mobile' 		=> $this->input->post('customer_name_mobile'),
				'customer_email' 		=> $this->input->post('customer_name_email'),
				'status' 				=> 1
				);
		
			$this->Customers->customer_entry($data);
		  	//Previous balance adding -> Sending to customer model to adjust the data.
			$this->Customers->previous_balance_add(0,$customer_id);
		}
		else{
			$customer_id=$this->input->post('customer_id');
		}

		//Full or partial Payment record.
		$paid_amount=$this->input->post('paid_amount');
		if($this->input->post('paid_amount') > 0)
		{

			//Insert to customer_ledger Table 
			$data2 = array(
				'transaction_id'	=>	$this->auth->generator(15),
				'customer_id'		=>	$customer_id,
                                'company_id' 	=> $this->session->userdata('company_id'),
				'receipt_no'		=>	$this->auth->generator(10),
				'date'				=>	$this->input->post('invoice_date'),
				'amount'			=>	$this->input->post('paid_amount'),
				'payment_type'		=>	1,
				'description'		=>	'ITP',
				'status'			=>	1
			);
			$this->db->insert('customer_ledger',$data2);

			// Inserting for Accounts adjustment.
			############ default table :: customer_payment :: inflow_92mizdldrv #################
			//Insert to customer_ledger Table 
			$account_table="inflow_92mizdldrv";
			$account_adjustment = array(
				'transection_id'	=>	$this->auth->generator(15),
				'tracing_id'		=>	$customer_id,
				'date'				=>	$this->input->post('invoice_date'),
				'amount'			=>	$this->input->post('paid_amount'),
				'payment_type'		=>	1,
				'description'		=>	'ITP',
				'status'			=>	1
			);
			$this->db->insert($account_table,$account_adjustment);
		}

		//Data inserting into advancedinvoice table
		$data=array(
			'advancedinvoice_id'	=>	$advancedinvoice_id,
			'customer_id'		=>	$customer_id,
                        'company_id' 	=> $this->session->userdata('company_id'),
			'date'			=>	$this->input->post('advancedinvoice_date'),
			'total_amount'		=>	$this->input->post('grand_total_price'),
			'invoice'		=>	$this->number_generator(),  
			'payment_method'=> $this->input->post('payment_method'),
			'status'		=>	1
			
		);
		$this->db->insert('advancedinvoice',$data);
		
		
		//Insert to customer_ledger Table 
		$data2 = array(
			'transaction_id'	=>	$this->generator(15),
			'customer_id'		=>	$customer_id,
                        'company_id' 	=> $this->session->userdata('company_id'),
			'invoice_no'		=>	$advancedinvoice_id,
			'date'			=>	$this->input->post('advancedinvoice_date'),
			'amount'		=>	$this->input->post('grand_total_price'),
			'status'		=>	1
		);
		$this->db->insert('customer_ledger',$data2);

		//Insert payment method
		$payment_method = $this->input->post('payment_method');
		$card_no = $this->input->post('card_no');
		$bank_name = $this->input->post('bank_name');
		if ($card_no != null) {
			$data3 = array(
			'payment_type'	=>	$payment_method,
			'card_no'			=>	$card_no,
			'bank_name'			=>	$bank_name,
			'price'				=>	$this->input->post('grand_total_price'),
			);
			$this->db->insert('payment_method',$data3);
		}

		
		$rate = $this->input->post('product_rate');
        $cgst = $this->input->post('cgst_per');
        $sgst = $this->input->post('sgst_per');
		$p_id = $this->input->post('product_id');
		$total_amount = $this->input->post('total_price');
		$discount = $this->input->post('discount');
		$expiry_date = $this->input->post('expiry_date');
		
		
		$nrt = $this->input->post('netrate');

		$available_quantity = $this->input->post('available_quantity');
		$quantity = $this->input->post('product_quantity');
		$free = $this->input->post('product_free');
		$tot_cgst = $this->input->post('total_cgst');
		$tot_sgst = $this->input->post('total_sgst');
        
        
		$result = array();
		
       
		for ($i=0, $n=count($quantity); $i < $n; $i++) {
			$product_quantity = $quantity[$i];
			
			$product_rate = $rate[$i];
            $product_cgst = $cgst[$i];
            $product_sgst = $sgst[$i]; 
			$product_id = $p_id[$i];
			$discount_rate = $discount[$i];
			$expiry_date_rate = $expiry_date[$i];
			
			$nt_rate = $nrt[$i];
			$total_price = $total_amount[$i];
			$cgst_rate = $tot_cgst[$i];
			$sgst_rate = $tot_sgst[$i];
			
			$supplier_rate=$this->supplier_rate($product_id);
		
			if($discount_rate){
			      	$tax_amt = ($product_rate * $product_quantity * $discount_rate) / 100;
			      	$taxable_amt = ($product_rate * $product_quantity) - $tax_amt;
			      	$cgst_rate =  ($product_cgst * $taxable_amt) / 100 ;
			        $sgst_rate =  ($product_sgst * $taxable_amt) / 100 ;
			}else{    
			    	$taxable_amt = $product_rate * $product_quantity;
			        $cgst_rate =  ($product_cgst * $taxable_amt) / 100 ;
			        $sgst_rate =  ($product_sgst * $taxable_amt) / 100 ;
			}
			
			
			$data1 = array(
				'advancedinvoice_details_id'	=>	$this->generator(15),
				'advancedinvoice_id'		    =>	$advancedinvoice_id,
				'product_id'			        =>	$product_id,
				'quantity'			            =>	$product_quantity,
				
				'rate'				            =>	$product_rate,
				
				'discount'                      =>	$discount_rate,
				'taxable_amt'                   =>  $taxable_amt,   
				'tax'           		        =>	$this->input->post('total_tax'),
				'total_cgst'           		    =>	$this->input->post('total_cgst'),
				'total_sgst'           		    =>	$this->input->post('total_sgst'),
                'cgst'           	            =>	$cgst_rate,
                'sgst'           	            =>	$sgst_rate,
				'paid_amount'           	    =>	$this->input->post('paid_amount'),
				'due_amount'           	        =>	$this->input->post('due_amount'),
				'supplier_rate'                 =>	$supplier_rate[0]['supplier_price'],
				'total_price'                   =>	$total_price,
				'status'			            =>	1,
				
				
			);
			
			if(!empty($quantity))
			{
				$this->db->insert('advancedinvoice_details',$data1);

			}
		}
		return $advancedinvoice_id;
	}
    public function advancedinvoice_to_main_invoice_entry($data_details)
	{
		

		//Data inserting into invoice table
		$data=array(
			'invoice_id'		=>	$data_details[0]['advancedinvoice_id'],
			'customer_id'		=>	$data_details[0]['customer_id'],
			'date'			=>	$data_details[0]['date'],
			'total_amount'		=>	$data_details[0]['total_amount'],
			'invoice'		=>	$this->number_generator1(),
			'status'		=>	1
		);
		$this->db->insert('invoice',$data);
				
		for ($i=0, $n=count($data_details); $i < $n; $i++) {			
			
			$data1 = array(
				'invoice_details_id'	=>	$data_details[$i]['advancedinvoice_details_id'],
				'invoice_id'		=>	$data_details[$i]['advancedinvoice_id'],
				'product_id'		=>	$data_details[$i]['product_id'],
				'quantity'		=>	$data_details[$i]['quantity'],
				'rate'			=>	$data_details[$i]['rate'],
				'discount'           	=>	$data_details[$i]['discount'],
				'tax'           	=>	$data_details[$i]['tax'],
				'total_cgst'           	=>	$data_details[$i]['total_cgst'],
				'total_sgst'           	=>	$data_details[$i]['total_sgst'],			
               'cgst'           	=>	$data_details[$i]['cgst'],
               'sgst'           	=>	$data_details[$i]['sgst'],
				'paid_amount'           =>	$data_details[$i]['paid_amount'],
				'due_amount'           	=>	$data_details[$i]['due_amount'],
				'supplier_rate'         =>	$data_details[$i]['supplier_rate'],
				'total_price'           =>	$data_details[$i]['total_price'],
				'status'		=>	1
			);
			$this->db->insert('invoice_details',$data1);

		}
		return true;
	}
	//Get Supplier rate of a product
	public function supplier_rate($product_id)
	{
		$this->db->select('supplier_price');
		$this->db->from('product_information');
		$this->db->where(array('product_id' => $product_id)); 
		$query = $this->db->get();
		return $query->result_array();
	
	}
	//Retrieve advancedinvoice Edit Data
	public function retrieve_advancedinvoice_editdata($advancedinvoice_id)
	{
		$this->db->select('a.*,b.customer_name,c.*,c.tax as total_tax, c.total_cgst as total_cgst, c.total_sgst as total_sgst,c.product_id,d.product_name, d.hsn_code, d.cgst_per, d.sgst_per');
		$this->db->from('advancedinvoice a');
		$this->db->join('customer_information b','b.customer_id = a.customer_id');
		$this->db->join('advancedinvoice_details c','c.advancedinvoice_id = a.advancedinvoice_id');
		$this->db->join('product_information d','d.product_id = c.product_id');
		$this->db->where('a.advancedinvoice_id',$advancedinvoice_id);
		$query = $this->db->get();

		if ($query->num_rows() > 0) {
		
			return $query->result_array();	
		}
		return false;
	}
	//update_advancedinvoice
	public function update_advancedinvoice()
	{
		$advancedinvoice_id = $this->input->post('advancedinvoice_id');

		$data=array(
			'customer_id'		=>	$this->input->post('customer_id'),
			'date'				=>	$this->input->post('advancedinvoice_date'),
			'total_amount'		=>	$this->input->post('grand_total_price'),
				'payment_method'=> $this->input->post('payment_method')
		);
		$data2 = array(
			'customer_id'		=>	$this->input->post('customer_id'),
			'invoice_no'		=>	$advancedinvoice_id,
			'date'				=>	$this->input->post('advancedinvoice_date'),
			'amount'			=>	$this->input->post('grand_total_price')
		);
		
		if($advancedinvoice_id!='')
		{
			$this->db->where('advancedinvoice_id',$advancedinvoice_id);
			$this->db->update('advancedinvoice',$data); 
			
			//Update Another table
			$this->db->where('invoice_no',$advancedinvoice_id);
			$this->db->update('customer_ledger',$data2); 
		}

		$advancedinvoice_d_id = $this->input->post('advancedinvoice_details_id');
		$rate = $this->input->post('product_rate');
		$p_id = $this->input->post('product_id');
		$advancedinvoice_id = $this->input->post('advancedinvoice_id');
		$quantity = $this->input->post('product_quantity');
		$total_amount = $this->input->post('total_price');
		$discount = $this->input->post('discount');
		$cgst = $this->input->post('product_tax');
        $sgst = $this->input->post('product_sgst');
          $cgst_per = $this->input->post('cgst_per');
        $sgst_per = $this->input->post('sgst_per');
        
       
	
		
				
		
		for ($i=0, $n=count($advancedinvoice_d_id); $i < $n; $i++) {
		   
			$product_quantity = $quantity[$i];
			$product_rate = $rate[$i];
			 $product_cgst = $cgst[$i];
            $product_sgst = $sgst[$i];
            $product_cgst_per = $cgst_per[$i];
            $product_sgst_per = $sgst_per[$i]; 
            
				
			$product_id = $p_id[$i];
			$advancedinvoice_detail_id = $advancedinvoice_d_id[$i];
			$total_price = $total_amount[$i];
			$discount_rate = $discount[$i];
			
			
		
			if($discount_rate){
			      	$tax_amt = ($product_rate * $product_quantity * $discount_rate) / 100;
			      	$taxable_amt = ($product_rate * $product_quantity) - $tax_amt;
			      	$cgst_rate =  ($product_cgst_per * $taxable_amt) / 100 ;
			        $sgst_rate =  ($product_sgst_per * $taxable_amt) / 100 ;
			}else{    
			    
			    	$taxable_amt = $product_rate * $product_quantity;
			        $cgst_rate =  ($product_cgst_per * $taxable_amt) / 100 ;
			        $sgst_rate =  ($product_sgst_per * $taxable_amt) / 100 ;
			        
			}	
			
			
			$data1 = array(
				'advancedinvoice_id'		=>	$advancedinvoice_id,
				'product_id'		=>	$product_id,
				'quantity'			=>	$product_quantity,
				
				'rate'				            =>	$product_rate,
				
				'discount'			=>	$discount_rate,
				'taxable_amt'                   =>  $taxable_amt,   
				'total_price'		=>	$total_price,
				'tax'           		=>	$this->input->post('total_tax'),
				'total_cgst'           		    =>	$this->input->post('total_cgst'),
				'total_sgst'           		    =>	$this->input->post('total_sgst'),
                'cgst'           	            =>	$cgst_rate,
                'sgst'           	            =>	$sgst_rate,
				'paid_amount'           =>	$this->input->post('paid_amount'),
				'due_amount'           	=>	$this->input->post('due_amount'),
				
			);
					$this->db->where('advancedinvoice_details_id',$advancedinvoice_detail_id);
			$this->db->update('advancedinvoice_details',$data1); 
			
		}

		return $advancedinvoice_id;
	}
	//Retrieve advancedinvoice_html_data
	
	public function retrieve_return_wholesale_editdata($advancedinvoice_id)
	{
		$this->db->select('a.*,c.*,d.product_id,d.product_name,d.product_details, d.mfg, d.pack, d.cgst_per, d.sgst_per , (c.rate * c.quantity) as tot_rate');
		$this->db->from('advancedinvoice a');		
		$this->db->join('advancedinvoice_details c','c.advancedinvoice_id = a.advancedinvoice_id');
		$this->db->join('product_information d','d.product_id = c.product_id');		
		$this->db->where('a.advancedinvoice_id',$advancedinvoice_id);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}
	// Delete adv
	public function retrieve_advancedinvoice_html_data($advancedinvoice_id)
	{
		$this->db->select('a.*,b.*,c.*,d.product_id, d.product_name,d.product_details,d.hsn_code, d.mfg, d.pack, d.cgst_per, d.sgst_per , p.quantity as pquantity,  p.total_amount as ptotal_amount, (c.rate * c.quantity) as tot_rate');
		$this->db->from('advancedinvoice a');
		$this->db->join('customer_information b','b.customer_id = a.customer_id');
		$this->db->join('advancedinvoice_details c','c.advancedinvoice_id = a.advancedinvoice_id');
		$this->db->join('product_information d','d.product_id = c.product_id');
		$this->db->join('product_purchase_details p','p.product_id = c.product_id');
		$this->db->join('product_purchase ps','ps.purchase_id = p.purchase_id');
		$this->db->where('a.advancedinvoice_id',$advancedinvoice_id);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}
	// Delete advancedinvoice Item
	public function retrieve_product_data($product_id)
	{
		$this->db->select('supplier_price,price,supplier_id,tax');
		$this->db->from('product_information');
		$this->db->where(array('product_id' => $product_id,'status' => 1)); 
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			foreach ($query->result() as $row) {
				$data[] = $row;
			}
			return $data;
		}
		return false;
	}
	//Retrieve company Edit Data
	public function retrieve_company()
	{
		$this->db->select('*');
		$this->db->from('company_information');
		$this->db->limit('1');
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}
	// Delete advancedinvoice Item
	public function delete_advancedinvoice($advancedinvoice_id)
	{	
		//Delete Advancedadvancedinvoice table
		$this->db->where('advancedinvoice_id',$advancedinvoice_id);
		$this->db->delete('advancedinvoice'); 
		//Delete advancedinvoice_details table
		$this->db->where('advancedinvoice_id',$advancedinvoice_id);
		$this->db->delete('advancedinvoice_details'); 
		return true;
	}
	public function advancedinvoice_search_list($cat_id,$company_id)
	{
		$this->db->select('a.*,b.sub_category_name,c.category_name');
		$this->db->from('advancedinvoices a');
		$this->db->join('advancedinvoice_sub_category b','b.sub_category_id = a.sub_category_id');
		$this->db->join('advancedinvoice_category c','c.category_id = b.category_id');
		$this->db->where('a.sister_company_id',$company_id);
		$this->db->where('c.category_id',$cat_id);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}
	// GET TOTAL PURCHASE PRODUCT
	public function get_total_purchase_item($product_id)
	{
		$this->db->select('SUM(quantity) as total_purchase');
		$this->db->from('product_purchase_details');
		$this->db->where('product_id',$product_id);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}
	// GET TOTAL SALES PRODUCT
	public function get_total_sales_item($product_id)
	{
		$this->db->select('SUM(quantity) as total_sale');
		$this->db->from('advancedinvoice_details');
		$this->db->where('product_id',$product_id);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}

	//Get total product
	public function get_total_product($product_id){
		$this->db->select('SUM(a.quantity) as total_purchase');
		$this->db->from('product_purchase_details a');
		$this->db->where('a.product_id',$product_id);
		$total_purchase = $this->db->get()->row();

		$this->db->select('SUM(b.quantity) as total_sale');
		$this->db->from('advancedinvoice_details b');
		$this->db->where('b.product_id',$product_id);
		$total_sale = $this->db->get()->row();

		$this->db->select('supplier_price,price,supplier_id,tax');
		$this->db->from('product_information');
		$this->db->where(array('product_id' => $product_id,'status' => 1)); 
		$product_information = $this->db->get()->row();

		$data2 = array(
			'total_product' => ($total_purchase->total_purchase - $total_sale->total_sale), 
			'supplier_price' => $product_information->supplier_price, 
			'price' => $product_information->price, 
			'supplier_id' => $product_information->supplier_id, 
			'tax' => $product_information->tax, 
			);

		return $data2;
	}




	//This function is used to Generate Key
	public function generator($lenth)
	{
		$number=array("1","2","3","4","5","6","7","8","9");
	
		for($i=0; $i<$lenth; $i++)
		{
			$rand_value=rand(0,8);
			$rand_number=$number["$rand_value"];
		
			if(empty($con))
			{ 
			$con=$rand_number;
			}
			else
			{
			$con="$con"."$rand_number";}
		}
		return $con;
	}
	//NUMBER GENERATOR
public function number_generator1()
	{
		$this->db->select_max('invoice', 'invoice_no');
		$query = $this->db->get('invoice');	
		$result = $query->result_array();	
		$invoice_no = $result[0]['invoice_no'];
		if ($invoice_no !='') {
			$invoice_no = $invoice_no + 1;	
		}else{
			$invoice_no = 1000;
		}
		return $invoice_no;		
	}
	public function number_generator()
	{
		$this->db->select_max('invoice', 'invoice_no');
		$query = $this->db->get('advancedinvoice');	
		$result = $query->result_array();	
		$invoice_no = $result[0]['invoice_no'];
		if ($invoice_no !='') {
			$invoice_no = $invoice_no + 1;	
		}else{
			$invoice_no = 1000;
		}
		return $invoice_no;		
	}
        // retrive advanced invoice data
	public function retrieve_advancedinvoice_data($advancedinvoice_id)
	{
		$this->db->select('a.*,c.*');
		$this->db->from('advancedinvoice a');
		$this->db->join('advancedinvoice_details c','c.advancedinvoice_id = a.advancedinvoice_id');		
		$this->db->where('a.advancedinvoice_id',$advancedinvoice_id);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	} 

}