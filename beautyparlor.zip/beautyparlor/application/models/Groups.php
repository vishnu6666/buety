<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Groups extends CI_Model {
	public function __construct()
	{
		parent::__construct();
	}
	//BANK LIST
	public function get_group_list()
	{
		$this->db->select('*');
		$this->db->from('groups');
		$this->db->limit('500');
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}
	//Get group by id
	public function get_group_by_id($id)
	{
		$this->db->select('*');
		$this->db->from('groups');
		$this->db->where('id',$id);		
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}
       public function get_group_permissions($id)
	{
		$this->db->select('*');
		$this->db->from('permissions');
		$this->db->where('group_id',$id);		
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}

	//Bank updaet by id
	public function group_update_by_id($id)
	{
		$data['name']=$this->input->post('group_name');
		$data['description']=$this->input->post('group_description');
		$this->db->where('id',$id);
		$this->db->update('groups',$data); 
		return true;
	}

        public function permission_update_by_id($id, $data)
	{
		
		$this->db->where('id',$id);
		$this->db->update('permissions',$data); 
		return true;
	}
	
	//COUNT PRODUCT
	public function group_entry( $data )
	{
		$this->db->insert('groups',$data);
	}
        public function permission_entry( $data )
	{
		$this->db->insert('permissions',$data);
	}

        public function get_group_by_name($name)
	{
		$this->db->select('*');
		$this->db->from('groups');
		$this->db->where('name',$name);		
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return true;
		}
		return false;
	}
        public function get_group_by_name_id($name, $id, $gid)
	{
		$this->db->select('*');
		$this->db->from('groups');
		//$this->db->where('name',$name);
                $this->db->where('id',$gid);		
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
   		   return $query->result_array();	
                }
		return false;
	}
        public function checkPermissions($id, $action = null)
        {
             // $id= $this->session->userdata('group_id');
              $this->db->select('*');
	      $this->db->from('permissions');
	      $this->db->where($action,1);
              $this->db->where('group_id',$id);		
	      $query = $this->db->get();
	      if ($query->num_rows() > 0) {
		return true;
	      }
	      return false;
        }
                
     
        
}