<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Purchases extends CI_Model {
	public function __construct()
	{
		parent::__construct();
	}
	//Count purchase
	public function count_purchase()
	{
		$this->db->select('a.*,b.supplier_name');
		$this->db->from('product_purchase a');
		$this->db->join('supplier_information b','b.supplier_id = a.supplier_id');
		return $query=$this->db->get()->num_rows();
	}
	//purchase List
	public function purchase_list()
	{
		$this->db->select('a.*,b.supplier_name');
		$this->db->from('product_purchase a');
		$this->db->join('supplier_information b','b.supplier_id = a.supplier_id');
		$this->db->order_by('a.purchase_date','desc');
		$this->db->order_by('purchase_id','desc');
		$this->db->limit('500');
		$query = $this->db->get();
		
		$last_query =  $this->db->last_query();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}
     public function purchase_return_list()
	{
		$this->db->select('a.*,b.supplier_name');
		$this->db->from('purchase_return_details a');
		$this->db->join('supplier_information b','b.supplier_id = a.supplier_id');
		//$this->db->order_by('a.invoice','desc');
		$this->db->limit('500');
		$query = $this->db->get();

		if ($query->num_rows() > 0) {

			return $query->result_array();	
		}

		return false;
	}
	
	//Select All Supplier List
	public function select_all_supplier()
	{
		$query = $this->db->select('*')
					->from('supplier_information')
					->where('status','1')
					->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}
public function select_all_product()
	{
		$query = $this->db->select('*')
					->from('product_information')
					->where('status','1')
					->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}
	//purchase Search  List
	public function purchase_by_search($supplier_id)
	{
		$this->db->select('a.*,b.supplier_name');
		$this->db->from('product_purchase a');
		$this->db->join('supplier_information b','b.supplier_id = a.supplier_id');
		$this->db->where('b.supplier_id',$supplier_id);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}
	//Count purchase
	public function purchase_entry()
	{
	  //print_r($_REQUEST);exit;
		if ($_FILES['invoice_image']['name']) {
			//Chapter chapter add start
			$config['upload_path']          = './my-assets/image/product/';
	        $config['allowed_types']        = '*';
	        $config['max_size']             = "*";
	        $config['max_width']            = "*";
	        $config['max_height']           = "*";
	        $config['encrypt_name'] 		= TRUE;

	        $this->load->library('upload', $config);
	        if ( ! $this->upload->do_upload('invoice_image'))
	        {
	            $error = array('error' => $this->upload->display_errors());
	            $this->session->set_userdata(array('error_message'=> display('Image Not Uploaded!')));
	            redirect(base_url('Cpurchase'));
	        }
	        else
	        {
	        	$image =$this->upload->data();
	        	$image_url = base_url()."my-assets/image/purchase/".$image['file_name'];
	        }
		}
		
		$purchase_id = date('YmdHis');
		
		$p_id = $this->input->post('product_id');
		$supplier_id=$this->input->post('supplier_id');

		//supplier & product id relation ship checker.
		//for ($i=0, $n=count($p_id); $i < $n; $i++) {
		//	$product_id =$p_id[$i];
		//	$value=$this->product_supplier_check($product_id,$supplier_id);
		
		
		//	if($value==0){
		//	  	$this->session->set_userdata(array('message'=>"Product and Supplier did not match!"));
		//	  	redirect(base_url('cpurchase'));
		//	  	exit();
		//	}
		//}
		
		$data=array(
			'purchase_id'			=>	$purchase_id,
			'chalan_no'				=>	$this->input->post('chalan_no'),
			'supplier_id '          =>  $supplier_id,
			'grand_total_amount'	=>	$this->input->post('grand_total_price'),
			'purchase_date'			=>	$this->input->post('purchase_date'),
			'purchase_details'		=>	$this->input->post('purchase_details'),
			'invoice_image' 		=> (!empty($image_url)?$image_url:null),
			'status'				=>	1
		);
		$this->db->insert('product_purchase',$data);
		
		
		
		$ledger=array(
			'transaction_id'		=>	$purchase_id,
			'chalan_no'				=>	$this->input->post('chalan_no'),
			'supplier_id'			=>	$this->input->post('supplier_id'),
			'amount'				=>	$this->input->post('grand_total_price'),
			'date'					=>	$this->input->post('purchase_date'),
			'description'			=>	$this->input->post('purchase_details'),
			'status'				=>	1
		);
		$this->db->insert('supplier_ledger',$ledger);
	
			
		$rate = $this->input->post('product_rate');
		$mrp = $this->input->post('product_mrp');
		$quantity = $this->input->post('product_quantity');
		$discount = $this->input->post('product_discount');
		
	//	$t_price = $this->input->post('total_price');
	//	$t_taxable = $this->input->post('total_taxable');
	
		
		$cgst_percentage = $this->input->post('product_cgst');
		$sgst_percentage = $this->input->post('product_sgst');
	
		$pr_id = $this->input->post('product_id');
		
		$grand_total_price = 0;
	
		for ($i=0, $n=count($pr_id); $i < $n; $i++) {
			$product_quantity        = @$quantity[$i];
			$product_discount        = @$discount[$i];
			
			$product_rate            = @$rate[$i];
			if($product_discount > 0){
			$total_discount           = ($product_rate * $product_quantity * $product_discount) / 100;
			$total_taxable            = ($product_rate * $product_quantity) - $total_discount;
			}else{
			$total_discount           = 0;
			$total_taxable            = $product_rate * $product_quantity ;   
			}
			$product_mrp            = @$mrp[$i];
		 	$product_id              = @$pr_id[$i];
		//	$total_price             = @$t_price[$i];
			
			$product_cgst_percentage = @$cgst_percentage[$i];
			$product_cgst_amount     = ($total_taxable * $product_cgst_percentage)/100;
			$product_sgst_percentage = @$sgst_percentage[$i];
			$product_sgst_amount     = ($total_taxable * $product_sgst_percentage)/100;
			$total_amount            = $total_taxable + $product_cgst_amount + $product_sgst_amount ;
			$grand_total_price       = 	$grand_total_price +  $total_amount;
			
		
			$data1 = array(
				'purchase_detail_id'=>	$this->generator(15),
				'purchase_id'		=>	$purchase_id,
				'product_id'		=>	$product_id,
				'supplier_id'       =>  $this->input->post('supplier_id'),
				'quantity'			=>	$product_quantity,
				
				'rate'				=>	$product_rate,
				'mrp'				=>	$product_mrp, 
				'cgst_percentage'   =>  $product_cgst_percentage,
				'cgst_amount'       =>  $product_cgst_amount,
				'sgst_percentage'   =>  $product_sgst_percentage,
				'sgst_amount'       =>  $product_sgst_amount,		
				'discount'          =>  $product_discount,	
				'discount_amt'      =>  $total_discount,	
				'total_amount'		=>	$total_amount,
				'taxable_amt'       =>  $total_taxable,
				
				'status'			=>	1
			);

			if(!empty($quantity))
			{
				$this->db->insert('product_purchase_details',$data1);
			}
		}
		     $this->db->query("UPDATE product_purchase SET grand_total_amount ='".$grand_total_price."'  where purchase_id='".$purchase_id."' and supplier_id='".$this->input->post('supplier_id')."'");     
		    $this->db->query("UPDATE supplier_ledger SET amount ='".$grand_total_price."'  where transaction_id='".$purchase_id."' and supplier_id='".$this->input->post('supplier_id')."'");     			
		 	$this->db->select('a.product_name, a.product_id');
		    $this->db->from('product_information a');
		    $this->db->join('product_purchase_details b','b.product_id = a.product_id');
		    $this->db->where('a.status',1);
		    $this->db->group_by('a.product_id');
		    $this->db->order_by('a.product_id','desc');
		   	$query = $this->db->get();
			foreach ($query->result() as $row) {
				$json_purchase[] = array('label'=>$row->product_name,'value'=>$row->product_id);
			}
			$cache_file = './my-assets/js/admin_js/json/purchase.json';
			$purchaseList = json_encode($json_purchase);
			file_put_contents($cache_file,$purchaseList);
			return $purchase_id;
	}
	public function purchase_return_entry()
	{

     	$p_id = $this->input->post('product_id');
		$supplier_id=$this->input->post('supplier_id');
		$purchase_id2 	= $this->input->post('purchase_id');
		$total_price2 = $this->input->post('total_price');

		//supplier & product id relation ship checker.
		//for ($i=0, $n=count($p_id); $i < $n; $i++) {
			//$product_id =$p_id[$i];
			//$value=$this->product_supplier_check($product_id,$supplier_id);
			///if($value==0){
			  	//$this->session->set_userdata(array('message'=>"Product and Supplier did not match!"));
			  	//redirect(base_url('cpurchase'));
			  	//exit();
			//}

		//}
		   	
		
		for ($i=0, $n=count($p_id); $i < $n; $i++) {       
			$query = $this->db->query("select grand_total_amount from product_purchase where purchase_id='".$purchase_id2[$i]."' and supplier_id='".$this->input->post('supplier_id')."'");     $res=$query->result_array();
			$grand_total_amount_in_stock = $res[0]['grand_total_amount'];
			$grand_total_amount_stock = $grand_total_amount_in_stock - $total_price2[$i];
			$this->db->query("UPDATE product_purchase SET grand_total_amount ='".$grand_total_amount_stock."'  where purchase_id='".$purchase_id2[$i]."' and supplier_id='".$this->input->post('supplier_id')."'");     
			$this->db->query("UPDATE supplier_ledger SET amount ='".$grand_total_amount_stock."'  where transaction_id='".$purchase_id2[$i]."' and supplier_id='".$this->input->post('supplier_id')."'");     			
					
		}
		
		$rate = $this->input->post('product_rate');
		$quantity = $this->input->post('product_quantity');
		
		$t_price = $this->input->post('total_price');
		$purchase_id 	= $this->input->post('purchase_id');		
		
		for ($i=0, $n=count($p_id); $i < $n; $i++) {
			$product_quantity = $quantity[$i];
			
			$product_rate = $rate[$i];
			$product_id = $p_id[$i];
			$total_price = $t_price[$i];
			$purchaseid = $purchase_id[$i];		
			
			$data1 = array(				
				'purchase_id'		=>	$purchaseid,
				'supplier_id'       =>  $this->input->post('supplier_id'),
				'product_id'		=>	$product_id,
				'quantity'			=>	$product_quantity,
				
				'rate'				=>	$product_rate,
				'total_amount'		=>	$total_price,			
				'return_reason'		=>	$this->input->post('return_reason')
			);
			$this->db->insert('purchase_return_details',$data1);
			
			$this->db->select('quantity, rate, total_amount');
            $this->db->where('purchase_id',$purchaseid);
			$this->db->where('product_id',$product_id);
            $query = $this->db->get('product_purchase_details');
            $row1 = $query->row();
            $quantity_in_stock = $row1->quantity;
			$rate_in_stock = $row1->rate;
			$total_amount_in_stock = $row1->total_amount;
		    
			$quantity2=$quantity_in_stock-$product_quantity;
			$total_amount2= $total_amount_in_stock -$total_price;
			$data2 = array(			
				'quantity'			=>	$quantity2,
				'rate'				=>	$product_rate,
				'total_amount'		=>	$total_amount2,				
			);		
			
			$this->db->where('purchase_id',$purchaseid);
			$this->db->where('product_id',$product_id);
			$this->db->update('product_purchase_details',$data2); 			
			
		}
		return true;
	}
	//Retrieve purchase Edit Data
	//Product search item
	public function retrieve_return_purchase_editdata($supplier_id){
		$this->db->select('a.*,b.*,c.product_id,c.product_name,d.supplier_id,d.supplier_name');
		$this->db->from('product_purchase a');
		$this->db->join('product_purchase_details b','b.purchase_id =a.purchase_id');
		$this->db->join('product_information c','c.product_id =b.product_id');
		$this->db->join('supplier_information d','d.supplier_id = a.supplier_id');
		$this->db->where('a.supplier_id',$supplier_id);
		$this->db->order_by('a.purchase_details','asc');
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
		
	}
	public function retrieve_purchase_editdata($purchase_id)
	{
		$this->db->select('a.*,b.*,c.product_id,c.product_name,d.supplier_id,d.supplier_name');
		$this->db->from('product_purchase a');
		$this->db->join('product_purchase_details b','b.purchase_id =a.purchase_id');
		$this->db->join('product_information c','c.product_id =b.product_id');
		$this->db->join('supplier_information d','d.supplier_id = a.supplier_id');
		$this->db->where('a.purchase_id',$purchase_id);
		$this->db->order_by('a.purchase_details','asc');
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}
	//Retrieve company Edit Data
	public function retrieve_company()
	{
		$this->db->select('*');
		$this->db->from('company_information');
		$this->db->limit('1');
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}
	//Update Categories
	public function update_purchase()
	{
	   
	   	$purchase_id  = $this->input->post('purchase_id'); 
	   	if($purchase_id!='')
		{	
	   $this->delete_purchase_details($purchase_id);
		}
		
	   if ($_FILES['invoice_image']['name']) {
			//Chapter chapter add start
			$config['upload_path']          = './my-assets/image/purchase/';
	        $config['allowed_types']        = '*';
	        $config['max_size']             = "*";
	        $config['max_width']            = "*";
	        $config['max_height']           = "*";
	        $config['encrypt_name'] 		= TRUE;

	        $this->load->library('upload', $config);
	        if ( ! $this->upload->do_upload('invoice_image'))
	        {
	            $error = array('error' => $this->upload->display_errors());
	            $this->session->set_userdata(array('error_message'=> display('image_not_uploaded!')));
	            redirect(base_url('Cproduct'));
	        }
	        else
	        {
	        	$image =$this->upload->data();
	        	$old_image = $this->input->post('old_image');
	        	$image_url = base_url()."my-assets/image/purchase/".$image['file_name'];
	        }
		}
	
		$old_image = $this->input->post('old_image');
		
	
		$data=array(
			'chalan_no'			=>	$this->input->post('chalan_no'),
			'supplier_id'			=>	$this->input->post('supplier_id'),
			'grand_total_amount'		=>	$this->input->post('grand_total_price'),
			'purchase_date'			=>	$this->input->post('purchase_date'),
			'purchase_details'		=>	$this->input->post('purchase_details'),
			'invoice_image' 				=> (!empty($image_url)?$image_url:$old_image),
			
		);
		
		if($purchase_id!='')
		{
			$this->db->where('purchase_id',$purchase_id);
			$this->db->update('product_purchase',$data); 
			
		}
		$ledger=array(
			'transaction_id'		=>	$purchase_id,
			'chalan_no'				=>	$this->input->post('chalan_no'),
			'supplier_id'			=>	$this->input->post('supplier_id'),
			'amount'				=>	$this->input->post('grand_total_price'),
			'date'					=>	$this->input->post('purchase_date'),
			'description'			=>	$this->input->post('purchase_details')
		);
		if($purchase_id!='')
		{
			$this->db->where('transaction_id',$purchase_id);
			$this->db->update('supplier_ledger',$ledger); 
			
		}
		
		$rate = $this->input->post('product_rate');
		$mrp = $this->input->post('product_mrp');
		$p_id = $this->input->post('product_id');
		$quantity = $this->input->post('product_quantity');
		//$t_taxable = $this->input->post('total_taxable');
		$discount = $this->input->post('product_discount');
		
		$t_price = $this->input->post('total_price');
		$purchase_d_id = $this->input->post('purchase_detail_id');
		
		$cgst_percentage = $this->input->post('product_cgst');
		$sgst_percentage = $this->input->post('product_sgst');
		$grand_total_price = 0;
		for ($i=0, $n=count($p_id); $i < $n; $i++) {
			
			$product_quantity         = @$quantity[$i];
			$product_discount         = @$discount[$i];
			
			$product_rate = @$rate[$i];
			if($product_discount > 0){
			     $total_discount           = ($product_rate * $product_quantity * $product_discount) / 100;
			     $total_taxable            = ($product_rate * $product_quantity) - $total_discount;
			}else{
			     $total_discount           = 0;
			     $total_taxable            = $product_rate * $product_quantity ;   
			}
			$product_mrp              = @$mrp[$i];
			$product_id               = @$p_id[$i];
		//	$total_price   = @$t_price[$i];
			$purchase_detail_id = @$purchase_d_id[$i];
			
			$product_cgst_percentage = @$cgst_percentage[$i];
			$product_cgst_amount     = ($total_taxable * $product_cgst_percentage)/100;
			$product_sgst_percentage = @$sgst_percentage[$i];
			$product_sgst_amount     = ($total_taxable * $product_sgst_percentage)/100;
			$total_amount            = $total_taxable + $product_cgst_amount + $product_sgst_amount ;
			$grand_total_price       = 	$grand_total_price +  $total_amount;
			
			$data1 = array(
				'product_id'		=>	$product_id,
				'quantity'			=>	$product_quantity,
				'discount'			=>	$product_discount,
				
				'rate'				=>	$product_rate,
				'mrp'				=>	$product_mrp, 
				'cgst_percentage'   =>  $product_cgst_percentage,
				'cgst_amount'       =>  $product_cgst_amount,
				'sgst_percentage'   =>  $product_sgst_percentage,
				'sgst_amount'       =>  $product_sgst_amount,		
				'discount'       =>  $product_discount,		
				'discount_amt'      =>  $total_discount,
			    'total_amount'		=>	$total_amount,
				'taxable_amt'       =>  $total_taxable,
				
			);
			$data2 = array(
				'purchase_detail_id'=>	$this->generator(15),
				'purchase_id'		=>	$purchase_id,
				'product_id'		=>	$product_id,
				'supplier_id'       =>  $this->input->post('supplier_id'),
				'quantity'			=>	$product_quantity,
				
				'rate'				=>	$product_rate,
				'mrp'				=>	$product_mrp, 
				'cgst_percentage'   =>  $product_cgst_percentage,
				'cgst_amount'       =>  $product_cgst_amount,
				'sgst_percentage'   =>  $product_sgst_percentage,
				'sgst_amount'       =>  $product_sgst_amount,		
				'discount'          =>  $product_discount,	
				'discount_amt'      =>  $total_discount,
				'total_amount'		=>	$total_amount,
				'taxable_amt'       =>  $total_taxable,
				
				'status'			=>	1
			);
		
			$value=$this->product_purchase_check($product_id,$purchase_id);
			if($value==0){
			  	   $this->purchase_entry_in_update($data2);
			}else{
					if(!empty($quantity))
			        {
				       $this->db->where('purchase_detail_id',$purchase_detail_id);
				       $this->db->update('product_purchase_details',$data1); 
			        }
			}
		}
		    $this->db->query("UPDATE product_purchase SET grand_total_amount ='".$grand_total_price."'  where purchase_id='".$purchase_id."' and supplier_id='".$this->input->post('supplier_id')."'");     
		    $this->db->query("UPDATE supplier_ledger SET amount ='".$grand_total_price."'  where transaction_id='".$purchase_id."' and supplier_id='".$this->input->post('supplier_id')."'");     			
		    
			$this->db->select('a.product_name, a.product_id');
		    $this->db->from('product_information a');
		    $this->db->join('product_purchase_details b','b.product_id = a.product_id');
		    $this->db->where('a.status',1);
		    $this->db->group_by('a.product_id');
		    $this->db->order_by('a.product_id','desc');
		   	$query = $this->db->get();
			foreach ($query->result() as $row) {
				$json_purchase[] = array('label'=>$row->product_name,'value'=>$row->product_id);
			}
			$cache_file = './my-assets/js/admin_js/json/purchase.json';
			$purchaseList = json_encode($json_purchase);
			file_put_contents($cache_file,$purchaseList);
		return true;
	}
	public function purchase_entry_in_update($data2)
	{
	  	$this->db->insert('product_purchase_details',$data2);
	
	}
	public function product_purchase_check($product_id,$purchase_id)
	{
	 $this->db->select('*');
	  $this->db->from('product_purchase_details');
	  $this->db->where('product_id',$product_id);
	  $this->db->where('purchase_id',$purchase_id);	
	  $query = $this->db->get();
		if ($query->num_rows() > 0) {
			return true;	
		}
		return 0;
	}
	// Delete purchase Item
	public function delete_purchase_details($purchase_id)
	{
		//Delete product_purchase_details table
		$this->db->where('purchase_id',$purchase_id);
		$this->db->delete('product_purchase_details');
		return true;
	}
	public function delete_purchase($purchase_id)
	{
		//Delete product_purchase table
		$this->db->where('purchase_id',$purchase_id);
		$this->db->delete('product_purchase'); 
		//Delete product_purchase_details table
		$this->db->where('purchase_id',$purchase_id);
		$this->db->delete('product_purchase_details');
			$this->db->select('a.product_name, a.product_id');
		    $this->db->from('product_information a');
		    $this->db->join('product_purchase_details b','b.product_id = a.product_id');
		    $this->db->where('a.status',1);
		    $this->db->group_by('a.product_id');
		    $this->db->order_by('b.expire_date','desc');
		   	$query = $this->db->get();
			foreach ($query->result() as $row) {
				$json_purchase[] = array('label'=>$row->product_name,'value'=>$row->product_id);
			}
			$cache_file = './my-assets/js/admin_js/json/purchase.json';
			$purchaseList = json_encode($json_purchase);
			file_put_contents($cache_file,$purchaseList);
		return true;
	}
	public function purchase_search_list($cat_id,$company_id)
	{
		$this->db->select('a.*,b.sub_category_name,c.category_name');
		$this->db->from('purchases a');
		$this->db->join('purchase_sub_category b','b.sub_category_id = a.sub_category_id');
		$this->db->join('purchase_category c','c.category_id = b.category_id');
		$this->db->where('a.sister_company_id',$company_id);
		$this->db->where('c.category_id',$cat_id);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}
	//Retrieve purchase_details_data
	public function purchase_details_data($purchase_id)
	{
		$this->db->select('a.*,b.*,c.*,e.purchase_details,d.product_id,d.product_name');
		$this->db->from('product_purchase a');
		$this->db->join('supplier_information b','b.supplier_id = a.supplier_id');
		$this->db->join('product_purchase_details c','c.purchase_id = a.purchase_id');
		$this->db->join('product_information d','d.product_id = c.product_id');
		$this->db->join('product_purchase e','e.purchase_id = c.purchase_id');
		$this->db->where('a.purchase_id',$purchase_id);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}
	
	//This function will check the product & supplier relationship.
	public function product_supplier_check($product_id,$supplier_id)
	{
	 $this->db->select('*');
	  $this->db->from('product_information');
	  $this->db->where('product_id',$product_id);
	  $this->db->where('supplier_id',$supplier_id);	
	  $query = $this->db->get();
		if ($query->num_rows() > 0) {
			return true;	
		}
		return 0;
	}
	//This function is used to Generate Key
	public function generator($lenth)
	{
		$number=array("A","B","C","D","E","F","G","H","I","J","K","L","N","M","O","P","Q","R","S","U","V","T","W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","1","2","3","4","5","6","7","8","9","0");
	
		for($i=0; $i<$lenth; $i++)
		{
			$rand_value=rand(0,61);
			$rand_number=$number["$rand_value"];
		
			if(empty($con))
			{ 
			$con=$rand_number;
			}
			else
			{
			$con="$con"."$rand_number";}
		}
		return $con;
	}
}