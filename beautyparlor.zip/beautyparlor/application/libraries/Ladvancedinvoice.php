<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Ladvancedinvoice {
	
	//Retrieve  Advancedinvoice List
	public function advancedinvoice_list()
	{
		$CI =& get_instance();
		$CI->load->model('Advancedinvoices');
		$CI->load->model('Web_settings');
                $CI->load->model('Groups');  
		$CI->load->library('occational');
                $CI->load->model('Companies');
                
                $page = 0;
		$limit = 0;
	        $c = $CI->Companies->company_list($limit, $page);
		if($CI->input->post('company_id') > 0){
                     $company_id=$CI->input->post('company_id');
                     $company_detail = $CI->Companies->getCompanyById($company_id);
                }else{
                     $company_id=0; 
                     $company_detail="";
                }       
		 $gid= $CI->session->userdata('group_id'); 
		$advancedinvoices_list = $CI->Advancedinvoices->advancedinvoice_list($company_id);

		if(!empty($advancedinvoices_list)){
			foreach($advancedinvoices_list as $k=>$v){
				$advancedinvoices_list[$k]['final_date'] = $CI->occational->dateConvert($advancedinvoices_list[$k]['date']);
			}
			$i=0;
			foreach($advancedinvoices_list as $k=>$v){$i++;
			   $advancedinvoices_list[$k]['sl']=$i;
			}
		}
		$currency_details = $CI->Web_settings->retrieve_setting_editdata();
                 $gid= $CI->session->userdata('group_id'); 
                $uid= $CI->session->userdata('user_id');  
    
      
                $gp = $CI->Groups->get_group_by_name_id('admin', $uid, $gid);
                if($gp[0]["name"]=='admin'){
                   $update=1; 
                   $delete=1; 

                }else{
                   $update=$CI->Groups->checkPermissions($gid, 'advancedinvoice-edit'); 
                   $delete=$CI->Groups->checkPermissions($gid, 'advancedinvoice-delete'); 

                } 
               
                if($company_detail != ""){
                $data = array(
				'title' => 'Advanced Invoice List',
				'invoices_list' => $advancedinvoices_list,
                                 'company_list' => $c ,
                                'company_id' => $company_id,
 'g_id' => $gid,
                                 'c_name'                => $company_detail[0]['company_name'], 
				'currency' => $currency_details[0]['currency'],
				'position' => $currency_details[0]['currency_position'],
                                 'update' => $update,
                                'delete' => $delete, 
			);
 
                }else{

		$data = array(
				'title' => 'Advanced Invoice List',
				'invoices_list' => $advancedinvoices_list,
                                 'company_list' => $c ,
                                'company_id' => $company_id,
 'g_id' => $gid,
                                 'c_name'                => '', 
				'currency' => $currency_details[0]['currency'],
				'position' => $currency_details[0]['currency_position'],
                                 'update' => $update,
                                'delete' => $delete, 
			);
                 }    

		$advancedinvoiceList = $CI->parser->parse('advancedinvoice/advancedinvoice',$data,true);
		return $advancedinvoiceList;
	}
	public function wholesale_return_list()
	{
		$CI =& get_instance();
		$CI->load->model('Advancedinvoices');
		$CI->load->model('Web_settings');
                $CI->load->model('Groups');  
		$CI->load->library('occational');
		
		$advancedinvoices_list = $CI->Advancedinvoices->wholesale_return_list();

		if(!empty($advancedinvoices_list)){
			
			$i=0;
			foreach($advancedinvoices_list as $k=>$v){$i++;
			   $advancedinvoices_list[$k]['sl']=$i;
			}
		}
		$currency_details = $CI->Web_settings->retrieve_setting_editdata();

		$data = array(
				'title' => 'Wholesale Return List',
				'invoices_list' => $advancedinvoices_list,
				'currency' => $currency_details[0]['currency'],
				'position' => $currency_details[0]['currency_position']
			);

		$advancedinvoiceList = $CI->parser->parse('advancedinvoice/wholesale_return',$data,true);
		return $advancedinvoiceList;
	}
	//Pos advancedinvoice add form
	public function pos_advancedinvoice_add_form()
	{
		$CI =& get_instance();
		$CI->load->model('Advancedinvoices');
		$customer_details = $CI->Advancedinvoices->pos_customer_setup();
	
		$data = array(
				'title' => 'Add advancedinvoice',
				'customer_name' => $customer_details[0]['customer_name'],
				'customer_id' => $customer_details[0]['customer_id']
			);
		$advancedinvoiceForm = $CI->parser->parse('advancedinvoice/add_pos_advancedinvoice_form',$data,true);
		return $advancedinvoiceForm;
	}
	//Retrieve  Advancedinvoice List
	public function search_inovoice_item($customer_id)
	{
		$CI =& get_instance();
		$CI->load->model('Advancedinvoices');
		$CI->load->library('occational');
		$advancedinvoices_list = $CI->Advancedinvoices->search_inovoice_item($customer_id);
		if(!empty($advancedinvoices_list)){
			foreach($advancedinvoices_list as $k=>$v){
				$advancedinvoices_list[$k]['final_date'] = $CI->occational->dateConvert($advancedinvoices_list[$k]['date']);
			}
			$i=0;
			foreach($advancedinvoices_list as $k=>$v){$i++;
			   $advancedinvoices_list[$k]['sl']=$i;
			}
		}
		$data = array(
				'title' => 'Advancedinvoices Search Item',
				'advancedinvoices_list' => $advancedinvoices_list
			);
		$advancedinvoiceList = $CI->parser->parse('advancedinvoice/advancedinvoice',$data,true);
		return $advancedinvoiceList;
	}
	//Sub Category Add
	public function advancedinvoice_add_form()
	{
		$CI =& get_instance();
		$CI->load->model('Advancedinvoices');
		$CI->load->model('Settings');
		$bank_list = $CI->Settings->get_bank_list( );
		$data = array(
				'title' => 'Add New Advanced Invoice',
				'bank_list' => $bank_list
			);

		$advancedinvoiceForm = $CI->parser->parse('advancedinvoice/add_advancedinvoice_form',$data,true);
		return $advancedinvoiceForm;
	}
	public function wholesale_return_add_form()
	{
		$CI =& get_instance();
		$CI->load->model('Advancedinvoices');
	
		$data = array(
				'title' => 'Add Wholesale Return Form',
				
			);
		$purchaseForm = $CI->parser->parse('advancedinvoice/add_return_wholesale',$data,true);
		return $purchaseForm;
	}
	public function insert_advancedinvoice($data)
	{
		$CI =& get_instance();
		$CI->load->model('Advancedinvoices');
        $CI->Advancedinvoices->advancedinvoice_entry($data);
		return true;
	}
	//advancedinvoice Edit Data
	public function advancedinvoice_edit_data($advancedinvoice_id)
	{
		$CI =& get_instance();
		$CI->load->model('Advancedinvoices');
		$advancedinvoice_detail = $CI->Advancedinvoices->retrieve_advancedinvoice_editdata($advancedinvoice_id);
	
		$i=0;
		foreach($advancedinvoice_detail as $k=>$v){$i++;
		   $advancedinvoice_detail[$k]['sl']=$i;
		}

		$data=array(
			'advancedinvoice_id'		=>	$advancedinvoice_detail[0]['advancedinvoice_id'],
			'customer_id'		=>	$advancedinvoice_detail[0]['customer_id'],
			'customer_name'		=>	$advancedinvoice_detail[0]['customer_name'],
			'date'				=>	$advancedinvoice_detail[0]['date'],
			'total_amount'		=>	$advancedinvoice_detail[0]['total_amount'],
			'paid_amount'		=>	$advancedinvoice_detail[0]['paid_amount'],
			'due_amount'		=>	$advancedinvoice_detail[0]['due_amount'],
			'tax'				=>	$advancedinvoice_detail[0]['tax'],
			'total_tax'			=>	$advancedinvoice_detail[0]['total_tax'],
			'total_cgst'			=>	$advancedinvoice_detail[0]['total_cgst'],
			'total_sgst'			=>	$advancedinvoice_detail[0]['total_sgst'],
			'cgst'			=>	$advancedinvoice_detail[0]['cgst'],
			'sgst'			=>	$advancedinvoice_detail[0]['sgst'],
			'cgst_per'			=>	$advancedinvoice_detail[0]['cgst_per'],
			'sgst_per'			=>	$advancedinvoice_detail[0]['sgst_per'],
			
			'advancedinvoice_all_data'	=>	$advancedinvoice_detail
			);
		$chapterList = $CI->parser->parse('advancedinvoice/edit_advancedinvoice_form',$data,true);
		return $chapterList;
	}
	//advancedinvoice html Data
	public function advancedinvoice_html_data($advancedinvoice_id)
	{
		$CI =& get_instance();
		$CI->load->model('Advancedinvoices');
		$CI->load->model('Web_settings');
		$CI->load->library('occational');
		$advancedinvoice_detail = $CI->Advancedinvoices->retrieve_advancedinvoice_html_data($advancedinvoice_id);

		$subTotal_quantity = 0;
		$subTotal_free = 0;
		$subTotal_cartoon = 0;
		$subTotal_discount = 0;
		$discount =0;
		$tot_rate=0;
		$tot_taxable=0;
		if(!empty($advancedinvoice_detail)){
			foreach($advancedinvoice_detail as $k=>$v){
				$advancedinvoice_detail[$k]['final_date'] = $CI->occational->dateConvert($advancedinvoice_detail[$k]['date']);
				
				$subTotal_quantity = $subTotal_quantity+$advancedinvoice_detail[$k]['quantity'];
				$subTotal_cartoon = $subTotal_cartoon+$advancedinvoice_detail[$k]['cartoon'];
				$subTotal_discount = $subTotal_discount+$advancedinvoice_detail[$k]['discount'];
				$tot_taxable = $tot_taxable + $advancedinvoice_detail[$k]['taxable_amt'];
				
				$tot_rate = $tot_rate+$advancedinvoice_detail[$k]['tot_rate'];
				
				$discount = $discount + ($advancedinvoice_detail[$k]['tot_rate'] * $advancedinvoice_detail[$k]['quantity'] * $advancedinvoice_detail[$k]['discount']) / 100;
				
			}
			
			$i=0;
			foreach($advancedinvoice_detail as $k=>$v){$i++;
			   $advancedinvoice_detail[$k]['sl']=$i;
			}
		}
		$currency_details = $CI->Web_settings->retrieve_setting_editdata();
		$company_info = $CI->Advancedinvoices->retrieve_company();
		$data=array(
			'advancedinvoice_id'=>	$advancedinvoice_detail[0]['advancedinvoice_id'],
			'advancedinvoice_no'=>	$advancedinvoice_detail[0]['invoice'],
			'customer_name'		=>	$advancedinvoice_detail[0]['customer_name'],
			'customer_address'	=>	$advancedinvoice_detail[0]['customer_address'],
			'customer_mobile'	=>	$advancedinvoice_detail[0]['customer_mobile'],
			'customer_email'	=>	$advancedinvoice_detail[0]['customer_email'],
			'final_date'		=>	$advancedinvoice_detail[0]['final_date'],
			'total_amount'		=>	$advancedinvoice_detail[0]['total_amount'],
			'customer_gst_no'		    =>	$advancedinvoice_detail[0]['gst_no'],
			'customer_drug_license'		=>	$advancedinvoice_detail[0]['drug_license'],
			'customer_pan_no'		    =>	$advancedinvoice_detail[0]['pan_no'],
			'subTotal_cartoon'	=>	$subTotal_cartoon,
			'subTotal_discount'	=>	$discount,
			'tax'				=>	$advancedinvoice_detail[0]['tax'],
			'total_tax'			=>	$advancedinvoice_detail[0]['tax'],
			'total_cgst'		=>	$advancedinvoice_detail[0]['total_cgst'],
			'total_sgst'		=>	$advancedinvoice_detail[0]['total_sgst'],
			'cgst'			    =>	$advancedinvoice_detail[0]['cgst'],
			'sgst'			    =>	$advancedinvoice_detail[0]['sgst'],
			'cgst_per'			=>	$advancedinvoice_detail[0]['cgst_per'],
			'sgst_per'			=>	$advancedinvoice_detail[0]['sgst_per'],
			'gross_total'       => $tot_rate,
			'taxable_amount'    => $tot_rate - $discount,
			'tot_taxable'    => $tot_taxable,
			'payment_method' => $advancedinvoice_detail[0]['payment_method'],
			'paid_amount'		=>	$advancedinvoice_detail[0]['paid_amount'],
			'due_amount'		=>	$advancedinvoice_detail[0]['due_amount'],
			'subTotal_quantity'	=>	$subTotal_quantity,
			'advancedinvoice_all_data'	=>	$advancedinvoice_detail,
			'company_info'	    =>	$company_info,
			'currency' => $currency_details[0]['currency'],
			'position' => $currency_details[0]['currency_position'],
			);
			
		$chapterList = $CI->parser->parse('advancedinvoice/advancedinvoice_html',$data,true);
		return $chapterList;
	}
	public function p_html_data($advancedinvoice_id)
	{
		$CI =& get_instance();
		$CI->load->model('Advancedinvoices');
		$CI->load->model('Web_settings');
		$CI->load->library('occational');
		$advancedinvoice_detail = $CI->Advancedinvoices->retrieve_advancedinvoice_html_data($advancedinvoice_id);

		$subTotal_quantity = 0;
		$subTotal_free = 0;
		$subTotal_cartoon = 0;
		$subTotal_discount = 0;
		$discount =0;
		$tot_rate=0;
		if(!empty($advancedinvoice_detail)){
			foreach($advancedinvoice_detail as $k=>$v){
				$advancedinvoice_detail[$k]['final_date'] = $CI->occational->dateConvert($advancedinvoice_detail[$k]['date']);
				$advancedinvoice_detail[$k]['expire_date'] = date('d-m-y',strtotime($advancedinvoice_detail[$k]['expire_date']));
				$subTotal_quantity = $subTotal_quantity+$advancedinvoice_detail[$k]['quantity'];
				$subTotal_cartoon = $subTotal_cartoon+$advancedinvoice_detail[$k]['cartoon'];
				$subTotal_discount = $subTotal_discount+$advancedinvoice_detail[$k]['discount'];
				
				$tot_rate = $tot_rate+$advancedinvoice_detail[$k]['tot_rate'];
				
				$discount = $discount + ($advancedinvoice_detail[$k]['tot_rate'] * $advancedinvoice_detail[$k]['quantity'] * $advancedinvoice_detail[$k]['discount']) / 100;
				
			}
			
			$i=0;
			foreach($advancedinvoice_detail as $k=>$v){$i++;
			   $advancedinvoice_detail[$k]['sl']=$i;
			}
		}
		$currency_details = $CI->Web_settings->retrieve_setting_editdata();
		$company_info = $CI->Advancedinvoices->retrieve_company();
		$data=array(
			'advancedinvoice_id'=>	$advancedinvoice_detail[0]['advancedinvoice_id'],
			'advancedinvoice_no'=>	$advancedinvoice_detail[0]['invoice'],
			'customer_name'		=>	$advancedinvoice_detail[0]['customer_name'],
			'customer_address'	=>	$advancedinvoice_detail[0]['customer_address'],
			'customer_mobile'	=>	$advancedinvoice_detail[0]['customer_mobile'],
			'customer_email'	=>	$advancedinvoice_detail[0]['customer_email'],
			'final_date'		=>	$advancedinvoice_detail[0]['final_date'],
			'total_amount'		=>	$advancedinvoice_detail[0]['total_amount'],
			'gst_no'		    =>	$advancedinvoice_detail[0]['gst_no'],
			'drug_license'		=>	$advancedinvoice_detail[0]['drug_license'],
			'pan_no'		    =>	$advancedinvoice_detail[0]['pan_no'],
			'subTotal_cartoon'	=>	$subTotal_cartoon,
			'subTotal_discount'	=>	$discount,
			'tax'				=>	$advancedinvoice_detail[0]['tax'],
			'total_tax'			=>	$advancedinvoice_detail[0]['tax'],
			'total_cgst'		=>	$advancedinvoice_detail[0]['total_cgst'],
			'total_sgst'		=>	$advancedinvoice_detail[0]['total_sgst'],
			'cgst'			    =>	$advancedinvoice_detail[0]['cgst'],
			'sgst'			    =>	$advancedinvoice_detail[0]['sgst'],
			'cgst_per'			=>	$advancedinvoice_detail[0]['cgst_per'],
			'sgst_per'			=>	$advancedinvoice_detail[0]['sgst_per'],
			'gross_total'       => $tot_rate,
			'taxable_amount'    => $tot_rate - $discount,
			'paid_amount'		=>	$advancedinvoice_detail[0]['paid_amount'],
			'due_amount'		=>	$advancedinvoice_detail[0]['due_amount'],
			'subTotal_quantity'	=>	$subTotal_quantity,
			'advancedinvoice_all_data'	=>	$advancedinvoice_detail,
			'company_info'	    =>	$company_info,
			'currency' => $currency_details[0]['currency'],
			'position' => $currency_details[0]['currency_position'],
			);
			
		$chapterList = $CI->parser->parse('advancedinvoice/p',$data,true);
		return $chapterList;
	}

	//POS advancedinvoice html Data
	public function pos_advancedinvoice_html_data($advancedinvoice_id)
	{
		$CI =& get_instance();
		$CI->load->model('Advancedinvoices');
		$CI->load->model('Web_settings');
		$CI->load->library('occational');
		$advancedinvoice_detail = $CI->Advancedinvoices->retrieve_advancedinvoice_html_data($advancedinvoice_id);
		$subTotal_quantity = 0;
		$subTotal_cartoon = 0;
		$subTotal_discount = 0;
		if(!empty($advancedinvoice_detail)){
			foreach($advancedinvoice_detail as $k=>$v){
				$advancedinvoice_detail[$k]['final_date'] = $CI->occational->dateConvert($advancedinvoice_detail[$k]['date']);
				$subTotal_quantity = $subTotal_quantity+$advancedinvoice_detail[$k]['quantity'];
				$subTotal_cartoon = $subTotal_cartoon+$advancedinvoice_detail[$k]['cartoon'];
				$subTotal_discount = $subTotal_discount+$advancedinvoice_detail[$k]['discount'];
			}
			$i=0;
			foreach($advancedinvoice_detail as $k=>$v){$i++;
			   $advancedinvoice_detail[$k]['sl']=$i;
			}
		}
		$currency_details = $CI->Web_settings->retrieve_setting_editdata();
		$company_info = $CI->Advancedinvoices->retrieve_company();
		$data=array(
			'advancedinvoice_id'		=>	$advancedinvoice_detail[0]['advancedinvoice_id'],
			'advancedinvoice_no'		=>	$advancedinvoice_detail[0]['advancedinvoice'],
			'customer_name'		=>	$advancedinvoice_detail[0]['customer_name'],
			'customer_address'	=>	$advancedinvoice_detail[0]['customer_address'],
			'customer_mobile'	=>	$advancedinvoice_detail[0]['customer_mobile'],
			'customer_email'	=>	$advancedinvoice_detail[0]['customer_email'],
			'final_date'		=>	$advancedinvoice_detail[0]['final_date'],
			'total_amount'		=>	$advancedinvoice_detail[0]['total_amount'],
			'subTotal_cartoon'	=>	$subTotal_cartoon,
			'subTotal_discount'	=>	$subTotal_discount,
			'tax'				=>	$advancedinvoice_detail[0]['tax'],
			'paid_amount'		=>	$advancedinvoice_detail[0]['paid_amount'],
			'due_amount'		=>	$advancedinvoice_detail[0]['due_amount'],
			'subTotal_quantity'	=>	$subTotal_quantity,
			'advancedinvoice_all_data'	=>	$advancedinvoice_detail,
			'company_info'	=>	$company_info,
			'currency' => $currency_details[0]['currency'],
			'position' => $currency_details[0]['currency_position'],
			);
		$chapterList = $CI->parser->parse('advancedinvoice/pos_advancedinvoice_html',$data,true);
		return $chapterList;
	}
}
?>