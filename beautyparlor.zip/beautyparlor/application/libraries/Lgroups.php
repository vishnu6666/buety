<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Lgroups {
	#===============Bank list============#
	public function permission_list($id)
	{
		$CI =& get_instance();
		$CI->load->model('Groups');
		$permission_list = $CI->Groups->get_group_permissions($id);

		$i=0;
		if(!empty($permission_list)){		
			foreach($permission_list as $k=>$v){$i++;
			   $permission_list[$k]['sl']=$i;
			}
		}

		$data = array(
				'title' => 'User Groups',
				'permission_list' => $permission_list
			);
		$groupList = $CI->parser->parse('groups/permissions',$data,true);
		return $groupList;
	}
        public function group_list()
	{
		$CI =& get_instance();
		$CI->load->model('Groups');
		$group_list = $CI->Groups->get_group_list( );
		$i=0;
		if(!empty($group_list)){		
			foreach($group_list as $k=>$v){$i++;
			   $group_list[$k]['sl']=$i;
			}
		}
		$data = array(
				'title' => 'User Groups',
				'group_list' => $group_list
			);
		$groupList = $CI->parser->parse('groups/group',$data,true);
		return $groupList;
	}
	#=============Bank show by id=======#
	public function group_show_by_id($group_id){
		$CI =& get_instance();
		$CI->load->model('Groups');
		$group_list = $CI->Groups->get_group_by_id($group_id);
		$data = array(
				'title' => 'Edit User Group',
				'group_list' => $group_list
			);
		$groupList = $CI->parser->parse('groups/edit_group',$data,true);
		return $groupList;
	}
	#=============Bank Update by id=======#
	public function group_update_by_id($group_id){
		$CI =& get_instance();
		$CI->load->model('Groups');
		$group_list = $CI->Groups->group_update_by_id($group_id);
		return true;
	}
      
	
}
?>