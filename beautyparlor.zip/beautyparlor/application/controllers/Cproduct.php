<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Cproduct extends CI_Controller {
	
	public $product_id;
	function __construct() {
      parent::__construct();
	  
	  $this->template->current_menu = 'product';

    }
    //Index page load
	public function index()
	{	
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lproduct');
		$content = $CI->lproduct->product_add_form();
		$this->template->full_admin_html_view($content);
	}
	    public function add_manufacture()
	{	
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lproduct');
		$content = $CI->lproduct->manufacture_add_form();
		$this->template->full_admin_html_view($content);
	}
       public function add_product_mapping()
	{	
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lproduct');
		$content = $CI->lproduct->product_mapping_add_form();
		$this->template->full_admin_html_view($content);
	}
  public function manage_manufacture()
	{	
	
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->library('lproduct');
		$CI->load->model('Products');
        $content = $CI->lproduct->manufacture_list();
		$this->template->full_admin_html_view($content);
	
	}

       public function manage_product_mapping()
	{	
	
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->library('lproduct');
		$CI->load->model('Products');
                $content = $CI->lproduct->product_mapping_list();
		$this->template->full_admin_html_view($content);
	
	}
        //Insert Product and uload
	public function insert_manufacture()
	{
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lproduct');		

		$data=array(
			'product_id' 			=> $this->input->post('product_id'),
			'quantity' 			=> $this->input->post('quantity')		
			);

		$result=$CI->lproduct->insert_manufacture($data);
		$this->session->set_userdata(array('message'=>display('successfully_added')));
		if(isset($_POST['add-product'])){
			redirect(base_url('Cproduct/manage_manufacture'));
			exit;
		}elseif(isset($_POST['add-product-another'])){
			redirect(base_url('Cproduct/add_manufacture'));
			exit;
		}
		
	}
        public function insert_product_mapping()
	{
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lproduct');		
                $today = date('Y-m-d');
		$data=array(
			'product_id' 			=> $this->input->post('product_id'),
                        'price' 			=> $this->input->post('price'),
			'quantity' 			=> $this->input->post('quantity'),
                        'dateadded' => $today 		
			);

		$result=$CI->lproduct->insert_product_mapping();
		$this->session->set_userdata(array('message'=>display('successfully_added')));
		if(isset($_POST['add-product'])){
			redirect(base_url('Cproduct/manage_product_mapping'));
			exit;
		}elseif(isset($_POST['add-product-another'])){
			redirect(base_url('Cproduct/add_product_mapping'));
			exit;
		}
		
	}
        public function update_product_mapping()
	{
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lproduct');		
$CI->load->model('Products');
		
                $product_id=$this->input->post('product_id');
                $result = $CI->Products->update_product_mapping($product_id);
		if ($result == true) {
			$this->session->set_userdata(array('message'=>display('successfully_updated')));
			redirect(base_url('Cproduct/manage_product_mapping'));
		}else{
			$this->session->set_userdata(array('error_message'=>display('product_model_already_exist')));
			redirect(base_url('Cproduct/add_product_mapping'));
		}

		
		
		
	}
        public function update_manufacture()
	{
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lproduct');		
$CI->load->model('Products');
		
               $id=$this->input->post('id');
                $result = $CI->Products->update_manufacture($id);
		if ($result == true) {
			$this->session->set_userdata(array('message'=>display('successfully_updated')));
			redirect(base_url('Cproduct/manage_manufacture'));
		}else{
			$this->session->set_userdata(array('error_message'=>display('product_model_already_exist')));
			redirect(base_url('Cproduct/add_manufacture'));
		}

		
		
		
	}
            public function product_mapping_update_form($product_id)
	{	
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lproduct');
		$content = $CI->lproduct->product_mapping_edit_data($product_id);
		$this->template->full_admin_html_view($content);
	} 

	//Product Update Form
        public function manufacture_update_form($id)
	{	
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lproduct');
		$content = $CI->lproduct->manufacture_edit_data($id);
		$this->template->full_admin_html_view($content);
	}	
	//Product Add Form
	public function manage_product()
	{	
	
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->library('lproduct');
		$CI->load->model('Products');
        $content = $CI->lproduct->product_list();
		$this->template->full_admin_html_view($content);
	
	}
	public function insert_product()
	{
		$CI =& get_instance();
		$CI->load->model('Categories');
		$CI->auth->check_admin_auth();
		$CI->load->library('lproduct');


		$price = $this->input->post('price');
		
		$tax_percentage = $this->input->post('tax');
		$sgst_percentage = $this->input->post('sgst');
		$tax = ($price * $tax_percentage)/100;
		$sgst = ($price * $sgst_percentage)/100;
		
		$cgst_ptr = ($price * $tax_percentage)/100;
		$sgst_ptr = ($price * $sgst_percentage)/100;
		
		$c_id = $this->input->post('category_id');
		$category_id = $this->generator(8);
		if($c_id == 333)
		{
		$category_id = $category_id;
		
		$data=array(
			'category_name' 		=>$this->input->post('category_name'),
			'category_id' 			=>$category_id,
			'status' 			=> 1
			);
		$result=$this->Categories->category_entry($data);
		}
		else
		{
		$category_id = $this->input->post('category_id');
		}

		$data=array(
			'product_id' 			=> $this->generator(8),
			'product_name' 			=> $this->input->post('product_name'),
			'category_id' 			=> $category_id,
			'price' 			=> $price,	
			'supplier_price' 		=> $this->input->post('supplier_price'),
			'cgst_per' 			=> $this->input->post('tax'),
			'sgst_per' 			=> $this->input->post('sgst'),
			'tax'				=> $tax,
			'sgst'				=> $sgst,
			'cgst_ptr'			=> $cgst_ptr,
			'sgst_ptr'			=> $sgst_ptr,
			'product_details' 		=> $this->input->post('description'),
			//'image' 			=> (!empty($image_url)?$image_url:null),
			'status' 			=> 1
			);

			

		$result=$CI->lproduct->insert_product($data);
		if ($result == 1) {
			$this->session->set_userdata(array('message'=>display('successfully_added')));
			if(isset($_POST['add-product'])){
				redirect(base_url('Cproduct/manage_product'));
				exit;
			}elseif(isset($_POST['add-product-another'])){
				redirect(base_url('Cproduct'));
				exit;
			}
		}else{
			$this->session->set_userdata(array('error_message'=>display('product_model_already_exist')));
			redirect(base_url('Cproduct'));
		}
	}
	
	//Product Update Form
	public function product_update_form($product_id)
	{	
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lproduct');
		$content = $CI->lproduct->product_edit_data($product_id);
		$this->template->full_admin_html_view($content);
	}
	// Product Update
	public function product_update()
	{
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->model('Products');

		$product_id  = $this->input->post('product_id');
		if ($_FILES['image']['name']) {
			//Chapter chapter add start
			$config['upload_path']          = './my-assets/image/product/';
	        $config['allowed_types']        = '*';
	        $config['max_size']             = "*";
	        $config['max_width']            = "*";
	        $config['max_height']           = "*";
	        $config['encrypt_name'] 		= TRUE;

	        $this->load->library('upload', $config);
	        if ( ! $this->upload->do_upload('image'))
	        {
	            $error = array('error' => $this->upload->display_errors());
	            $this->session->set_userdata(array('error_message'=> display('image_not_uploaded!')));
	            redirect(base_url('Cproduct'));
	        }
	        else
	        {
	        	$image =$this->upload->data();
	        	$old_image = $this->input->post('old_image');
	        	$image_url = base_url()."my-assets/image/product/".$image['file_name'];
	        }
		}
		$old_image = $this->input->post('old_image');
		
		$price = $this->input->post('price');
		
		$tax_percentage = $this->input->post('tax');
		$sgst_percentage = $this->input->post('sgst');
		$tax = ($price * $tax_percentage)/100;
		$sgst = ($price * $sgst_percentage)/100;
		
		$cgst_ptr = ($price * $tax_percentage)/100;
		$sgst_ptr = ($price * $sgst_percentage)/100;
		
	//	$d = $this->input->post('dd');
	//	$m = $this->input->post('mm');
//		$y = $this->input->post('yy');
//		$expire_date=$y.'-'.$m.'-'.$d;
		
		$data=array(
			'product_name' 			=> $this->input->post('product_name'),		
                        'product_type' 			=> $this->input->post('product_type'),
			'mfg' 			        => $this->input->post('mfg'),
			'pack' 			        => $this->input->post('pack'),			
			'supplier_id' 			=> $this->input->post('supplier_id'),
			'category_id' 			=> $this->input->post('category_id'),
			'price' 				=> $this->input->post('price'),
			
			'supplier_price' 		=> $this->input->post('supplier_price'),			
			'product_details' 		=> $this->input->post('description'),
			'cgst_per' 		        => $this->input->post('tax'),
			'sgst_per' 		        => $this->input->post('sgst'),
			'tax'					=> $tax,
			'sgst'					=> $sgst,		
			'cgst_ptr'					=> $cgst_ptr,
			'sgst_ptr'					=> $sgst_ptr,
			'generic_name' 			=> $this->input->post('generic_name'),			
			'product_location' 		=> $this->input->post('product_location'),
			'image' 				=> (!empty($image_url)?$image_url:$old_image),
			'status' 				=> 1
		);
		
		$result = $CI->Products->update_product($data,$product_id);
		if ($result == true) {
			$this->session->set_userdata(array('message'=>display('successfully_updated')));
			redirect(base_url('Cproduct/manage_product'));
		}else{
			$this->session->set_userdata(array('error_message'=>display('product_model_already_exist')));
			redirect(base_url('Cproduct/manage_product'));
		}
	}
	// product_delete
	public function product_delete()
	{	
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->model('Products');
		$product_id =  $_POST['product_id'];
		$result=$CI->Products->delete_product($product_id);
		return true;
			
	}
	     public function manufacture_delete()
	{	
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->model('Products');
		$id =  $_POST['product_id'];
		$result=$CI->Products->delete_manufacture($id);
		return true;
			
	}
	//Retrieve Single Item  By Search
	public function product_by_search()
	{
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->library('lproduct');
		$product_id = $this->input->post('product_id');		
        $content = $CI->lproduct->product_search_list($product_id);
        $sub_menu = array(
				array('label'=> 'Manage Product', 'url' => 'Cproduct', 'class' =>'active'),
				array('label'=> 'Add Product', 'url' => 'Cproduct/manage_product')
			);
		$this->template->full_admin_html_view($content,$sub_menu);
	}
	//Retrieve Single Item  By Search
	public function product_details($product_id)
	{
		$this->product_id=$product_id;
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->library('lproduct');	
        $content = $CI->lproduct->product_details($product_id);
		$this->template->full_admin_html_view($content);
	}
	
	//Retrieve Single Item  By Search
	public function product_sales_supplier_rate($product_id=null,$startdate=null,$enddate=null)
	{
		if($startdate==null){$startdate= date('Y-m-d',strtotime('-30 days'));}
		if($enddate==null){$enddate= date('Y-m-d');}
		$product_id_input=$this->input->post('product_id');
		if(!empty($product_id_input))
			{
				$product_id=$this->input->post('product_id');
				$startdate=$this->input->post('from_date');
				$enddate=$this->input->post('to_date');
			}
		
		$this->product_id=$product_id;
		
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->library('lproduct');	
        $content = $CI->lproduct->product_sales_supplier_rate($product_id,$startdate,$enddate);
		$this->template->full_admin_html_view($content);
	}

	//This function is used to Generate Key
	public function generator($lenth)
	{
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->model('Products');

		$number=array("1","2","3","4","5","6","7","8","9","0");
		for($i=0; $i<$lenth; $i++)
		{
			$rand_value=rand(0,8);
			$rand_number=$number["$rand_value"];
		
			if(empty($con))
			{ 
				$con=$rand_number;
			}
			else
			{
				$con="$con"."$rand_number";
			}
		}

		$result = $this->Products->product_id_check($con);

		if ($result === true) {
			$this->generator(8);
		}else{
			return $con;
		}
	}
	public function retrieve_product_purchase_data()
	{	

		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->model('Products');
		$product_id = $this->input->post('product_id');
		$product_info = $CI->Products->retrieve_product_purchase_data($product_id);
		echo json_encode($product_info);
	}
	public function transfer_products(){
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lproduct');
		$content = $CI->lproduct->transfer_product_form();
		$this->template->full_admin_html_view($content);
		
		
	}	
	public function transfer_product_entry(){
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lproduct');		
		$today =date("Y-m-d");
        $data=array(
			'purchase_detail_id' 	=> $this->input->post('prid'),
			'company_id' 	=> $this->input->post('company_id'),
         	'quantity' 			    => $this->input->post('transfer_product_quantity'),
            'date_added'            => $today 		
			);

		$result=$CI->lproduct->insert_product_transfer($data);
		$this->session->set_userdata(array('message'=>display('successfully_added')));
		if(isset($_POST['add-product'])){
			redirect(base_url('Cproduct/manage_product_transfer'));
			exit;
		}elseif(isset($_POST['add-product-another'])){
			redirect(base_url('Cproduct/transfer_products'));
			exit;
		}
		
		
	}	
	public function manage_product_transfer()
	{	
	
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->library('lproduct');
		$CI->load->model('Products');
        $content = $CI->lproduct->product_transfer_list();
		$this->template->full_admin_html_view($content);
	
	}
}