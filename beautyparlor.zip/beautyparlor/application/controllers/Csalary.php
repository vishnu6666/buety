<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Csalary extends CI_Controller {
	
	function __construct() {
      parent::__construct();
	  $this->load->library('Lsalary');
	  $this->load->library('auth');
	  $this->load->library('session');
	  $this->load->model('Salary');
	  $this->auth->check_admin_auth();
	  $this->template->current_menu = 'Salary';

	   if ($this->session->userdata('user_type') == '2') {
            $this->session->set_userdata(array('error_message'=>display('you_are_not_access_this_part')));
            redirect('Admin_dashboard');
        }
    }
	
	public function index()
	{
		$CI =& get_instance();
		$CI->load->model('Userm');
        $CI->load->model('Groups');
        $CI->load->model('Companies');
                		
		$page = 0;
		$limit = 10;
		$group_id= 7;
	    $c = $CI->Companies->company_list($limit, $page);
	    $s = $CI->Userm->user_salary_list($group_id);
                  
		$data = array(
				'title' 			=> display('add_user'),
                'company_list' 		=> $c ,
 				'salary_list' 		=> $s 
			);
			

        $content = $this->parser->parse('salary/new_salary_book',$data,true);
		$this->template->full_admin_html_view($content);
	}
	#================Add salary book==============#
	public function add_salary_book()
	{ 
		$CI =& get_instance();
		$CI->load->model('Web_settings');

		$setting_detail = $CI->Web_settings->retrieve_setting_editdata();


			$late_comming_per	= $setting_detail[0]['late_comming'];
			$half_day_per		= $setting_detail[0]['half_day'];
			$leave_day_per	    = $setting_detail[0]['leave_day'];
			$over_time	    	= $setting_detail[0]['over_time'];
			$user_id			=	$this->input->post('staff');
			$CI->load->model('Salary');
			$salary_user 		= $CI->Salary->salary_by_user_id($user_id);
			$salary				= $salary_user[0]['salary'];
			$first_name			= $salary_user[0]['first_name'];
			$last_name			= $salary_user[0]['last_name'];


			$working_days		=	$this->input->post('working_days');
			$late_coming		=	$this->input->post('late_coming');
			$half_day			=	$this->input->post('half_day');
			$over_times			=	$this->input->post('over_time');
			$leave				=	$this->input->post('leave');
			$date				=	$this->input->post('date');
			$day=date('t');
//salary per day
			$perday_salary=$salary/$day;
			//echo $perday_salary;echo"<br>";

//over times 
			$overtime_total = ($over_time*$over_times);
//total leve
			$balance_deduct_for_leave=($perday_salary*$leave);
			$total_deduct_leave=($balance_deduct_for_leave*$leave_day_per)/100;
			//echo $total_deduct_leave;exit;
			
			
//total half day			
			$balance_deduct_for_halfday=($perday_salary*$half_day);
			$total_deduct_halfday=($balance_deduct_for_halfday*$half_day_per)/100;
			
//total latecomming
			//$balance_deduct_for_latecomming=($perday_salary*$late_coming);
			//$total_deduct_latecomming=($balance_deduct_for_latecomming*$late_comming_per)/100;
			
			$total_deduct_latecomming=($late_comming_per*$late_coming);
//total salary
			$total_salary=$salary-($total_deduct_leave+$total_deduct_halfday+$total_deduct_latecomming+$overtime_total);
			//echo $total_salary;echo "total_salary";

			$data=array(
				'user_id'							=>$user_id,
				'name'								=>$first_name." ".$last_name,
				'late_coming'						=>$late_coming,
				'over_times'						=>$over_times,
				'overtime_total'					=>$overtime_total,
				'half_day'							=>$half_day,
				'leave'								=>$leave,
				'balance_deduct_for_latecomming'	=>$total_deduct_latecomming,
				'balance_deduct_for_halfday'		=>$total_deduct_halfday,
				'balance_deduct_for_leave'			=>$total_deduct_leave,
				'monthly_salary'					=>$salary,
				'net_salary'						=>$total_salary,
				'date'		=>$date		
			);
			
		
		$invoice_id = $this->Salary->salary_book_entry($data);
		$this->session->set_userdata(array('message'=>display('successfully_added')));
		redirect(base_url('Csalary/manage_salary'));exit;
	}
	#==============salary list============#
	public function manage_salary()
	{
        $content = $this->lsalary->salary_user_list( );
		$this->template->full_admin_html_view($content);
	}

	#==============user salary details============#
	public function view_salary_statment($user_id)
	{

        $content = $this->lsalary->salary_user_details_list($user_id);
		$this->template->full_admin_html_view($content);




















		
	}
	#=============Bank edit==============#
	public function edit_bank($bank_id)
	{
        $content = $this->lsalary->bank_show_by_id($bank_id);
		$this->template->full_admin_html_view($content);
	}
	#============Update Bank=============#
	public function update_bank($bank_id)
	{
        $content = $this->lsalary->bank_update_by_id($bank_id);
        $this->session->set_userdata(array('message'=>display('successfully_updated')));
        redirect('Csalary/bank_list');
	}

	#==============Table list============#
	public function table_list()
	{
        $content = $this->lsalary->table_list( );
		$this->template->full_admin_html_view($content);
	}
	#===========Table Create============#
	public function table_create()
	{
			$data=array('title'=>display('add_new_account'));
			$content = $this->parser->parse('Salary/table_create',$data,true);
			$this->template->full_admin_html_view($content);
	} 
	#===========Table edit============#
	public function table_edit($account_id)
	{

			$table_data = $this->Salary->retrive_table_data($account_id);
			$data=array(
				'title'=> display('table_edit'),
				'account_name'=>$table_data[0]['account_name'],
				'account_id'=>$table_data[0]['account_id'],
				);
			$content = $this->parser->parse('Salary/table_edit',$data,true);
			$this->template->full_admin_html_view($content);
	} 

	#===========Table update============#
	public function update_account_data()
	{
		$account_id = $this->input->post('account_id');
		$data['account_name'] = $this->input->post('account_name');
		$table_data = $this->Salary->update_table_data($data,$account_id);
		
		$content = $this->lsalary->table_list( );
		$this->template->full_admin_html_view($content);
	}
	#==============Create account data============#
	public function create_account_data()
	{
		$id_generator=$this->auth->generator(10);
		$this->Salary->table_create($id_generator);
		redirect(base_url('Csalary/table_list'));exit;
	}
}