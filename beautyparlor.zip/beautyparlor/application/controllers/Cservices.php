<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Cservices extends CI_Controller {
	
	public $product_id;
	function __construct() {
      parent::__construct();
	  $this->load->model('Categories');
	  $this->template->current_menu = 'service';
    }
    //Index page load
	public function index()
	{	
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lservice');
		$content = $CI->lservice->services_add_form();
		$this->template->full_admin_html_view($content);
	}
	
	//service addAdd Form
	public function manage_services()
	{	
	
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->library('lservice');
		$CI->load->model('Services');
        	$content = $CI->lservice->services_list();
		$this->template->full_admin_html_view($content);
	
	}
	//Insert service and uload
	public function insert_services()
	{
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lservice');
		
		$price = $this->input->post('price');
		$tax_percentage = $this->input->post('tax');
		$sgst_percentage = $this->input->post('sgst');
		$tax = ($price * $tax_percentage)/100;
		$sgst = ($price * $sgst_percentage)/100;
		
		$cgst_ptr = ($price * $tax_percentage)/100;
		$sgst_ptr = ($price * $sgst_percentage)/100;
		
		$staff_id = $this->input->post('staff[]');
		$staff=implode(',',$staff_id);
		
		$c_id = $this->input->post('category_id');
		$category_id = $this->generator(8);
		if($c_id == 333)
		{
		$category_id = $category_id;
		
		$data=array(
			'category_name' 		=>$this->input->post('category_name'),
			'category_id' 			=>$category_id,
			'status' 			=> 1
			);
		$result=$this->Categories->category_entry($data);
		}
		else
		{
		$category_id = $this->input->post('category_id');
		}
		
		$data=array(
			'product_id' 			=> $this->generator(8),
			'services_name' 		=> $this->input->post('services_name'),
			'staff_id'			=> $staff,
			'category_id' 			=> $category_id,
			'price' 			=> $price,	
			'cgst_per' 			=> $this->input->post('tax'),
			'sgst_per' 			=> $this->input->post('sgst'),
			'tax'				=> $tax,
			'sgst'				=> $sgst,
			'cgst_ptr'			=> $cgst_ptr,
			'sgst_ptr'			=> $sgst_ptr,
			'services_details' 		=> $this->input->post('description'),
			//'image' 			=> (!empty($image_url)?$image_url:null),
			'status' 			=> 1
			);			
		$result=$CI->lservice->insert_service($data);
		if ($result == 1) {
			$this->session->set_userdata(array('message'=>display('successfully_added')));
			if(isset($_POST['add-product'])){
				redirect(base_url('Cservices/manage_services'));
				exit;
			}elseif(isset($_POST['add-service-another'])){
				redirect(base_url('Cservices'));
				exit;
			}
		}else{
			$this->session->set_userdata(array('error_message'=>display('product_model_already_exist')));
			redirect(base_url('Cservices'));
		}
	}
	//Product Update Form
	public function servis_update_form($product_id)
	{	
	
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lservice');
		$content = $CI->lservice->service_edit_data($product_id);
		$this->template->full_admin_html_view($content);
	}
	// Product Update
	public function service_update()
	{
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->model('Services');

		$service_id  = $this->input->post('product_id');
		
		$old_image = $this->input->post('old_image');
		
		$price = $this->input->post('price');
		
		$tax_percentage = $this->input->post('tax');
		$sgst_percentage = $this->input->post('sgst');
		$tax = ($price * $tax_percentage)/100;
		$sgst = ($price * $sgst_percentage)/100;
		
		$cgst_ptr = ($price * $tax_percentage)/100;
		$sgst_ptr = ($price * $sgst_percentage)/100;
		
		
		$data=array(
			'services_name' 		=> $this->input->post('services_name'),		
           	'product_type' 			=> $this->input->post('product_type'),
			'category_id' 			=> $this->input->post('category_id'),
			'price' 			=> $this->input->post('price'),
			'supplier_price' 		=> $this->input->post('supplier_price'),			
			'services_details' 		=> $this->input->post('description'),
			'cgst_per' 		        => $this->input->post('tax'),
			'sgst_per' 		        => $this->input->post('sgst'),
			'tax'			        => $tax,
			'sgst'				=> $sgst,		
			'cgst_ptr'			=> $cgst_ptr,
			'sgst_ptr'			=> $sgst_ptr,
			'generic_name' 			=> $this->input->post('generic_name'),			
			'product_location' 		=> $this->input->post('product_location'),
			//'image' 			=> (!empty($image_url)?$image_url:$old_image),
			'status' 			=> 1
		);
		
		
		$result = $CI->Services->update_services($data,$service_id);
		if ($result == true) {
			$this->session->set_userdata(array('message'=>display('successfully_updated')));
			redirect(base_url('Cservices/manage_services'));
		}else{
			$this->session->set_userdata(array('error_message'=>display('product_model_already_exist')));
			redirect(base_url('Cservices/manage_services'));
		}
	}
	// product_delete
	public function service_delete()
	{	
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->model('Services');
		$service_id =  $_POST['product_id'];
		$result=$CI->Services->delete_service($service_id);
		return true;
			
	}
	    public function add_manufacture()
	{	
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lservice');
		$content = $CI->lservice->manufacture_add_form();
		$this->template->full_admin_html_view($content);
	}
       public function add_product_mapping()
	{	
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lservice');
		$content = $CI->lservice->product_mapping_add_form();
		$this->template->full_admin_html_view($content);
	}
  public function manage_manufacture()
	{	
	
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->library('lservice');
		$CI->load->model('Services');
        	$content = $CI->lservice->manufacture_list();
		$this->template->full_admin_html_view($content);
	
	}

       public function manage_product_mapping()
	{	
	
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->library('lservice');
		$CI->load->model('Services');
                $content = $CI->lservice->product_mapping_list();
		$this->template->full_admin_html_view($content);
	
	}
	
        //Insert Product and uload
	public function insert_manufacture()
	{
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lservice');		

		$data=array(
			'product_id' 			=> $this->input->post('product_id'),
			'quantity' 			=> $this->input->post('quantity')		
			);

		$result=$CI->lservice->insert_manufacture($data);
		$this->session->set_userdata(array('message'=>display('successfully_added')));
		if(isset($_POST['add-product'])){
			redirect(base_url('Cproduct/manage_manufacture'));
			exit;
		}elseif(isset($_POST['add-product-another'])){
			redirect(base_url('Cproduct/add_manufacture'));
			exit;
		}
		
	}
        public function insert_product_mapping()
	{
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lservice');		
        	$today = date('Y-m-d');
		$data=array(
			'product_id' 	    => $this->input->post('product_id'),
            'price' 			=> $this->input->post('price'),
			'quantity' 			=> $this->input->post('quantity'),
            'dateadded'         => $today 		
			);

		$result=$CI->lservice->insert_product_mapping();
		$this->session->set_userdata(array('message'=>display('successfully_added')));
		if(isset($_POST['add-product'])){
			redirect(base_url('Cproduct/manage_product_mapping'));
			exit;
		}elseif(isset($_POST['add-product-another'])){
			redirect(base_url('Cproduct/add_product_mapping'));
			exit;
		}
		
	}
        public function update_product_mapping()
	{
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lservice');		
$CI->load->model('Services');
		
                $product_id=$this->input->post('product_id');
                $result = $CI->Services->update_product_mapping($product_id);
		if ($result == true) {
			$this->session->set_userdata(array('message'=>display('successfully_updated')));
			redirect(base_url('Cproduct/manage_product_mapping'));
		}else{
			$this->session->set_userdata(array('error_message'=>display('product_model_already_exist')));
			redirect(base_url('Cproduct/add_product_mapping'));
		}

		
		
		
	}
        public function update_manufacture()
	{
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lservice');		
		$CI->load->model('Services');
		
               $id=$this->input->post('id');
                $result = $CI->Services->update_manufacture($id);
		if ($result == true) {
			$this->session->set_userdata(array('message'=>display('successfully_updated')));
			redirect(base_url('Cproduct/manage_manufacture'));
		}else{
			$this->session->set_userdata(array('error_message'=>display('product_model_already_exist')));
			redirect(base_url('Cproduct/add_manufacture'));
		}

		
		
		
	}
            public function product_mapping_update_form($product_id)
	{	
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lservice');
		$content = $CI->lservice->product_mapping_edit_data($product_id);
		$this->template->full_admin_html_view($content);
	} 

	//Product Update Form
        public function manufacture_update_form($id)
	{	
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lservice');
		$content = $CI->lservice->manufacture_edit_data($id);
		$this->template->full_admin_html_view($content);
	}	
	
	     public function manufacture_delete()
	{	
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->model('Services');
		$id =  $_POST['product_id'];
		$result=$CI->Services->delete_manufacture($id);
		return true;
			
	}
	//Retrieve Single Item  By Search
	public function product_by_search()
	{
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->library('lservice');
		$product_id = $this->input->post('product_id');		
        $content = $CI->lservice->product_search_list($product_id);
        $sub_menu = array(
				array('label'=> 'Manage Product', 'url' => 'Cproduct', 'class' =>'active'),
				array('label'=> 'Add Product', 'url' => 'Cproduct/manage_product')
			);
		$this->template->full_admin_html_view($content,$sub_menu);
	}
	//Retrieve Single Item  By Search
	public function product_details($product_id)
	{
		$this->product_id=$product_id;
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->library('lservice');	
        $content = $CI->lservice->product_details($product_id);
		$this->template->full_admin_html_view($content);
	}
	
	//Retrieve Single Item  By Search
	public function product_sales_supplier_rate($product_id=null,$startdate=null,$enddate=null)
	{
		if($startdate==null){$startdate= date('Y-m-d',strtotime('-30 days'));}
		if($enddate==null){$enddate= date('Y-m-d');}
		$product_id_input=$this->input->post('product_id');
		if(!empty($product_id_input))
			{
				$product_id=$this->input->post('product_id');
				$startdate=$this->input->post('from_date');
				$enddate=$this->input->post('to_date');
			}
		
		$this->product_id=$product_id;
		
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->library('lservice');	
        $content = $CI->lservice->product_sales_supplier_rate($product_id,$startdate,$enddate);
		$this->template->full_admin_html_view($content);
	}

	//This function is used to Generate Key
	public function generator($lenth)
	{
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->model('Services');

		$number=array("1","2","3","4","5","6","7","8","9","0");
		for($i=0; $i<$lenth; $i++)
		{
			$rand_value=rand(0,8);
			$rand_number=$number["$rand_value"];
		
			if(empty($con))
			{ 
				$con=$rand_number;
			}
			else
			{
				$con="$con"."$rand_number";
			}
		}

		$result = $this->Services->product_id_check($con);

		if ($result === true) {
			$this->generator(8);
		}else{
			return $con;
		}
	}
	public function retrieve_product_purchase_data()
	{	

		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->model('Services');
		$product_id = $this->input->post('product_id');
		$product_info = $CI->Services->retrieve_product_purchase_data($product_id);
		echo json_encode($product_info);
	}
	public function transfer_Services(){
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lservice');
		$content = $CI->lservice->transfer_product_form();
		$this->template->full_admin_html_view($content);
		
		
	}	
	public function transfer_product_entry(){
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lservice');		
		$today =date("Y-m-d");
        $data=array(
			'purchase_detail_id' 	=> $this->input->post('prid'),
			'company_id' 	=> $this->input->post('company_id'),
         	'quantity' 			    => $this->input->post('transfer_product_quantity'),
            'date_added'            => $today 		
			);

		$result=$CI->lservice->insert_product_transfer($data);
		$this->session->set_userdata(array('message'=>display('successfully_added')));
		if(isset($_POST['add-product'])){
			redirect(base_url('Cproduct/manage_product_transfer'));
			exit;
		}elseif(isset($_POST['add-product-another'])){
			redirect(base_url('Cproduct/transfer_Services'));
			exit;
		}
		
		
	}	
	public function manage_product_transfer()
	{	
	
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->library('lservice');
		$CI->load->model('Services');
        $content = $CI->lservice->product_transfer_list();
		$this->template->full_admin_html_view($content);
	
	}
}