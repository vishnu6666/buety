var FLYERBD = angular.module('FLYERBD', [
	'ngRoute'
	]);

FLYERBD.config(['$routeProvider', function ($routeProvider) {
	$routeProvider
	.when('/', {
		templateUrl: 'homee',
		controller: 'HomeCtrl',
		 title: 'Home Page'
	})
	.when('/about', {
		templateUrl: 'about',
		controller: 'AboutCtrl',
		 title: 'Aboutus Page'
	})
	.when('/contact', {
		templateUrl: 'contact',
		controller: 'ContactCtrl',
		title: 'Contact Us Page'
	})
}]);

FLYERBD.controller('AboutCtrl', ['$scope', function ($scope) { 

    $scope.$on('$routeChangeSuccess', function (event, data) {
    	//console.log($scope);
    	//alert($scope);

        $scope.hd_page_title = data.title;

        console.log($scope.hd_page_title);

    });

} ]);