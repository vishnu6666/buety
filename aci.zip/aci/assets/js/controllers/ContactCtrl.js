FLYERBD
.controller('ContactCtrl', ['$scope', function ($scope) {
	$scope.title = 'This is contact view';
}]);