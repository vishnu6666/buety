FLYERBD
.controller('HomeCtrl', ['$scope', function ($scope) {
	$scope.title = 'This is home view';
}]);