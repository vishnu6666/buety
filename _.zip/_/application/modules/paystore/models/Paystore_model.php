<?php

class Paystore_model extends CI_Model
{

    function __construct()
    {
        parent::__construct();
    }

    public function get_tbl_categorys()
    {
        $this->db->select('*')
            ->from('tbl_categorys');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
            return false;
        }
    }

    public function get_tbl_stats()
    {
        $this->db->select('*')
            ->from('tbl_states');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
            return false;
        }
    }

    public function get_tbl_citys()
    {
        $this->db->select('*')
            ->from('tbl_cities');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
            return false;
        }
    }

    public function get_paystore_offers()
    {
        $this->db->select('*')
            ->from('tbl_feature_offers');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
            return false;
        }
    }

    public function get_tbl_tabs_categorys()
    {
        $data = array(1,2,3,4,5,6,7,8,9,16);
        $this->db->select('*')
            ->where_in('id',$data)
            ->limit(11)
            ->from('tbl_categorys');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
            return false;
        }
    }

    public function get_mobile_sub_categorys()
    {
        $this->db->select('*')
             ->where('category_id',1)
             ->where('status',1)
             ->from('tbl_sub_categorys');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
            return false;
        }
    }

    public function get_dth_sub_categorys()
    {
        $this->db->select('*')
             ->where('category_id',2)
             ->where('status',1)
             ->from('tbl_sub_categorys');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
            return false;
        }
    }

    public function get_datacard_sub_categorys()
    {
        $this->db->select('*')
             ->where('category_id',3)
             ->where('status',1)
             ->from('tbl_sub_categorys');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
            return false;
        }
    }

    public function get_landline_sub_categorys()
    {
        $this->db->select('*')
             ->where('category_id',4)
             ->where('status',1)
             ->from('tbl_sub_categorys');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
            return false;
        }
    }

    public function get_elecricity_sub_categorys()
    {
        $this->db->select('*')
             ->where('category_id',5)
             ->where('status',1)
             ->from('tbl_sub_categorys');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
            return false;
        }
    }

    public function get_broadband_sub_categorys()
    {
        $this->db->select('*')
             ->where('category_id',6)
             ->where('status',1)
             ->from('tbl_sub_categorys');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
            return false;
        }
    }

    public function get_gas_sub_categorys()
    {
        $this->db->select('*')
             ->where('category_id',7)
             ->where('status',1)
             ->from('tbl_sub_categorys');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
            return false;
        }
    }

    public function get_insurance_sub_categorys()
    {
        $this->db->select('*')
             ->where('category_id',8)
             ->where('status',1)
             ->from('tbl_sub_categorys');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
            return false;
        }
    }

    public function get_transport_sub_categorys()
    {
        $this->db->select('*')
             ->where('category_id',9)
             ->where('status',1)
             ->from('tbl_sub_categorys');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
            return false;
        }
    }

    public function get_water_sub_categorys()
    {
        $this->db->select('*')
             ->where('category_id',11)
             ->where('status',1)
             ->from('tbl_sub_categorys');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
            return false;
        }
    }

    public function get_cable_sub_categorys()
    {
        $this->db->select('*')
             ->where('category_id',12)
             ->where('status',1)
             ->from('tbl_sub_categorys');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
            return false;
        }
    }

    public function get_municipal_sub_categorys()
    {
        $this->db->select('*')
             ->where('category_id',13)
             ->where('status',1)
             ->from('tbl_sub_categorys');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
            return false;
        }
    }

    public function get_institute_fee_sub_categorys()
    {
        $this->db->select('*')
             ->where('category_id',14)
             ->where('status',1)
             ->from('tbl_sub_categorys');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
            return false;
        }
    }

    public function get_casino_fee_sub_categorys()
    {
        $this->db->select('*')
             ->where('category_id',16)
             ->where('status',1)
             ->from('tbl_sub_categorys');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
            return false;
        }
    }

}
?>