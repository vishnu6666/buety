<style type="text/css">

.subcategory{
  width: 60px;
  height: 60px;
  max-width: 60px;
  max-height: 60px;
  border-radius: 50%;
}
.image{
 display: inline-grid;
 text-align: center;
 margin: 10px;
 padding: 15px;
 opacity: 1;
 border-radius: 3px;
}
.image{
  text-decoration: none;
}

/* Style the tab */
.tab {
  overflow: hidden;
  border: 1px solid #ccc;
  border-radius: 10px;
  background-color: #f1f1f1;
}

/* Style the buttons inside the tab */
.tab button {
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
  font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
  display: none;
  padding: 6px 12px;
  border: 1px solid #ccc;
  border-radius: 10px;
  border-top: none;
}
.prepaid_recharge {
  background-color: #f37335;
}
</style>

<div id="main"><!--- strat main--->
  <div class="tabOnlinPay paddingLeftRight"><!--- strat tabOnlinPay--->
    <div class="tabOnlineBox">
      <!-- Tab panes -->
      <ul id="nav" class="nav nav-pills" role="tablist">
        <?php if(isset($categorys)){?>
          <?php foreach($categorys as $key => $category){?>
            <li class="nav-item ">
              <?php if($key <= 8){?>
                <a class="nav-link <?php if($this->uri->segment(2) == 'prepaid_recharge'){ echo  'active-class'; } ?>"  href="<?php echo base_url('paystore/');?><?php echo str_replace('-', ' ', strtolower($category['url_name'])); ?>">
                  <?php echo $category['category_icone']; ?>
                  <p><?php echo $category['category_name']; ?></p>
                </a>
              <?php }else if($key === 9){?>
                <a class="waves-effect waves-light btn modal-trigger nav-link" data-toggle="pill" href="#modal1" data-target="#tab015">
                  <span style="font-size: 20px;display: inline-table;margin-top: 15px;">+5</span> 
                  <p>More</p>
                </a>
              <?php }?>
            </li>
          <?php } ?>
        <?php }?>
      </ul>

      <!-- Modal Structure -->
      <div id="modal1" class="more_model">
        <div class="modal-content">
          <ul class="nav nav-pills" role="tablist">
            <?php if(isset($categorys)){?>
              <?php foreach($categorys as $key => $category){?> 
                <?php if($key >= 10){?>  
                  <li class="nav-item spaceTabSection" style="margin: 6px;">
                    <a class="nav-link "  href="<?php echo base_url('paystore/');?><?php echo str_replace('-', ' ', strtolower($category['url_name'])); ?>">
                      <?php echo $category['category_icone']; ?>
                      <p><?php echo $category['category_name']; ?></p>
                    </a>
                  </li>
                <?php }?>
              <?php }?>
            <?php }?>
          </ul>
        </div>
      </div>
      <!--  </ul> -->
      <!-- Tab panes -->
      <div class="tab-content">
        <div id="tab001" class="tab-pane active"><br>
          <h2>Mobile Recharge or Bill Payment</h2>
          <p>Tell us your number and we will figure out the rest</p>
          <div class="col-xl-12">
            <div class="row">
              <div class="col-xl-12 checkBoxCustom">
                <div class="custom-control custom-checkbox">
                  <input type="radio" name="mobile_radio" value="prepaid" id="prepaid" checked="" />
                  <label for="defaultChecked1">Prepaid</label>
                </div>
                <div class="custom-control custom-checkbox">
                   <!--                          <input type="radio" class="custom-control-input" name="mobile_radio" id="defaultChecked2" />
                    <label class="custom-control-label" for="defaultChecked2">Postpaid</label> -->
                    <input type="radio"  name="mobile_radio" value="postpaid" id="postpaid" />
                    <label for="defaultChecked2">Postpaid</label>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-12 figure">
              <div class="row">
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
                  <div class="form-group">
                    <input type="text" class="form-control inputBox" id="mobile_number" placeholder="Mobile No (+255)" title="Please Enter Your Mobile Number" onblur="validationallmobilerecharge('mobile_number', 'errormobile_no', 'Mobile Number (+255) cannot be empty.');" onkeypress='return (event.charCode >= 48 && event.charCode <= 57 || event.charCode == 0)' maxlength="10">
                    <p class="p12 text-center color7 pull-left text-danger"><span name="errormobile_no" id="errormobile_no"
                      data-valmsg-for="phone_number"
                      data-valmsg-replace="true"><?php echo form_error('errormobile_no'); ?></span>
                    </p>
                  </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
                  <div class="form-group">
                    <select class="form-control inputBox" title="Please Select Your Operator" id="mobile_operator" onblur="validationallmobilerecharge('mobile_operator', 'errormobileoperator', 'Operator cannot be empty.');">
                      <option value="">Select Operator</option>
                      <?php if(isset($mobile_sub_categorys)){?>
                        <?php foreach($mobile_sub_categorys as $key => $sub_category){?>
                          <option value="<?php echo $sub_category['category_id'];?>"><?php echo $sub_category['subcategory_name'];?>
                          <img src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                        </option>
                      <?php }?>
                    <?php }?>

                  </select>
                  <p class="p12 text-center color7 pull-left text-danger"><span name="errormobileoperator" id="errormobileoperator"
                    data-valmsg-for="mobile_operator"
                    data-valmsg-replace="true"><?php echo form_error('errormobileoperator'); ?></span>
                  </p>
                </div>
              </div>

              <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
                <div class="form-group">
                  <select class="form-control inputBox" title="Please Select Your Circle" id="mobile_circle" onblur="validationallmobilerecharge('mobile_circle', 'errormobilecircle', 'Circle cannot be empty.');">
                     <option value="">Select Circle</option>
                      <?php if(isset($stats)){?>
                        <?php foreach($stats as $key => $stat){?>
                          <option value="<?php echo $stat['state_id'];?>"><?php echo $stat['state_name'];?>
                          <!-- <img src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $stat['subcategory_image'];?>"> -->
                        </option>
                      <?php }?>
                    <?php }?>
                  </select>
                  <p class="p12 text-center color7 pull-left text-danger"><span name="errormobilecircle" id="errormobilecircle"
                    data-valmsg-for="mobile_circle"
                    data-valmsg-replace="true"><?php echo form_error('errormobilecircle'); ?></span>
                  </p>
                </div>
              </div>

              <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
                <div class="form-group">
                  <input type="text" class="form-control inputBox" id="mobilerecharge_amount" placeholder="Amount" title="Please Enter Your Amount"  onblur="validationallmobilerecharge('mobilerecharge_amount', 'errormobileamount', 'Amount cannot be empty.');" onkeypress='return (event.charCode >= 48 && event.charCode <= 57 || event.charCode == 0)'>
                  <p class="p12 text-center color7 pull-left text-danger"><span name="errormobileamount" id="errormobileamount"
                    data-valmsg-for="mobilerecharge_amount"
                    data-valmsg-replace="true"><?php echo form_error('errormobileamount'); ?></span>
                  </p>
                </div>
              </div>
            </div>
          </div>
          <button class="btn goButtob" id="mobilerecharge_button" onclick="mobile_recharge()" title="Click Here" disabled="disabled">Go</button>
        </div>
      </div>
    </div>

  </div><!---end tabOnlinPay--->

  <div class="wholeBox paddingLeftRight"><!--- strat tabOnlinPay--->

    <div class="row">
      <div class="col-xl-12">
        <p class="sliderHeading">Featured offer</p>
        <div class="owl-carousel owl-theme">
        <?php if(isset($paystore_offers)){?>
          <?php foreach($paystore_offers as $paystore_offer){?>
        <div class="item">
          <a href=""> <img src="<?php echo base_url('Assets/images/feature_offers/');?><?php echo $paystore_offer['offer_image'];?>" class="img-fluid"/></a>
        </div>
        <?php }?>
      <?php }?>
      </div>
      </div>
    </div>

  </div>

  <div class="whypayBills paddingLeftRight bgGradien">
    <div class="row">
      <div class="col-xl-6 col-lg-6 col-md-6 whypayBillsDetails">
        <h2 class="headingH2 color2">Why Pay bills On Paystore</h2>
        <p class="color2">Create multiple stores as per your requirements with no setup and maintenance charges. Just create your products and add it to your webstore. Share your webstore link with your customers on any platform and get paid online. You can sell Physical Items, Digital Items, Event tickets or Services.
        </p>
        <a href="" class="btn Button1">READ MORE</a>
      </div>
      <div class="col-xl-6 col-lg-6 col-md-6 whypayBillsImage">
        <img src="<?php echo base_url('Assets/NewDesign/images/16544-eps.png');?>" class="img-fluid"/>
      </div>
    </div>
  </div>

  <div class="whypayBills paddingLeftRight ">
    <div class="row">
      <div class="col-xl-6 col-lg-6 col-md-6 ">
        <img src="<?php echo base_url('Assets/NewDesign/images/445821-PF5LWH-598-eps.png');?>" class="img-fluid"/>
      </div>
      <div class="col-xl-6 col-lg-6 col-md-6 whypayBillsDetails">
        <h2 class="headingH2 color1">All In One Platform</h2>
        <p class="color1">No Need of POS machine
          A simple way to reach your customer for payments using our several link solutions with integrated QR code, Easepay and Quickpay can be circulated using integrated Email/SMS, whatsapp or any social media.
        </p>
      </div>
    </div>
  </div>

  <div class="whypayBills paddingLeftRight bgGradien">
    <div class="row">
      <div class="col-xl-6 col-lg-6 col-md-6 whypayBillsDetails">
        <h2 class="headingH2 color2">Paystore for Educational Institutes</h2>
        <p class="color2">Is your admission and fees collection process too complex? </br>
          We provide single platform where any educational institute can go paperless & collect payments online for their admission process, fee collection & much more.
        </p>
        <a href="" class="btn Button1">READ MORE</a>
      </div>
      <div class="col-xl-6 col-lg-6 col-md-6 whypayBillsImage">
        <img src="<?php echo base_url('Assets/NewDesign/images/672-eps.png');?>" class="img-fluid"/>
      </div>
    </div>
  </div>


  <div class="wholeBox paddingLeftRight"><!--- strat tabOnlinPay--->
    <div class="row">
      <div class="col-xl-12">
        <h4>Do Recharge & Bill Payments at Paystoreonline</h4><br>
        <div class="tab">
         <?php if(isset($tabscategorys)){?>
          <?php foreach($tabscategorys as $key => $category){?>                              
            <button class="tablinks" onclick="openCity(event, '<?php echo 'tab000'.$category['id']; ?>')" id="defaultOpen"><?php echo $category['category_name']; ?></button>
          <?php }?>
        <?php }?>
      </div>

      <div id="tab0001" class="tabcontent">
        <p>
          <?php if(is_array($mobile_sub_categorys)){?>
            <?php foreach($mobile_sub_categorys as $key => $sub_category){?>
              <a href="#" class="image"><img class="subcategory"  src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                <?php echo $sub_category['subcategory_name'];?></a>
              <?php }?>
            <?php }else{?>
              <center><h4>Not Available Now</h4></center>
            <?php }?>
          </p>
        </div>

        <div id="tab0002" class="tabcontent">
          <p>
            <?php if(is_array($dth_sub_categorys)){?>
              <?php foreach($dth_sub_categorys as $key => $sub_category){?>
                <a href="#" class="image"><img  class="subcategory"  src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                  <?php echo $sub_category['subcategory_name'];?></a>
                <?php }?>
              <?php }else{?>
                <center><h4>Not Available Now</h4></center>
              <?php }?>
            </p>
          </div>

          <div id="tab0003" class="tabcontent">
            <p>
              <?php if(is_array($datacard_sub_categorys)){?>
                <?php foreach($datacard_sub_categorys as $key => $sub_category){?>
                  <a href="#" class="image"><img  class="subcategory" src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                    <?php echo $sub_category['subcategory_name'];?></a>
                  <?php }?>
                <?php }else{?>
                  <center><h4>Not Available Now</h4></center>
                <?php }?>
              </p>
            </div>

            <div id="tab0004" class="tabcontent">
              <p>
                <?php if(is_array($landline_sub_categorys)){?>
                  <?php foreach($landline_sub_categorys as $key => $sub_category){?>
                    <a href="#" class="image"><img  class="subcategory" src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                      <?php echo $sub_category['subcategory_name'];?></a>
                    <?php }?>
                  <?php }else{?>
                    <center><h4>Not Available Now</h4></center>
                  <?php }?>
                </p>
              </div>

              <div id="tab0005" class="tabcontent">
                <p>
                  <?php if(is_array($elecricity_sub_categorys)){?>
                    <?php foreach($elecricity_sub_categorys as $key => $sub_category){?>
                      <a href="#" class="image"><img  class="subcategory" src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                        <?php echo $sub_category['subcategory_name'];?></a>
                      <?php }?>
                    <?php }else{?>
                      <center><h4>Not Available Now</h4></center>
                    <?php }?>
                  </p>
                </div>

                <div id="tab0006" class="tabcontent">
                  <p>
                    <?php if(is_array($broadband_sub_categorys)){?>
                      <?php foreach($broadband_sub_categorys as $key => $sub_category){?>
                        <a href="#" class="image"><img  class="subcategory" src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                          <?php echo $sub_category['subcategory_name'];?></a>
                        <?php }?>
                      <?php }else{?>
                        <center><h4>Not Available Now</h4></center>
                      <?php }?>
                    </p>
                  </div>

                  <div id="tab0007" class="tabcontent">
                    <p>
                      <?php if(is_array($gas_sub_categorys)){?>
                        <?php foreach($gas_sub_categorys as $key => $sub_category){?>
                          <a href="#" class="image"><img  class="subcategory" src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                            <?php echo $sub_category['subcategory_name'];?></a>
                          <?php }?>
                        <?php }else{?>
                          <center><h4>Not Available Now</h4></center>
                        <?php }?>
                      </p>
                    </div>

                    <div id="tab0008" class="tabcontent">
                      <p>
                        <?php if(is_array($insurance_sub_categorys)){?>
                          <?php foreach($insurance_sub_categorys as $key => $sub_category){?>
                            <a href="#" class="image"><img class="subcategory" src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                              <?php echo $sub_category['subcategory_name'];?></a>
                            <?php }?>
                          <?php }else{?>
                            <center><h4>Not Available Now</h4></center>
                          <?php }?>
                        </p>
                      </div>

                      <div id="tab0009" class="tabcontent">
                        <p>
                          <?php if(is_array($transport_sub_categorys)){?>
                            <?php foreach($transport_sub_categorys as $key => $sub_category){?>
                              <a href="#" class="image"><img  class="subcategory" src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                                <?php echo $sub_category['subcategory_name'];?></a>
                              <?php }?>
                            <?php }else{?>
                              <center><h4>Not Available Now</h4></center>
                            <?php }?>
                          </p>
                        </div>

                        <div id="tab00016" class="tabcontent">
                      <p>
                        <?php if(is_array($casino_fee_sub_categorys)){?>
                          <?php foreach($casino_fee_sub_categorys as $key => $sub_category){?>
                            <a href="#" class="image"><img  class="subcategory" src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                              <?php echo $sub_category['subcategory_name'];?></a>
                            <?php }?>
                          <?php }else{?>
                            <center><h4>Not Available Now</h4></center>
                          <?php }?>
                        </p>
                      </div>

                        <!-- <div id="tab00010" class="tabcontent">
                          <h3>10London</h3>
                          <p>London is the capital city of England.</p>
                        </div>

                        <div id="tab00011" class="tabcontent">
                          <h3>11London</h3>
                          <p>London is the capital city of England.</p>
                        </div> -->
                      </div>
                    </div>

                  </div>
                  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
                 <!--  <script>
                    $(document).ready(function(){
                       $('ul#nav li a').click(function(){
                       alert("you click a link");
                       var page = $(this).attr('href');
                       alert(page);
                       $(this).load(page);
                       //return false;
                       });
                    });
                  </script> -->




                  <script>
                    function openCity(evt, cityName) {
                      var i, tabcontent, tablinks;
                      tabcontent = document.getElementsByClassName("tabcontent");
                      for (i = 0; i < tabcontent.length; i++) {
                        tabcontent[i].style.display = "none";
                      }
                      tablinks = document.getElementsByClassName("tablinks");
                      for (i = 0; i < tablinks.length; i++) {
                        tablinks[i].className = tablinks[i].className.replace(" active", "");
                      }
                      document.getElementById(cityName).style.display = "block";
                      evt.currentTarget.className += " active";
                    }
                    document.getElementById("defaultOpen").click();
                  </script>

                  <script>
                    $( function() {
                      $( "#tabs" ).tabs();
                    } );
                  </script>

                  <script>
                    $('.nav-item').click(function() {
                      $('#modal1').modal('close');

                    });

    // Manage selection options Mobile Recharge
    $('#prepaid').click(function () {
      $('#prepaid').attr('checked', 'checked');
      $('#postpaid').removeAttr('checked');
    });

    $('#postpaid').click(function () {
      $('#postpaid').attr('checked', 'checked');
      $('#prepaid').removeAttr('checked');
    });

    // Manage selection options Datacard
    $('#datacard_prepaid').click(function () {
      $('#datacard_prepaid').attr('checked', 'checked');
      $('#datacard_postpaid').removeAttr('checked');
    });

    $('#datacard_postpaid').click(function () {
      $('#datacard_postpaid').attr('checked', 'checked');
      $('#datacard_prepaid').removeAttr('checked');
    });
      // Manage selection options Insurace
      $('#pay_premium').click(function () {
        $('#pay_premium').attr('checked', 'checked');
        $('#buy_insurance').removeAttr('checked');
      });

      $('#buy_insurance').click(function () {
        $('#buy_insurance').attr('checked', 'checked');
        $('#pay_premium').removeAttr('checked');
      });

      /*Start Mobile Recharge*/

      function validationallmobilerecharge(filedname, spanname, message) {
        var username = $("#" + filedname).val();
        var mobile_number = $("#mobile_number").val();
        var mobilerecharge_amount = $("#mobilerecharge_amount").val();
        var mobile_operator = $("#mobile_operator").val();
        var mobile_circle = $("#mobile_circle").val();
        var numpattern = /^[0-9]*$/;
        if (filedname == 'mobile_number') {
          if (username === "" || username === "null") {
            $("#" + spanname).html(message);
            $("#" + spanname).css("display", "block");
            $('#mobilerecharge_button').attr('disabled', true);
            return false;
          }
          else {
            if (!mobile_number.match(numpattern)) {
              $("#" + spanname).text('Mobile Number (+255) cannot be empty.');
              $("#" + spanname).css("display", "block");
              $('#mobilerecharge_button').attr('disabled', true);
              return false;
            }
            else {
              if (mobile_number.length < 8 || mobile_number.length > 10) {
                $("#" + spanname).text('Please enter valid mobile number.');
                $("#" + spanname).css("display", "block");
                $('#mobilerecharge_button').attr('disabled', true);
                return false;
              }
              else {
                var mobile_number = $("#mobile_number").val();
                var mobile_operator = $("#mobile_operator").val();
                var mobile_circle = $("#mobile_circle").val();
                var mobilerecharge_amount = $("#mobilerecharge_amount").val();
                if (mobile_number == '' || mobile_operator == '' || mobile_circle == ''  || mobilerecharge_amount == '' || mobile_number.length < 8 || mobile_number.length > 10) {
                  $('#mobilerecharge_button').attr('disabled', true);
                }
                else {
                  $('#mobilerecharge_button').attr('disabled', false);
                }
                $("#" + spanname).text('');
                $("#" + spanname).css("display", "none");
                return true;
              }
            }
          }
        }
        else if (filedname == 'mobilerecharge_amount') {
          if (username === "" || username === "null") {
            $("#" + spanname).html(message);
            $("#" + spanname).css("display", "block");
            $('#mobilerecharge_button').attr('disabled', true);
            return false;
          }
          else {
            var mobile_number = $("#mobile_number").val();
            var mobile_operator = $("#mobile_operator").val();
            var mobile_circle = $("#mobile_circle").val();
            var mobilerecharge_amount = $("#mobilerecharge_amount").val();
            if (mobile_number == '' || mobile_operator == '' || mobile_circle == '' || mobilerecharge_amount == '' || mobile_number.length < 8 || mobile_number.length > 10) {
              $('#mobilerecharge_button').attr('disabled', true);
            }
            else {
              $('#mobilerecharge_button').attr('disabled', false);
            }
            $("#" + spanname).text('');
            $("#" + spanname).css("display", "none");
            return true;
          }
        }
        else if (filedname == 'mobile_operator') {
          if (username === "" || username === "null") {
            $("#" + spanname).html(message);
            $("#" + spanname).css("display", "block");
            $('#mobilerecharge_button').attr('disabled', true);
            return false;
          }
          else {
            var mobile_number = $("#mobile_number").val();
            var mobile_operator = $("#mobile_operator").val();
            var mobile_circle = $("#mobile_circle").val();
            var mobilerecharge_amount = $("#mobilerecharge_amount").val();
            if (mobile_number == '' || mobile_operator == '' || mobile_circle == '' || mobilerecharge_amount == '' || mobile_number.length < 8 || mobile_number.length > 10) {
              $('#mobilerecharge_button').attr('disabled', true);
            }
            else {
              $('#mobilerecharge_button').attr('disabled', false);
            }
            $("#" + spanname).text('');
            $("#" + spanname).css("display", "none");
            return true;
          }
        }
        else if (filedname == 'mobile_circle') {
          if (username === "" || username === "null") {
            $("#" + spanname).html(message);
            $("#" + spanname).css("display", "block");
            $('#mobilerecharge_button').attr('disabled', true);
            return false;
          }
          else {
            var mobile_number = $("#mobile_number").val();
            var mobile_operator = $("#mobile_operator").val();
            var mobile_circle = $("#mobile_circle").val();
            var mobilerecharge_amount = $("#mobilerecharge_amount").val();
            if (mobile_number == '' || mobile_operator == ''  || mobile_circle == '' || mobilerecharge_amount == '' || mobile_number.length < 8 || mobile_number.length > 10) {
              $('#mobilerecharge_button').attr('disabled', true);
            }
            else {
              $('#mobilerecharge_button').attr('disabled', false);
            }
            $("#" + spanname).text('');
            $("#" + spanname).css("display", "none");
            return true;
          }
        }
        else {
          if (username === "" || username === "null") {
            $("#" + spanname).html(message);
            $("#" + spanname).css("display", "block");
            $('#mobilerecharge_button').attr('disabled', true);
            return false;
          } else {
            $("#" + spanname).html("");
            return true;
          }
        }

      }

      function mobile_recharge() {
        if ($('#prepaid').attr('checked') == 'checked') {
          sim_type = $('#prepaid').val();

        } else if ($('#postpaid').attr('checked') == 'checked') {
          sim_type = $('#postpaid').val();
        }
        var mobile_number = $("#mobile_number").val();
        var mobile_operator = $("#mobile_operator").val();
        var mobile_circle = $("#mobile_circle").val();
        var mobilerecharge_amount = $("#mobilerecharge_amount").val();
        var numpattern = /^[0-9]*$/;
        var a = 0, b = 0, c = 0, d = 0, e = 0, f = 0, g = 0, er = 0, m10 = 0, un = 0;
        if (mobile_number == '') {
          $("#errormobile_no").text('Mobile Number (+255) cannot be empty.');
          $("#errormobile_no").css("display", "block");
          a = 1
        }
        else {
          if (!mobile_number.match(numpattern)) {
            $("#errormobile_no").text('Enter Only number.');
            $("#errormobile_no").css("display", "block");
            a = 1;
          }
          else {
            if (mobile_number.length < 8 || mobile_number.length > 10) {
              $("#errormobile_no").text('Please enter valid mobile number.');
              $("#errormobile_no").css("display", "block");
              a = 1;
            }
            else {
              $("#errormobile_no").text('');
              $("#errormobile_no").css("display", "none");
              a = 0;
            }
          }
        }
        if (mobile_operator == '') {
         $("#errormobileoperator").text('Operator cannot be empty');
         $("#errormobileoperator").css("display", "block");
         b = 1;
       }
       else
       {
         $("#errormobileoperator").text('');
         $("#errormobileoperator").css("display", "none");
         b = 0;
       }
       if (mobilerecharge_amount == '') {
         $("#errormobileamount").text('Amount cannot be empty.');
         $("#errormobileamount").css("display", "block");
         c = 1;
       }
       else
       {
         $("#errormobileamount").text('');
         $("#errormobileamount").css("display", "none");
         c = 0;
       }
       if (mobile_circle == '') {
         $("#errormobilecircle").text('Circle cannot be empty');
         $("#errormobilecircle").css("display", "block");
         d = 1;
       }
       else
       {
         $("#errormobilecircle").text('');
         $("#errormobilecircle").css("display", "none");
         d = 0;
       }
       if ((a == 0) && (b == 0) && (c == 0) && (d == 0)) {
         var datavalue = {
          'sim_type': sim_type,
          'mobile_number': mobile_number,
          'mobile_operator': mobile_operator,
          'mobile_circle': mobile_circle,
          'mobilerecharge_amount': mobilerecharge_amount,
        };
        //alert(JSON.stringify(datavalue));
        $.ajax
        ({
          type: "POST",
          data: JSON.stringify(datavalue),
          contentType: "application/json",
          dataType: "json",
          url: "<?php echo base_url('api/submit_mobile_recharge');?>",
          success: function (result) {
            var objToString = JSON.stringify(result);
            var stringToArray = [];
            stringToArray.push(objToString);
            var jsonObj = $.parseJSON(stringToArray);
            var message = jsonObj.Common.Message;
            var status = jsonObj.Common.Status;
  
            if (status == "Success") {
            swal("Recharge Done!", "Mobile Recharge Successfull.", "success");
                //window.location.href = "<?php echo base_url('api/prepaid_recharge'); ?>";
            }
            else {
              swal("Somthing Wrong !", "Somthing Wrong , Please Tray Again", "warning");
            }

          }
        });
      } else {
        return false;
      }
    }
    /*End Mobile Recharge*/
  </script>