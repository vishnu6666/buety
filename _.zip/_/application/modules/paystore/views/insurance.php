<style type="text/css">

.subcategory{
  width: 60px;
  height: 60px;
  max-width: 60px;
  max-height: 60px;
  border-radius: 50%;
}
.image{
 display: inline-grid;
 text-align: center;
 margin: 10px;
 padding: 15px;
 opacity: 1;
 border-radius: 3px;
}
.image{
  text-decoration: none;
}

/* Style the tab */
.tab {
  overflow: hidden;
  border: 1px solid #ccc;
  border-radius: 10px;
  background-color: #f1f1f1;
}

/* Style the buttons inside the tab */
.tab button {
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
  font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
  display: none;
  padding: 6px 12px;
  border: 1px solid #ccc;
  border-radius: 10px;
  border-top: none;
}
.prepaid_recharge {
  background-color: #f37335;
}
</style>

<div id="main"><!--- strat main--->
  <div class="tabOnlinPay paddingLeftRight"><!--- strat tabOnlinPay--->
    <div class="tabOnlineBox">
      <!-- Tab panes -->
      <ul id="nav" class="nav nav-pills" role="tablist">
        <?php if(isset($categorys)){?>
          <?php foreach($categorys as $key => $category){?>
            <li class="nav-item ">
              <?php if($key <= 8){?>
                <a class="nav-link "  href="<?php echo base_url('paystore/');?><?php echo str_replace('-', ' ', strtolower($category['url_name'])); ?>">
                  <?php echo $category['category_icone']; ?>
                  <p><?php echo $category['category_name']; ?></p>
                </a>
              <?php }else if($key === 9){?>
                <a class="waves-effect waves-light btn modal-trigger nav-link" data-toggle="pill" href="#modal1" data-target="#tab015">
                  <span style="font-size: 20px;display: inline-table;margin-top: 15px;">+5</span> 
                  <p>More</p>
                </a>
              <?php }?>
            </li>
          <?php } ?>
        <?php }?>
      </ul>

      <!-- Modal Structure -->
      <div id="modal1" class="more_model">
        <div class="modal-content">
          <ul class="nav nav-pills" role="tablist">
            <?php if(isset($categorys)){?>
              <?php foreach($categorys as $key => $category){?> 
                <?php if($key >= 10){?>  
                  <li class="nav-item spaceTabSection" style="margin: 6px;">
                    <a class="nav-link "  href="<?php echo base_url('paystore/');?><?php echo str_replace('-', ' ', strtolower($category['url_name'])); ?>">
                      <?php echo $category['category_icone']; ?>
                      <p><?php echo $category['category_name']; ?></p>
                    </a>
                  </li>
                <?php }?>
              <?php }?>
            <?php }?>
          </ul>
        </div>
      </div>

      <!-- Tab panes -->
      <div class="tab-content">
        <div id="tab002" class=" tab-pane active"><br>
          <h2>Pay Your Insurance Premium</h2>
          <p>Tell us your number and we will figure out the rest</p>
          <div class="col-xl-12">
            <div class="row">
              <div class="col-xl-12 checkBoxCustom">
                <div class="custom-control custom-checkbox">
                  <input type="radio" name="insurance_checkbox" id="pay_premium" value="pay premium" checked="checked" />
                  <label>Pay Premium</label>
                </div>
                <div class="custom-control custom-checkbox">
                  <input type="radio" name="insurance_checkbox" id="buy_insurance" value="buy insurance" />
                  <label>Buy Insurance</label>
                </div>
              </div>
            </div>
          </div>
          <div class="col-xl-12 figure">
            <div class="row">
              <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
                <div class="form-group">
                  <select class="form-control inputBox" title="Please Select Your Insurance" id="insurance_operator" onblur="validationallInsurance('insurance_operator', 'errorinsurance_operator', 'Operator cannot be empty.');">
                    <option value="">Select Insurance</option>
                    <?php if(isset($insurance_sub_categorys)){?>
                      <?php foreach($insurance_sub_categorys as $key => $sub_category){?>
                        <option value="<?php echo $sub_category['category_id'];?>"><?php echo $sub_category['subcategory_name'];?>
                        <img src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                      </option>
                    <?php }?>
                  <?php }?>
                </select>  
                <p class="p12 text-center color7 pull-left text-danger"><span name="errorinsurance_operator" id="errorinsurance_operator"
                  data-valmsg-for="insurance_operator"
                  data-valmsg-replace="true"><?php echo form_error('errorinsurance_operator'); ?></span>
                </p>
              </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
              <div class="form-group">
                <input type="text" class="form-control inputBox" id="insurance_policyno" placeholder="Policy Number" title="Please Enter Policy Number" onblur="validationallInsurance('insurance_policyno', 'errorinsurance_policyno', 'Policy Number cannot be empty.');">
                <p class="p12 text-center color7 pull-left text-danger"><span name="errorinsurance_policyno" id="errorinsurance_policyno"
                  data-valmsg-for="insurance_policyno"
                  data-valmsg-replace="true"><?php echo form_error('errorinsurance_policyno'); ?></span>
                </p>
              </div>
            </div>
          </div>
        </div>
        <button class="btn goButtob" title="Click Here" onclick="insurance_pay()" id="insurance_submit" disabled="disabled">Go</button>
      </div>
    </div>
  </div>
</div><!---end tabOnlinPay--->
<div class="wholeBox paddingLeftRight"><!--- strat tabOnlinPay--->
  <div class="row">
    <div class="col-xl-12">
      <p class="sliderHeading">Featured offer</p>
      <div class="owl-carousel owl-theme">
        <?php if(isset($paystore_offers)){?>
          <?php foreach($paystore_offers as $paystore_offer){?>
        <div class="item">
          <a href=""> <img src="<?php echo base_url('Assets/images/feature_offers/');?><?php echo $paystore_offer['offer_image'];?>" class="img-fluid"/></a>
        </div>
        <?php }?>
      <?php }?>
      </div>
    </div>
  </div>

</div>





<div class="whypayBills paddingLeftRight bgGradien">
  <div class="row">
    <div class="col-xl-6 col-lg-6 col-md-6 whypayBillsDetails">
      <h2 class="headingH2 color2">Why Pay bills On Paystore</h2>
      <p class="color2">Create multiple stores as per your requirements with no setup and maintenance charges. Just create your products and add it to your webstore. Share your webstore link with your customers on any platform and get paid online. You can sell Physical Items, Digital Items, Event tickets or Services.
      </p>
      <a href="" class="btn Button1">READ MORE</a>
    </div>
    <div class="col-xl-6 col-lg-6 col-md-6 whypayBillsImage">
      <img src="<?php echo base_url('Assets/NewDesign/images/16544-eps.png');?>" class="img-fluid"/>
    </div>
  </div>
</div>

<div class="whypayBills paddingLeftRight ">
  <div class="row">
    <div class="col-xl-6 col-lg-6 col-md-6 ">
      <img src="<?php echo base_url('Assets/NewDesign/images/445821-PF5LWH-598-eps.png');?>" class="img-fluid"/>
    </div>
    <div class="col-xl-6 col-lg-6 col-md-6 whypayBillsDetails">
      <h2 class="headingH2 color1">All In One Platform</h2>
      <p class="color1">No Need of POS machine
        A simple way to reach your customer for payments using our several link solutions with integrated QR code, Easepay and Quickpay can be circulated using integrated Email/SMS, whatsapp or any social media.
      </p>
    </div>
  </div>
</div>

<div class="whypayBills paddingLeftRight bgGradien">
  <div class="row">
    <div class="col-xl-6 col-lg-6 col-md-6 whypayBillsDetails">
      <h2 class="headingH2 color2">Paystore for Educational Institutes</h2>
      <p class="color2">Is your admission and fees collection process too complex? </br>
        We provide single platform where any educational institute can go paperless & collect payments online for their admission process, fee collection & much more.
      </p>
      <a href="" class="btn Button1">READ MORE</a>
    </div>
    <div class="col-xl-6 col-lg-6 col-md-6 whypayBillsImage">
      <img src="<?php echo base_url('Assets/NewDesign/images/672-eps.png');?>" class="img-fluid"/>
    </div>
  </div>
</div>

<div class="wholeBox paddingLeftRight"><!--- strat tabOnlinPay--->
  <div class="row">
    <div class="col-xl-12">
      <h4>Do Recharge & Bill Payments at Paystoreonline</h4><br>
      <div class="tab">
       <?php if(isset($tabscategorys)){?>
        <?php foreach($tabscategorys as $key => $category){?>                              
          <button class="tablinks" onclick="openCity(event, '<?php echo 'tab000'.$category['id']; ?>')" id="defaultOpen"><?php echo $category['category_name']; ?></button>
        <?php }?>
      <?php }?>
    </div>

    <div id="tab0001" class="tabcontent">
      <p>
        <?php if(is_array($mobile_sub_categorys)){?>
          <?php foreach($mobile_sub_categorys as $key => $sub_category){?>
            <a href="#" class="image"><img class="subcategory"  src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
              <?php echo $sub_category['subcategory_name'];?></a>
            <?php }?>
          <?php }else{?>
            <center><h4>Not Available Now</h4></center>
          <?php }?>
        </p>
      </div>

      <div id="tab0002" class="tabcontent">
        <p>
          <?php if(is_array($dth_sub_categorys)){?>
            <?php foreach($dth_sub_categorys as $key => $sub_category){?>
              <a href="#" class="image"><img  class="subcategory"  src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                <?php echo $sub_category['subcategory_name'];?></a>
              <?php }?>
            <?php }else{?>
              <center><h4>Not Available Now</h4></center>
            <?php }?>
          </p>
        </div>

        <div id="tab0003" class="tabcontent">
          <p>
            <?php if(is_array($datacard_sub_categorys)){?>
              <?php foreach($datacard_sub_categorys as $key => $sub_category){?>
                <a href="#" class="image"><img  class="subcategory" src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                  <?php echo $sub_category['subcategory_name'];?></a>
                <?php }?>
              <?php }else{?>
                <center><h4>Not Available Now</h4></center>
              <?php }?>
            </p>
          </div>

          <div id="tab0004" class="tabcontent">
            <p>
              <?php if(is_array($landline_sub_categorys)){?>
                <?php foreach($landline_sub_categorys as $key => $sub_category){?>
                  <a href="#" class="image"><img  class="subcategory" src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                    <?php echo $sub_category['subcategory_name'];?></a>
                  <?php }?>
                <?php }else{?>
                  <center><h4>Not Available Now</h4></center>
                <?php }?>
              </p>
            </div>

            <div id="tab0005" class="tabcontent">
              <p>
                <?php if(is_array($elecricity_sub_categorys)){?>
                  <?php foreach($elecricity_sub_categorys as $key => $sub_category){?>
                    <a href="#" class="image"><img  class="subcategory" src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                      <?php echo $sub_category['subcategory_name'];?></a>
                    <?php }?>
                  <?php }else{?>
                    <center><h4>Not Available Now</h4></center>
                  <?php }?>
                </p>
              </div>

              <div id="tab0006" class="tabcontent">
                <p>
                  <?php if(is_array($broadband_sub_categorys)){?>
                    <?php foreach($broadband_sub_categorys as $key => $sub_category){?>
                      <a href="#" class="image"><img  class="subcategory" src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                        <?php echo $sub_category['subcategory_name'];?></a>
                      <?php }?>
                    <?php }else{?>
                      <center><h4>Not Available Now</h4></center>
                    <?php }?>
                  </p>
                </div>

                <div id="tab0007" class="tabcontent">
                  <p>
                    <?php if(is_array($gas_sub_categorys)){?>
                      <?php foreach($gas_sub_categorys as $key => $sub_category){?>
                        <a href="#" class="image"><img  class="subcategory" src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                          <?php echo $sub_category['subcategory_name'];?></a>
                        <?php }?>
                      <?php }else{?>
                        <center><h4>Not Available Now</h4></center>
                      <?php }?>
                    </p>
                  </div>

                  <div id="tab0008" class="tabcontent">
                    <p>
                      <?php if(is_array($insurance_sub_categorys)){?>
                        <?php foreach($insurance_sub_categorys as $key => $sub_category){?>
                          <a href="#" class="image"><img class="subcategory" src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                            <?php echo $sub_category['subcategory_name'];?></a>
                          <?php }?>
                        <?php }else{?>
                          <center><h4>Not Available Now</h4></center>
                        <?php }?>
                      </p>
                    </div>

                    <div id="tab0009" class="tabcontent">
                      <p>
                        <?php if(is_array($transport_sub_categorys)){?>
                          <?php foreach($transport_sub_categorys as $key => $sub_category){?>
                            <a href="#" class="image"><img  class="subcategory" src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                              <?php echo $sub_category['subcategory_name'];?></a>
                            <?php }?>
                          <?php }else{?>
                            <center><h4>Not Available Now</h4></center>
                          <?php }?>
                        </p>
                      </div>

                      <div id="tab00016" class="tabcontent">
                      <p>
                        <?php if(is_array($casino_fee_sub_categorys)){?>
                          <?php foreach($casino_fee_sub_categorys as $key => $sub_category){?>
                            <a href="#" class="image"><img  class="subcategory" src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                              <?php echo $sub_category['subcategory_name'];?></a>
                            <?php }?>
                          <?php }else{?>
                            <center><h4>Not Available Now</h4></center>
                          <?php }?>
                        </p>
                      </div>

                      <!-- <div id="tab00010" class="tabcontent">
                        <h3>10London</h3>
                        <p>London is the capital city of England.</p>
                      </div>

                      <div id="tab00011" class="tabcontent">
                        <h3>11London</h3>
                        <p>London is the capital city of England.</p>
                      </div> -->
                    </div>
                  </div>

                </div>

                <script>
                  function openCity(evt, cityName) {
                    var i, tabcontent, tablinks;
                    tabcontent = document.getElementsByClassName("tabcontent");
                    for (i = 0; i < tabcontent.length; i++) {
                      tabcontent[i].style.display = "none";
                    }
                    tablinks = document.getElementsByClassName("tablinks");
                    for (i = 0; i < tablinks.length; i++) {
                      tablinks[i].className = tablinks[i].className.replace(" active", "");
                    }
                    document.getElementById(cityName).style.display = "block";
                    evt.currentTarget.className += " active";
                  }
                  document.getElementById("defaultOpen").click();
                </script>
                <script>
                  $( function() {
                    $( "#tabs" ).tabs();
                  } );
                </script>

                <script>
                  $('.nav-item').click(function() {
                    $('#modal1').modal('close');

                  });

    // Manage selection options Mobile Recharge
    $('#prepaid').click(function () {
      $('#prepaid').attr('checked', 'checked');
      $('#postpaid').removeAttr('checked');
    });

    $('#postpaid').click(function () {
      $('#postpaid').attr('checked', 'checked');
      $('#prepaid').removeAttr('checked');
    });

    // Manage selection options Datacard
    $('#datacard_prepaid').click(function () {
      $('#datacard_prepaid').attr('checked', 'checked');
      $('#datacard_postpaid').removeAttr('checked');
    });

    $('#datacard_postpaid').click(function () {
      $('#datacard_postpaid').attr('checked', 'checked');
      $('#datacard_prepaid').removeAttr('checked');
    });
      // Manage selection options Insurace
      $('#pay_premium').click(function () {
        $('#pay_premium').attr('checked', 'checked');
        $('#buy_insurance').removeAttr('checked');
      });

      $('#buy_insurance').click(function () {
        $('#buy_insurance').attr('checked', 'checked');
        $('#pay_premium').removeAttr('checked');
      });

      



      /*Start Insurance Recharge*/
      function validationallInsurance(filedname, spanname, message) {
        var username = $("#" + filedname).val();
        var insurance_policyno = $("#insurance_policyno").val();
        var insurance_operator = $("#insurance_operator").val();
        if (filedname == 'insurance_policyno') {
          if (username === "" || username === "null") {
            $("#" + spanname).html(message);
            $("#" + spanname).css("display", "block");
            $('#insurance_submit').attr('disabled', true);
            return false;
          }
          else {
            if (insurance_policyno.length < 8 || insurance_policyno.length > 10) {
              $("#" + spanname).text('Please enter valid Policy Number.');
              $("#" + spanname).css("display", "block");
              $('#insurance_submit').attr('disabled', true);
              return false;
            }
            else {
              var insurance_policyno = $("#insurance_policyno").val();
              var insurance_operator = $("#insurance_operator").val();
              if (insurance_policyno == '' || insurance_operator == '' || insurance_policyno.length < 8 || insurance_policyno.length > 10) {
                $('#insurance_submit').attr('disabled', true);
              }
              else {
                $('#insurance_submit').attr('disabled', false);
              }
              $("#" + spanname).text('');
              $("#" + spanname).css("display", "none");
              return true;
            }
          }
        }
        else if (filedname == 'insurance_operator') {
          if (username === "" || username === "null") {
            $("#" + spanname).html(message);
            $("#" + spanname).css("display", "block");
            $('#insurance_submit').attr('disabled', true);
            return false;
          }
          else {
            var insurance_policyno = $("#insurance_policyno").val();
            var insurance_operator = $("#insurance_operator").val();
            if (insurance_policyno == '' || insurance_operator == '' || insurance_policyno.length < 8 || insurance_policyno.length > 10) {
              $('#insurance_submit').attr('disabled', true);
            }
            else {
              $('#insurance_submit').attr('disabled', false);
            }
            $("#" + spanname).text('');
            $("#" + spanname).css("display", "none");
            return true;
          }
        }
        else {
          if (username === "" || username === "null") {
            $("#" + spanname).html(message);
            $("#" + spanname).css("display", "block");
            $('#submit_datacard').attr('disabled', true);
            return false;
          } else {
            $("#" + spanname).html("");
            return true;
          }
        }

      }

      function insurance_pay() {
        if ($('#pay_premium').attr('checked') == 'checked') {
          insurance_type = $('#pay_premium').val();

        } else if ($('#buy_insurance').attr('checked') == 'checked') {
          insurance_type = $('#buy_insurance').val();
        }
        var insurance_policyno = $("#insurance_policyno").val();
        var insurance_operator = $("#insurance_operator").val();
        var a = 0, b = 0, c = 0, d = 0, e = 0;
        if (insurance_policyno == '') {
          $("#errorinsurance_policyno").text('Policy Number cannot be empty.');
          $("#errorinsurance_policyno").css("display", "block");
          a = 1
        }
        else {
          if (insurance_policyno.length < 8 || insurance_policyno.length > 10) {
            $("#errorinsurance_policyno").text('Please enter valid Policy Number.');
            $("#errorinsurance_policyno").css("display", "block");
            a = 1;
          }
          else {
            $("#errorinsurance_policyno").text('');
            $("#errorinsurance_policyno").css("display", "none");
            a = 0;
          }
        }
        if (insurance_operator == '') {
         $("#errorinsurance_operator").text('Operator cannot be empty');
         $("#errorinsurance_operator").css("display", "block");
         b = 1;
       }
       else
       {
         $("#errorinsurance_operator").text('');
         $("#errorinsurance_operator").css("display", "none");
         b = 0;
       }
       if ((a == 0) && (b == 0)) {
         var datavalue = {
          'insurance_policyno': insurance_policyno,
          'insurance_operator': insurance_operator,
          'insurance_type': insurance_type,
        };

        //alert(JSON.stringify(datavalue));
        $.ajax
        ({
          type: "POST",
          data: JSON.stringify(datavalue),
          contentType: "application/json",
          dataType: "json",
          url: "<?php echo base_url('api/submit_insurance_recharge');?>",
          success: function (result) {
            var objToString = JSON.stringify(result);
            var stringToArray = [];
            stringToArray.push(objToString);
            var jsonObj = $.parseJSON(stringToArray);
            var message = jsonObj.Common.Message;
            var status = jsonObj.Common.Status;
            if (status == "Success") {
              swal("Insurance Premium Done!", "Insurance Premium Successfull.", "success");
                //window.location.href = "<?php echo base_url('paystore/dth_recharge'); ?>";
            }
            else {
              swal("Somthing Wrong !", "Somthing Wrong , Please Tray Again", "warning");
            }

          }
        });
      } else {
        return false;
        /*********************************/
      }
    }

    /*End Insurance Recharge*/
  </script>


