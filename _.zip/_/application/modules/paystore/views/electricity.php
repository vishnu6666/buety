
<style type="text/css">

.subcategory{
  width: 60px;
  height: 60px;
  max-width: 60px;
  max-height: 60px;
  border-radius: 50%;
}
.image{
  display: inline-grid;
  text-align: center;
  margin: 10px;
  padding: 15px;
  opacity: 1;
  border-radius: 3px;
}
.image{
  text-decoration: none;
}

/* Style the tab */
.tab {
  overflow: hidden;
  border: 1px solid #ccc;
  border-radius: 10px;
  background-color: #f1f1f1;
}

/* Style the buttons inside the tab */
.tab button {
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
  font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
  display: none;
  padding: 6px 12px;
  border: 1px solid #ccc;
  border-radius: 10px;
  border-top: none;
}
.prepaid_recharge {
  background-color: #f37335;
}
</style>

<div id="main"><!--- strat main--->
  <div class="tabOnlinPay paddingLeftRight"><!--- strat tabOnlinPay--->
    <div class="tabOnlineBox">
      <!-- Tab panes -->
      <ul id="nav" class="nav nav-pills" role="tablist">
        <?php if(isset($categorys)){?>
          <?php foreach($categorys as $key => $category){?>
            <li class="nav-item ">
              <?php if($key <= 8){?>
                <a class="nav-link "  href="<?php echo base_url('paystore/');?><?php echo str_replace('-', ' ', strtolower($category['url_name'])); ?>">
                  <?php echo $category['category_icone']; ?>
                  <p><?php echo $category['category_name']; ?></p>
                </a>
              <?php }else if($key === 9){?>
                <a class="waves-effect waves-light btn modal-trigger nav-link" data-toggle="pill" href="#modal1" data-target="#tab015">
                  <span style="font-size: 20px;display: inline-table;margin-top: 15px;">+5</span> 
                  <p>More</p>
                </a>
              <?php }?>
            </li>
          <?php } ?>
        <?php }?>
      </ul>

      <!-- Modal Structure -->
      <div id="modal1" class="more_model">
        <div class="modal-content">
          <ul class="nav nav-pills" role="tablist">
            <?php if(isset($categorys)){?>
              <?php foreach($categorys as $key => $category){?> 
                <?php if($key >= 10){?>  
                  <li class="nav-item spaceTabSection" style="margin: 6px;">
                    <a class="nav-link "  href="<?php echo base_url('paystore/');?><?php echo str_replace('-', ' ', strtolower($category['url_name'])); ?>">
                      <?php echo $category['category_icone']; ?>
                      <p><?php echo $category['category_name']; ?></p>
                    </a>
                  </li>
                <?php }?>
              <?php }?>
            <?php }?>
          </ul>
        </div>
      </div>

      <!-- Tab panes -->
      <div class="tab-content">    
        <div id="tab001" class="tab-pane active"><br>
          <h2>Pay For Electricity</h2>
          <p>Tell us your number and we will figure out the rest</p>
          <div class="col-xl-12 figure">
            <div class="row">
              <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
                <div class="form-group">
                  <select class="form-control inputBox" title="Please Select Your State" id="electricity_state" onblur="validationall_electricity('electricity_state', 'errorelectricity_state', 'State cannot be empty.');"> 
                    <option value="">Select State</option>
                    <?php if(isset($stats)){?>
                        <?php foreach($stats as $key => $stat){?>
                          <option value="<?php echo $stat['state_id'];?>"><?php echo $stat['state_name'];?>
                          <!-- <img src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $stat['subcategory_image'];?>"> -->
                        </option>
                      <?php }?>
                    <?php }?>
                  </select>
                  <p class="p12 text-center color7 pull-left text-danger"><span name="errorelectricity_state" id="errorelectricity_state"
                    data-valmsg-for="electricity_state"
                    data-valmsg-replace="true"><?php echo form_error('errorelectricity_state'); ?></span>
                  </p>
                </div>
              </div>
              <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
               <div class="form-group">
                <select class="form-control inputBox" title="Please Select Your Electricity Board" id="electricity_board" onblur="validationall_electricity('electricity_board', 'errorelectricity_board', 'Electricity Board cannot be empty.');">
                  <option value="">Select Electricity Board</option>
                  <?php if(isset($elecricity_sub_categorys)){?>
                    <?php foreach($elecricity_sub_categorys as $key => $sub_category){?>
                      <option value="<?php echo $sub_category['category_id'];?>"><?php echo $sub_category['subcategory_name'];?>
                      <img src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                    </option>
                  <?php }?>
                <?php }?>
              </select>
              <p class="p12 text-center color7 pull-left text-danger"><span name="errorelectricity_board" id="errorelectricity_board"
                data-valmsg-for="electricity_board"
                data-valmsg-replace="true"><?php echo form_error('errorelectricity_board'); ?></span>
              </p>
            </div>
          </div>
          <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
            <div class="form-group">
              <select class="form-control inputBox" title="Please Select Your District" id="electricity_district" onblur="validationall_electricity('electricity_district', 'errorelectricity_district', 'District cannot be empty.');">
                <option value="">Select District</option>
                <?php if(isset($citys)){?>
                        <?php foreach($citys as $key => $city){?>
                          <option value="<?php echo $city['city_id'];?>"><?php echo $city['city_name'];?>
                          <!-- <img src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $city['subcategory_image'];?>"> -->
                        </option>
                      <?php }?>
                    <?php }?>
              </select>
              <p class="p12 text-center color7 pull-left text-danger"><span name="errorelectricity_district" id="errorelectricity_district"
                data-valmsg-for="electricity_district"
                data-valmsg-replace="true"><?php echo form_error('errorelectricity_district'); ?></span>
              </p>
            </div>
          </div>
          <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
            <div class="form-group">
              <input type="text" class="form-control inputBox" id="electricity_number" placeholder="Service Number" title="Please Enter Your Service Number" onblur="validationall_electricity('electricity_number', 'errorelectricity_number', 'Service Number cannot be empty.');" onkeypress='return (event.charCode >= 48 && event.charCode <= 57 || event.charCode == 0)'>
              <p class="p12 text-center color7 pull-left text-danger"><span name="errorelectricity_number" id="errorelectricity_number"
                data-valmsg-for="electricity_number"
                data-valmsg-replace="true"><?php echo form_error('errorelectricity_number'); ?></span>
              </p>
            </div>
          </div>
        </div>
      </div>
      <button class="btn goButtob" title="Click Here" id="submit_electricity" onclick="electricity_pay()" disabled="disabled">Go</button>
    </div>
  </div>
</div>
</div><!---end tabOnlinPay--->

<div class="wholeBox paddingLeftRight"><!--- strat tabOnlinPay--->

  <div class="row">
    <div class="col-xl-12">
      <p class="sliderHeading">Featured offer</p>
      <div class="owl-carousel owl-theme">
        <?php if(isset($paystore_offers)){?>
          <?php foreach($paystore_offers as $paystore_offer){?>
        <div class="item">
          <a href=""> <img src="<?php echo base_url('Assets/images/feature_offers/');?><?php echo $paystore_offer['offer_image'];?>" class="img-fluid"/></a>
        </div>
        <?php }?>
      <?php }?>
      </div>
    </div>
  </div>

</div>





<div class="whypayBills paddingLeftRight bgGradien">
  <div class="row">
    <div class="col-xl-6 col-lg-6 col-md-6 whypayBillsDetails">
      <h2 class="headingH2 color2">Why Pay bills On Paystore</h2>
      <p class="color2">Create multiple stores as per your requirements with no setup and maintenance charges. Just create your products and add it to your webstore. Share your webstore link with your customers on any platform and get paid online. You can sell Physical Items, Digital Items, Event tickets or Services.
      </p>
      <a href="" class="btn Button1">READ MORE</a>
    </div>
    <div class="col-xl-6 col-lg-6 col-md-6 whypayBillsImage">
      <img src="<?php echo base_url('Assets/NewDesign/images/16544-eps.png');?>" class="img-fluid"/>
    </div>
  </div>
</div>

<div class="whypayBills paddingLeftRight ">
  <div class="row">
    <div class="col-xl-6 col-lg-6 col-md-6 ">
      <img src="<?php echo base_url('Assets/NewDesign/images/445821-PF5LWH-598-eps.png');?>" class="img-fluid"/>
    </div>
    <div class="col-xl-6 col-lg-6 col-md-6 whypayBillsDetails">
      <h2 class="headingH2 color1">All In One Platform</h2>
      <p class="color1">No Need of POS machine
        A simple way to reach your customer for payments using our several link solutions with integrated QR code, Easepay and Quickpay can be circulated using integrated Email/SMS, whatsapp or any social media.
      </p>
    </div>
  </div>
</div>

<div class="whypayBills paddingLeftRight bgGradien">
  <div class="row">
    <div class="col-xl-6 col-lg-6 col-md-6 whypayBillsDetails">
      <h2 class="headingH2 color2">Paystore for Educational Institutes</h2>
      <p class="color2">Is your admission and fees collection process too complex? </br>
        We provide single platform where any educational institute can go paperless & collect payments online for their admission process, fee collection & much more.
      </p>
      <a href="" class="btn Button1">READ MORE</a>
    </div>
    <div class="col-xl-6 col-lg-6 col-md-6 whypayBillsImage">
      <img src="<?php echo base_url('Assets/NewDesign/images/672-eps.png');?>" class="img-fluid"/>
    </div>
  </div>
</div>

<div class="wholeBox paddingLeftRight"><!--- strat tabOnlinPay--->
  <div class="row">
    <div class="col-xl-12">
      <h4>Do Recharge & Bill Payments at Paystoreonline</h4><br>
      <div class="tab">
       <?php if(isset($tabscategorys)){?>
        <?php foreach($tabscategorys as $key => $category){?>                              
          <button class="tablinks" onclick="openCity(event, '<?php echo 'tab000'.$category['id']; ?>')" id="defaultOpen"><?php echo $category['category_name']; ?></button>
        <?php }?>
      <?php }?>
    </div>

    <div id="tab0001" class="tabcontent">
      <p>
        <?php if(is_array($mobile_sub_categorys)){?>
          <?php foreach($mobile_sub_categorys as $key => $sub_category){?>
            <a href="#" class="image"><img class="subcategory"  src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
              <?php echo $sub_category['subcategory_name'];?></a>
            <?php }?>
          <?php }else{?>
            <center><h4>Not Available Now</h4></center>
          <?php }?>
        </p>
      </div>

      <div id="tab0002" class="tabcontent">
        <p>
          <?php if(is_array($dth_sub_categorys)){?>
            <?php foreach($dth_sub_categorys as $key => $sub_category){?>
              <a href="#" class="image"><img  class="subcategory"  src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                <?php echo $sub_category['subcategory_name'];?></a>
              <?php }?>
            <?php }else{?>
              <center><h4>Not Available Now</h4></center>
            <?php }?>
          </p>
        </div>

        <div id="tab0003" class="tabcontent">
          <p>
            <?php if(is_array($datacard_sub_categorys)){?>
              <?php foreach($datacard_sub_categorys as $key => $sub_category){?>
                <a href="#" class="image"><img  class="subcategory" src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                  <?php echo $sub_category['subcategory_name'];?></a>
                <?php }?>
              <?php }else{?>
                <center><h4>Not Available Now</h4></center>
              <?php }?>
            </p>
          </div>

          <div id="tab0004" class="tabcontent">
            <p>
              <?php if(is_array($landline_sub_categorys)){?>
                <?php foreach($landline_sub_categorys as $key => $sub_category){?>
                  <a href="#" class="image"><img  class="subcategory" src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                    <?php echo $sub_category['subcategory_name'];?></a>
                  <?php }?>
                <?php }else{?>
                  <center><h4>Not Available Now</h4></center>
                <?php }?>
              </p>
            </div>

            <div id="tab0005" class="tabcontent">
              <p>
                <?php if(is_array($elecricity_sub_categorys)){?>
                  <?php foreach($elecricity_sub_categorys as $key => $sub_category){?>
                    <a href="#" class="image"><img  class="subcategory" src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                      <?php echo $sub_category['subcategory_name'];?></a>
                    <?php }?>
                  <?php }else{?>
                    <center><h4>Not Available Now</h4></center>
                  <?php }?>
                </p>
              </div>

              <div id="tab0006" class="tabcontent">
                <p>
                  <?php if(is_array($broadband_sub_categorys)){?>
                    <?php foreach($broadband_sub_categorys as $key => $sub_category){?>
                      <a href="#" class="image"><img  class="subcategory" src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                        <?php echo $sub_category['subcategory_name'];?></a>
                      <?php }?>
                    <?php }else{?>
                      <center><h4>Not Available Now</h4></center>
                    <?php }?>
                  </p>
                </div>

                <div id="tab0007" class="tabcontent">
                  <p>
                    <?php if(is_array($gas_sub_categorys)){?>
                      <?php foreach($gas_sub_categorys as $key => $sub_category){?>
                        <a href="#" class="image"><img  class="subcategory" src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                          <?php echo $sub_category['subcategory_name'];?></a>
                        <?php }?>
                      <?php }else{?>
                        <center><h4>Not Available Now</h4></center>
                      <?php }?>
                    </p>
                  </div>

                  <div id="tab0008" class="tabcontent">
                    <p>
                      <?php if(is_array($insurance_sub_categorys)){?>
                        <?php foreach($insurance_sub_categorys as $key => $sub_category){?>
                          <a href="#" class="image"><img class="subcategory" src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                            <?php echo $sub_category['subcategory_name'];?></a>
                          <?php }?>
                        <?php }else{?>
                          <center><h4>Not Available Now</h4></center>
                        <?php }?>
                      </p>
                    </div>

                    <div id="tab0009" class="tabcontent">
                      <p>
                        <?php if(is_array($transport_sub_categorys)){?>
                          <?php foreach($transport_sub_categorys as $key => $sub_category){?>
                            <a href="#" class="image"><img  class="subcategory" src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                              <?php echo $sub_category['subcategory_name'];?></a>
                            <?php }?>
                          <?php }else{?>
                            <center><h4>Not Available Now</h4></center>
                          <?php }?>
                        </p>
                      </div>

                      <div id="tab00016" class="tabcontent">
                      <p>
                        <?php if(is_array($casino_fee_sub_categorys)){?>
                          <?php foreach($casino_fee_sub_categorys as $key => $sub_category){?>
                            <a href="#" class="image"><img  class="subcategory" src="<?php echo base_url('/Assets/images/subcategorys/') ?><?php echo $sub_category['subcategory_image'];?>">
                              <?php echo $sub_category['subcategory_name'];?></a>
                            <?php }?>
                          <?php }else{?>
                            <center><h4>Not Available Now</h4></center>
                          <?php }?>
                        </p>
                      </div>

                      <!-- <div id="tab00010" class="tabcontent">
                        <h3>10London</h3>
                        <p>London is the capital city of England.</p>
                      </div>

                      <div id="tab00011" class="tabcontent">
                        <h3>11London</h3>
                        <p>London is the capital city of England.</p>
                      </div> -->
                    </div>
                  </div>

                </div>

                <script>
                  function openCity(evt, cityName) {
                    var i, tabcontent, tablinks;
                    tabcontent = document.getElementsByClassName("tabcontent");
                    for (i = 0; i < tabcontent.length; i++) {
                      tabcontent[i].style.display = "none";
                    }
                    tablinks = document.getElementsByClassName("tablinks");
                    for (i = 0; i < tablinks.length; i++) {
                      tablinks[i].className = tablinks[i].className.replace(" active", "");
                    }
                    document.getElementById(cityName).style.display = "block";
                    evt.currentTarget.className += " active";
                  }
                  document.getElementById("defaultOpen").click();
                </script>
                <script>
                  $( function() {
                    $( "#tabs" ).tabs();
                  } );
                </script>

                <script>
                  $('.nav-item').click(function() {
                    $('#modal1').modal('close');

                  });

  // Manage selection options Mobile Recharge
  $('#prepaid').click(function () {
    $('#prepaid').attr('checked', 'checked');
    $('#postpaid').removeAttr('checked');
  });

  $('#postpaid').click(function () {
    $('#postpaid').attr('checked', 'checked');
    $('#prepaid').removeAttr('checked');
  });

  // Manage selection options Datacard
  $('#datacard_prepaid').click(function () {
    $('#datacard_prepaid').attr('checked', 'checked');
    $('#datacard_postpaid').removeAttr('checked');
  });

  $('#datacard_postpaid').click(function () {
    $('#datacard_postpaid').attr('checked', 'checked');
    $('#datacard_prepaid').removeAttr('checked');
  });
    // Manage selection options Insurace
    $('#pay_premium').click(function () {
      $('#pay_premium').attr('checked', 'checked');
      $('#buy_insurance').removeAttr('checked');
    });

    $('#buy_insurance').click(function () {
      $('#buy_insurance').attr('checked', 'checked');
      $('#pay_premium').removeAttr('checked');
    });




    /*Start Electricity Recharge*/

    function validationall_electricity(filedname, spanname, message) {
      var username = $("#" + filedname).val();
      var electricity_number = $("#electricity_number").val();
      var electricity_state = $("#electricity_state").val();
      var electricity_board = $("#electricity_board").val();
      var electricity_district = $("#electricity_district").val();
      var numpattern = /^[0-9]*$/;
      if (filedname == 'electricity_number') {
        if (username === "" || username === "null") {
          $("#" + spanname).html(message);
          $("#" + spanname).css("display", "block");
          $('#submit_electricity').attr('disabled', true);
          return false;
        }
        else {
          if (!electricity_number.match(numpattern)) {
            $("#" + spanname).text('Service Number cannot be empty.');
            $("#" + spanname).css("display", "block");
            $('#submit_electricity').attr('disabled', true);
            return false;
          }
          else {
            if (electricity_number.length < 8 || electricity_number.length > 9) {
              $("#" + spanname).text('Please enter valid Service Number.');
              $("#" + spanname).css("display", "block");
              $('#submit_electricity').attr('disabled', true);
              return false;
            }
            else {
              var electricity_number = $("#electricity_number").val();
              var electricity_board = $("#electricity_board").val();
              var electricity_state = $("#electricity_state").val();
              var electricity_district = $("#electricity_district").val();
              if (electricity_number == '' || electricity_board == '' || electricity_state == ''  || electricity_district == '' || electricity_number.length < 8 || electricity_number.length > 9) {
                $('#submit_electricity').attr('disabled', true);
              }
              else {
                $('#submit_electricity').attr('disabled', false);
              }
              $("#" + spanname).text('');
              $("#" + spanname).css("display", "none");
              return true;
            }
          }
        }
      }
      else if (filedname == 'electricity_state') {
        if (username === "" || username === "null") {
          $("#" + spanname).html(message);
          $("#" + spanname).css("display", "block");
          $('#submit_electricity').attr('disabled', true);
          return false;
        }
        else {
          var electricity_number = $("#electricity_number").val();
          var electricity_board = $("#electricity_board").val();
          var electricity_state = $("#electricity_state").val();
          var electricity_district = $("#electricity_district").val();
          if (electricity_number == '' || electricity_board == '' || electricity_state == ''  || electricity_district == '' || electricity_number.length < 8 || electricity_number.length > 9) {
            $('#submit_electricity').attr('disabled', true);
          }
          else {
            $('#submit_electricity').attr('disabled', false);
          }
          $("#" + spanname).text('');
          $("#" + spanname).css("display", "none");
          return true;
        }
      }
      else if (filedname == 'electricity_board') {
        if (username === "" || username === "null") {
          $("#" + spanname).html(message);
          $("#" + spanname).css("display", "block");
          $('#submit_electricity').attr('disabled', true);
          return false;
        }
        else {
          var electricity_number = $("#electricity_number").val();
          var electricity_board = $("#electricity_board").val();
          var electricity_district = $("#electricity_district").val();
          var electricity_state = $("#electricity_state").val();
          if (electricity_number == '' || electricity_board == '' || electricity_state == ''  || electricity_district == '' || electricity_number.length < 8 || electricity_number.length > 9) {
            $('#submit_electricity').attr('disabled', true);
          }
          else {
            $('#submit_electricity').attr('disabled', false);
          }
          $("#" + spanname).text('');
          $("#" + spanname).css("display", "none");
          return true;
        }
      }
      else if (filedname == 'electricity_board') {
        if (username === "" || username === "null") {
          $("#" + spanname).html(message);
          $("#" + spanname).css("display", "block");
          $('#submit_electricity').attr('disabled', true);
          return false;
        }
        else {
          var electricity_number = $("#electricity_number").val();
          var electricity_board = $("#electricity_board").val();
          var electricity_state = $("#electricity_state").val();
          var electricity_district = $("#electricity_district").val();
          if (electricity_number == '' || electricity_board == '' || electricity_state == ''  || electricity_district == '' || electricity_number.length < 8 || electricity_number.length > 9) {
            $('#submit_electricity').attr('disabled', true);
          }
          else {
            $('#submit_electricity').attr('disabled', false);
          }
          $("#" + spanname).text('');
          $("#" + spanname).css("display", "none");
          return true;
        }
      }
      else {
        if (username === "" || username === "null") {
          $("#" + spanname).html(message);
          $("#" + spanname).css("display", "block");
          $('#submit_electricity').attr('disabled', true);
          return false;
        } else {
          $("#" + spanname).html("");
          return true;
        }
      }

    }

    function electricity_pay() {
      var electricity_number = $("#electricity_number").val();
      var electricity_board = $("#electricity_board").val();
      var electricity_state = $("#electricity_state").val();
      var electricity_district = $("#electricity_district").val();
      var numpattern = /^[0-9]*$/;
      var a = 0, b = 0, c = 0, d = 0, e = 0, f = 0, g = 0, er = 0, m10 = 0, un = 0;
      if (electricity_number == '') {
        $("#errorelectricity_number").text('Service Number cannot be empty.');
        $("#errorelectricity_number").css("display", "block");
        a = 1
      }
      else {
        if (!electricity_number.match(numpattern)) {
          $("#errorelectricity_number").text('Enter Only number.');
          $("#errorelectricity_number").css("display", "block");
          a = 1;
        }
        else {
          if (electricity_number.length < 8 || electricity_number.length > 9) {
            $("#errorelectricity_number").text('Please enter valid Service Number.');
            $("#errorelectricity_number").css("display", "block");
            a = 1;
          }
          else {
            $("#errorelectricity_number").text('');
            $("#errorelectricity_number").css("display", "none");
            a = 0;
          }
        }
      }
      if (electricity_board == '') {
       $("#errorelectricity_board").text('Electricity Board cannot be empty');
       $("#errorelectricity_board").css("display", "block");
       b = 1;
     }
     else
     {
       $("#errorelectricity_board").text('');
       $("#errorelectricity_board").css("display", "none");
       b = 0;
     }
     if (electricity_district == '') {
       $("#errorelectricity_district").text('District cannot be empty.');
       $("#errorelectricity_district").css("display", "block");
       c = 1;
     }
     else
     {
       $("#errorelectricity_district").text('');
       $("#errorelectricity_district").css("display", "none");
       c = 0;
     }
     if (electricity_state == '') {
       $("#errorelectricity_state").text('State cannot be empty.');
       $("#errorelectricity_state").css("display", "block");
       d = 1;
     }
     else
     {
       $("#errorelectricity_state").text('');
       $("#errorelectricity_state").css("display", "none");
       d = 0;
     }
     if ((a == 0) && (b == 0) && (c == 0) && (d == 0)) {
       var datavalue = {
        'electricity_number': electricity_number,
        'electricity_board': electricity_board,
        'electricity_district': electricity_district,
        'electricity_state': electricity_state,
      };
      //alert(JSON.stringify(datavalue));
      $.ajax
      ({
        type: "POST",
        data: JSON.stringify(datavalue),
        contentType: "application/json",
        dataType: "json",
        url: "<?php echo base_url('api/submit_electricity_recharge');?>",
        success: function (result) {
          var objToString = JSON.stringify(result);
          var stringToArray = [];
          stringToArray.push(objToString);
          var jsonObj = $.parseJSON(stringToArray);
          var message = jsonObj.Common.Message;
          var status = jsonObj.Common.Status;
          if (status == "Success") {
            swal("Payment Done!", "Electricity Bill Pay Successfull.", "success");
            //window.location.href = "<?php echo base_url('paystore/electricity_bill_payment'); ?>";
            }
            else {
              swal("Somthing Wrong !", "Somthing Wrong , Please Tray Again", "warning");
            }

        }
      });
    } else {
      return false;
      /*********************************/
    }
  }

</script>


<!--strat menu js-->
