<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Paystore extends MX_Controller 
{
		function __construct()
		{
    		parent::__construct();
    		$this->load->model('paystore_model');
		}

		public function get_category_data()
		{
			$data['categorys']              = $this->paystore_model->get_tbl_categorys();
	        $data['tabscategorys']          = $this->paystore_model->get_tbl_tabs_categorys();
	        $data['stats']          		= $this->paystore_model->get_tbl_stats();
	        $data['citys']          		= $this->paystore_model->get_tbl_citys();
	        $data['mobile_sub_categorys']   = $this->paystore_model->get_mobile_sub_categorys();
	        $data['dth_sub_categorys']      = $this->paystore_model->get_dth_sub_categorys();
	        $data['datacard_sub_categorys'] = $this->paystore_model->get_datacard_sub_categorys();
	        $data['landline_sub_categorys'] = $this->paystore_model->get_landline_sub_categorys();
	        $data['elecricity_sub_categorys'] = $this->paystore_model->get_elecricity_sub_categorys();
	        $data['broadband_sub_categorys'] = $this->paystore_model->get_broadband_sub_categorys();
	        $data['gas_sub_categorys']      = $this->paystore_model->get_gas_sub_categorys();
	        $data['insurance_sub_categorys'] = $this->paystore_model->get_insurance_sub_categorys();
	        $data['transport_sub_categorys'] = $this->paystore_model->get_transport_sub_categorys();
	        $data['water_sub_categorys']    = $this->paystore_model->get_water_sub_categorys();
	        $data['cable_sub_categorys']    = $this->paystore_model->get_cable_sub_categorys();
	        $data['municipal_sub_categorys'] = $this->paystore_model->get_municipal_sub_categorys();
	        $data['institute_fee_sub_categorys'] = $this->paystore_model->get_institute_fee_sub_categorys();
	        $data['casino_fee_sub_categorys'] = $this->paystore_model->get_casino_fee_sub_categorys();
	        $data['paystore_offers'] = $this->paystore_model->get_paystore_offers();
	        return $data;
		}

		public function index()
		{
	        $this->template->title = 'Online Mobile Recharge, DTH Recharge, Bill Payments, Bus Tickets, Easy Recharge';
	        $this->template->content->view('paystore',$this->get_category_data());
	        $this->template->publish();
		}

		public function prepaid_recharge(){
			$this->template->title = 'Online Mobile Recharge';
	        $this->template->content->view('mobile',$this->get_category_data());
	        $this->template->publish();
		}

		public function dth_recharge(){
			$this->template->title = 'Online DTH Recharge';
	        $this->template->content->view('dth',$this->get_category_data());
	        $this->template->publish();
		}

		public function datacard_recharge()
		{
			$this->template->title = 'Online Datacard Recharge';
	        $this->template->content->view('datacard',$this->get_category_data());
	        $this->template->publish();
		}
		
		public function landline_bill_payment()
		{
			$this->template->title = 'Online Landline Bill Payment.';
	        $this->template->content->view('landline',$this->get_category_data());
	        $this->template->publish();
		}
		public function electricity_bill_payment()
		{
			$this->template->title = 'Online Electricity Bill Payment.';
	        $this->template->content->view('electricity',$this->get_category_data());
	        $this->template->publish();
		}

		public function broadband_bill_payment()
		{
			$this->template->title = 'Online Broadband Bill Payment.';
	        $this->template->content->view('broadband',$this->get_category_data());
	        $this->template->publish();
		}
		public function gas_bill_payment()
		{
			$this->template->title = 'Online Gas Payment.';
	        $this->template->content->view('gas',$this->get_category_data());
	        $this->template->publish();
		}
		public function insurance_payment()
		{
			$this->template->title = 'Online Insurance Payment.';
	        $this->template->content->view('insurance',$this->get_category_data());
	        $this->template->publish();
		}
		public function transport()
		{
			$this->template->title = 'Online Transport Payment.';
	        $this->template->content->view('transport',$this->get_category_data());
	        $this->template->publish();
		}

        public function water_bill_payment()
        {
            $this->template->title = 'Online Water Bill Payment.';
            $this->template->content->view('water-bill-payment',$this->get_category_data());
            $this->template->publish();
        }
        public function cable_bill_payment()
        {
            $this->template->title = 'Online Cable Bill Payment.';
            $this->template->content->view('cable-bill-payment',$this->get_category_data());
            $this->template->publish();
        }
        public function municipal_property_tax_payment()
        {
            $this->template->title = 'Online Municipal Property Tax Payment.';
            $this->template->content->view('municipal-property-tax-payment',$this->get_category_data());
            $this->template->publish();
        }
        public function pay_institute_fee()
        {
            $this->template->title = 'Online Pay Institute Fee.';
            $this->template->content->view('pay-institute-fee',$this->get_category_data());
            $this->template->publish();
        }

        public function pay_casino()
        {
        	$this->template->title = 'Online Pay Casino Fee.';
            $this->template->content->view('pay-casino',$this->get_category_data());
            $this->template->publish();
        }
		
}
