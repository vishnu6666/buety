<?php

class Api_model extends CI_Model
    {

    function __construct()
    {
            parent::__construct();
    }

    public function checkUserRegistration($mobile)
    {
        $this->db->select('count(*) as cnt');
        $this->db->from('tbl_registered_user');
        $this->db->where('mobile_number', $mobile);
        $query = $this->db->get();
        return $result = $query->row_array();
    }

    function getMobileDataByMobileno($mobile){
        $this->db->select('*');
        $this->db->from('tbl_registered_user');
        $this->db->where('mobile_number',$mobile);
        return $this->db->get()->row_array();
    }

    function getuserdata_by_id($lastid){
        $this->db->select('*');
        $this->db->from('tbl_registered_user');
        $this->db->where('id',$lastid);
        return $this->db->get()->row_array();
    }

    function insertOtpCode($data){
        return $this->db->insert('tbl_otp_code', $data);
    }

    function insertMobileData($data){
        return $this->db->insert('tbl_registered_user', $data);
    }

    function varifyOtpCodeSignup($registered_id,$otp_check_signup,$code_id){
        $this->db->select('*');
        $this->db->from('tbl_otp_code');
        $this->db->join('tbl_registered_user', 'tbl_otp_code.registered_id = tbl_registered_user.registered_id');
        $this->db->where('tbl_otp_code.registered_id',$registered_id);
        $this->db->where('tbl_otp_code.code',$otp_check_signup);
        $this->db->where('tbl_otp_code.code_id',$code_id);
        $this->db->where('tbl_otp_code.status',1);
        return $this->db->get()->row_array();
    }

    function updateOtpStatusSignup($data) {
        $this->db->where('registered_id', $data['registered_id']);
        return $this->db->update('tbl_otp_code', ['status' => 0]);
    }

    function checkExistMobileNumber($mobileNumber){
        $this->db->select('*');
        $this->db->from('tbl_registered_user');
        $this->db->where('mobile_number',$mobileNumber);
        // $this->db->where('verified',1);
        return $this->db->get()->row_array();
    }

    function updateOtpData_signup($registered_id, $code_id, $data) {
        $this->db->where('registered_id',$registered_id);
        $this->db->where('code_id', $code_id);
        $this->db->where('status', 1);
        return $this->db->update('tbl_otp_code', $data);
    }

    function insertOtpCode_login($data){
        return $this->db->insert('tbl_otp_login', $data);
    }

    function varifyOtpCodeLogin($id,$code,$code_id_login){
        $this->db->select('*');
        $this->db->from('tbl_otp_login');
        $this->db->join('tbl_registered_user', 'tbl_otp_login.registered_id = tbl_registered_user.registered_id');
        $this->db->where('tbl_otp_login.registered_id',$id);
        $this->db->where('tbl_otp_login.code',$code);
        $this->db->where('tbl_otp_login.code_id_login',$code_id_login);
        $this->db->where('tbl_otp_login.status',1);
        return $this->db->get()->row_array();
    }

    function updateOtpStatusLogin($data) {
        $this->db->where('registered_id', $data['registered_id']);
        return $this->db->update('tbl_otp_login', ['status' => 0]);
    }

    function updateOtpData_login($registered_id, $code_id_login, $data) {
        $this->db->where('registered_id',$registered_id);
        $this->db->where('code_id_login', $code_id_login);
        $this->db->where('status', 1);
        return $this->db->update('tbl_otp_login', $data);
    }

    public function insert_mobile_data($data)
    {
        $this->db->insert('tbl_mobile_rechage', $data);
        return true;
    }

    public function get_mobile_data()
    {
       $this->db->select('*')
            // ->where('category_id',12)
             ->from('tbl_mobile_rechage');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        }else{
            return false;
        } 
    }

    public function insert_dth_data($data)
    {
        $this->db->insert('tbl_dth_recharge', $data);
        return true;
    }

    public function get_dth_data()
    {
       $this->db->select('*')
            // ->where('category_id',12)
             ->from('tbl_dth_recharge');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        }else{
            return false;
        } 
    }

    public function insert_datacard_data($data)
    {
        $this->db->insert('tbl_datacard_recharge', $data);
        return true;
    }

    public function get_datacard_data()
    {
       $this->db->select('*')
            // ->where('category_id',12)
             ->from('tbl_datacard_recharge');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        }else{
            return false;
        } 
    }

    public function insert_landline_data($data)
    {
        $this->db->insert('tbl_landline_recharge', $data);
        return true;
    }

    public function get_landline_data()
    {
       $this->db->select('*')
            // ->where('category_id',12)
             ->from('tbl_landline_recharge');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        }else{
            return false;
        } 
    }

    public function insert_electricity_data($data)
    {
        $this->db->insert('tbl_electricity_pay', $data);
        return true;
    }

    public function get_electricity_data()
    {
       $this->db->select('*')
            // ->where('category_id',12)
             ->from('tbl_electricity_pay');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        }else{
            return false;
        } 
    }

    public function insert_broadband_data($data)
    {
        $this->db->insert('tbl_braodband_bill', $data);
        return true;
    }

    public function get_broadband_data()
    {
       $this->db->select('*')
            // ->where('category_id',12)
             ->from('tbl_braodband_bill');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        }else{
            return false;
        } 
    }

    public function insert_gas_data($data)
    {
        $this->db->insert('tbl_gas_payment', $data);
        return true;
    }

    public function get_gas_data()
    {
       $this->db->select('*')
            // ->where('category_id',12)
             ->from('tbl_gas_payment');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        }else{
            return false;
        } 
    }

    public function insert_insurance_data($data)
    {
        $this->db->insert('tbl_insurance_pay', $data);
        return true;
    }

    public function get_insurance_data()
    {
       $this->db->select('*')
            // ->where('category_id',12)
             ->from('tbl_insurance_pay');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        }else{
            return false;
        } 
    }

    public function insert_transport_data($data)
    {
        $this->db->insert('tbl_transportation', $data);
        return true;
    }

    public function get_transport_data()
    {
       $this->db->select('*')
            // ->where('category_id',12)
             ->from('tbl_transportation');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        }else{
            return false;
        } 
    }

    public function insert_water_pay_data($data)
    {
        $this->db->insert('tbl_water_pay', $data);
        return true;
    }

    public function get_water_pay_data()
    {
       $this->db->select('*')
            // ->where('category_id',12)
             ->from('tbl_water_pay');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        }else{
            return false;
        } 
    }

    public function insert_cable_pay_data($data)
    {
        $this->db->insert('tbl_cable_pay', $data);
        return true;
    }

    public function get_cable_pay_data()
    {
       $this->db->select('*')
            // ->where('category_id',12)
             ->from('tbl_cable_pay');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        }else{
            return false;
        } 
    }

    public function insert_municipal_pay_data($data)
    {
        $this->db->insert('tbl_municipal_pay', $data);
        return true;
    }

    public function get_municipal_pay_data()
    {
       $this->db->select('*')
            // ->where('category_id',12)
             ->from('tbl_municipal_pay');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        }else{
            return false;
        } 
    }

    public function insert_institute_fee_pay_data($data)
    {
        $this->db->insert('tbl_institute_pay', $data);
        return true;
    }

    public function get_institute_fee_pay_data()
    {
       $this->db->select('*')
            // ->where('category_id',12)
             ->from('tbl_institute_pay');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        }else{
            return false;
        } 
    }

    public function insert_casino_fee_pay_data($data)
    {
        $this->db->insert('tbl_casino_fee_pay', $data);
        return true;
    }

    public function get_casino_fee_pay_data()
    {
       $this->db->select('*')
            // ->where('category_id',12)
             ->from('tbl_casino_fee_pay');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        }else{
            return false;
        } 
    }
}
?>