<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Api extends MX_Controller 
{
		function __construct()
		{
    		parent::__construct();
    		$this->load->model('api_model');
		}

    public function otp_check_signup()
    {
            $registered_id = $this->session->userdata('registered_id');
            $code_id = $this->session->userdata('code_id');
            $otp_check_signup = $this->input->post('otp_check_signup');

            $result = 0;
            $user_data = $this->api_model->varifyOtpCodeSignup($registered_id,$otp_check_signup,$code_id);
       
            if ($user_data) { 
                 $otpStatus = $this->api_model->updateOtpStatusSignup($user_data);
                 $session_data = array(
                        "fname"         => $user_data['fname'],
                        "lname"         => $user_data['lname'],
                        "email"         => $user_data['email'],
                        "mobile_number" => $user_data['mobile_number'],
                        "birth_date"    => $user_data['birth_date'],
                        "gender"        => $user_data['gender'],
                        "verified"      => $user_data['verified'],
                        "logged_in"     => true,
                    );
                $this->session->set_userdata($session_data);
                $result = 2;
           }else{
                $result = 1;
            }
           echo $result;
        }
    public function signup()
    {
        $mobile_no = $this->input->post("mobile_no_signup");
        $email = $this->input->post("email_signup");
        $check_old_edit = $this->api_model->checkUserRegistration($mobile_no);

        $count = $check_old_edit['cnt'];
        $result = 0;
        if ($count > 0) {
             $getUser = $this->api_model->getMobileDataByMobileno($mobile_no);

               $Phonecode = rand(1111, 9999);
                $data_otp_phone = array(
                    'registered_id' => $getUser['registered_id'],
                    'code'    => $Phonecode,
                    'cdate'   => date('Y-m-d H:i:s'),
                    'status'  => '1',
                );
                //$this->sendMail($getUser['email'], $Phonecode);
                $res_otp = $this->api_model->insertOtpCode($data_otp_phone);
                $code_id_last = $this->db->insert_id();

                if ($res_otp === TRUE) {

                 $session_data = array(
                    'registered_id' => $getUser['registered_id'],
                    'code_id'       => $code_id_last,
                    );
                    $session_id = $this->session->set_userdata($session_data);
                    $result = 1;
             } else {
                    $result = 0;
                }
          } else {
            $data = array(
                'mobile_number' => $mobile_no,
                'email' => $email,
                'cdate' => date('Y-m-d H:i:s'),
                'udate' => date('Y-m-d H:i:s'),
            );
            $insertResult = $this->api_model->insertMobileData($data);
            if ($insertResult === TRUE) {

                $cid = $this->db->insert_id();

                $Phonecode = rand(1111, 9999);
                $data_otp_phone = array(
                    'registered_id' => $cid,
                    'code'    => $Phonecode,
                    'cdate'   => date('Y-m-d H:i:s'),
                    'status'  => '1',
                );
                //$getUser = $this->api_model->getuserdata_by_id($cid);

                //$this->sendMail($getUser['email'], $Phonecode);

                $res_otp = $this->api_model->insertOtpCode($data_otp_phone);
                $code_id_last = $this->db->insert_id();

                if ($res_otp === TRUE) {

                 $session_data = array(
                    'registered_id' => $cid,
                    'code_id'       => $code_id_last,
                    );
                    $session_id = $this->session->set_userdata($session_data);
                    $result = 1;
                } else {
                    $result = 0;
                }
            } else {
                $result = 0;
            }
        }

        echo $result;
    }

    public function login()
    {
            $mobile_no = $this->input->post('mobile_no');
            $result = 0;
            $user_data = $this->api_model->checkExistMobileNumber($mobile_no);
            $registered_id = $user_data['registered_id'];
             if ($user_data) { 
                $Phonecode = rand(1111, 9999);
                $data_otp_phone = array(
                    'registered_id' => $user_data['registered_id'],
                    'code'    => $Phonecode,
                    'cdate'   => date('Y-m-d H:i:s'),
                    'status'  => '1',
                );
                
                //$this->sendMail($user_data['email'], $Phonecode);

                $res_otp = $this->api_model->insertOtpCode_login($data_otp_phone);
                    $cid = $this->db->insert_id();
                if ($res_otp) {
                    $id = $this->session->set_userdata('registered_id',$registered_id);
                    $code_id_login = $this->session->set_userdata('code_id_login',$cid);
                    $result = 3;
                } else {
                    $result = 0;
                }
           }else{
                $result = 1;
            }
           echo $result;
    }

    public function otp_check_login()
    {
            $registered_id = $this->session->userdata('registered_id');
            $code_id_login = $this->session->userdata('code_id_login');
            $otp = $this->input->post('otp');

            $result = 0;
            $user_data = $this->api_model->varifyOtpCodeLogin($registered_id,$otp,$code_id_login);
       
            if ($user_data) { 
                 $otpStatus = $this->api_model->updateOtpStatusLogin($user_data);
                 $session_data = array(
                        "fname"         => $user_data['fname'],
                        "lname"         => $user_data['lname'],
                        "email"         => $user_data['email'],
                        "mobile_number" => $user_data['mobile_number'],
                        "birth_date"    => $user_data['birth_date'],
                        "gender"        => $user_data['gender'],
                        "verified"      => $user_data['verified'],
                        "logged_in"     => true,
                    );
                $this->session->set_userdata($session_data);
                $result = 2;
           }else{
                $result = 1;
            }
           echo $result;
    }

    public function resendOtpLogin()
    {
        $date = date("Y-m-d H:i:s");
        $registered_id = $this->session->userdata('registered_id');
        $code_id_login = $this->session->userdata('code_id_login');
        $result = 0;
        $data = array(
            'status' => 0,
            'cdate' => $date
        );
        $updateResult = $this->api_model->updateOtpData_login($registered_id, $code_id_login, $data);

        if ($updateResult === TRUE) {
            $otpCode = rand(1111, 9999);
            $data_otp_phone = array(
                'registered_id' => $registered_id,
                'code' => $otpCode,
                'cdate' => date("Y-m-d H:i:s")
            );
            $res_otp = $this->api_model->insertOtpCode_login($data_otp_phone);
             $insert_id = $this->db->insert_id();
            if ($res_otp == TRUE) {
                $code_id_login = $this->session->set_userdata('code_id_login',$insert_id);
                $result = 1;
            } else {
                $result = 0;
            }
        } else {
            $result = 0;
        }
        echo $result;
    }

    public function resendOtpSignup()
    {
        $date = date("Y-m-d H:i:s");
        $registered_id = $this->session->userdata('registered_id');
        $code_id = $this->session->userdata('code_id');
        $result = 0;
        $data = array(
            'status' => 0,
            'cdate' => $date
        );
        $updateResult = $this->api_model->updateOtpData_signup($registered_id, $code_id, $data);

        if ($updateResult === TRUE) {
            $otpCode = rand(1111, 9999);
            $data_otp_phone = array(
                'registered_id' => $registered_id,
                'code' => $otpCode,
                'cdate' => date("Y-m-d H:i:s")
            );
            $res_otp = $this->api_model->insertOtpCode($data_otp_phone);
             $insert_id = $this->db->insert_id();
            if ($res_otp == TRUE) {
                $code_id = $this->session->set_userdata('code_id',$insert_id);
                $result = 1;
            } else {
                $result = 0;
            }
        } else {
            $result = 0;
        }
        echo $result;
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect(base_url());
    }

    public function sendMail($to,$Phonecode)
    {
        /*$this->load->library('email');
        $config = Array(
            'protocol' => 'smtp',
            'smtp_host' => 'ssl://smtp.googlemail.com',
            'smtp_port' => ,
            'smtp_user' => '',
            'smtp_pass' => '',
            'mailtype' => 'html',
            'charset' => 'iso-8859-1'
        );
        $subject ="this is test.";
        $body = "OK this is bydy ";
        $this->email->initialize($config);
        $this->email->set_mailtype("html");
        $this->email->set_newline("\r\n");
        $this->email->from('jashphp@gmail.com', 'Bimabazaaar');
        $this->email->to($to);
        $this->email->subject($subject);
        $this->email->message($body);
        $this->email->send();*/
        $subject ="this is test.";
        $body ="this is test for body.";
        mail($to,$Phonecode,$body);
        return TRUE;
    }

    public function logoutAccount()
    {
        if (($_SERVER['CONTENT_TYPE'] == 'application/json') && ($_SERVER['REQUEST_METHOD'] == 'POST')) {
            $inputJSON = file_get_contents("php://input");
            $input = json_decode($inputJSON, TRUE);

            $this->session->sess_destroy();

            $status = "Success";
            $message = "Logout Successful.";

            $data = array("Common" => array("Title" => "logout Account Api", 'version' => '1.0', 'Description' => 'logout Account Api', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => 'LOGGED_OUT');
            print(json_encode($data, JSON_UNESCAPED_UNICODE));
        } else {
            $status = "Fail";
            $message = "Invalid request.";

            $data = array("Common" => array("Title" => "logout Account Api", 'version' => '1.0', 'Description' => 'logout Account Api', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("value" => "INVALID_REQUEST"));
            print(json_encode($data, JSON_UNESCAPED_UNICODE));
        }
    }

	public function submit_mobile_recharge()
    {
        if ($_SERVER['CONTENT_TYPE'] == 'application/json' && $_SERVER['REQUEST_METHOD'] == 'POST') {
            $inputJSON = file_get_contents("php://input");
            $input = json_decode($inputJSON, TRUE);

            $data = array(
               'sim_type' => $input['sim_type'],
               'mobile_number' => $input['mobile_number'],
               'mobile_operator' => $input['mobile_operator'],
               'mobile_circle' => $input['mobile_circle'],
               'mobilerecharge_amount' => $input['mobilerecharge_amount'],
               'cdate' => date('Y-m-d H:i:s'),
            );
            $insertResult = $this->api_model->insert_mobile_data($data);
            $getUserData = $this->api_model->get_mobile_data();
             if($insertResult != FALSE){
                    $status = "Success";
                    $message = "Sucessfully Mobile Recharge.";
                    $data = array("Common" => array("Title" => "Online Mobile Recharge", 'version' => '1.0', 'Description' => 'Online Mobile Recharge API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Success', "Data" => $getUserData));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                } else {
                    $status = "Fail";
                    $message = "No Record Found.";
                    $data = array("Common" => array("Title" => "Online Mobile Recharge", 'version' => '1.0', 'Description' => 'Online Mobile Recharge API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                }
        } else {
            $status = "Fail";
            $message = "Invalid Request.";

            $data = array("Common" => array("Title" => "Online Mobile Recharge", 'version' => '1.0', 'Description' => 'Online Mobile Recharge API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
            print(json_encode($data, JSON_UNESCAPED_UNICODE));
        }
    }

    public function submit_dth_recharge()
    {
        if ($_SERVER['CONTENT_TYPE'] == 'application/json' && $_SERVER['REQUEST_METHOD'] == 'POST') {
            $inputJSON = file_get_contents("php://input");
            $input = json_decode($inputJSON, TRUE);

            $data = array(
               'dth_customer_id' => $input['dth_customer_id'],
               'dth_operator' => $input['dth_operator'],
               'dth_amount' => $input['dth_amount'],
               'cdate' => date('Y-m-d H:i:s'),
            );

            $insertResult = $this->api_model->insert_dth_data($data);
            $getUserData = $this->api_model->get_dth_data();
                if($insertResult != FALSE){
                    $status = "Success";
                    $message = "Sucessfully DTH Recharge.";
                    $data = array("Common" => array("Title" => "Online DTH Recharge API", 'version' => '1.0', 'Description' => 'Online DTH Recharge API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Success', "Data" => $getUserData));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                } else {
                    $status = "Fail";
                    $message = "No Record Found.";
                    $data = array("Common" => array("Title" => "Online DTH Recharge API", 'version' => '1.0', 'Description' => 'Online DTH Recharge API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                }
        } else {
            $status = "Fail";
            $message = "Invalid Request.";

            $data = array("Common" => array("Title" => "Online DTH Recharge API", 'version' => '1.0', 'Description' => 'Online DTH Recharge API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
            print(json_encode($data, JSON_UNESCAPED_UNICODE));
        }
    }

    public function submit_datacard_recharge()
    {
        if ($_SERVER['CONTENT_TYPE'] == 'application/json' && $_SERVER['REQUEST_METHOD'] == 'POST') {
            $inputJSON = file_get_contents("php://input");
            $input = json_decode($inputJSON, TRUE);

            $data = array(
               'datacard_number' => $input['datacard_number'],
               'datacard_type' => $input['datacard_type'],
               'datacard_operator' => $input['datacard_operator'],
               'datacard_circle' => $input['datacard_circle'],
               'datacard_amount' => $input['datacard_amount'],
               'cdate' => date('Y-m-d H:i:s'),
            );

            $insertResult = $this->api_model->insert_datacard_data($data);
            $getUserData = $this->api_model->get_datacard_data();
              if($insertResult != FALSE){
                    $status = "Success";
                    $message = "Sucessfully Online Datacard Recharge.";
                    $data = array("Common" => array("Title" => "Online Datacard Recharge API", 'version' => '1.0', 'Description' => 'Online Datacard Recharge API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Success', "Data" => $getUserData));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                } else {
                    $status = "Fail";
                    $message = "No Record Found.";
                    $data = array("Common" => array("Title" => "Online Datacard Recharge API", 'version' => '1.0', 'Description' => 'Online Datacard Recharge API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                }
        } else {
            $status = "Fail";
            $message = "Invalid Request.";

            $data = array("Common" => array("Title" => "Online Datacard Recharge API", 'version' => '1.0', 'Description' => 'Online Datacard Recharge API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
            print(json_encode($data, JSON_UNESCAPED_UNICODE));
        }
    }

    public function submit_landline_recharge()
    {
        if ($_SERVER['CONTENT_TYPE'] == 'application/json' && $_SERVER['REQUEST_METHOD'] == 'POST') {
            $inputJSON = file_get_contents("php://input");
            $input = json_decode($inputJSON, TRUE);

            $data = array(
               'landline_number' => $input['landline_number'],
               'landline_operator' => $input['landline_operator'],
               'landline_amount' => $input['landline_amount'],
               'cdate' => date('Y-m-d H:i:s'),
            );

            $insertResult = $this->api_model->insert_landline_data($data);
            $getUserData = $this->api_model->get_landline_data();
              if($insertResult != FALSE){
                    $status = "Success";
                    $message = "Sucessfully Online Landline Recharge.";
                    $data = array("Common" => array("Title" => "Online Landline Recharge API", 'version' => '1.0', 'Description' => 'Online Landline Recharge API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Success', "Data" => $getUserData));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                } else {
                    $status = "Fail";
                    $message = "No Record Found.";
                    $data = array("Common" => array("Title" => "Online Landline Recharge API", 'version' => '1.0', 'Description' => 'Online Landline Recharge API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                }
        } else {
            $status = "Fail";
            $message = "Invalid Request.";

            $data = array("Common" => array("Title" => "Online Landline Recharge API", 'version' => '1.0', 'Description' => 'Online Landline Recharge API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
            print(json_encode($data, JSON_UNESCAPED_UNICODE));
        }
    }

    public function submit_electricity_recharge()
    {
        if ($_SERVER['CONTENT_TYPE'] == 'application/json' && $_SERVER['REQUEST_METHOD'] == 'POST') {
            $inputJSON = file_get_contents("php://input");
            $input = json_decode($inputJSON, TRUE);

            $data = array(
               'electricity_number' => $input['electricity_number'],
               'electricity_board' => $input['electricity_board'],
               'electricity_district' => $input['electricity_district'],
               'electricity_state' => $input['electricity_state'],
               'cdate' => date('Y-m-d H:i:s'),
            );

            $insertResult = $this->api_model->insert_electricity_data($data);
            $getUserData = $this->api_model->get_electricity_data();
              if($insertResult != FALSE){
                    $status = "Success";
                    $message = "Sucessfully Online Electricity Bill Pay.";
                    $data = array("Common" => array("Title" => "Online Electricity Bill Pay API", 'version' => '1.0', 'Description' => 'Online Electricity Bill API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Success', "Data" => $getUserData));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                } else {
                    $status = "Fail";
                    $message = "No Record Found.";
                    $data = array("Common" => array("Title" => "Online Electricity Bill API", 'version' => '1.0', 'Description' => 'Online Electricity Bill API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                }
        } else {
            $status = "Fail";
            $message = "Invalid Request.";

            $data = array("Common" => array("Title" => "Online Electricity Bill API", 'version' => '1.0', 'Description' => 'Online Electricity Bill API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
            print(json_encode($data, JSON_UNESCAPED_UNICODE));
        }
    }

    public function submit_broadband_recharge()
    {
        if ($_SERVER['CONTENT_TYPE'] == 'application/json' && $_SERVER['REQUEST_METHOD'] == 'POST') {
            $inputJSON = file_get_contents("php://input");
            $input = json_decode($inputJSON, TRUE);

            $data = array(
               'broadband_number' => $input['broadband_number'],
               'broadband_operator'  => $input['broadband_operator'],
               'broadband_amount' => $input['broadband_amount'],
               'cdate'              => date('Y-m-d H:i:s'),
            );

            $insertResult = $this->api_model->insert_broadband_data($data);
            $getUserData = $this->api_model->get_broadband_data();
              if($insertResult != FALSE){
                    $status = "Success";
                    $message = "Sucessfully Online Broadband Bill Pay.";
                    $data = array("Common" => array("Title" => "Online Broadband Bill Pay API", 'version' => '1.0', 'Description' => 'Online Broadband Bill API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Success', "Data" => $getUserData));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                } else {
                    $status = "Fail";
                    $message = "No Record Found.";
                    $data = array("Common" => array("Title" => "Online Broadband Bill API", 'version' => '1.0', 'Description' => 'Online Broadband Bill API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                }
        } else {
            $status = "Fail";
            $message = "Invalid Request.";

            $data = array("Common" => array("Title" => "Online Broadband Bill API", 'version' => '1.0', 'Description' => 'Online Broadband Bill API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
            print(json_encode($data, JSON_UNESCAPED_UNICODE));
        }
    }

    public function submit_gas_recharge()
    {
        if ($_SERVER['CONTENT_TYPE'] == 'application/json' && $_SERVER['REQUEST_METHOD'] == 'POST') {
            $inputJSON = file_get_contents("php://input");
            $input = json_decode($inputJSON, TRUE);

            $data = array(
               'gas_number' => $input['gas_number'],
               'gas_provider'  => $input['gas_provider'],
               'cdate'              => date('Y-m-d H:i:s'),
            );

            $insertResult = $this->api_model->insert_gas_data($data);
            $getUserData = $this->api_model->get_gas_data();
              if($insertResult != FALSE){
                    $status = "Success";
                    $message = "Sucessfully Online Gas Bill Pay.";
                    $data = array("Common" => array("Title" => "Online Gas Bill Pay API", 'version' => '1.0', 'Description' => 'Online Gas Bill API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Success', "Data" => $getUserData));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                } else {
                    $status = "Fail";
                    $message = "No Record Found.";
                    $data = array("Common" => array("Title" => "Online Gas Bill API", 'version' => '1.0', 'Description' => 'Online Gas Bill API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                }
        } else {
            $status = "Fail";
            $message = "Invalid Request.";

            $data = array("Common" => array("Title" => "Online Gas Bill API", 'version' => '1.0', 'Description' => 'Online Gas Bill API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
            print(json_encode($data, JSON_UNESCAPED_UNICODE));
        }
    }

    public function submit_insurance_recharge()
    {
        if ($_SERVER['CONTENT_TYPE'] == 'application/json' && $_SERVER['REQUEST_METHOD'] == 'POST') {
            $inputJSON = file_get_contents("php://input");
            $input = json_decode($inputJSON, TRUE);

            $data = array(
               'insurance_policyno' => $input['insurance_policyno'],
               'insurance_operator' => $input['insurance_operator'],
               'insurance_type'     => $input['insurance_type'],
               'cdate'              => date('Y-m-d H:i:s'),
            );

            $insertResult = $this->api_model->insert_insurance_data($data);
            $getUserData = $this->api_model->get_insurance_data();
              if($insertResult != FALSE){
                    $status = "Success";
                    $message = "Sucessfully Insurance Premium .";
                    $data = array("Common" => array("Title" => "Online Insurance Premium API", 'version' => '1.0', 'Description' => 'Online Insurance Premium API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Success', "Data" => $getUserData));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                } else {
                    $status = "Fail";
                    $message = "No Record Found.";
                    $data = array("Common" => array("Title" => "Online Insurance Premium API", 'version' => '1.0', 'Description' => 'Online Insurance Premium API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                }
        } else {
            $status = "Fail";
            $message = "Invalid Request.";

            $data = array("Common" => array("Title" => "Online Insurance Premium API", 'version' => '1.0', 'Description' => 'Online Insurance Premium API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
            print(json_encode($data, JSON_UNESCAPED_UNICODE));
        }
    }

    public function submit_transport()
    {
        if ($_SERVER['CONTENT_TYPE'] == 'application/json' && $_SERVER['REQUEST_METHOD'] == 'POST') {
            $inputJSON = file_get_contents("php://input");
            $input = json_decode($inputJSON, TRUE);

            $data = array(
               'bus_card_no'  => $input['bus_card_no'],
               'bus_operator' => $input['bus_operator'],
               'cdate'        => date('Y-m-d H:i:s'),
            );

            $insertResult = $this->api_model->insert_transport_data($data);
            $getUserData = $this->api_model->get_transport_data();
              if($insertResult != FALSE){
                    $status = "Success";
                    $message = "Sucessfully Transport Pay .";
                    $data = array("Common" => array("Title" => "Online Transport API", 'version' => '1.0', 'Description' => 'Online Transport API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Success', "Data" => $getUserData));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                } else {
                    $status = "Fail";
                    $message = "No Record Found.";
                    $data = array("Common" => array("Title" => "Online Transport API", 'version' => '1.0', 'Description' => 'Online Transport API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                }
        } else {
            $status = "Fail";
            $message = "Invalid Request.";

            $data = array("Common" => array("Title" => "Online Transport API", 'version' => '1.0', 'Description' => 'Online Transport API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
            print(json_encode($data, JSON_UNESCAPED_UNICODE));
        }
    }

    public function submit_water_pay()
    {
        if ($_SERVER['CONTENT_TYPE'] == 'application/json' && $_SERVER['REQUEST_METHOD'] == 'POST') {
            $inputJSON = file_get_contents("php://input");
            $input = json_decode($inputJSON, TRUE);

            $data = array(
               'water_connection_id'  => $input['water_connection_id'],
               'water_operator' => $input['water_operator'],
               'cdate'        => date('Y-m-d H:i:s'),
            );

            $insertResult = $this->api_model->insert_water_pay_data($data);
            $getUserData = $this->api_model->get_water_pay_data();
              if($insertResult != FALSE){
                    $status = "Success";
                    $message = "Sucessfully Transport Pay .";
                    $data = array("Common" => array("Title" => "Online Transport API", 'version' => '1.0', 'Description' => 'Online Transport API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Success', "Data" => $getUserData));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                } else {
                    $status = "Fail";
                    $message = "No Record Found.";
                    $data = array("Common" => array("Title" => "Online Transport API", 'version' => '1.0', 'Description' => 'Online Transport API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                }
        } else {
            $status = "Fail";
            $message = "Invalid Request.";

            $data = array("Common" => array("Title" => "Online Transport API", 'version' => '1.0', 'Description' => 'Online Transport API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
            print(json_encode($data, JSON_UNESCAPED_UNICODE));
        }
    }

    public function submit_cable_pay()
    {
        if ($_SERVER['CONTENT_TYPE'] == 'application/json' && $_SERVER['REQUEST_METHOD'] == 'POST') {
            $inputJSON = file_get_contents("php://input");
            $input = json_decode($inputJSON, TRUE);

            $data = array(
               'cable_ac_no'  => $input['cable_ac_no'],
               'cable_operator' => $input['cable_operator'],
               'cable_amount' => $input['cable_amount'],
               'cdate'        => date('Y-m-d H:i:s'),
            );

            $insertResult = $this->api_model->insert_cable_pay_data($data);
            $getUserData = $this->api_model->get_cable_pay_data();
              if($insertResult != FALSE){
                    $status = "Success";
                    $message = "Sucessfully Cable Bill Payment .";
                    $data = array("Common" => array("Title" => "Online Cable Bill Payment API", 'version' => '1.0', 'Description' => 'Online Cable Bill Payment API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Success', "Data" => $getUserData));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                } else {
                    $status = "Fail";
                    $message = "No Record Found.";
                    $data = array("Common" => array("Title" => "Online Cable Bill Payment API", 'version' => '1.0', 'Description' => 'Online Cable Bill Payment API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                }
        } else {
            $status = "Fail";
            $message = "Invalid Request.";

            $data = array("Common" => array("Title" => "Online Cable Bill Payment API", 'version' => '1.0', 'Description' => 'Online Cable Bill Payment API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
            print(json_encode($data, JSON_UNESCAPED_UNICODE));
        }
    }

    public function submit_municipal_pay()
    {
        if ($_SERVER['CONTENT_TYPE'] == 'application/json' && $_SERVER['REQUEST_METHOD'] == 'POST') {
            $inputJSON = file_get_contents("php://input");
            $input = json_decode($inputJSON, TRUE);

            $data = array(
               'municipal_mobile_num'   => $input['municipal_mobile_num'],
               'municipal_operator'     => $input['municipal_operator'],
               'municipal_property_id'  => $input['municipal_property_id'],
               'municipal_email'        => $input['municipal_email'],
               'cdate'                  => date('Y-m-d H:i:s'),
            );

            $insertResult = $this->api_model->insert_municipal_pay_data($data);
            $getUserData = $this->api_model->get_municipal_pay_data();
              if($insertResult != FALSE){
                    $status = "Success";
                    $message = "Sucessfully Municipal Pay .";
                    $data = array("Common" => array("Title" => "Online Municipal API", 'version' => '1.0', 'Description' => 'Online Municipal API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Success', "Data" => $getUserData));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                } else {
                    $status = "Fail";
                    $message = "No Record Found.";
                    $data = array("Common" => array("Title" => "Online Municipal API", 'version' => '1.0', 'Description' => 'Online Municipal API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                }
        } else {
            $status = "Fail";
            $message = "Invalid Request.";

            $data = array("Common" => array("Title" => "Online Municipal API", 'version' => '1.0', 'Description' => 'Online Municipal API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
            print(json_encode($data, JSON_UNESCAPED_UNICODE));
        }
    }

    public function submit_education_pay()
    {
        if ($_SERVER['CONTENT_TYPE'] == 'application/json' && $_SERVER['REQUEST_METHOD'] == 'POST') {
            $inputJSON = file_get_contents("php://input");
            $input = json_decode($inputJSON, TRUE);

            $data = array(
               'edu_institute_location'  => $input['edu_institute_location'],
               'edu_institute' => $input['edu_institute'],
               'cdate'        => date('Y-m-d H:i:s'),
            );

            $insertResult = $this->api_model->insert_institute_fee_pay_data($data);
            $getUserData = $this->api_model->get_institute_fee_pay_data();
              if($insertResult != FALSE){
                    $status = "Success";
                    $message = "Sucessfully Pay Institute Fee .";
                    $data = array("Common" => array("Title" => "Online Pay Institute Fee API", 'version' => '1.0', 'Description' => 'Online Pay Institute Fee API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Success', "Data" => $getUserData));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                } else {
                    $status = "Fail";
                    $message = "No Record Found.";
                    $data = array("Common" => array("Title" => "Online Pay Institute Fee API", 'version' => '1.0', 'Description' => 'Online Pay Institute Fee API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                }
        } else {
            $status = "Fail";
            $message = "Invalid Request.";

            $data = array("Common" => array("Title" => "Online Pay Institute Fee API", 'version' => '1.0', 'Description' => 'Online Pay Institute Fee API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
            print(json_encode($data, JSON_UNESCAPED_UNICODE));
        }
    }

    public function submit_casino_pay()
    {
        if ($_SERVER['CONTENT_TYPE'] == 'application/json' && $_SERVER['REQUEST_METHOD'] == 'POST') {
            $inputJSON = file_get_contents("php://input");
            $input = json_decode($inputJSON, TRUE);

            $data = array(
               'casino_name'  => $input['casino_name'],
               'amount' => $input['amount'],
               'cdate'        => date('Y-m-d H:i:s'),
            );

            $insertResult = $this->api_model->insert_casino_fee_pay_data($data);
            $getUserData = $this->api_model->get_casino_fee_pay_data();
              if($insertResult != FALSE){
                    $status = "Success";
                    $message = "Sucessfully Pay Casino Fee .";
                    $data = array("Common" => array("Title" => "Online Pay Casino Fee API", 'version' => '1.0', 'Description' => 'Online Pay Casino Fee API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Success', "Data" => $getUserData));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                } else {
                    $status = "Fail";
                    $message = "No Record Found.";
                    $data = array("Common" => array("Title" => "Online Pay Casino Fee API", 'version' => '1.0', 'Description' => 'Online Pay Casino Fee API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
                    print(json_encode($data, JSON_UNESCAPED_UNICODE));
                }
        } else {
            $status = "Fail";
            $message = "Invalid Request.";

            $data = array("Common" => array("Title" => "Online Pay Casino Fee API", 'version' => '1.0', 'Description' => 'Online Pay Casino Fee API', 'Method' => 'POST', 'Status' => $status, 'Message' => $message), "Response" => array("Value" => 'Fail'));
            print(json_encode($data, JSON_UNESCAPED_UNICODE));
        }
    }
}
