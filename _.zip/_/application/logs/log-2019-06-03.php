<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-06-03 10:42:08 --> Config Class Initialized
INFO - 2019-06-03 10:42:08 --> Hooks Class Initialized
DEBUG - 2019-06-03 10:42:08 --> UTF-8 Support Enabled
INFO - 2019-06-03 10:42:08 --> Utf8 Class Initialized
INFO - 2019-06-03 10:42:08 --> URI Class Initialized
DEBUG - 2019-06-03 10:42:08 --> No URI present. Default controller set.
INFO - 2019-06-03 10:42:08 --> Router Class Initialized
INFO - 2019-06-03 10:42:08 --> Output Class Initialized
INFO - 2019-06-03 10:42:08 --> Security Class Initialized
DEBUG - 2019-06-03 10:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 10:42:08 --> Input Class Initialized
INFO - 2019-06-03 10:42:08 --> Language Class Initialized
INFO - 2019-06-03 10:42:08 --> Language Class Initialized
INFO - 2019-06-03 10:42:08 --> Config Class Initialized
INFO - 2019-06-03 10:42:08 --> Loader Class Initialized
INFO - 2019-06-03 10:42:08 --> Helper loaded: form_helper
INFO - 2019-06-03 10:42:08 --> Helper loaded: url_helper
INFO - 2019-06-03 10:42:08 --> Helper loaded: cookie_helper
INFO - 2019-06-03 10:42:08 --> Database Driver Class Initialized
DEBUG - 2019-06-03 10:42:08 --> Template library initialized
INFO - 2019-06-03 10:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-03 10:42:08 --> Controller Class Initialized
DEBUG - 2019-06-03 10:42:08 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-03 10:42:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-06-03 10:42:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-03 10:42:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-03 10:42:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-03 10:42:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-03 10:42:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-03 10:42:08 --> Final output sent to browser
DEBUG - 2019-06-03 10:42:08 --> Total execution time: 0.0474
INFO - 2019-06-03 10:42:11 --> Config Class Initialized
INFO - 2019-06-03 10:42:11 --> Hooks Class Initialized
DEBUG - 2019-06-03 10:42:11 --> UTF-8 Support Enabled
INFO - 2019-06-03 10:42:11 --> Utf8 Class Initialized
INFO - 2019-06-03 10:42:11 --> URI Class Initialized
INFO - 2019-06-03 10:42:11 --> Router Class Initialized
INFO - 2019-06-03 10:42:11 --> Output Class Initialized
INFO - 2019-06-03 10:42:11 --> Security Class Initialized
DEBUG - 2019-06-03 10:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 10:42:11 --> Input Class Initialized
INFO - 2019-06-03 10:42:11 --> Language Class Initialized
ERROR - 2019-06-03 10:42:11 --> 404 Page Not Found: /index
INFO - 2019-06-03 10:42:11 --> Config Class Initialized
INFO - 2019-06-03 10:42:11 --> Hooks Class Initialized
DEBUG - 2019-06-03 10:42:11 --> UTF-8 Support Enabled
INFO - 2019-06-03 10:42:11 --> Utf8 Class Initialized
INFO - 2019-06-03 10:42:11 --> URI Class Initialized
INFO - 2019-06-03 10:42:11 --> Router Class Initialized
INFO - 2019-06-03 10:42:11 --> Output Class Initialized
INFO - 2019-06-03 10:42:11 --> Security Class Initialized
DEBUG - 2019-06-03 10:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 10:42:11 --> Input Class Initialized
INFO - 2019-06-03 10:42:11 --> Language Class Initialized
ERROR - 2019-06-03 10:42:11 --> 404 Page Not Found: /index
INFO - 2019-06-03 10:42:12 --> Config Class Initialized
INFO - 2019-06-03 10:42:12 --> Hooks Class Initialized
DEBUG - 2019-06-03 10:42:12 --> UTF-8 Support Enabled
INFO - 2019-06-03 10:42:12 --> Utf8 Class Initialized
INFO - 2019-06-03 10:42:12 --> URI Class Initialized
INFO - 2019-06-03 10:42:12 --> Router Class Initialized
INFO - 2019-06-03 10:42:12 --> Output Class Initialized
INFO - 2019-06-03 10:42:12 --> Security Class Initialized
DEBUG - 2019-06-03 10:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 10:42:12 --> Input Class Initialized
INFO - 2019-06-03 10:42:12 --> Language Class Initialized
ERROR - 2019-06-03 10:42:12 --> 404 Page Not Found: /index
INFO - 2019-06-03 10:42:12 --> Config Class Initialized
INFO - 2019-06-03 10:42:12 --> Hooks Class Initialized
DEBUG - 2019-06-03 10:42:12 --> UTF-8 Support Enabled
INFO - 2019-06-03 10:42:12 --> Utf8 Class Initialized
INFO - 2019-06-03 10:42:12 --> URI Class Initialized
INFO - 2019-06-03 10:42:12 --> Router Class Initialized
INFO - 2019-06-03 10:42:12 --> Output Class Initialized
INFO - 2019-06-03 10:42:12 --> Security Class Initialized
DEBUG - 2019-06-03 10:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 10:42:12 --> Input Class Initialized
INFO - 2019-06-03 10:42:12 --> Language Class Initialized
ERROR - 2019-06-03 10:42:12 --> 404 Page Not Found: /index
INFO - 2019-06-03 15:37:00 --> Config Class Initialized
INFO - 2019-06-03 15:37:00 --> Hooks Class Initialized
DEBUG - 2019-06-03 15:37:00 --> UTF-8 Support Enabled
INFO - 2019-06-03 15:37:00 --> Utf8 Class Initialized
INFO - 2019-06-03 15:37:00 --> URI Class Initialized
INFO - 2019-06-03 15:37:00 --> Router Class Initialized
INFO - 2019-06-03 15:37:00 --> Output Class Initialized
INFO - 2019-06-03 15:37:00 --> Security Class Initialized
DEBUG - 2019-06-03 15:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 15:37:00 --> Input Class Initialized
INFO - 2019-06-03 15:37:00 --> Language Class Initialized
INFO - 2019-06-03 15:37:00 --> Language Class Initialized
INFO - 2019-06-03 15:37:00 --> Config Class Initialized
INFO - 2019-06-03 15:37:00 --> Loader Class Initialized
INFO - 2019-06-03 15:37:00 --> Helper loaded: form_helper
INFO - 2019-06-03 15:37:00 --> Helper loaded: url_helper
INFO - 2019-06-03 15:37:00 --> Helper loaded: cookie_helper
INFO - 2019-06-03 15:37:00 --> Database Driver Class Initialized
DEBUG - 2019-06-03 15:37:00 --> Template library initialized
INFO - 2019-06-03 15:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-03 15:37:00 --> Controller Class Initialized
DEBUG - 2019-06-03 15:37:00 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-03 15:37:00 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-06-03 15:37:00 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/datacard.php
DEBUG - 2019-06-03 15:37:00 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-03 15:37:00 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-03 15:37:00 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-03 15:37:00 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-03 15:37:01 --> Final output sent to browser
DEBUG - 2019-06-03 15:37:01 --> Total execution time: 0.0503
INFO - 2019-06-03 15:37:01 --> Config Class Initialized
INFO - 2019-06-03 15:37:01 --> Hooks Class Initialized
DEBUG - 2019-06-03 15:37:01 --> UTF-8 Support Enabled
INFO - 2019-06-03 15:37:01 --> Utf8 Class Initialized
INFO - 2019-06-03 15:37:01 --> URI Class Initialized
INFO - 2019-06-03 15:37:01 --> Router Class Initialized
INFO - 2019-06-03 15:37:01 --> Output Class Initialized
INFO - 2019-06-03 15:37:01 --> Security Class Initialized
DEBUG - 2019-06-03 15:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 15:37:01 --> Input Class Initialized
INFO - 2019-06-03 15:37:01 --> Language Class Initialized
ERROR - 2019-06-03 15:37:01 --> 404 Page Not Found: /index
INFO - 2019-06-03 15:37:01 --> Config Class Initialized
INFO - 2019-06-03 15:37:01 --> Hooks Class Initialized
DEBUG - 2019-06-03 15:37:01 --> UTF-8 Support Enabled
INFO - 2019-06-03 15:37:01 --> Utf8 Class Initialized
INFO - 2019-06-03 15:37:01 --> URI Class Initialized
INFO - 2019-06-03 15:37:01 --> Router Class Initialized
INFO - 2019-06-03 15:37:01 --> Output Class Initialized
INFO - 2019-06-03 15:37:01 --> Security Class Initialized
DEBUG - 2019-06-03 15:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 15:37:01 --> Input Class Initialized
INFO - 2019-06-03 15:37:01 --> Language Class Initialized
ERROR - 2019-06-03 15:37:01 --> 404 Page Not Found: /index
INFO - 2019-06-03 15:37:01 --> Config Class Initialized
INFO - 2019-06-03 15:37:01 --> Hooks Class Initialized
DEBUG - 2019-06-03 15:37:01 --> UTF-8 Support Enabled
INFO - 2019-06-03 15:37:01 --> Utf8 Class Initialized
INFO - 2019-06-03 15:37:01 --> URI Class Initialized
INFO - 2019-06-03 15:37:01 --> Router Class Initialized
INFO - 2019-06-03 15:37:01 --> Output Class Initialized
INFO - 2019-06-03 15:37:01 --> Security Class Initialized
DEBUG - 2019-06-03 15:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 15:37:01 --> Input Class Initialized
INFO - 2019-06-03 15:37:01 --> Language Class Initialized
ERROR - 2019-06-03 15:37:01 --> 404 Page Not Found: /index
INFO - 2019-06-03 15:37:02 --> Config Class Initialized
INFO - 2019-06-03 15:37:02 --> Hooks Class Initialized
DEBUG - 2019-06-03 15:37:02 --> UTF-8 Support Enabled
INFO - 2019-06-03 15:37:02 --> Utf8 Class Initialized
INFO - 2019-06-03 15:37:02 --> URI Class Initialized
INFO - 2019-06-03 15:37:02 --> Router Class Initialized
INFO - 2019-06-03 15:37:02 --> Output Class Initialized
INFO - 2019-06-03 15:37:02 --> Security Class Initialized
DEBUG - 2019-06-03 15:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 15:37:02 --> Input Class Initialized
INFO - 2019-06-03 15:37:02 --> Language Class Initialized
ERROR - 2019-06-03 15:37:02 --> 404 Page Not Found: /index
INFO - 2019-06-03 15:37:06 --> Config Class Initialized
INFO - 2019-06-03 15:37:06 --> Hooks Class Initialized
DEBUG - 2019-06-03 15:37:06 --> UTF-8 Support Enabled
INFO - 2019-06-03 15:37:06 --> Utf8 Class Initialized
INFO - 2019-06-03 15:37:06 --> URI Class Initialized
INFO - 2019-06-03 15:37:06 --> Router Class Initialized
INFO - 2019-06-03 15:37:06 --> Output Class Initialized
INFO - 2019-06-03 15:37:06 --> Security Class Initialized
DEBUG - 2019-06-03 15:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 15:37:06 --> Input Class Initialized
INFO - 2019-06-03 15:37:06 --> Language Class Initialized
INFO - 2019-06-03 15:37:06 --> Language Class Initialized
INFO - 2019-06-03 15:37:06 --> Config Class Initialized
INFO - 2019-06-03 15:37:06 --> Loader Class Initialized
INFO - 2019-06-03 15:37:06 --> Helper loaded: form_helper
INFO - 2019-06-03 15:37:06 --> Helper loaded: url_helper
INFO - 2019-06-03 15:37:06 --> Helper loaded: cookie_helper
INFO - 2019-06-03 15:37:06 --> Database Driver Class Initialized
DEBUG - 2019-06-03 15:37:06 --> Template library initialized
INFO - 2019-06-03 15:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-03 15:37:06 --> Controller Class Initialized
DEBUG - 2019-06-03 15:37:06 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-03 15:37:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-06-03 15:37:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/landline.php
DEBUG - 2019-06-03 15:37:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-03 15:37:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-03 15:37:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-03 15:37:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-03 15:37:06 --> Final output sent to browser
DEBUG - 2019-06-03 15:37:06 --> Total execution time: 0.0453
INFO - 2019-06-03 15:37:07 --> Config Class Initialized
INFO - 2019-06-03 15:37:07 --> Hooks Class Initialized
DEBUG - 2019-06-03 15:37:07 --> UTF-8 Support Enabled
INFO - 2019-06-03 15:37:07 --> Utf8 Class Initialized
INFO - 2019-06-03 15:37:07 --> URI Class Initialized
INFO - 2019-06-03 15:37:07 --> Router Class Initialized
INFO - 2019-06-03 15:37:07 --> Output Class Initialized
INFO - 2019-06-03 15:37:07 --> Security Class Initialized
DEBUG - 2019-06-03 15:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 15:37:07 --> Input Class Initialized
INFO - 2019-06-03 15:37:07 --> Language Class Initialized
ERROR - 2019-06-03 15:37:07 --> 404 Page Not Found: /index
INFO - 2019-06-03 15:37:07 --> Config Class Initialized
INFO - 2019-06-03 15:37:07 --> Hooks Class Initialized
DEBUG - 2019-06-03 15:37:07 --> UTF-8 Support Enabled
INFO - 2019-06-03 15:37:07 --> Utf8 Class Initialized
INFO - 2019-06-03 15:37:07 --> URI Class Initialized
INFO - 2019-06-03 15:37:07 --> Router Class Initialized
INFO - 2019-06-03 15:37:07 --> Output Class Initialized
INFO - 2019-06-03 15:37:07 --> Security Class Initialized
DEBUG - 2019-06-03 15:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 15:37:07 --> Input Class Initialized
INFO - 2019-06-03 15:37:07 --> Language Class Initialized
ERROR - 2019-06-03 15:37:07 --> 404 Page Not Found: /index
INFO - 2019-06-03 15:37:07 --> Config Class Initialized
INFO - 2019-06-03 15:37:07 --> Hooks Class Initialized
DEBUG - 2019-06-03 15:37:07 --> UTF-8 Support Enabled
INFO - 2019-06-03 15:37:07 --> Utf8 Class Initialized
INFO - 2019-06-03 15:37:07 --> URI Class Initialized
INFO - 2019-06-03 15:37:07 --> Router Class Initialized
INFO - 2019-06-03 15:37:07 --> Output Class Initialized
INFO - 2019-06-03 15:37:07 --> Security Class Initialized
DEBUG - 2019-06-03 15:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 15:37:07 --> Input Class Initialized
INFO - 2019-06-03 15:37:07 --> Language Class Initialized
ERROR - 2019-06-03 15:37:07 --> 404 Page Not Found: /index
INFO - 2019-06-03 15:37:07 --> Config Class Initialized
INFO - 2019-06-03 15:37:07 --> Hooks Class Initialized
DEBUG - 2019-06-03 15:37:08 --> UTF-8 Support Enabled
INFO - 2019-06-03 15:37:08 --> Utf8 Class Initialized
INFO - 2019-06-03 15:37:08 --> URI Class Initialized
INFO - 2019-06-03 15:37:08 --> Router Class Initialized
INFO - 2019-06-03 15:37:08 --> Output Class Initialized
INFO - 2019-06-03 15:37:08 --> Security Class Initialized
DEBUG - 2019-06-03 15:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 15:37:08 --> Input Class Initialized
INFO - 2019-06-03 15:37:08 --> Language Class Initialized
ERROR - 2019-06-03 15:37:08 --> 404 Page Not Found: /index
INFO - 2019-06-03 17:14:57 --> Config Class Initialized
INFO - 2019-06-03 17:14:57 --> Hooks Class Initialized
DEBUG - 2019-06-03 17:14:57 --> UTF-8 Support Enabled
INFO - 2019-06-03 17:14:57 --> Utf8 Class Initialized
INFO - 2019-06-03 17:14:57 --> URI Class Initialized
DEBUG - 2019-06-03 17:14:57 --> No URI present. Default controller set.
INFO - 2019-06-03 17:14:57 --> Router Class Initialized
INFO - 2019-06-03 17:14:57 --> Output Class Initialized
INFO - 2019-06-03 17:14:57 --> Security Class Initialized
DEBUG - 2019-06-03 17:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 17:14:57 --> Input Class Initialized
INFO - 2019-06-03 17:14:57 --> Language Class Initialized
INFO - 2019-06-03 17:14:57 --> Language Class Initialized
INFO - 2019-06-03 17:14:57 --> Config Class Initialized
INFO - 2019-06-03 17:14:57 --> Loader Class Initialized
INFO - 2019-06-03 17:14:57 --> Helper loaded: form_helper
INFO - 2019-06-03 17:14:57 --> Helper loaded: url_helper
INFO - 2019-06-03 17:14:57 --> Helper loaded: cookie_helper
INFO - 2019-06-03 17:14:57 --> Database Driver Class Initialized
DEBUG - 2019-06-03 17:14:57 --> Template library initialized
INFO - 2019-06-03 17:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-03 17:14:57 --> Controller Class Initialized
DEBUG - 2019-06-03 17:14:57 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-03 17:14:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-06-03 17:14:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-03 17:14:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-03 17:14:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-03 17:14:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-03 17:14:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-03 17:14:58 --> Final output sent to browser
DEBUG - 2019-06-03 17:14:58 --> Total execution time: 0.0482
INFO - 2019-06-03 17:15:00 --> Config Class Initialized
INFO - 2019-06-03 17:15:00 --> Hooks Class Initialized
DEBUG - 2019-06-03 17:15:00 --> UTF-8 Support Enabled
INFO - 2019-06-03 17:15:00 --> Utf8 Class Initialized
INFO - 2019-06-03 17:15:00 --> URI Class Initialized
INFO - 2019-06-03 17:15:00 --> Router Class Initialized
INFO - 2019-06-03 17:15:00 --> Output Class Initialized
INFO - 2019-06-03 17:15:00 --> Security Class Initialized
DEBUG - 2019-06-03 17:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 17:15:00 --> Input Class Initialized
INFO - 2019-06-03 17:15:00 --> Language Class Initialized
ERROR - 2019-06-03 17:15:00 --> 404 Page Not Found: /index
INFO - 2019-06-03 17:15:00 --> Config Class Initialized
INFO - 2019-06-03 17:15:00 --> Hooks Class Initialized
DEBUG - 2019-06-03 17:15:00 --> UTF-8 Support Enabled
INFO - 2019-06-03 17:15:00 --> Utf8 Class Initialized
INFO - 2019-06-03 17:15:00 --> URI Class Initialized
INFO - 2019-06-03 17:15:00 --> Router Class Initialized
INFO - 2019-06-03 17:15:00 --> Output Class Initialized
INFO - 2019-06-03 17:15:00 --> Security Class Initialized
DEBUG - 2019-06-03 17:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 17:15:00 --> Input Class Initialized
INFO - 2019-06-03 17:15:00 --> Language Class Initialized
ERROR - 2019-06-03 17:15:00 --> 404 Page Not Found: /index
INFO - 2019-06-03 17:15:01 --> Config Class Initialized
INFO - 2019-06-03 17:15:01 --> Hooks Class Initialized
DEBUG - 2019-06-03 17:15:01 --> UTF-8 Support Enabled
INFO - 2019-06-03 17:15:01 --> Utf8 Class Initialized
INFO - 2019-06-03 17:15:01 --> URI Class Initialized
INFO - 2019-06-03 17:15:01 --> Router Class Initialized
INFO - 2019-06-03 17:15:01 --> Output Class Initialized
INFO - 2019-06-03 17:15:01 --> Security Class Initialized
DEBUG - 2019-06-03 17:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 17:15:01 --> Input Class Initialized
INFO - 2019-06-03 17:15:01 --> Language Class Initialized
ERROR - 2019-06-03 17:15:01 --> 404 Page Not Found: /index
INFO - 2019-06-03 19:14:32 --> Config Class Initialized
INFO - 2019-06-03 19:14:32 --> Hooks Class Initialized
DEBUG - 2019-06-03 19:14:32 --> UTF-8 Support Enabled
INFO - 2019-06-03 19:14:32 --> Utf8 Class Initialized
INFO - 2019-06-03 19:14:32 --> URI Class Initialized
DEBUG - 2019-06-03 19:14:32 --> No URI present. Default controller set.
INFO - 2019-06-03 19:14:32 --> Router Class Initialized
INFO - 2019-06-03 19:14:32 --> Output Class Initialized
INFO - 2019-06-03 19:14:32 --> Security Class Initialized
DEBUG - 2019-06-03 19:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 19:14:32 --> Input Class Initialized
INFO - 2019-06-03 19:14:32 --> Language Class Initialized
INFO - 2019-06-03 19:14:32 --> Language Class Initialized
INFO - 2019-06-03 19:14:32 --> Config Class Initialized
INFO - 2019-06-03 19:14:32 --> Loader Class Initialized
INFO - 2019-06-03 19:14:32 --> Helper loaded: form_helper
INFO - 2019-06-03 19:14:32 --> Helper loaded: url_helper
INFO - 2019-06-03 19:14:32 --> Helper loaded: cookie_helper
INFO - 2019-06-03 19:14:32 --> Database Driver Class Initialized
DEBUG - 2019-06-03 19:14:32 --> Template library initialized
INFO - 2019-06-03 19:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-03 19:14:32 --> Controller Class Initialized
DEBUG - 2019-06-03 19:14:32 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-03 19:14:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-06-03 19:14:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-03 19:14:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-03 19:14:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-03 19:14:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-03 19:14:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-03 19:14:33 --> Final output sent to browser
DEBUG - 2019-06-03 19:14:33 --> Total execution time: 0.0451
INFO - 2019-06-03 19:14:33 --> Config Class Initialized
INFO - 2019-06-03 19:14:33 --> Hooks Class Initialized
DEBUG - 2019-06-03 19:14:33 --> UTF-8 Support Enabled
INFO - 2019-06-03 19:14:33 --> Utf8 Class Initialized
INFO - 2019-06-03 19:14:33 --> URI Class Initialized
INFO - 2019-06-03 19:14:33 --> Router Class Initialized
INFO - 2019-06-03 19:14:33 --> Output Class Initialized
INFO - 2019-06-03 19:14:33 --> Security Class Initialized
DEBUG - 2019-06-03 19:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 19:14:33 --> Input Class Initialized
INFO - 2019-06-03 19:14:33 --> Language Class Initialized
ERROR - 2019-06-03 19:14:33 --> 404 Page Not Found: /index
INFO - 2019-06-03 19:14:34 --> Config Class Initialized
INFO - 2019-06-03 19:14:34 --> Hooks Class Initialized
DEBUG - 2019-06-03 19:14:34 --> UTF-8 Support Enabled
INFO - 2019-06-03 19:14:34 --> Utf8 Class Initialized
INFO - 2019-06-03 19:14:34 --> URI Class Initialized
INFO - 2019-06-03 19:14:34 --> Router Class Initialized
INFO - 2019-06-03 19:14:34 --> Output Class Initialized
INFO - 2019-06-03 19:14:34 --> Security Class Initialized
DEBUG - 2019-06-03 19:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 19:14:34 --> Input Class Initialized
INFO - 2019-06-03 19:14:34 --> Language Class Initialized
ERROR - 2019-06-03 19:14:34 --> 404 Page Not Found: /index
INFO - 2019-06-03 19:14:34 --> Config Class Initialized
INFO - 2019-06-03 19:14:34 --> Hooks Class Initialized
DEBUG - 2019-06-03 19:14:34 --> UTF-8 Support Enabled
INFO - 2019-06-03 19:14:34 --> Utf8 Class Initialized
INFO - 2019-06-03 19:14:34 --> URI Class Initialized
INFO - 2019-06-03 19:14:34 --> Router Class Initialized
INFO - 2019-06-03 19:14:34 --> Output Class Initialized
INFO - 2019-06-03 19:14:34 --> Security Class Initialized
DEBUG - 2019-06-03 19:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 19:14:34 --> Input Class Initialized
INFO - 2019-06-03 19:14:34 --> Language Class Initialized
ERROR - 2019-06-03 19:14:34 --> 404 Page Not Found: /index
INFO - 2019-06-03 19:14:34 --> Config Class Initialized
INFO - 2019-06-03 19:14:34 --> Hooks Class Initialized
DEBUG - 2019-06-03 19:14:34 --> UTF-8 Support Enabled
INFO - 2019-06-03 19:14:34 --> Utf8 Class Initialized
INFO - 2019-06-03 19:14:34 --> URI Class Initialized
INFO - 2019-06-03 19:14:34 --> Router Class Initialized
INFO - 2019-06-03 19:14:34 --> Output Class Initialized
INFO - 2019-06-03 19:14:34 --> Security Class Initialized
DEBUG - 2019-06-03 19:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 19:14:34 --> Input Class Initialized
INFO - 2019-06-03 19:14:34 --> Language Class Initialized
ERROR - 2019-06-03 19:14:34 --> 404 Page Not Found: /index
INFO - 2019-06-03 19:14:34 --> Config Class Initialized
INFO - 2019-06-03 19:14:34 --> Hooks Class Initialized
DEBUG - 2019-06-03 19:14:34 --> UTF-8 Support Enabled
INFO - 2019-06-03 19:14:34 --> Utf8 Class Initialized
INFO - 2019-06-03 19:14:34 --> URI Class Initialized
INFO - 2019-06-03 19:14:34 --> Router Class Initialized
INFO - 2019-06-03 19:14:34 --> Output Class Initialized
INFO - 2019-06-03 19:14:34 --> Security Class Initialized
DEBUG - 2019-06-03 19:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 19:14:34 --> Input Class Initialized
INFO - 2019-06-03 19:14:34 --> Language Class Initialized
ERROR - 2019-06-03 19:14:34 --> 404 Page Not Found: /index
INFO - 2019-06-03 19:14:35 --> Config Class Initialized
INFO - 2019-06-03 19:14:35 --> Hooks Class Initialized
DEBUG - 2019-06-03 19:14:35 --> UTF-8 Support Enabled
INFO - 2019-06-03 19:14:35 --> Utf8 Class Initialized
INFO - 2019-06-03 19:14:35 --> URI Class Initialized
INFO - 2019-06-03 19:14:35 --> Router Class Initialized
INFO - 2019-06-03 19:14:35 --> Output Class Initialized
INFO - 2019-06-03 19:14:35 --> Security Class Initialized
DEBUG - 2019-06-03 19:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 19:14:35 --> Input Class Initialized
INFO - 2019-06-03 19:14:35 --> Language Class Initialized
ERROR - 2019-06-03 19:14:35 --> 404 Page Not Found: /index
INFO - 2019-06-03 19:14:35 --> Config Class Initialized
INFO - 2019-06-03 19:14:35 --> Hooks Class Initialized
DEBUG - 2019-06-03 19:14:35 --> UTF-8 Support Enabled
INFO - 2019-06-03 19:14:35 --> Utf8 Class Initialized
INFO - 2019-06-03 19:14:35 --> URI Class Initialized
INFO - 2019-06-03 19:14:35 --> Router Class Initialized
INFO - 2019-06-03 19:14:35 --> Output Class Initialized
INFO - 2019-06-03 19:14:35 --> Security Class Initialized
DEBUG - 2019-06-03 19:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 19:14:35 --> Input Class Initialized
INFO - 2019-06-03 19:14:35 --> Language Class Initialized
ERROR - 2019-06-03 19:14:35 --> 404 Page Not Found: /index
INFO - 2019-06-03 19:14:35 --> Config Class Initialized
INFO - 2019-06-03 19:14:35 --> Hooks Class Initialized
DEBUG - 2019-06-03 19:14:35 --> UTF-8 Support Enabled
INFO - 2019-06-03 19:14:35 --> Utf8 Class Initialized
INFO - 2019-06-03 19:14:35 --> URI Class Initialized
INFO - 2019-06-03 19:14:35 --> Router Class Initialized
INFO - 2019-06-03 19:14:35 --> Output Class Initialized
INFO - 2019-06-03 19:14:35 --> Security Class Initialized
DEBUG - 2019-06-03 19:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 19:14:35 --> Input Class Initialized
INFO - 2019-06-03 19:14:35 --> Language Class Initialized
ERROR - 2019-06-03 19:14:35 --> 404 Page Not Found: /index
INFO - 2019-06-03 19:14:36 --> Config Class Initialized
INFO - 2019-06-03 19:14:36 --> Hooks Class Initialized
DEBUG - 2019-06-03 19:14:36 --> UTF-8 Support Enabled
INFO - 2019-06-03 19:14:36 --> Utf8 Class Initialized
INFO - 2019-06-03 19:14:36 --> URI Class Initialized
INFO - 2019-06-03 19:14:36 --> Router Class Initialized
INFO - 2019-06-03 19:14:36 --> Output Class Initialized
INFO - 2019-06-03 19:14:36 --> Security Class Initialized
DEBUG - 2019-06-03 19:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 19:14:36 --> Input Class Initialized
INFO - 2019-06-03 19:14:36 --> Language Class Initialized
ERROR - 2019-06-03 19:14:36 --> 404 Page Not Found: /index
INFO - 2019-06-03 19:14:36 --> Config Class Initialized
INFO - 2019-06-03 19:14:36 --> Hooks Class Initialized
DEBUG - 2019-06-03 19:14:36 --> UTF-8 Support Enabled
INFO - 2019-06-03 19:14:36 --> Utf8 Class Initialized
INFO - 2019-06-03 19:14:36 --> URI Class Initialized
INFO - 2019-06-03 19:14:36 --> Router Class Initialized
INFO - 2019-06-03 19:14:36 --> Output Class Initialized
INFO - 2019-06-03 19:14:36 --> Security Class Initialized
DEBUG - 2019-06-03 19:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 19:14:36 --> Input Class Initialized
INFO - 2019-06-03 19:14:36 --> Language Class Initialized
ERROR - 2019-06-03 19:14:36 --> 404 Page Not Found: /index
INFO - 2019-06-03 19:14:37 --> Config Class Initialized
INFO - 2019-06-03 19:14:37 --> Hooks Class Initialized
DEBUG - 2019-06-03 19:14:37 --> UTF-8 Support Enabled
INFO - 2019-06-03 19:14:37 --> Utf8 Class Initialized
INFO - 2019-06-03 19:14:37 --> URI Class Initialized
INFO - 2019-06-03 19:14:37 --> Router Class Initialized
INFO - 2019-06-03 19:14:37 --> Output Class Initialized
INFO - 2019-06-03 19:14:37 --> Security Class Initialized
DEBUG - 2019-06-03 19:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 19:14:37 --> Input Class Initialized
INFO - 2019-06-03 19:14:37 --> Language Class Initialized
ERROR - 2019-06-03 19:14:37 --> 404 Page Not Found: /index
INFO - 2019-06-03 19:14:37 --> Config Class Initialized
INFO - 2019-06-03 19:14:37 --> Hooks Class Initialized
DEBUG - 2019-06-03 19:14:37 --> UTF-8 Support Enabled
INFO - 2019-06-03 19:14:37 --> Utf8 Class Initialized
INFO - 2019-06-03 19:14:37 --> URI Class Initialized
INFO - 2019-06-03 19:14:37 --> Router Class Initialized
INFO - 2019-06-03 19:14:37 --> Output Class Initialized
INFO - 2019-06-03 19:14:37 --> Security Class Initialized
DEBUG - 2019-06-03 19:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-03 19:14:37 --> Input Class Initialized
INFO - 2019-06-03 19:14:37 --> Language Class Initialized
ERROR - 2019-06-03 19:14:37 --> 404 Page Not Found: /index
