<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-05-29 07:11:52 --> Config Class Initialized
INFO - 2019-05-29 07:11:52 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:11:52 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:11:52 --> Utf8 Class Initialized
INFO - 2019-05-29 07:11:52 --> URI Class Initialized
DEBUG - 2019-05-29 07:11:52 --> No URI present. Default controller set.
INFO - 2019-05-29 07:11:52 --> Router Class Initialized
INFO - 2019-05-29 07:11:52 --> Output Class Initialized
INFO - 2019-05-29 07:11:52 --> Security Class Initialized
DEBUG - 2019-05-29 07:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:11:52 --> Input Class Initialized
INFO - 2019-05-29 07:11:52 --> Language Class Initialized
INFO - 2019-05-29 07:11:52 --> Language Class Initialized
INFO - 2019-05-29 07:11:52 --> Config Class Initialized
INFO - 2019-05-29 07:11:52 --> Loader Class Initialized
INFO - 2019-05-29 07:11:52 --> Helper loaded: form_helper
INFO - 2019-05-29 07:11:52 --> Helper loaded: url_helper
INFO - 2019-05-29 07:11:52 --> Helper loaded: cookie_helper
INFO - 2019-05-29 07:11:52 --> Database Driver Class Initialized
DEBUG - 2019-05-29 07:11:52 --> Template library initialized
INFO - 2019-05-29 07:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-29 07:11:52 --> Controller Class Initialized
DEBUG - 2019-05-29 07:11:52 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-29 07:11:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-29 07:11:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-29 07:11:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-29 07:11:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-29 07:11:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-29 07:11:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-29 07:11:53 --> Final output sent to browser
DEBUG - 2019-05-29 07:11:53 --> Total execution time: 0.0636
INFO - 2019-05-29 07:12:04 --> Config Class Initialized
INFO - 2019-05-29 07:12:04 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:04 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:04 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:04 --> URI Class Initialized
INFO - 2019-05-29 07:12:04 --> Router Class Initialized
INFO - 2019-05-29 07:12:04 --> Output Class Initialized
INFO - 2019-05-29 07:12:04 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:04 --> Input Class Initialized
INFO - 2019-05-29 07:12:04 --> Language Class Initialized
ERROR - 2019-05-29 07:12:04 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:12:05 --> Config Class Initialized
INFO - 2019-05-29 07:12:05 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:05 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:05 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:05 --> URI Class Initialized
INFO - 2019-05-29 07:12:05 --> Router Class Initialized
INFO - 2019-05-29 07:12:05 --> Output Class Initialized
INFO - 2019-05-29 07:12:05 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:05 --> Input Class Initialized
INFO - 2019-05-29 07:12:05 --> Language Class Initialized
ERROR - 2019-05-29 07:12:05 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:12:05 --> Config Class Initialized
INFO - 2019-05-29 07:12:05 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:05 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:05 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:05 --> URI Class Initialized
INFO - 2019-05-29 07:12:05 --> Router Class Initialized
INFO - 2019-05-29 07:12:05 --> Output Class Initialized
INFO - 2019-05-29 07:12:05 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:05 --> Input Class Initialized
INFO - 2019-05-29 07:12:05 --> Language Class Initialized
ERROR - 2019-05-29 07:12:05 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:12:05 --> Config Class Initialized
INFO - 2019-05-29 07:12:05 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:05 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:05 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:05 --> URI Class Initialized
INFO - 2019-05-29 07:12:05 --> Router Class Initialized
INFO - 2019-05-29 07:12:05 --> Output Class Initialized
INFO - 2019-05-29 07:12:05 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:05 --> Input Class Initialized
INFO - 2019-05-29 07:12:05 --> Language Class Initialized
ERROR - 2019-05-29 07:12:05 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:12:20 --> Config Class Initialized
INFO - 2019-05-29 07:12:20 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:20 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:20 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:20 --> URI Class Initialized
DEBUG - 2019-05-29 07:12:20 --> No URI present. Default controller set.
INFO - 2019-05-29 07:12:20 --> Router Class Initialized
INFO - 2019-05-29 07:12:20 --> Output Class Initialized
INFO - 2019-05-29 07:12:20 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:20 --> Input Class Initialized
INFO - 2019-05-29 07:12:20 --> Language Class Initialized
INFO - 2019-05-29 07:12:20 --> Language Class Initialized
INFO - 2019-05-29 07:12:20 --> Config Class Initialized
INFO - 2019-05-29 07:12:20 --> Loader Class Initialized
INFO - 2019-05-29 07:12:20 --> Helper loaded: form_helper
INFO - 2019-05-29 07:12:20 --> Helper loaded: url_helper
INFO - 2019-05-29 07:12:20 --> Helper loaded: cookie_helper
INFO - 2019-05-29 07:12:20 --> Database Driver Class Initialized
DEBUG - 2019-05-29 07:12:20 --> Template library initialized
INFO - 2019-05-29 07:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-29 07:12:20 --> Controller Class Initialized
DEBUG - 2019-05-29 07:12:20 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-29 07:12:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-29 07:12:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-29 07:12:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-29 07:12:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-29 07:12:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-29 07:12:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-29 07:12:20 --> Final output sent to browser
DEBUG - 2019-05-29 07:12:20 --> Total execution time: 0.0541
INFO - 2019-05-29 07:12:21 --> Config Class Initialized
INFO - 2019-05-29 07:12:21 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:21 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:21 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:21 --> URI Class Initialized
INFO - 2019-05-29 07:12:21 --> Router Class Initialized
INFO - 2019-05-29 07:12:21 --> Output Class Initialized
INFO - 2019-05-29 07:12:21 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:21 --> Input Class Initialized
INFO - 2019-05-29 07:12:21 --> Language Class Initialized
ERROR - 2019-05-29 07:12:21 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:12:21 --> Config Class Initialized
INFO - 2019-05-29 07:12:21 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:21 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:21 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:21 --> URI Class Initialized
INFO - 2019-05-29 07:12:21 --> Router Class Initialized
INFO - 2019-05-29 07:12:21 --> Output Class Initialized
INFO - 2019-05-29 07:12:21 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:21 --> Input Class Initialized
INFO - 2019-05-29 07:12:21 --> Language Class Initialized
ERROR - 2019-05-29 07:12:21 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:12:21 --> Config Class Initialized
INFO - 2019-05-29 07:12:21 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:21 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:21 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:21 --> URI Class Initialized
INFO - 2019-05-29 07:12:21 --> Router Class Initialized
INFO - 2019-05-29 07:12:21 --> Output Class Initialized
INFO - 2019-05-29 07:12:21 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:21 --> Input Class Initialized
INFO - 2019-05-29 07:12:21 --> Language Class Initialized
ERROR - 2019-05-29 07:12:21 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:12:25 --> Config Class Initialized
INFO - 2019-05-29 07:12:25 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:25 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:25 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:25 --> URI Class Initialized
INFO - 2019-05-29 07:12:25 --> Router Class Initialized
INFO - 2019-05-29 07:12:25 --> Output Class Initialized
INFO - 2019-05-29 07:12:25 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:25 --> Input Class Initialized
INFO - 2019-05-29 07:12:25 --> Language Class Initialized
INFO - 2019-05-29 07:12:25 --> Language Class Initialized
INFO - 2019-05-29 07:12:25 --> Config Class Initialized
INFO - 2019-05-29 07:12:25 --> Loader Class Initialized
INFO - 2019-05-29 07:12:25 --> Helper loaded: form_helper
INFO - 2019-05-29 07:12:25 --> Helper loaded: url_helper
INFO - 2019-05-29 07:12:25 --> Helper loaded: cookie_helper
INFO - 2019-05-29 07:12:25 --> Database Driver Class Initialized
DEBUG - 2019-05-29 07:12:25 --> Template library initialized
INFO - 2019-05-29 07:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-29 07:12:25 --> Controller Class Initialized
DEBUG - 2019-05-29 07:12:25 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-29 07:12:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-29 07:12:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/mobile.php
DEBUG - 2019-05-29 07:12:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-29 07:12:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-29 07:12:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-29 07:12:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-29 07:12:25 --> Final output sent to browser
DEBUG - 2019-05-29 07:12:25 --> Total execution time: 0.0462
INFO - 2019-05-29 07:12:26 --> Config Class Initialized
INFO - 2019-05-29 07:12:26 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:26 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:26 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:26 --> URI Class Initialized
INFO - 2019-05-29 07:12:26 --> Router Class Initialized
INFO - 2019-05-29 07:12:26 --> Output Class Initialized
INFO - 2019-05-29 07:12:26 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:26 --> Input Class Initialized
INFO - 2019-05-29 07:12:26 --> Language Class Initialized
ERROR - 2019-05-29 07:12:26 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:12:26 --> Config Class Initialized
INFO - 2019-05-29 07:12:26 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:26 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:26 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:26 --> URI Class Initialized
INFO - 2019-05-29 07:12:26 --> Router Class Initialized
INFO - 2019-05-29 07:12:26 --> Output Class Initialized
INFO - 2019-05-29 07:12:26 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:26 --> Input Class Initialized
INFO - 2019-05-29 07:12:26 --> Language Class Initialized
ERROR - 2019-05-29 07:12:26 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:12:26 --> Config Class Initialized
INFO - 2019-05-29 07:12:26 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:26 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:26 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:26 --> URI Class Initialized
INFO - 2019-05-29 07:12:26 --> Router Class Initialized
INFO - 2019-05-29 07:12:26 --> Output Class Initialized
INFO - 2019-05-29 07:12:26 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:26 --> Input Class Initialized
INFO - 2019-05-29 07:12:26 --> Language Class Initialized
ERROR - 2019-05-29 07:12:26 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:12:30 --> Config Class Initialized
INFO - 2019-05-29 07:12:30 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:30 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:30 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:30 --> URI Class Initialized
INFO - 2019-05-29 07:12:30 --> Router Class Initialized
INFO - 2019-05-29 07:12:30 --> Output Class Initialized
INFO - 2019-05-29 07:12:30 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:30 --> Input Class Initialized
INFO - 2019-05-29 07:12:30 --> Language Class Initialized
INFO - 2019-05-29 07:12:30 --> Language Class Initialized
INFO - 2019-05-29 07:12:30 --> Config Class Initialized
INFO - 2019-05-29 07:12:31 --> Loader Class Initialized
INFO - 2019-05-29 07:12:31 --> Helper loaded: form_helper
INFO - 2019-05-29 07:12:31 --> Helper loaded: url_helper
INFO - 2019-05-29 07:12:31 --> Helper loaded: cookie_helper
INFO - 2019-05-29 07:12:31 --> Database Driver Class Initialized
DEBUG - 2019-05-29 07:12:31 --> Template library initialized
INFO - 2019-05-29 07:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-29 07:12:31 --> Controller Class Initialized
DEBUG - 2019-05-29 07:12:31 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-29 07:12:31 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-29 07:12:31 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/water-bill-payment.php
DEBUG - 2019-05-29 07:12:31 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-29 07:12:31 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-29 07:12:31 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-29 07:12:31 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-29 07:12:31 --> Final output sent to browser
DEBUG - 2019-05-29 07:12:31 --> Total execution time: 0.0454
INFO - 2019-05-29 07:12:31 --> Config Class Initialized
INFO - 2019-05-29 07:12:31 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:31 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:31 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:31 --> URI Class Initialized
INFO - 2019-05-29 07:12:31 --> Router Class Initialized
INFO - 2019-05-29 07:12:31 --> Output Class Initialized
INFO - 2019-05-29 07:12:31 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:31 --> Input Class Initialized
INFO - 2019-05-29 07:12:31 --> Language Class Initialized
ERROR - 2019-05-29 07:12:31 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:12:32 --> Config Class Initialized
INFO - 2019-05-29 07:12:32 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:32 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:32 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:32 --> URI Class Initialized
INFO - 2019-05-29 07:12:32 --> Router Class Initialized
INFO - 2019-05-29 07:12:32 --> Output Class Initialized
INFO - 2019-05-29 07:12:32 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:32 --> Input Class Initialized
INFO - 2019-05-29 07:12:32 --> Language Class Initialized
ERROR - 2019-05-29 07:12:32 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:12:32 --> Config Class Initialized
INFO - 2019-05-29 07:12:32 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:32 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:32 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:32 --> URI Class Initialized
INFO - 2019-05-29 07:12:32 --> Router Class Initialized
INFO - 2019-05-29 07:12:32 --> Output Class Initialized
INFO - 2019-05-29 07:12:32 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:32 --> Input Class Initialized
INFO - 2019-05-29 07:12:32 --> Language Class Initialized
ERROR - 2019-05-29 07:12:32 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:12:35 --> Config Class Initialized
INFO - 2019-05-29 07:12:35 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:35 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:35 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:35 --> URI Class Initialized
INFO - 2019-05-29 07:12:35 --> Router Class Initialized
INFO - 2019-05-29 07:12:35 --> Output Class Initialized
INFO - 2019-05-29 07:12:35 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:35 --> Input Class Initialized
INFO - 2019-05-29 07:12:35 --> Language Class Initialized
INFO - 2019-05-29 07:12:35 --> Language Class Initialized
INFO - 2019-05-29 07:12:35 --> Config Class Initialized
INFO - 2019-05-29 07:12:35 --> Loader Class Initialized
INFO - 2019-05-29 07:12:35 --> Helper loaded: form_helper
INFO - 2019-05-29 07:12:35 --> Helper loaded: url_helper
INFO - 2019-05-29 07:12:35 --> Helper loaded: cookie_helper
INFO - 2019-05-29 07:12:35 --> Database Driver Class Initialized
DEBUG - 2019-05-29 07:12:35 --> Template library initialized
INFO - 2019-05-29 07:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-29 07:12:35 --> Controller Class Initialized
DEBUG - 2019-05-29 07:12:35 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-29 07:12:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-29 07:12:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/cable-bill-payment.php
DEBUG - 2019-05-29 07:12:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-29 07:12:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-29 07:12:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-29 07:12:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-29 07:12:35 --> Final output sent to browser
DEBUG - 2019-05-29 07:12:35 --> Total execution time: 0.0496
INFO - 2019-05-29 07:12:36 --> Config Class Initialized
INFO - 2019-05-29 07:12:36 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:36 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:36 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:36 --> URI Class Initialized
INFO - 2019-05-29 07:12:36 --> Config Class Initialized
INFO - 2019-05-29 07:12:36 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:36 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:36 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:36 --> URI Class Initialized
INFO - 2019-05-29 07:12:36 --> Router Class Initialized
INFO - 2019-05-29 07:12:36 --> Router Class Initialized
INFO - 2019-05-29 07:12:36 --> Output Class Initialized
INFO - 2019-05-29 07:12:36 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:36 --> Input Class Initialized
INFO - 2019-05-29 07:12:36 --> Language Class Initialized
ERROR - 2019-05-29 07:12:36 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:12:36 --> Config Class Initialized
INFO - 2019-05-29 07:12:36 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:36 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:36 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:36 --> URI Class Initialized
INFO - 2019-05-29 07:12:36 --> Output Class Initialized
INFO - 2019-05-29 07:12:36 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:36 --> Input Class Initialized
INFO - 2019-05-29 07:12:36 --> Language Class Initialized
ERROR - 2019-05-29 07:12:36 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:12:36 --> Router Class Initialized
INFO - 2019-05-29 07:12:36 --> Output Class Initialized
INFO - 2019-05-29 07:12:36 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:36 --> Input Class Initialized
INFO - 2019-05-29 07:12:36 --> Language Class Initialized
ERROR - 2019-05-29 07:12:36 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:12:40 --> Config Class Initialized
INFO - 2019-05-29 07:12:40 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:40 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:40 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:40 --> URI Class Initialized
INFO - 2019-05-29 07:12:40 --> Router Class Initialized
INFO - 2019-05-29 07:12:40 --> Output Class Initialized
INFO - 2019-05-29 07:12:40 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:40 --> Input Class Initialized
INFO - 2019-05-29 07:12:40 --> Language Class Initialized
INFO - 2019-05-29 07:12:40 --> Language Class Initialized
INFO - 2019-05-29 07:12:40 --> Config Class Initialized
INFO - 2019-05-29 07:12:40 --> Loader Class Initialized
INFO - 2019-05-29 07:12:40 --> Helper loaded: form_helper
INFO - 2019-05-29 07:12:40 --> Helper loaded: url_helper
INFO - 2019-05-29 07:12:40 --> Helper loaded: cookie_helper
INFO - 2019-05-29 07:12:40 --> Database Driver Class Initialized
DEBUG - 2019-05-29 07:12:40 --> Template library initialized
INFO - 2019-05-29 07:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-29 07:12:40 --> Controller Class Initialized
DEBUG - 2019-05-29 07:12:40 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-29 07:12:40 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-29 07:12:40 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/municipal-property-tax-payment.php
DEBUG - 2019-05-29 07:12:40 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-29 07:12:40 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-29 07:12:40 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-29 07:12:40 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-29 07:12:40 --> Final output sent to browser
DEBUG - 2019-05-29 07:12:40 --> Total execution time: 0.0459
INFO - 2019-05-29 07:12:41 --> Config Class Initialized
INFO - 2019-05-29 07:12:41 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:41 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:41 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:41 --> URI Class Initialized
INFO - 2019-05-29 07:12:41 --> Router Class Initialized
INFO - 2019-05-29 07:12:41 --> Output Class Initialized
INFO - 2019-05-29 07:12:41 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:41 --> Input Class Initialized
INFO - 2019-05-29 07:12:41 --> Language Class Initialized
ERROR - 2019-05-29 07:12:41 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:12:41 --> Config Class Initialized
INFO - 2019-05-29 07:12:41 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:41 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:41 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:41 --> URI Class Initialized
INFO - 2019-05-29 07:12:41 --> Router Class Initialized
INFO - 2019-05-29 07:12:41 --> Output Class Initialized
INFO - 2019-05-29 07:12:41 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:41 --> Input Class Initialized
INFO - 2019-05-29 07:12:41 --> Language Class Initialized
ERROR - 2019-05-29 07:12:41 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:12:41 --> Config Class Initialized
INFO - 2019-05-29 07:12:41 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:41 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:41 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:41 --> URI Class Initialized
INFO - 2019-05-29 07:12:41 --> Router Class Initialized
INFO - 2019-05-29 07:12:41 --> Output Class Initialized
INFO - 2019-05-29 07:12:41 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:41 --> Input Class Initialized
INFO - 2019-05-29 07:12:41 --> Language Class Initialized
ERROR - 2019-05-29 07:12:41 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:12:49 --> Config Class Initialized
INFO - 2019-05-29 07:12:49 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:49 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:49 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:49 --> URI Class Initialized
INFO - 2019-05-29 07:12:49 --> Router Class Initialized
INFO - 2019-05-29 07:12:49 --> Output Class Initialized
INFO - 2019-05-29 07:12:49 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:49 --> Input Class Initialized
INFO - 2019-05-29 07:12:49 --> Language Class Initialized
INFO - 2019-05-29 07:12:49 --> Language Class Initialized
INFO - 2019-05-29 07:12:49 --> Config Class Initialized
INFO - 2019-05-29 07:12:49 --> Loader Class Initialized
INFO - 2019-05-29 07:12:49 --> Helper loaded: form_helper
INFO - 2019-05-29 07:12:49 --> Helper loaded: url_helper
INFO - 2019-05-29 07:12:49 --> Helper loaded: cookie_helper
INFO - 2019-05-29 07:12:49 --> Database Driver Class Initialized
DEBUG - 2019-05-29 07:12:49 --> Template library initialized
INFO - 2019-05-29 07:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-29 07:12:49 --> Controller Class Initialized
DEBUG - 2019-05-29 07:12:49 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-29 07:12:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-29 07:12:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/pay-institute-fee.php
DEBUG - 2019-05-29 07:12:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-29 07:12:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-29 07:12:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-29 07:12:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-29 07:12:49 --> Final output sent to browser
DEBUG - 2019-05-29 07:12:49 --> Total execution time: 0.0455
INFO - 2019-05-29 07:12:50 --> Config Class Initialized
INFO - 2019-05-29 07:12:50 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:50 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:50 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:50 --> URI Class Initialized
INFO - 2019-05-29 07:12:50 --> Router Class Initialized
INFO - 2019-05-29 07:12:50 --> Output Class Initialized
INFO - 2019-05-29 07:12:50 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:50 --> Input Class Initialized
INFO - 2019-05-29 07:12:50 --> Language Class Initialized
ERROR - 2019-05-29 07:12:50 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:12:50 --> Config Class Initialized
INFO - 2019-05-29 07:12:50 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:50 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:50 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:50 --> URI Class Initialized
INFO - 2019-05-29 07:12:50 --> Router Class Initialized
INFO - 2019-05-29 07:12:50 --> Output Class Initialized
INFO - 2019-05-29 07:12:50 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:50 --> Input Class Initialized
INFO - 2019-05-29 07:12:50 --> Language Class Initialized
ERROR - 2019-05-29 07:12:50 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:12:50 --> Config Class Initialized
INFO - 2019-05-29 07:12:50 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:12:50 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:12:50 --> Utf8 Class Initialized
INFO - 2019-05-29 07:12:50 --> URI Class Initialized
INFO - 2019-05-29 07:12:50 --> Router Class Initialized
INFO - 2019-05-29 07:12:50 --> Output Class Initialized
INFO - 2019-05-29 07:12:50 --> Security Class Initialized
DEBUG - 2019-05-29 07:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:12:50 --> Input Class Initialized
INFO - 2019-05-29 07:12:50 --> Language Class Initialized
ERROR - 2019-05-29 07:12:50 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:13:01 --> Config Class Initialized
INFO - 2019-05-29 07:13:01 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:13:01 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:13:01 --> Utf8 Class Initialized
INFO - 2019-05-29 07:13:01 --> URI Class Initialized
INFO - 2019-05-29 07:13:01 --> Router Class Initialized
INFO - 2019-05-29 07:13:01 --> Output Class Initialized
INFO - 2019-05-29 07:13:01 --> Security Class Initialized
DEBUG - 2019-05-29 07:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:13:01 --> Input Class Initialized
INFO - 2019-05-29 07:13:01 --> Language Class Initialized
INFO - 2019-05-29 07:13:01 --> Language Class Initialized
INFO - 2019-05-29 07:13:01 --> Config Class Initialized
INFO - 2019-05-29 07:13:01 --> Loader Class Initialized
INFO - 2019-05-29 07:13:01 --> Helper loaded: form_helper
INFO - 2019-05-29 07:13:01 --> Helper loaded: url_helper
INFO - 2019-05-29 07:13:01 --> Helper loaded: cookie_helper
INFO - 2019-05-29 07:13:01 --> Database Driver Class Initialized
DEBUG - 2019-05-29 07:13:01 --> Template library initialized
INFO - 2019-05-29 07:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-29 07:13:01 --> Controller Class Initialized
DEBUG - 2019-05-29 07:13:01 --> Api MX_Controller Initialized
DEBUG - 2019-05-29 07:13:01 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-29 07:13:01 --> Final output sent to browser
DEBUG - 2019-05-29 07:13:01 --> Total execution time: 0.0362
INFO - 2019-05-29 07:13:20 --> Config Class Initialized
INFO - 2019-05-29 07:13:20 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:13:20 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:13:20 --> Utf8 Class Initialized
INFO - 2019-05-29 07:13:20 --> URI Class Initialized
DEBUG - 2019-05-29 07:13:20 --> No URI present. Default controller set.
INFO - 2019-05-29 07:13:20 --> Router Class Initialized
INFO - 2019-05-29 07:13:20 --> Output Class Initialized
INFO - 2019-05-29 07:13:20 --> Security Class Initialized
DEBUG - 2019-05-29 07:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:13:20 --> Input Class Initialized
INFO - 2019-05-29 07:13:20 --> Language Class Initialized
INFO - 2019-05-29 07:13:20 --> Language Class Initialized
INFO - 2019-05-29 07:13:20 --> Config Class Initialized
INFO - 2019-05-29 07:13:20 --> Loader Class Initialized
INFO - 2019-05-29 07:13:20 --> Helper loaded: form_helper
INFO - 2019-05-29 07:13:20 --> Helper loaded: url_helper
INFO - 2019-05-29 07:13:20 --> Helper loaded: cookie_helper
INFO - 2019-05-29 07:13:20 --> Database Driver Class Initialized
DEBUG - 2019-05-29 07:13:20 --> Template library initialized
INFO - 2019-05-29 07:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-29 07:13:20 --> Controller Class Initialized
DEBUG - 2019-05-29 07:13:20 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-29 07:13:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-29 07:13:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-29 07:13:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-29 07:13:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-29 07:13:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-29 07:13:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-29 07:13:21 --> Final output sent to browser
DEBUG - 2019-05-29 07:13:21 --> Total execution time: 0.0551
INFO - 2019-05-29 07:13:21 --> Config Class Initialized
INFO - 2019-05-29 07:13:21 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:13:21 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:13:21 --> Utf8 Class Initialized
INFO - 2019-05-29 07:13:21 --> URI Class Initialized
INFO - 2019-05-29 07:13:21 --> Router Class Initialized
INFO - 2019-05-29 07:13:21 --> Output Class Initialized
INFO - 2019-05-29 07:13:21 --> Security Class Initialized
DEBUG - 2019-05-29 07:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:13:21 --> Input Class Initialized
INFO - 2019-05-29 07:13:21 --> Language Class Initialized
ERROR - 2019-05-29 07:13:21 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:13:21 --> Config Class Initialized
INFO - 2019-05-29 07:13:21 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:13:21 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:13:21 --> Utf8 Class Initialized
INFO - 2019-05-29 07:13:21 --> URI Class Initialized
INFO - 2019-05-29 07:13:21 --> Router Class Initialized
INFO - 2019-05-29 07:13:21 --> Output Class Initialized
INFO - 2019-05-29 07:13:21 --> Security Class Initialized
DEBUG - 2019-05-29 07:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:13:21 --> Input Class Initialized
INFO - 2019-05-29 07:13:21 --> Language Class Initialized
ERROR - 2019-05-29 07:13:21 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:13:21 --> Config Class Initialized
INFO - 2019-05-29 07:13:21 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:13:21 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:13:21 --> Utf8 Class Initialized
INFO - 2019-05-29 07:13:21 --> URI Class Initialized
INFO - 2019-05-29 07:13:21 --> Router Class Initialized
INFO - 2019-05-29 07:13:21 --> Output Class Initialized
INFO - 2019-05-29 07:13:21 --> Security Class Initialized
DEBUG - 2019-05-29 07:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:13:21 --> Input Class Initialized
INFO - 2019-05-29 07:13:21 --> Language Class Initialized
ERROR - 2019-05-29 07:13:21 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:31:47 --> Config Class Initialized
INFO - 2019-05-29 07:31:47 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:31:47 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:31:47 --> Utf8 Class Initialized
INFO - 2019-05-29 07:31:47 --> URI Class Initialized
DEBUG - 2019-05-29 07:31:47 --> No URI present. Default controller set.
INFO - 2019-05-29 07:31:47 --> Router Class Initialized
INFO - 2019-05-29 07:31:47 --> Output Class Initialized
INFO - 2019-05-29 07:31:47 --> Security Class Initialized
DEBUG - 2019-05-29 07:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:31:47 --> Input Class Initialized
INFO - 2019-05-29 07:31:47 --> Language Class Initialized
INFO - 2019-05-29 07:31:47 --> Language Class Initialized
INFO - 2019-05-29 07:31:47 --> Config Class Initialized
INFO - 2019-05-29 07:31:47 --> Loader Class Initialized
INFO - 2019-05-29 07:31:47 --> Helper loaded: form_helper
INFO - 2019-05-29 07:31:47 --> Helper loaded: url_helper
INFO - 2019-05-29 07:31:47 --> Helper loaded: cookie_helper
INFO - 2019-05-29 07:31:47 --> Database Driver Class Initialized
DEBUG - 2019-05-29 07:31:47 --> Template library initialized
INFO - 2019-05-29 07:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-29 07:31:47 --> Controller Class Initialized
DEBUG - 2019-05-29 07:31:47 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-29 07:31:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-29 07:31:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-29 07:31:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-29 07:31:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-29 07:31:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-29 07:31:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-29 07:31:48 --> Final output sent to browser
DEBUG - 2019-05-29 07:31:48 --> Total execution time: 0.0549
INFO - 2019-05-29 07:31:48 --> Config Class Initialized
INFO - 2019-05-29 07:31:48 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:31:48 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:31:48 --> Utf8 Class Initialized
INFO - 2019-05-29 07:31:48 --> URI Class Initialized
INFO - 2019-05-29 07:31:48 --> Router Class Initialized
INFO - 2019-05-29 07:31:48 --> Output Class Initialized
INFO - 2019-05-29 07:31:48 --> Security Class Initialized
DEBUG - 2019-05-29 07:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:31:48 --> Input Class Initialized
INFO - 2019-05-29 07:31:48 --> Language Class Initialized
ERROR - 2019-05-29 07:31:48 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:31:49 --> Config Class Initialized
INFO - 2019-05-29 07:31:49 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:31:49 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:31:49 --> Utf8 Class Initialized
INFO - 2019-05-29 07:31:49 --> URI Class Initialized
INFO - 2019-05-29 07:31:49 --> Router Class Initialized
INFO - 2019-05-29 07:31:49 --> Output Class Initialized
INFO - 2019-05-29 07:31:49 --> Security Class Initialized
DEBUG - 2019-05-29 07:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:31:49 --> Input Class Initialized
INFO - 2019-05-29 07:31:49 --> Language Class Initialized
ERROR - 2019-05-29 07:31:49 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:31:49 --> Config Class Initialized
INFO - 2019-05-29 07:31:49 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:31:49 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:31:49 --> Utf8 Class Initialized
INFO - 2019-05-29 07:31:49 --> URI Class Initialized
INFO - 2019-05-29 07:31:49 --> Router Class Initialized
INFO - 2019-05-29 07:31:49 --> Output Class Initialized
INFO - 2019-05-29 07:31:49 --> Security Class Initialized
DEBUG - 2019-05-29 07:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:31:49 --> Input Class Initialized
INFO - 2019-05-29 07:31:49 --> Language Class Initialized
ERROR - 2019-05-29 07:31:49 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:31:50 --> Config Class Initialized
INFO - 2019-05-29 07:31:50 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:31:50 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:31:50 --> Utf8 Class Initialized
INFO - 2019-05-29 07:31:50 --> URI Class Initialized
INFO - 2019-05-29 07:31:50 --> Router Class Initialized
INFO - 2019-05-29 07:31:50 --> Output Class Initialized
INFO - 2019-05-29 07:31:50 --> Security Class Initialized
DEBUG - 2019-05-29 07:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:31:50 --> Input Class Initialized
INFO - 2019-05-29 07:31:50 --> Language Class Initialized
ERROR - 2019-05-29 07:31:50 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:31:50 --> Config Class Initialized
INFO - 2019-05-29 07:31:50 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:31:50 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:31:50 --> Utf8 Class Initialized
INFO - 2019-05-29 07:31:50 --> URI Class Initialized
INFO - 2019-05-29 07:31:50 --> Router Class Initialized
INFO - 2019-05-29 07:31:50 --> Output Class Initialized
INFO - 2019-05-29 07:31:50 --> Security Class Initialized
DEBUG - 2019-05-29 07:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:31:50 --> Input Class Initialized
INFO - 2019-05-29 07:31:50 --> Language Class Initialized
ERROR - 2019-05-29 07:31:50 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:31:50 --> Config Class Initialized
INFO - 2019-05-29 07:31:50 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:31:50 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:31:50 --> Utf8 Class Initialized
INFO - 2019-05-29 07:31:50 --> URI Class Initialized
INFO - 2019-05-29 07:31:50 --> Router Class Initialized
INFO - 2019-05-29 07:31:50 --> Output Class Initialized
INFO - 2019-05-29 07:31:50 --> Security Class Initialized
DEBUG - 2019-05-29 07:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:31:50 --> Input Class Initialized
INFO - 2019-05-29 07:31:50 --> Language Class Initialized
ERROR - 2019-05-29 07:31:50 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:31:51 --> Config Class Initialized
INFO - 2019-05-29 07:31:51 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:31:51 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:31:51 --> Utf8 Class Initialized
INFO - 2019-05-29 07:31:51 --> URI Class Initialized
INFO - 2019-05-29 07:31:51 --> Router Class Initialized
INFO - 2019-05-29 07:31:51 --> Output Class Initialized
INFO - 2019-05-29 07:31:51 --> Security Class Initialized
DEBUG - 2019-05-29 07:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:31:51 --> Input Class Initialized
INFO - 2019-05-29 07:31:51 --> Language Class Initialized
ERROR - 2019-05-29 07:31:51 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:31:51 --> Config Class Initialized
INFO - 2019-05-29 07:31:51 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:31:51 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:31:51 --> Utf8 Class Initialized
INFO - 2019-05-29 07:31:51 --> URI Class Initialized
INFO - 2019-05-29 07:31:51 --> Router Class Initialized
INFO - 2019-05-29 07:31:51 --> Output Class Initialized
INFO - 2019-05-29 07:31:51 --> Security Class Initialized
DEBUG - 2019-05-29 07:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:31:51 --> Input Class Initialized
INFO - 2019-05-29 07:31:51 --> Language Class Initialized
ERROR - 2019-05-29 07:31:51 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:31:51 --> Config Class Initialized
INFO - 2019-05-29 07:31:51 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:31:51 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:31:51 --> Utf8 Class Initialized
INFO - 2019-05-29 07:31:51 --> URI Class Initialized
INFO - 2019-05-29 07:31:51 --> Router Class Initialized
INFO - 2019-05-29 07:31:51 --> Output Class Initialized
INFO - 2019-05-29 07:31:51 --> Security Class Initialized
DEBUG - 2019-05-29 07:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:31:51 --> Input Class Initialized
INFO - 2019-05-29 07:31:51 --> Language Class Initialized
ERROR - 2019-05-29 07:31:51 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:31:51 --> Config Class Initialized
INFO - 2019-05-29 07:31:51 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:31:51 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:31:51 --> Utf8 Class Initialized
INFO - 2019-05-29 07:31:51 --> URI Class Initialized
INFO - 2019-05-29 07:31:51 --> Router Class Initialized
INFO - 2019-05-29 07:31:51 --> Output Class Initialized
INFO - 2019-05-29 07:31:51 --> Security Class Initialized
DEBUG - 2019-05-29 07:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:31:51 --> Input Class Initialized
INFO - 2019-05-29 07:31:51 --> Language Class Initialized
ERROR - 2019-05-29 07:31:51 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:31:52 --> Config Class Initialized
INFO - 2019-05-29 07:31:52 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:31:52 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:31:52 --> Utf8 Class Initialized
INFO - 2019-05-29 07:31:52 --> URI Class Initialized
INFO - 2019-05-29 07:31:52 --> Router Class Initialized
INFO - 2019-05-29 07:31:52 --> Output Class Initialized
INFO - 2019-05-29 07:31:52 --> Security Class Initialized
DEBUG - 2019-05-29 07:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:31:52 --> Input Class Initialized
INFO - 2019-05-29 07:31:52 --> Language Class Initialized
ERROR - 2019-05-29 07:31:52 --> 404 Page Not Found: /index
INFO - 2019-05-29 07:31:52 --> Config Class Initialized
INFO - 2019-05-29 07:31:52 --> Hooks Class Initialized
DEBUG - 2019-05-29 07:31:52 --> UTF-8 Support Enabled
INFO - 2019-05-29 07:31:52 --> Utf8 Class Initialized
INFO - 2019-05-29 07:31:52 --> URI Class Initialized
INFO - 2019-05-29 07:31:52 --> Router Class Initialized
INFO - 2019-05-29 07:31:52 --> Output Class Initialized
INFO - 2019-05-29 07:31:52 --> Security Class Initialized
DEBUG - 2019-05-29 07:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 07:31:52 --> Input Class Initialized
INFO - 2019-05-29 07:31:52 --> Language Class Initialized
ERROR - 2019-05-29 07:31:52 --> 404 Page Not Found: /index
INFO - 2019-05-29 08:25:28 --> Config Class Initialized
INFO - 2019-05-29 08:25:28 --> Hooks Class Initialized
DEBUG - 2019-05-29 08:25:28 --> UTF-8 Support Enabled
INFO - 2019-05-29 08:25:28 --> Utf8 Class Initialized
INFO - 2019-05-29 08:25:28 --> URI Class Initialized
DEBUG - 2019-05-29 08:25:28 --> No URI present. Default controller set.
INFO - 2019-05-29 08:25:28 --> Router Class Initialized
INFO - 2019-05-29 08:25:28 --> Output Class Initialized
INFO - 2019-05-29 08:25:28 --> Security Class Initialized
DEBUG - 2019-05-29 08:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 08:25:28 --> Input Class Initialized
INFO - 2019-05-29 08:25:28 --> Language Class Initialized
INFO - 2019-05-29 08:25:28 --> Language Class Initialized
INFO - 2019-05-29 08:25:28 --> Config Class Initialized
INFO - 2019-05-29 08:25:28 --> Loader Class Initialized
INFO - 2019-05-29 08:25:28 --> Helper loaded: form_helper
INFO - 2019-05-29 08:25:28 --> Helper loaded: url_helper
INFO - 2019-05-29 08:25:28 --> Helper loaded: cookie_helper
INFO - 2019-05-29 08:25:28 --> Database Driver Class Initialized
DEBUG - 2019-05-29 08:25:28 --> Template library initialized
INFO - 2019-05-29 08:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-29 08:25:28 --> Controller Class Initialized
DEBUG - 2019-05-29 08:25:28 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-29 08:25:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-29 08:25:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-29 08:25:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-29 08:25:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-29 08:25:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-29 08:25:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-29 08:25:29 --> Final output sent to browser
DEBUG - 2019-05-29 08:25:29 --> Total execution time: 0.0479
INFO - 2019-05-29 09:10:17 --> Config Class Initialized
INFO - 2019-05-29 09:10:17 --> Hooks Class Initialized
DEBUG - 2019-05-29 09:10:17 --> UTF-8 Support Enabled
INFO - 2019-05-29 09:10:17 --> Utf8 Class Initialized
INFO - 2019-05-29 09:10:17 --> URI Class Initialized
DEBUG - 2019-05-29 09:10:17 --> No URI present. Default controller set.
INFO - 2019-05-29 09:10:17 --> Router Class Initialized
INFO - 2019-05-29 09:10:17 --> Output Class Initialized
INFO - 2019-05-29 09:10:17 --> Security Class Initialized
DEBUG - 2019-05-29 09:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 09:10:17 --> Input Class Initialized
INFO - 2019-05-29 09:10:17 --> Language Class Initialized
INFO - 2019-05-29 09:10:17 --> Language Class Initialized
INFO - 2019-05-29 09:10:17 --> Config Class Initialized
INFO - 2019-05-29 09:10:17 --> Loader Class Initialized
INFO - 2019-05-29 09:10:17 --> Helper loaded: form_helper
INFO - 2019-05-29 09:10:17 --> Helper loaded: url_helper
INFO - 2019-05-29 09:10:17 --> Helper loaded: cookie_helper
INFO - 2019-05-29 09:10:17 --> Database Driver Class Initialized
DEBUG - 2019-05-29 09:10:17 --> Template library initialized
INFO - 2019-05-29 09:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-29 09:10:17 --> Controller Class Initialized
DEBUG - 2019-05-29 09:10:17 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-29 09:10:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-29 09:10:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-29 09:10:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-29 09:10:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-29 09:10:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-29 09:10:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-29 09:10:17 --> Final output sent to browser
DEBUG - 2019-05-29 09:10:17 --> Total execution time: 0.0461
INFO - 2019-05-29 09:10:22 --> Config Class Initialized
INFO - 2019-05-29 09:10:22 --> Hooks Class Initialized
DEBUG - 2019-05-29 09:10:22 --> UTF-8 Support Enabled
INFO - 2019-05-29 09:10:22 --> Utf8 Class Initialized
INFO - 2019-05-29 09:10:22 --> URI Class Initialized
INFO - 2019-05-29 09:10:22 --> Router Class Initialized
INFO - 2019-05-29 09:10:22 --> Output Class Initialized
INFO - 2019-05-29 09:10:22 --> Security Class Initialized
DEBUG - 2019-05-29 09:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 09:10:22 --> Input Class Initialized
INFO - 2019-05-29 09:10:22 --> Language Class Initialized
ERROR - 2019-05-29 09:10:22 --> 404 Page Not Found: /index
INFO - 2019-05-29 09:10:22 --> Config Class Initialized
INFO - 2019-05-29 09:10:22 --> Hooks Class Initialized
DEBUG - 2019-05-29 09:10:22 --> UTF-8 Support Enabled
INFO - 2019-05-29 09:10:22 --> Utf8 Class Initialized
INFO - 2019-05-29 09:10:22 --> URI Class Initialized
INFO - 2019-05-29 09:10:22 --> Router Class Initialized
INFO - 2019-05-29 09:10:22 --> Output Class Initialized
INFO - 2019-05-29 09:10:22 --> Security Class Initialized
DEBUG - 2019-05-29 09:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 09:10:22 --> Input Class Initialized
INFO - 2019-05-29 09:10:22 --> Language Class Initialized
ERROR - 2019-05-29 09:10:22 --> 404 Page Not Found: /index
INFO - 2019-05-29 09:10:22 --> Config Class Initialized
INFO - 2019-05-29 09:10:22 --> Hooks Class Initialized
DEBUG - 2019-05-29 09:10:22 --> UTF-8 Support Enabled
INFO - 2019-05-29 09:10:22 --> Utf8 Class Initialized
INFO - 2019-05-29 09:10:22 --> URI Class Initialized
INFO - 2019-05-29 09:10:22 --> Router Class Initialized
INFO - 2019-05-29 09:10:22 --> Output Class Initialized
INFO - 2019-05-29 09:10:22 --> Security Class Initialized
DEBUG - 2019-05-29 09:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 09:10:22 --> Input Class Initialized
INFO - 2019-05-29 09:10:22 --> Language Class Initialized
ERROR - 2019-05-29 09:10:22 --> 404 Page Not Found: /index
INFO - 2019-05-29 09:10:48 --> Config Class Initialized
INFO - 2019-05-29 09:10:48 --> Hooks Class Initialized
DEBUG - 2019-05-29 09:10:48 --> UTF-8 Support Enabled
INFO - 2019-05-29 09:10:48 --> Utf8 Class Initialized
INFO - 2019-05-29 09:10:48 --> URI Class Initialized
INFO - 2019-05-29 09:10:48 --> Router Class Initialized
INFO - 2019-05-29 09:10:48 --> Output Class Initialized
INFO - 2019-05-29 09:10:48 --> Security Class Initialized
DEBUG - 2019-05-29 09:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 09:10:48 --> Input Class Initialized
INFO - 2019-05-29 09:10:48 --> Language Class Initialized
INFO - 2019-05-29 09:10:48 --> Language Class Initialized
INFO - 2019-05-29 09:10:48 --> Config Class Initialized
INFO - 2019-05-29 09:10:48 --> Loader Class Initialized
INFO - 2019-05-29 09:10:48 --> Helper loaded: form_helper
INFO - 2019-05-29 09:10:48 --> Helper loaded: url_helper
INFO - 2019-05-29 09:10:48 --> Helper loaded: cookie_helper
INFO - 2019-05-29 09:10:48 --> Database Driver Class Initialized
DEBUG - 2019-05-29 09:10:48 --> Template library initialized
INFO - 2019-05-29 09:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-29 09:10:48 --> Controller Class Initialized
DEBUG - 2019-05-29 09:10:48 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-29 09:10:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-29 09:10:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/dth.php
DEBUG - 2019-05-29 09:10:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-29 09:10:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-29 09:10:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-29 09:10:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-29 09:10:48 --> Final output sent to browser
DEBUG - 2019-05-29 09:10:48 --> Total execution time: 0.0490
INFO - 2019-05-29 09:10:49 --> Config Class Initialized
INFO - 2019-05-29 09:10:49 --> Hooks Class Initialized
DEBUG - 2019-05-29 09:10:49 --> UTF-8 Support Enabled
INFO - 2019-05-29 09:10:49 --> Utf8 Class Initialized
INFO - 2019-05-29 09:10:49 --> URI Class Initialized
INFO - 2019-05-29 09:10:49 --> Config Class Initialized
INFO - 2019-05-29 09:10:49 --> Hooks Class Initialized
DEBUG - 2019-05-29 09:10:49 --> UTF-8 Support Enabled
INFO - 2019-05-29 09:10:49 --> Utf8 Class Initialized
INFO - 2019-05-29 09:10:49 --> URI Class Initialized
INFO - 2019-05-29 09:10:49 --> Router Class Initialized
INFO - 2019-05-29 09:10:49 --> Output Class Initialized
INFO - 2019-05-29 09:10:49 --> Security Class Initialized
DEBUG - 2019-05-29 09:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 09:10:49 --> Input Class Initialized
INFO - 2019-05-29 09:10:49 --> Language Class Initialized
ERROR - 2019-05-29 09:10:49 --> 404 Page Not Found: /index
INFO - 2019-05-29 09:10:49 --> Router Class Initialized
INFO - 2019-05-29 09:10:49 --> Output Class Initialized
INFO - 2019-05-29 09:10:49 --> Security Class Initialized
DEBUG - 2019-05-29 09:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 09:10:49 --> Input Class Initialized
INFO - 2019-05-29 09:10:49 --> Language Class Initialized
ERROR - 2019-05-29 09:10:49 --> 404 Page Not Found: /index
INFO - 2019-05-29 09:10:49 --> Config Class Initialized
INFO - 2019-05-29 09:10:49 --> Hooks Class Initialized
DEBUG - 2019-05-29 09:10:49 --> UTF-8 Support Enabled
INFO - 2019-05-29 09:10:49 --> Utf8 Class Initialized
INFO - 2019-05-29 09:10:49 --> URI Class Initialized
INFO - 2019-05-29 09:10:49 --> Router Class Initialized
INFO - 2019-05-29 09:10:49 --> Output Class Initialized
INFO - 2019-05-29 09:10:49 --> Security Class Initialized
DEBUG - 2019-05-29 09:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 09:10:49 --> Input Class Initialized
INFO - 2019-05-29 09:10:49 --> Language Class Initialized
ERROR - 2019-05-29 09:10:49 --> 404 Page Not Found: /index
INFO - 2019-05-29 09:10:50 --> Config Class Initialized
INFO - 2019-05-29 09:10:50 --> Hooks Class Initialized
DEBUG - 2019-05-29 09:10:50 --> UTF-8 Support Enabled
INFO - 2019-05-29 09:10:50 --> Utf8 Class Initialized
INFO - 2019-05-29 09:10:50 --> URI Class Initialized
INFO - 2019-05-29 09:10:50 --> Router Class Initialized
INFO - 2019-05-29 09:10:50 --> Output Class Initialized
INFO - 2019-05-29 09:10:50 --> Security Class Initialized
DEBUG - 2019-05-29 09:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 09:10:50 --> Input Class Initialized
INFO - 2019-05-29 09:10:50 --> Language Class Initialized
INFO - 2019-05-29 09:10:50 --> Language Class Initialized
INFO - 2019-05-29 09:10:50 --> Config Class Initialized
INFO - 2019-05-29 09:10:50 --> Loader Class Initialized
INFO - 2019-05-29 09:10:50 --> Helper loaded: form_helper
INFO - 2019-05-29 09:10:50 --> Helper loaded: url_helper
INFO - 2019-05-29 09:10:50 --> Helper loaded: cookie_helper
INFO - 2019-05-29 09:10:50 --> Database Driver Class Initialized
DEBUG - 2019-05-29 09:10:50 --> Template library initialized
INFO - 2019-05-29 09:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-29 09:10:50 --> Controller Class Initialized
DEBUG - 2019-05-29 09:10:50 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-29 09:10:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-29 09:10:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/mobile.php
DEBUG - 2019-05-29 09:10:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-29 09:10:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-29 09:10:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-29 09:10:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-29 09:10:51 --> Final output sent to browser
DEBUG - 2019-05-29 09:10:51 --> Total execution time: 0.0459
INFO - 2019-05-29 09:10:51 --> Config Class Initialized
INFO - 2019-05-29 09:10:51 --> Hooks Class Initialized
DEBUG - 2019-05-29 09:10:51 --> UTF-8 Support Enabled
INFO - 2019-05-29 09:10:51 --> Utf8 Class Initialized
INFO - 2019-05-29 09:10:51 --> URI Class Initialized
INFO - 2019-05-29 09:10:51 --> Router Class Initialized
INFO - 2019-05-29 09:10:51 --> Output Class Initialized
INFO - 2019-05-29 09:10:51 --> Security Class Initialized
DEBUG - 2019-05-29 09:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 09:10:51 --> Input Class Initialized
INFO - 2019-05-29 09:10:51 --> Language Class Initialized
ERROR - 2019-05-29 09:10:51 --> 404 Page Not Found: /index
INFO - 2019-05-29 09:10:51 --> Config Class Initialized
INFO - 2019-05-29 09:10:51 --> Hooks Class Initialized
DEBUG - 2019-05-29 09:10:51 --> UTF-8 Support Enabled
INFO - 2019-05-29 09:10:51 --> Utf8 Class Initialized
INFO - 2019-05-29 09:10:51 --> URI Class Initialized
INFO - 2019-05-29 09:10:51 --> Config Class Initialized
INFO - 2019-05-29 09:10:51 --> Hooks Class Initialized
DEBUG - 2019-05-29 09:10:51 --> UTF-8 Support Enabled
INFO - 2019-05-29 09:10:51 --> Utf8 Class Initialized
INFO - 2019-05-29 09:10:51 --> URI Class Initialized
INFO - 2019-05-29 09:10:51 --> Router Class Initialized
INFO - 2019-05-29 09:10:51 --> Router Class Initialized
INFO - 2019-05-29 09:10:51 --> Output Class Initialized
INFO - 2019-05-29 09:10:51 --> Security Class Initialized
DEBUG - 2019-05-29 09:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 09:10:51 --> Input Class Initialized
INFO - 2019-05-29 09:10:51 --> Language Class Initialized
ERROR - 2019-05-29 09:10:51 --> 404 Page Not Found: /index
INFO - 2019-05-29 09:10:51 --> Output Class Initialized
INFO - 2019-05-29 09:10:51 --> Security Class Initialized
DEBUG - 2019-05-29 09:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 09:10:51 --> Input Class Initialized
INFO - 2019-05-29 09:10:51 --> Language Class Initialized
ERROR - 2019-05-29 09:10:51 --> 404 Page Not Found: /index
INFO - 2019-05-29 15:30:24 --> Config Class Initialized
INFO - 2019-05-29 15:30:24 --> Hooks Class Initialized
DEBUG - 2019-05-29 15:30:24 --> UTF-8 Support Enabled
INFO - 2019-05-29 15:30:24 --> Utf8 Class Initialized
INFO - 2019-05-29 15:30:24 --> URI Class Initialized
DEBUG - 2019-05-29 15:30:24 --> No URI present. Default controller set.
INFO - 2019-05-29 15:30:24 --> Router Class Initialized
INFO - 2019-05-29 15:30:24 --> Output Class Initialized
INFO - 2019-05-29 15:30:24 --> Security Class Initialized
DEBUG - 2019-05-29 15:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 15:30:24 --> Input Class Initialized
INFO - 2019-05-29 15:30:24 --> Language Class Initialized
INFO - 2019-05-29 15:30:24 --> Language Class Initialized
INFO - 2019-05-29 15:30:24 --> Config Class Initialized
INFO - 2019-05-29 15:30:24 --> Loader Class Initialized
INFO - 2019-05-29 15:30:24 --> Helper loaded: form_helper
INFO - 2019-05-29 15:30:24 --> Helper loaded: url_helper
INFO - 2019-05-29 15:30:24 --> Helper loaded: cookie_helper
INFO - 2019-05-29 15:30:24 --> Database Driver Class Initialized
DEBUG - 2019-05-29 15:30:24 --> Template library initialized
INFO - 2019-05-29 15:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-29 15:30:24 --> Controller Class Initialized
DEBUG - 2019-05-29 15:30:24 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-29 15:30:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-29 15:30:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-29 15:30:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-29 15:30:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-29 15:30:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-29 15:30:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-29 15:30:25 --> Final output sent to browser
DEBUG - 2019-05-29 15:30:25 --> Total execution time: 0.0525
INFO - 2019-05-29 15:30:29 --> Config Class Initialized
INFO - 2019-05-29 15:30:29 --> Hooks Class Initialized
DEBUG - 2019-05-29 15:30:29 --> UTF-8 Support Enabled
INFO - 2019-05-29 15:30:29 --> Utf8 Class Initialized
INFO - 2019-05-29 15:30:29 --> URI Class Initialized
DEBUG - 2019-05-29 15:30:29 --> No URI present. Default controller set.
INFO - 2019-05-29 15:30:29 --> Router Class Initialized
INFO - 2019-05-29 15:30:29 --> Output Class Initialized
INFO - 2019-05-29 15:30:29 --> Security Class Initialized
DEBUG - 2019-05-29 15:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 15:30:29 --> Input Class Initialized
INFO - 2019-05-29 15:30:29 --> Language Class Initialized
INFO - 2019-05-29 15:30:29 --> Language Class Initialized
INFO - 2019-05-29 15:30:29 --> Config Class Initialized
INFO - 2019-05-29 15:30:29 --> Loader Class Initialized
INFO - 2019-05-29 15:30:29 --> Helper loaded: form_helper
INFO - 2019-05-29 15:30:29 --> Helper loaded: url_helper
INFO - 2019-05-29 15:30:29 --> Helper loaded: cookie_helper
INFO - 2019-05-29 15:30:29 --> Database Driver Class Initialized
DEBUG - 2019-05-29 15:30:29 --> Template library initialized
INFO - 2019-05-29 15:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-29 15:30:29 --> Controller Class Initialized
DEBUG - 2019-05-29 15:30:29 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-29 15:30:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-29 15:30:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-29 15:30:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-29 15:30:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-29 15:30:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-29 15:30:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-29 15:30:29 --> Final output sent to browser
DEBUG - 2019-05-29 15:30:29 --> Total execution time: 0.0467
INFO - 2019-05-29 15:30:33 --> Config Class Initialized
INFO - 2019-05-29 15:30:33 --> Hooks Class Initialized
DEBUG - 2019-05-29 15:30:33 --> UTF-8 Support Enabled
INFO - 2019-05-29 15:30:33 --> Utf8 Class Initialized
INFO - 2019-05-29 15:30:33 --> URI Class Initialized
INFO - 2019-05-29 15:30:33 --> Router Class Initialized
INFO - 2019-05-29 15:30:33 --> Output Class Initialized
INFO - 2019-05-29 15:30:33 --> Security Class Initialized
DEBUG - 2019-05-29 15:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 15:30:33 --> Input Class Initialized
INFO - 2019-05-29 15:30:33 --> Language Class Initialized
ERROR - 2019-05-29 15:30:33 --> 404 Page Not Found: /index
INFO - 2019-05-29 15:30:33 --> Config Class Initialized
INFO - 2019-05-29 15:30:33 --> Hooks Class Initialized
DEBUG - 2019-05-29 15:30:33 --> UTF-8 Support Enabled
INFO - 2019-05-29 15:30:33 --> Utf8 Class Initialized
INFO - 2019-05-29 15:30:33 --> URI Class Initialized
INFO - 2019-05-29 15:30:33 --> Router Class Initialized
INFO - 2019-05-29 15:30:33 --> Output Class Initialized
INFO - 2019-05-29 15:30:33 --> Security Class Initialized
DEBUG - 2019-05-29 15:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 15:30:33 --> Input Class Initialized
INFO - 2019-05-29 15:30:33 --> Language Class Initialized
ERROR - 2019-05-29 15:30:33 --> 404 Page Not Found: /index
INFO - 2019-05-29 15:30:33 --> Config Class Initialized
INFO - 2019-05-29 15:30:33 --> Hooks Class Initialized
DEBUG - 2019-05-29 15:30:33 --> UTF-8 Support Enabled
INFO - 2019-05-29 15:30:33 --> Utf8 Class Initialized
INFO - 2019-05-29 15:30:33 --> URI Class Initialized
INFO - 2019-05-29 15:30:33 --> Router Class Initialized
INFO - 2019-05-29 15:30:33 --> Output Class Initialized
INFO - 2019-05-29 15:30:33 --> Security Class Initialized
DEBUG - 2019-05-29 15:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 15:30:33 --> Input Class Initialized
INFO - 2019-05-29 15:30:33 --> Language Class Initialized
ERROR - 2019-05-29 15:30:33 --> 404 Page Not Found: /index
INFO - 2019-05-29 15:30:37 --> Config Class Initialized
INFO - 2019-05-29 15:30:37 --> Hooks Class Initialized
DEBUG - 2019-05-29 15:30:37 --> UTF-8 Support Enabled
INFO - 2019-05-29 15:30:37 --> Utf8 Class Initialized
INFO - 2019-05-29 15:30:37 --> URI Class Initialized
INFO - 2019-05-29 15:30:37 --> Router Class Initialized
INFO - 2019-05-29 15:30:37 --> Output Class Initialized
INFO - 2019-05-29 15:30:37 --> Security Class Initialized
DEBUG - 2019-05-29 15:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 15:30:37 --> Input Class Initialized
INFO - 2019-05-29 15:30:37 --> Language Class Initialized
INFO - 2019-05-29 15:30:37 --> Language Class Initialized
INFO - 2019-05-29 15:30:37 --> Config Class Initialized
INFO - 2019-05-29 15:30:37 --> Loader Class Initialized
INFO - 2019-05-29 15:30:37 --> Helper loaded: form_helper
INFO - 2019-05-29 15:30:37 --> Helper loaded: url_helper
INFO - 2019-05-29 15:30:37 --> Helper loaded: cookie_helper
INFO - 2019-05-29 15:30:37 --> Database Driver Class Initialized
DEBUG - 2019-05-29 15:30:37 --> Template library initialized
INFO - 2019-05-29 15:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-29 15:30:37 --> Controller Class Initialized
DEBUG - 2019-05-29 15:30:37 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-29 15:30:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-29 15:30:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/mobile.php
DEBUG - 2019-05-29 15:30:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-29 15:30:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-29 15:30:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-29 15:30:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-29 15:30:37 --> Config Class Initialized
INFO - 2019-05-29 15:30:37 --> Hooks Class Initialized
INFO - 2019-05-29 15:30:37 --> Config Class Initialized
INFO - 2019-05-29 15:30:37 --> Hooks Class Initialized
INFO - 2019-05-29 15:30:37 --> Config Class Initialized
INFO - 2019-05-29 15:30:37 --> Hooks Class Initialized
INFO - 2019-05-29 15:30:37 --> Final output sent to browser
DEBUG - 2019-05-29 15:30:37 --> Total execution time: 0.0454
DEBUG - 2019-05-29 15:30:37 --> UTF-8 Support Enabled
INFO - 2019-05-29 15:30:37 --> Utf8 Class Initialized
INFO - 2019-05-29 15:30:37 --> URI Class Initialized
INFO - 2019-05-29 15:30:37 --> Router Class Initialized
INFO - 2019-05-29 15:30:37 --> Output Class Initialized
INFO - 2019-05-29 15:30:37 --> Security Class Initialized
DEBUG - 2019-05-29 15:30:37 --> UTF-8 Support Enabled
INFO - 2019-05-29 15:30:37 --> Utf8 Class Initialized
INFO - 2019-05-29 15:30:37 --> URI Class Initialized
INFO - 2019-05-29 15:30:37 --> Router Class Initialized
INFO - 2019-05-29 15:30:37 --> Output Class Initialized
INFO - 2019-05-29 15:30:37 --> Security Class Initialized
DEBUG - 2019-05-29 15:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 15:30:37 --> Input Class Initialized
INFO - 2019-05-29 15:30:37 --> Language Class Initialized
ERROR - 2019-05-29 15:30:37 --> 404 Page Not Found: /index
DEBUG - 2019-05-29 15:30:37 --> UTF-8 Support Enabled
INFO - 2019-05-29 15:30:37 --> Utf8 Class Initialized
INFO - 2019-05-29 15:30:37 --> URI Class Initialized
INFO - 2019-05-29 15:30:37 --> Router Class Initialized
INFO - 2019-05-29 15:30:37 --> Output Class Initialized
INFO - 2019-05-29 15:30:37 --> Security Class Initialized
DEBUG - 2019-05-29 15:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 15:30:37 --> Input Class Initialized
INFO - 2019-05-29 15:30:37 --> Language Class Initialized
ERROR - 2019-05-29 15:30:37 --> 404 Page Not Found: /index
DEBUG - 2019-05-29 15:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 15:30:37 --> Input Class Initialized
INFO - 2019-05-29 15:30:37 --> Language Class Initialized
ERROR - 2019-05-29 15:30:37 --> 404 Page Not Found: /index
INFO - 2019-05-29 15:30:42 --> Config Class Initialized
INFO - 2019-05-29 15:30:42 --> Hooks Class Initialized
DEBUG - 2019-05-29 15:30:42 --> UTF-8 Support Enabled
INFO - 2019-05-29 15:30:42 --> Utf8 Class Initialized
INFO - 2019-05-29 15:30:42 --> URI Class Initialized
INFO - 2019-05-29 15:30:42 --> Router Class Initialized
INFO - 2019-05-29 15:30:42 --> Output Class Initialized
INFO - 2019-05-29 15:30:42 --> Security Class Initialized
DEBUG - 2019-05-29 15:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 15:30:42 --> Input Class Initialized
INFO - 2019-05-29 15:30:42 --> Language Class Initialized
INFO - 2019-05-29 15:30:42 --> Language Class Initialized
INFO - 2019-05-29 15:30:42 --> Config Class Initialized
INFO - 2019-05-29 15:30:42 --> Loader Class Initialized
INFO - 2019-05-29 15:30:42 --> Helper loaded: form_helper
INFO - 2019-05-29 15:30:42 --> Helper loaded: url_helper
INFO - 2019-05-29 15:30:42 --> Helper loaded: cookie_helper
INFO - 2019-05-29 15:30:42 --> Database Driver Class Initialized
DEBUG - 2019-05-29 15:30:42 --> Template library initialized
INFO - 2019-05-29 15:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-29 15:30:42 --> Controller Class Initialized
DEBUG - 2019-05-29 15:30:42 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-29 15:30:42 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-29 15:30:42 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/electricity.php
DEBUG - 2019-05-29 15:30:42 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-29 15:30:42 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-29 15:30:42 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-29 15:30:42 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-29 15:30:42 --> Final output sent to browser
DEBUG - 2019-05-29 15:30:42 --> Total execution time: 0.0487
INFO - 2019-05-29 15:30:43 --> Config Class Initialized
INFO - 2019-05-29 15:30:43 --> Hooks Class Initialized
DEBUG - 2019-05-29 15:30:43 --> UTF-8 Support Enabled
INFO - 2019-05-29 15:30:43 --> Utf8 Class Initialized
INFO - 2019-05-29 15:30:43 --> URI Class Initialized
INFO - 2019-05-29 15:30:43 --> Router Class Initialized
INFO - 2019-05-29 15:30:43 --> Output Class Initialized
INFO - 2019-05-29 15:30:43 --> Security Class Initialized
DEBUG - 2019-05-29 15:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 15:30:43 --> Input Class Initialized
INFO - 2019-05-29 15:30:43 --> Language Class Initialized
ERROR - 2019-05-29 15:30:43 --> 404 Page Not Found: /index
INFO - 2019-05-29 15:30:43 --> Config Class Initialized
INFO - 2019-05-29 15:30:43 --> Hooks Class Initialized
DEBUG - 2019-05-29 15:30:43 --> UTF-8 Support Enabled
INFO - 2019-05-29 15:30:43 --> Utf8 Class Initialized
INFO - 2019-05-29 15:30:43 --> URI Class Initialized
INFO - 2019-05-29 15:30:43 --> Router Class Initialized
INFO - 2019-05-29 15:30:43 --> Output Class Initialized
INFO - 2019-05-29 15:30:43 --> Security Class Initialized
DEBUG - 2019-05-29 15:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 15:30:43 --> Input Class Initialized
INFO - 2019-05-29 15:30:43 --> Language Class Initialized
ERROR - 2019-05-29 15:30:43 --> 404 Page Not Found: /index
INFO - 2019-05-29 15:30:43 --> Config Class Initialized
INFO - 2019-05-29 15:30:43 --> Hooks Class Initialized
DEBUG - 2019-05-29 15:30:43 --> UTF-8 Support Enabled
INFO - 2019-05-29 15:30:43 --> Utf8 Class Initialized
INFO - 2019-05-29 15:30:43 --> URI Class Initialized
INFO - 2019-05-29 15:30:43 --> Router Class Initialized
INFO - 2019-05-29 15:30:43 --> Output Class Initialized
INFO - 2019-05-29 15:30:43 --> Security Class Initialized
DEBUG - 2019-05-29 15:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 15:30:43 --> Input Class Initialized
INFO - 2019-05-29 15:30:43 --> Language Class Initialized
ERROR - 2019-05-29 15:30:43 --> 404 Page Not Found: /index
INFO - 2019-05-29 15:30:51 --> Config Class Initialized
INFO - 2019-05-29 15:30:51 --> Hooks Class Initialized
DEBUG - 2019-05-29 15:30:51 --> UTF-8 Support Enabled
INFO - 2019-05-29 15:30:51 --> Utf8 Class Initialized
INFO - 2019-05-29 15:30:51 --> URI Class Initialized
INFO - 2019-05-29 15:30:51 --> Router Class Initialized
INFO - 2019-05-29 15:30:51 --> Output Class Initialized
INFO - 2019-05-29 15:30:51 --> Security Class Initialized
DEBUG - 2019-05-29 15:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 15:30:51 --> Input Class Initialized
INFO - 2019-05-29 15:30:51 --> Language Class Initialized
INFO - 2019-05-29 15:30:51 --> Language Class Initialized
INFO - 2019-05-29 15:30:51 --> Config Class Initialized
INFO - 2019-05-29 15:30:51 --> Loader Class Initialized
INFO - 2019-05-29 15:30:51 --> Helper loaded: form_helper
INFO - 2019-05-29 15:30:51 --> Helper loaded: url_helper
INFO - 2019-05-29 15:30:51 --> Helper loaded: cookie_helper
INFO - 2019-05-29 15:30:51 --> Database Driver Class Initialized
DEBUG - 2019-05-29 15:30:51 --> Template library initialized
INFO - 2019-05-29 15:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-29 15:30:51 --> Controller Class Initialized
DEBUG - 2019-05-29 15:30:51 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-29 15:30:51 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-29 15:30:51 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/dth.php
DEBUG - 2019-05-29 15:30:51 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-29 15:30:51 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-29 15:30:51 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-29 15:30:51 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-29 15:30:51 --> Final output sent to browser
DEBUG - 2019-05-29 15:30:51 --> Total execution time: 0.0474
INFO - 2019-05-29 15:30:51 --> Config Class Initialized
INFO - 2019-05-29 15:30:51 --> Hooks Class Initialized
DEBUG - 2019-05-29 15:30:51 --> UTF-8 Support Enabled
INFO - 2019-05-29 15:30:51 --> Utf8 Class Initialized
INFO - 2019-05-29 15:30:51 --> URI Class Initialized
INFO - 2019-05-29 15:30:51 --> Router Class Initialized
INFO - 2019-05-29 15:30:51 --> Output Class Initialized
INFO - 2019-05-29 15:30:52 --> Security Class Initialized
DEBUG - 2019-05-29 15:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 15:30:52 --> Input Class Initialized
INFO - 2019-05-29 15:30:52 --> Language Class Initialized
ERROR - 2019-05-29 15:30:52 --> 404 Page Not Found: /index
INFO - 2019-05-29 15:30:52 --> Config Class Initialized
INFO - 2019-05-29 15:30:52 --> Hooks Class Initialized
DEBUG - 2019-05-29 15:30:52 --> UTF-8 Support Enabled
INFO - 2019-05-29 15:30:52 --> Utf8 Class Initialized
INFO - 2019-05-29 15:30:52 --> URI Class Initialized
INFO - 2019-05-29 15:30:52 --> Router Class Initialized
INFO - 2019-05-29 15:30:52 --> Output Class Initialized
INFO - 2019-05-29 15:30:52 --> Security Class Initialized
DEBUG - 2019-05-29 15:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 15:30:52 --> Input Class Initialized
INFO - 2019-05-29 15:30:52 --> Language Class Initialized
ERROR - 2019-05-29 15:30:52 --> 404 Page Not Found: /index
INFO - 2019-05-29 15:30:52 --> Config Class Initialized
INFO - 2019-05-29 15:30:52 --> Hooks Class Initialized
DEBUG - 2019-05-29 15:30:52 --> UTF-8 Support Enabled
INFO - 2019-05-29 15:30:52 --> Utf8 Class Initialized
INFO - 2019-05-29 15:30:52 --> URI Class Initialized
INFO - 2019-05-29 15:30:52 --> Router Class Initialized
INFO - 2019-05-29 15:30:52 --> Output Class Initialized
INFO - 2019-05-29 15:30:52 --> Security Class Initialized
DEBUG - 2019-05-29 15:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 15:30:52 --> Input Class Initialized
INFO - 2019-05-29 15:30:52 --> Language Class Initialized
ERROR - 2019-05-29 15:30:52 --> 404 Page Not Found: /index
INFO - 2019-05-29 15:30:55 --> Config Class Initialized
INFO - 2019-05-29 15:30:55 --> Hooks Class Initialized
DEBUG - 2019-05-29 15:30:55 --> UTF-8 Support Enabled
INFO - 2019-05-29 15:30:55 --> Utf8 Class Initialized
INFO - 2019-05-29 15:30:55 --> URI Class Initialized
INFO - 2019-05-29 15:30:55 --> Router Class Initialized
INFO - 2019-05-29 15:30:55 --> Output Class Initialized
INFO - 2019-05-29 15:30:55 --> Security Class Initialized
DEBUG - 2019-05-29 15:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 15:30:55 --> Input Class Initialized
INFO - 2019-05-29 15:30:55 --> Language Class Initialized
INFO - 2019-05-29 15:30:55 --> Language Class Initialized
INFO - 2019-05-29 15:30:55 --> Config Class Initialized
INFO - 2019-05-29 15:30:55 --> Loader Class Initialized
INFO - 2019-05-29 15:30:55 --> Helper loaded: form_helper
INFO - 2019-05-29 15:30:55 --> Helper loaded: url_helper
INFO - 2019-05-29 15:30:55 --> Helper loaded: cookie_helper
INFO - 2019-05-29 15:30:55 --> Database Driver Class Initialized
DEBUG - 2019-05-29 15:30:55 --> Template library initialized
INFO - 2019-05-29 15:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-29 15:30:55 --> Controller Class Initialized
DEBUG - 2019-05-29 15:30:55 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-29 15:30:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-29 15:30:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/broadband.php
DEBUG - 2019-05-29 15:30:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-29 15:30:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-29 15:30:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-29 15:30:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-29 15:30:56 --> Final output sent to browser
DEBUG - 2019-05-29 15:30:56 --> Total execution time: 0.0470
INFO - 2019-05-29 15:30:56 --> Config Class Initialized
INFO - 2019-05-29 15:30:56 --> Hooks Class Initialized
DEBUG - 2019-05-29 15:30:56 --> UTF-8 Support Enabled
INFO - 2019-05-29 15:30:56 --> Utf8 Class Initialized
INFO - 2019-05-29 15:30:56 --> URI Class Initialized
INFO - 2019-05-29 15:30:56 --> Router Class Initialized
INFO - 2019-05-29 15:30:56 --> Output Class Initialized
INFO - 2019-05-29 15:30:56 --> Security Class Initialized
DEBUG - 2019-05-29 15:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 15:30:56 --> Input Class Initialized
INFO - 2019-05-29 15:30:56 --> Language Class Initialized
ERROR - 2019-05-29 15:30:56 --> 404 Page Not Found: /index
INFO - 2019-05-29 15:30:56 --> Config Class Initialized
INFO - 2019-05-29 15:30:56 --> Hooks Class Initialized
DEBUG - 2019-05-29 15:30:56 --> UTF-8 Support Enabled
INFO - 2019-05-29 15:30:56 --> Utf8 Class Initialized
INFO - 2019-05-29 15:30:56 --> URI Class Initialized
INFO - 2019-05-29 15:30:56 --> Router Class Initialized
INFO - 2019-05-29 15:30:56 --> Output Class Initialized
INFO - 2019-05-29 15:30:56 --> Security Class Initialized
DEBUG - 2019-05-29 15:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 15:30:56 --> Input Class Initialized
INFO - 2019-05-29 15:30:56 --> Language Class Initialized
ERROR - 2019-05-29 15:30:56 --> 404 Page Not Found: /index
INFO - 2019-05-29 15:30:56 --> Config Class Initialized
INFO - 2019-05-29 15:30:56 --> Hooks Class Initialized
DEBUG - 2019-05-29 15:30:56 --> UTF-8 Support Enabled
INFO - 2019-05-29 15:30:56 --> Utf8 Class Initialized
INFO - 2019-05-29 15:30:56 --> URI Class Initialized
INFO - 2019-05-29 15:30:56 --> Router Class Initialized
INFO - 2019-05-29 15:30:56 --> Output Class Initialized
INFO - 2019-05-29 15:30:56 --> Security Class Initialized
DEBUG - 2019-05-29 15:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-29 15:30:56 --> Input Class Initialized
INFO - 2019-05-29 15:30:56 --> Language Class Initialized
ERROR - 2019-05-29 15:30:56 --> 404 Page Not Found: /index
