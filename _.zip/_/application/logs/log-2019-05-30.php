<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-05-30 06:55:41 --> Config Class Initialized
INFO - 2019-05-30 06:55:41 --> Hooks Class Initialized
DEBUG - 2019-05-30 06:55:41 --> UTF-8 Support Enabled
INFO - 2019-05-30 06:55:41 --> Utf8 Class Initialized
INFO - 2019-05-30 06:55:41 --> URI Class Initialized
INFO - 2019-05-30 06:55:41 --> Router Class Initialized
INFO - 2019-05-30 06:55:41 --> Output Class Initialized
INFO - 2019-05-30 06:55:41 --> Security Class Initialized
DEBUG - 2019-05-30 06:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 06:55:41 --> Input Class Initialized
INFO - 2019-05-30 06:55:41 --> Language Class Initialized
INFO - 2019-05-30 06:55:41 --> Language Class Initialized
INFO - 2019-05-30 06:55:41 --> Config Class Initialized
INFO - 2019-05-30 06:55:41 --> Loader Class Initialized
INFO - 2019-05-30 06:55:41 --> Helper loaded: form_helper
INFO - 2019-05-30 06:55:41 --> Helper loaded: url_helper
INFO - 2019-05-30 06:55:41 --> Helper loaded: cookie_helper
INFO - 2019-05-30 06:55:41 --> Database Driver Class Initialized
DEBUG - 2019-05-30 06:55:41 --> Template library initialized
INFO - 2019-05-30 06:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-30 06:55:41 --> Controller Class Initialized
DEBUG - 2019-05-30 06:55:41 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-30 06:55:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-30 06:55:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/broadband.php
DEBUG - 2019-05-30 06:55:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-30 06:55:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-30 06:55:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-30 06:55:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-30 06:55:41 --> Final output sent to browser
DEBUG - 2019-05-30 06:55:41 --> Total execution time: 0.0490
INFO - 2019-05-30 06:55:47 --> Config Class Initialized
INFO - 2019-05-30 06:55:47 --> Hooks Class Initialized
DEBUG - 2019-05-30 06:55:47 --> UTF-8 Support Enabled
INFO - 2019-05-30 06:55:47 --> Utf8 Class Initialized
INFO - 2019-05-30 06:55:47 --> URI Class Initialized
INFO - 2019-05-30 06:55:47 --> Router Class Initialized
INFO - 2019-05-30 06:55:47 --> Output Class Initialized
INFO - 2019-05-30 06:55:47 --> Security Class Initialized
DEBUG - 2019-05-30 06:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 06:55:47 --> Input Class Initialized
INFO - 2019-05-30 06:55:47 --> Language Class Initialized
ERROR - 2019-05-30 06:55:47 --> 404 Page Not Found: /index
INFO - 2019-05-30 06:55:48 --> Config Class Initialized
INFO - 2019-05-30 06:55:48 --> Hooks Class Initialized
DEBUG - 2019-05-30 06:55:48 --> UTF-8 Support Enabled
INFO - 2019-05-30 06:55:48 --> Utf8 Class Initialized
INFO - 2019-05-30 06:55:48 --> URI Class Initialized
DEBUG - 2019-05-30 06:55:48 --> No URI present. Default controller set.
INFO - 2019-05-30 06:55:48 --> Router Class Initialized
INFO - 2019-05-30 06:55:48 --> Output Class Initialized
INFO - 2019-05-30 06:55:48 --> Security Class Initialized
DEBUG - 2019-05-30 06:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 06:55:48 --> Input Class Initialized
INFO - 2019-05-30 06:55:48 --> Language Class Initialized
INFO - 2019-05-30 06:55:48 --> Language Class Initialized
INFO - 2019-05-30 06:55:48 --> Config Class Initialized
INFO - 2019-05-30 06:55:48 --> Loader Class Initialized
INFO - 2019-05-30 06:55:48 --> Helper loaded: form_helper
INFO - 2019-05-30 06:55:48 --> Helper loaded: url_helper
INFO - 2019-05-30 06:55:48 --> Helper loaded: cookie_helper
INFO - 2019-05-30 06:55:48 --> Database Driver Class Initialized
DEBUG - 2019-05-30 06:55:48 --> Template library initialized
INFO - 2019-05-30 06:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-30 06:55:48 --> Controller Class Initialized
DEBUG - 2019-05-30 06:55:48 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-30 06:55:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-30 06:55:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-30 06:55:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-30 06:55:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-30 06:55:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-30 06:55:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-30 06:55:48 --> Final output sent to browser
DEBUG - 2019-05-30 06:55:48 --> Total execution time: 0.0709
INFO - 2019-05-30 06:55:49 --> Config Class Initialized
INFO - 2019-05-30 06:55:49 --> Hooks Class Initialized
DEBUG - 2019-05-30 06:55:49 --> UTF-8 Support Enabled
INFO - 2019-05-30 06:55:49 --> Utf8 Class Initialized
INFO - 2019-05-30 06:55:49 --> URI Class Initialized
INFO - 2019-05-30 06:55:49 --> Router Class Initialized
INFO - 2019-05-30 06:55:49 --> Output Class Initialized
INFO - 2019-05-30 06:55:49 --> Security Class Initialized
DEBUG - 2019-05-30 06:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 06:55:49 --> Input Class Initialized
INFO - 2019-05-30 06:55:49 --> Language Class Initialized
ERROR - 2019-05-30 06:55:49 --> 404 Page Not Found: /index
INFO - 2019-05-30 06:55:49 --> Config Class Initialized
INFO - 2019-05-30 06:55:49 --> Hooks Class Initialized
DEBUG - 2019-05-30 06:55:49 --> UTF-8 Support Enabled
INFO - 2019-05-30 06:55:49 --> Utf8 Class Initialized
INFO - 2019-05-30 06:55:49 --> URI Class Initialized
INFO - 2019-05-30 06:55:49 --> Router Class Initialized
INFO - 2019-05-30 06:55:49 --> Output Class Initialized
INFO - 2019-05-30 06:55:49 --> Security Class Initialized
DEBUG - 2019-05-30 06:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 06:55:49 --> Input Class Initialized
INFO - 2019-05-30 06:55:49 --> Language Class Initialized
ERROR - 2019-05-30 06:55:49 --> 404 Page Not Found: /index
INFO - 2019-05-30 06:55:49 --> Config Class Initialized
INFO - 2019-05-30 06:55:49 --> Hooks Class Initialized
DEBUG - 2019-05-30 06:55:49 --> UTF-8 Support Enabled
INFO - 2019-05-30 06:55:49 --> Utf8 Class Initialized
INFO - 2019-05-30 06:55:49 --> URI Class Initialized
INFO - 2019-05-30 06:55:49 --> Router Class Initialized
INFO - 2019-05-30 06:55:49 --> Output Class Initialized
INFO - 2019-05-30 06:55:49 --> Security Class Initialized
DEBUG - 2019-05-30 06:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 06:55:49 --> Input Class Initialized
INFO - 2019-05-30 06:55:49 --> Language Class Initialized
ERROR - 2019-05-30 06:55:49 --> 404 Page Not Found: /index
INFO - 2019-05-30 08:26:03 --> Config Class Initialized
INFO - 2019-05-30 08:26:03 --> Hooks Class Initialized
DEBUG - 2019-05-30 08:26:03 --> UTF-8 Support Enabled
INFO - 2019-05-30 08:26:03 --> Utf8 Class Initialized
INFO - 2019-05-30 08:26:03 --> URI Class Initialized
DEBUG - 2019-05-30 08:26:03 --> No URI present. Default controller set.
INFO - 2019-05-30 08:26:03 --> Router Class Initialized
INFO - 2019-05-30 08:26:03 --> Output Class Initialized
INFO - 2019-05-30 08:26:03 --> Security Class Initialized
DEBUG - 2019-05-30 08:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 08:26:03 --> Input Class Initialized
INFO - 2019-05-30 08:26:03 --> Language Class Initialized
INFO - 2019-05-30 08:26:03 --> Language Class Initialized
INFO - 2019-05-30 08:26:03 --> Config Class Initialized
INFO - 2019-05-30 08:26:03 --> Loader Class Initialized
INFO - 2019-05-30 08:26:03 --> Helper loaded: form_helper
INFO - 2019-05-30 08:26:03 --> Helper loaded: url_helper
INFO - 2019-05-30 08:26:03 --> Helper loaded: cookie_helper
INFO - 2019-05-30 08:26:03 --> Database Driver Class Initialized
DEBUG - 2019-05-30 08:26:03 --> Template library initialized
INFO - 2019-05-30 08:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-30 08:26:03 --> Controller Class Initialized
DEBUG - 2019-05-30 08:26:03 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-30 08:26:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-30 08:26:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-30 08:26:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-30 08:26:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-30 08:26:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-30 08:26:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-30 08:26:03 --> Final output sent to browser
DEBUG - 2019-05-30 08:26:03 --> Total execution time: 0.0498
INFO - 2019-05-30 09:20:56 --> Config Class Initialized
INFO - 2019-05-30 09:20:56 --> Hooks Class Initialized
DEBUG - 2019-05-30 09:20:56 --> UTF-8 Support Enabled
INFO - 2019-05-30 09:20:56 --> Utf8 Class Initialized
INFO - 2019-05-30 09:20:56 --> URI Class Initialized
DEBUG - 2019-05-30 09:20:56 --> No URI present. Default controller set.
INFO - 2019-05-30 09:20:56 --> Router Class Initialized
INFO - 2019-05-30 09:20:56 --> Output Class Initialized
INFO - 2019-05-30 09:20:56 --> Security Class Initialized
DEBUG - 2019-05-30 09:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 09:20:56 --> Input Class Initialized
INFO - 2019-05-30 09:20:56 --> Language Class Initialized
INFO - 2019-05-30 09:20:56 --> Language Class Initialized
INFO - 2019-05-30 09:20:56 --> Config Class Initialized
INFO - 2019-05-30 09:20:56 --> Loader Class Initialized
INFO - 2019-05-30 09:20:56 --> Helper loaded: form_helper
INFO - 2019-05-30 09:20:56 --> Helper loaded: url_helper
INFO - 2019-05-30 09:20:56 --> Helper loaded: cookie_helper
INFO - 2019-05-30 09:20:56 --> Database Driver Class Initialized
DEBUG - 2019-05-30 09:20:56 --> Template library initialized
INFO - 2019-05-30 09:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-30 09:20:56 --> Controller Class Initialized
DEBUG - 2019-05-30 09:20:56 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-30 09:20:56 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-30 09:20:56 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-30 09:20:56 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-30 09:20:56 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-30 09:20:56 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-30 09:20:56 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-30 09:20:57 --> Final output sent to browser
DEBUG - 2019-05-30 09:20:57 --> Total execution time: 0.0501
INFO - 2019-05-30 09:21:03 --> Config Class Initialized
INFO - 2019-05-30 09:21:03 --> Hooks Class Initialized
DEBUG - 2019-05-30 09:21:03 --> UTF-8 Support Enabled
INFO - 2019-05-30 09:21:03 --> Utf8 Class Initialized
INFO - 2019-05-30 09:21:03 --> URI Class Initialized
INFO - 2019-05-30 09:21:03 --> Router Class Initialized
INFO - 2019-05-30 09:21:03 --> Output Class Initialized
INFO - 2019-05-30 09:21:03 --> Security Class Initialized
DEBUG - 2019-05-30 09:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 09:21:03 --> Input Class Initialized
INFO - 2019-05-30 09:21:03 --> Language Class Initialized
ERROR - 2019-05-30 09:21:03 --> 404 Page Not Found: /index
INFO - 2019-05-30 09:21:03 --> Config Class Initialized
INFO - 2019-05-30 09:21:03 --> Hooks Class Initialized
DEBUG - 2019-05-30 09:21:03 --> UTF-8 Support Enabled
INFO - 2019-05-30 09:21:03 --> Utf8 Class Initialized
INFO - 2019-05-30 09:21:03 --> URI Class Initialized
INFO - 2019-05-30 09:21:03 --> Router Class Initialized
INFO - 2019-05-30 09:21:03 --> Output Class Initialized
INFO - 2019-05-30 09:21:03 --> Security Class Initialized
DEBUG - 2019-05-30 09:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 09:21:03 --> Input Class Initialized
INFO - 2019-05-30 09:21:03 --> Language Class Initialized
ERROR - 2019-05-30 09:21:03 --> 404 Page Not Found: /index
INFO - 2019-05-30 09:21:04 --> Config Class Initialized
INFO - 2019-05-30 09:21:04 --> Hooks Class Initialized
DEBUG - 2019-05-30 09:21:04 --> UTF-8 Support Enabled
INFO - 2019-05-30 09:21:04 --> Utf8 Class Initialized
INFO - 2019-05-30 09:21:04 --> URI Class Initialized
INFO - 2019-05-30 09:21:04 --> Router Class Initialized
INFO - 2019-05-30 09:21:04 --> Output Class Initialized
INFO - 2019-05-30 09:21:04 --> Security Class Initialized
DEBUG - 2019-05-30 09:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 09:21:04 --> Input Class Initialized
INFO - 2019-05-30 09:21:04 --> Language Class Initialized
ERROR - 2019-05-30 09:21:04 --> 404 Page Not Found: /index
INFO - 2019-05-30 09:21:04 --> Config Class Initialized
INFO - 2019-05-30 09:21:04 --> Hooks Class Initialized
DEBUG - 2019-05-30 09:21:04 --> UTF-8 Support Enabled
INFO - 2019-05-30 09:21:04 --> Utf8 Class Initialized
INFO - 2019-05-30 09:21:04 --> URI Class Initialized
INFO - 2019-05-30 09:21:04 --> Router Class Initialized
INFO - 2019-05-30 09:21:04 --> Output Class Initialized
INFO - 2019-05-30 09:21:04 --> Security Class Initialized
DEBUG - 2019-05-30 09:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 09:21:04 --> Input Class Initialized
INFO - 2019-05-30 09:21:04 --> Language Class Initialized
ERROR - 2019-05-30 09:21:04 --> 404 Page Not Found: /index
INFO - 2019-05-30 13:06:24 --> Config Class Initialized
INFO - 2019-05-30 13:06:24 --> Hooks Class Initialized
DEBUG - 2019-05-30 13:06:24 --> UTF-8 Support Enabled
INFO - 2019-05-30 13:06:24 --> Utf8 Class Initialized
INFO - 2019-05-30 13:06:24 --> URI Class Initialized
DEBUG - 2019-05-30 13:06:24 --> No URI present. Default controller set.
INFO - 2019-05-30 13:06:24 --> Router Class Initialized
INFO - 2019-05-30 13:06:24 --> Output Class Initialized
INFO - 2019-05-30 13:06:24 --> Security Class Initialized
DEBUG - 2019-05-30 13:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 13:06:24 --> Input Class Initialized
INFO - 2019-05-30 13:06:24 --> Language Class Initialized
INFO - 2019-05-30 13:06:24 --> Language Class Initialized
INFO - 2019-05-30 13:06:24 --> Config Class Initialized
INFO - 2019-05-30 13:06:24 --> Loader Class Initialized
INFO - 2019-05-30 13:06:24 --> Helper loaded: form_helper
INFO - 2019-05-30 13:06:24 --> Helper loaded: url_helper
INFO - 2019-05-30 13:06:24 --> Helper loaded: cookie_helper
INFO - 2019-05-30 13:06:24 --> Database Driver Class Initialized
DEBUG - 2019-05-30 13:06:24 --> Template library initialized
INFO - 2019-05-30 13:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-30 13:06:24 --> Controller Class Initialized
DEBUG - 2019-05-30 13:06:24 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-30 13:06:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-30 13:06:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-30 13:06:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-30 13:06:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-30 13:06:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-30 13:06:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-30 13:06:24 --> Final output sent to browser
DEBUG - 2019-05-30 13:06:24 --> Total execution time: 0.0522
INFO - 2019-05-30 13:06:24 --> Config Class Initialized
INFO - 2019-05-30 13:06:24 --> Hooks Class Initialized
DEBUG - 2019-05-30 13:06:24 --> UTF-8 Support Enabled
INFO - 2019-05-30 13:06:24 --> Utf8 Class Initialized
INFO - 2019-05-30 13:06:24 --> URI Class Initialized
INFO - 2019-05-30 13:06:24 --> Router Class Initialized
INFO - 2019-05-30 13:06:24 --> Output Class Initialized
INFO - 2019-05-30 13:06:24 --> Security Class Initialized
DEBUG - 2019-05-30 13:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 13:06:24 --> Input Class Initialized
INFO - 2019-05-30 13:06:24 --> Language Class Initialized
ERROR - 2019-05-30 13:06:24 --> 404 Page Not Found: /index
INFO - 2019-05-30 13:19:20 --> Config Class Initialized
INFO - 2019-05-30 13:19:20 --> Hooks Class Initialized
DEBUG - 2019-05-30 13:19:20 --> UTF-8 Support Enabled
INFO - 2019-05-30 13:19:20 --> Utf8 Class Initialized
INFO - 2019-05-30 13:19:20 --> URI Class Initialized
DEBUG - 2019-05-30 13:19:20 --> No URI present. Default controller set.
INFO - 2019-05-30 13:19:20 --> Router Class Initialized
INFO - 2019-05-30 13:19:20 --> Output Class Initialized
INFO - 2019-05-30 13:19:20 --> Security Class Initialized
DEBUG - 2019-05-30 13:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 13:19:20 --> Input Class Initialized
INFO - 2019-05-30 13:19:20 --> Language Class Initialized
INFO - 2019-05-30 13:19:20 --> Language Class Initialized
INFO - 2019-05-30 13:19:20 --> Config Class Initialized
INFO - 2019-05-30 13:19:20 --> Loader Class Initialized
INFO - 2019-05-30 13:19:20 --> Helper loaded: form_helper
INFO - 2019-05-30 13:19:20 --> Helper loaded: url_helper
INFO - 2019-05-30 13:19:20 --> Helper loaded: cookie_helper
INFO - 2019-05-30 13:19:20 --> Database Driver Class Initialized
DEBUG - 2019-05-30 13:19:20 --> Template library initialized
INFO - 2019-05-30 13:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-30 13:19:21 --> Controller Class Initialized
DEBUG - 2019-05-30 13:19:21 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-30 13:19:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-30 13:19:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-30 13:19:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-30 13:19:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-30 13:19:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-30 13:19:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-30 13:19:21 --> Final output sent to browser
DEBUG - 2019-05-30 13:19:21 --> Total execution time: 0.0535
INFO - 2019-05-30 14:18:44 --> Config Class Initialized
INFO - 2019-05-30 14:18:44 --> Hooks Class Initialized
DEBUG - 2019-05-30 14:18:44 --> UTF-8 Support Enabled
INFO - 2019-05-30 14:18:44 --> Utf8 Class Initialized
INFO - 2019-05-30 14:18:44 --> URI Class Initialized
INFO - 2019-05-30 14:18:44 --> Router Class Initialized
INFO - 2019-05-30 14:18:44 --> Output Class Initialized
INFO - 2019-05-30 14:18:44 --> Security Class Initialized
DEBUG - 2019-05-30 14:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 14:18:44 --> Input Class Initialized
INFO - 2019-05-30 14:18:44 --> Language Class Initialized
INFO - 2019-05-30 14:18:44 --> Language Class Initialized
INFO - 2019-05-30 14:18:44 --> Config Class Initialized
INFO - 2019-05-30 14:18:44 --> Loader Class Initialized
INFO - 2019-05-30 14:18:44 --> Helper loaded: form_helper
INFO - 2019-05-30 14:18:44 --> Helper loaded: url_helper
INFO - 2019-05-30 14:18:44 --> Helper loaded: cookie_helper
INFO - 2019-05-30 14:18:44 --> Database Driver Class Initialized
DEBUG - 2019-05-30 14:18:44 --> Template library initialized
INFO - 2019-05-30 14:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-30 14:18:44 --> Controller Class Initialized
DEBUG - 2019-05-30 14:18:44 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-30 14:18:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-30 14:18:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/dth.php
DEBUG - 2019-05-30 14:18:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-30 14:18:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-30 14:18:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-30 14:18:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-30 14:18:44 --> Final output sent to browser
DEBUG - 2019-05-30 14:18:44 --> Total execution time: 0.0489
INFO - 2019-05-30 14:18:45 --> Config Class Initialized
INFO - 2019-05-30 14:18:45 --> Hooks Class Initialized
DEBUG - 2019-05-30 14:18:45 --> UTF-8 Support Enabled
INFO - 2019-05-30 14:18:45 --> Utf8 Class Initialized
INFO - 2019-05-30 14:18:45 --> URI Class Initialized
INFO - 2019-05-30 14:18:45 --> Router Class Initialized
INFO - 2019-05-30 14:18:45 --> Output Class Initialized
INFO - 2019-05-30 14:18:45 --> Security Class Initialized
DEBUG - 2019-05-30 14:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 14:18:45 --> Input Class Initialized
INFO - 2019-05-30 14:18:45 --> Language Class Initialized
INFO - 2019-05-30 14:18:45 --> Language Class Initialized
INFO - 2019-05-30 14:18:45 --> Config Class Initialized
INFO - 2019-05-30 14:18:45 --> Loader Class Initialized
INFO - 2019-05-30 14:18:45 --> Helper loaded: form_helper
INFO - 2019-05-30 14:18:45 --> Helper loaded: url_helper
INFO - 2019-05-30 14:18:45 --> Helper loaded: cookie_helper
INFO - 2019-05-30 14:18:45 --> Database Driver Class Initialized
DEBUG - 2019-05-30 14:18:45 --> Template library initialized
INFO - 2019-05-30 14:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-30 14:18:45 --> Controller Class Initialized
DEBUG - 2019-05-30 14:18:45 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-30 14:18:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-30 14:18:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/electricity.php
DEBUG - 2019-05-30 14:18:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-30 14:18:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-30 14:18:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-30 14:18:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-30 14:18:45 --> Final output sent to browser
DEBUG - 2019-05-30 14:18:45 --> Total execution time: 0.0481
INFO - 2019-05-30 14:18:50 --> Config Class Initialized
INFO - 2019-05-30 14:18:50 --> Hooks Class Initialized
DEBUG - 2019-05-30 14:18:50 --> UTF-8 Support Enabled
INFO - 2019-05-30 14:18:50 --> Utf8 Class Initialized
INFO - 2019-05-30 14:18:50 --> URI Class Initialized
INFO - 2019-05-30 14:18:50 --> Router Class Initialized
INFO - 2019-05-30 14:18:50 --> Output Class Initialized
INFO - 2019-05-30 14:18:50 --> Security Class Initialized
DEBUG - 2019-05-30 14:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 14:18:50 --> Input Class Initialized
INFO - 2019-05-30 14:18:50 --> Language Class Initialized
ERROR - 2019-05-30 14:18:50 --> 404 Page Not Found: /index
INFO - 2019-05-30 14:18:50 --> Config Class Initialized
INFO - 2019-05-30 14:18:50 --> Hooks Class Initialized
DEBUG - 2019-05-30 14:18:50 --> UTF-8 Support Enabled
INFO - 2019-05-30 14:18:50 --> Utf8 Class Initialized
INFO - 2019-05-30 14:18:50 --> URI Class Initialized
INFO - 2019-05-30 14:18:50 --> Router Class Initialized
INFO - 2019-05-30 14:18:50 --> Output Class Initialized
INFO - 2019-05-30 14:18:50 --> Security Class Initialized
DEBUG - 2019-05-30 14:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 14:18:50 --> Input Class Initialized
INFO - 2019-05-30 14:18:50 --> Language Class Initialized
ERROR - 2019-05-30 14:18:50 --> 404 Page Not Found: /index
INFO - 2019-05-30 14:18:51 --> Config Class Initialized
INFO - 2019-05-30 14:18:51 --> Hooks Class Initialized
DEBUG - 2019-05-30 14:18:51 --> UTF-8 Support Enabled
INFO - 2019-05-30 14:18:51 --> Utf8 Class Initialized
INFO - 2019-05-30 14:18:51 --> URI Class Initialized
INFO - 2019-05-30 14:18:51 --> Router Class Initialized
INFO - 2019-05-30 14:18:51 --> Output Class Initialized
INFO - 2019-05-30 14:18:51 --> Security Class Initialized
DEBUG - 2019-05-30 14:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 14:18:51 --> Input Class Initialized
INFO - 2019-05-30 14:18:51 --> Language Class Initialized
ERROR - 2019-05-30 14:18:51 --> 404 Page Not Found: /index
INFO - 2019-05-30 14:18:52 --> Config Class Initialized
INFO - 2019-05-30 14:18:52 --> Hooks Class Initialized
DEBUG - 2019-05-30 14:18:52 --> UTF-8 Support Enabled
INFO - 2019-05-30 14:18:52 --> Utf8 Class Initialized
INFO - 2019-05-30 14:18:52 --> URI Class Initialized
INFO - 2019-05-30 14:18:52 --> Router Class Initialized
INFO - 2019-05-30 14:18:52 --> Output Class Initialized
INFO - 2019-05-30 14:18:52 --> Security Class Initialized
DEBUG - 2019-05-30 14:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 14:18:52 --> Input Class Initialized
INFO - 2019-05-30 14:18:52 --> Language Class Initialized
ERROR - 2019-05-30 14:18:52 --> 404 Page Not Found: /index
INFO - 2019-05-30 14:18:52 --> Config Class Initialized
INFO - 2019-05-30 14:18:52 --> Hooks Class Initialized
DEBUG - 2019-05-30 14:18:52 --> UTF-8 Support Enabled
INFO - 2019-05-30 14:18:52 --> Utf8 Class Initialized
INFO - 2019-05-30 14:18:52 --> URI Class Initialized
INFO - 2019-05-30 14:18:52 --> Router Class Initialized
INFO - 2019-05-30 14:18:52 --> Output Class Initialized
INFO - 2019-05-30 14:18:52 --> Security Class Initialized
DEBUG - 2019-05-30 14:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 14:18:52 --> Input Class Initialized
INFO - 2019-05-30 14:18:52 --> Language Class Initialized
INFO - 2019-05-30 14:18:52 --> Language Class Initialized
INFO - 2019-05-30 14:18:52 --> Config Class Initialized
INFO - 2019-05-30 14:18:52 --> Loader Class Initialized
INFO - 2019-05-30 14:18:52 --> Helper loaded: form_helper
INFO - 2019-05-30 14:18:52 --> Helper loaded: url_helper
INFO - 2019-05-30 14:18:52 --> Helper loaded: cookie_helper
INFO - 2019-05-30 14:18:52 --> Database Driver Class Initialized
DEBUG - 2019-05-30 14:18:52 --> Template library initialized
INFO - 2019-05-30 14:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-30 14:18:52 --> Controller Class Initialized
DEBUG - 2019-05-30 14:18:52 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-30 14:18:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-30 14:18:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/dth.php
DEBUG - 2019-05-30 14:18:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-30 14:18:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-30 14:18:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-30 14:18:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-30 14:18:52 --> Final output sent to browser
DEBUG - 2019-05-30 14:18:52 --> Total execution time: 0.0655
INFO - 2019-05-30 14:18:53 --> Config Class Initialized
INFO - 2019-05-30 14:18:53 --> Hooks Class Initialized
DEBUG - 2019-05-30 14:18:53 --> UTF-8 Support Enabled
INFO - 2019-05-30 14:18:53 --> Utf8 Class Initialized
INFO - 2019-05-30 14:18:53 --> URI Class Initialized
INFO - 2019-05-30 14:18:53 --> Config Class Initialized
INFO - 2019-05-30 14:18:53 --> Hooks Class Initialized
DEBUG - 2019-05-30 14:18:53 --> UTF-8 Support Enabled
INFO - 2019-05-30 14:18:53 --> Utf8 Class Initialized
INFO - 2019-05-30 14:18:53 --> URI Class Initialized
INFO - 2019-05-30 14:18:53 --> Config Class Initialized
INFO - 2019-05-30 14:18:53 --> Hooks Class Initialized
DEBUG - 2019-05-30 14:18:53 --> UTF-8 Support Enabled
INFO - 2019-05-30 14:18:53 --> Utf8 Class Initialized
INFO - 2019-05-30 14:18:53 --> URI Class Initialized
INFO - 2019-05-30 14:18:53 --> Router Class Initialized
INFO - 2019-05-30 14:18:53 --> Output Class Initialized
INFO - 2019-05-30 14:18:53 --> Security Class Initialized
DEBUG - 2019-05-30 14:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 14:18:53 --> Input Class Initialized
INFO - 2019-05-30 14:18:53 --> Language Class Initialized
ERROR - 2019-05-30 14:18:53 --> 404 Page Not Found: /index
INFO - 2019-05-30 14:18:53 --> Router Class Initialized
INFO - 2019-05-30 14:18:53 --> Output Class Initialized
INFO - 2019-05-30 14:18:53 --> Security Class Initialized
DEBUG - 2019-05-30 14:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 14:18:53 --> Input Class Initialized
INFO - 2019-05-30 14:18:53 --> Language Class Initialized
ERROR - 2019-05-30 14:18:53 --> 404 Page Not Found: /index
INFO - 2019-05-30 14:18:53 --> Router Class Initialized
INFO - 2019-05-30 14:18:53 --> Output Class Initialized
INFO - 2019-05-30 14:18:53 --> Security Class Initialized
DEBUG - 2019-05-30 14:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 14:18:53 --> Input Class Initialized
INFO - 2019-05-30 14:18:53 --> Language Class Initialized
ERROR - 2019-05-30 14:18:53 --> 404 Page Not Found: /index
INFO - 2019-05-30 14:18:54 --> Config Class Initialized
INFO - 2019-05-30 14:18:54 --> Hooks Class Initialized
DEBUG - 2019-05-30 14:18:54 --> UTF-8 Support Enabled
INFO - 2019-05-30 14:18:54 --> Utf8 Class Initialized
INFO - 2019-05-30 14:18:54 --> URI Class Initialized
INFO - 2019-05-30 14:18:54 --> Router Class Initialized
INFO - 2019-05-30 14:18:54 --> Output Class Initialized
INFO - 2019-05-30 14:18:54 --> Security Class Initialized
DEBUG - 2019-05-30 14:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 14:18:54 --> Input Class Initialized
INFO - 2019-05-30 14:18:54 --> Language Class Initialized
ERROR - 2019-05-30 14:18:54 --> 404 Page Not Found: /index
INFO - 2019-05-30 14:19:03 --> Config Class Initialized
INFO - 2019-05-30 14:19:03 --> Hooks Class Initialized
DEBUG - 2019-05-30 14:19:03 --> UTF-8 Support Enabled
INFO - 2019-05-30 14:19:03 --> Utf8 Class Initialized
INFO - 2019-05-30 14:19:03 --> URI Class Initialized
INFO - 2019-05-30 14:19:03 --> Router Class Initialized
INFO - 2019-05-30 14:19:03 --> Output Class Initialized
INFO - 2019-05-30 14:19:03 --> Security Class Initialized
DEBUG - 2019-05-30 14:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 14:19:03 --> Input Class Initialized
INFO - 2019-05-30 14:19:03 --> Language Class Initialized
INFO - 2019-05-30 14:19:03 --> Language Class Initialized
INFO - 2019-05-30 14:19:03 --> Config Class Initialized
INFO - 2019-05-30 14:19:03 --> Loader Class Initialized
INFO - 2019-05-30 14:19:03 --> Helper loaded: form_helper
INFO - 2019-05-30 14:19:03 --> Helper loaded: url_helper
INFO - 2019-05-30 14:19:03 --> Helper loaded: cookie_helper
INFO - 2019-05-30 14:19:03 --> Database Driver Class Initialized
DEBUG - 2019-05-30 14:19:03 --> Template library initialized
INFO - 2019-05-30 14:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-30 14:19:03 --> Controller Class Initialized
DEBUG - 2019-05-30 14:19:03 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-30 14:19:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-30 14:19:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/insurance.php
DEBUG - 2019-05-30 14:19:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-30 14:19:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-30 14:19:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-30 14:19:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-30 14:19:04 --> Final output sent to browser
DEBUG - 2019-05-30 14:19:04 --> Total execution time: 0.0482
INFO - 2019-05-30 14:19:05 --> Config Class Initialized
INFO - 2019-05-30 14:19:05 --> Hooks Class Initialized
INFO - 2019-05-30 14:19:05 --> Config Class Initialized
INFO - 2019-05-30 14:19:05 --> Hooks Class Initialized
DEBUG - 2019-05-30 14:19:05 --> UTF-8 Support Enabled
INFO - 2019-05-30 14:19:05 --> Utf8 Class Initialized
INFO - 2019-05-30 14:19:05 --> URI Class Initialized
INFO - 2019-05-30 14:19:05 --> Router Class Initialized
INFO - 2019-05-30 14:19:05 --> Config Class Initialized
INFO - 2019-05-30 14:19:05 --> Hooks Class Initialized
DEBUG - 2019-05-30 14:19:05 --> UTF-8 Support Enabled
INFO - 2019-05-30 14:19:05 --> Utf8 Class Initialized
INFO - 2019-05-30 14:19:05 --> URI Class Initialized
DEBUG - 2019-05-30 14:19:05 --> UTF-8 Support Enabled
INFO - 2019-05-30 14:19:05 --> Utf8 Class Initialized
INFO - 2019-05-30 14:19:05 --> URI Class Initialized
INFO - 2019-05-30 14:19:05 --> Router Class Initialized
INFO - 2019-05-30 14:19:05 --> Output Class Initialized
INFO - 2019-05-30 14:19:05 --> Security Class Initialized
DEBUG - 2019-05-30 14:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 14:19:05 --> Input Class Initialized
INFO - 2019-05-30 14:19:05 --> Language Class Initialized
ERROR - 2019-05-30 14:19:05 --> 404 Page Not Found: /index
INFO - 2019-05-30 14:19:05 --> Output Class Initialized
INFO - 2019-05-30 14:19:05 --> Security Class Initialized
DEBUG - 2019-05-30 14:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 14:19:05 --> Input Class Initialized
INFO - 2019-05-30 14:19:05 --> Language Class Initialized
ERROR - 2019-05-30 14:19:05 --> 404 Page Not Found: /index
INFO - 2019-05-30 14:19:05 --> Router Class Initialized
INFO - 2019-05-30 14:19:05 --> Output Class Initialized
INFO - 2019-05-30 14:19:05 --> Security Class Initialized
DEBUG - 2019-05-30 14:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 14:19:05 --> Input Class Initialized
INFO - 2019-05-30 14:19:05 --> Language Class Initialized
ERROR - 2019-05-30 14:19:05 --> 404 Page Not Found: /index
INFO - 2019-05-30 14:19:06 --> Config Class Initialized
INFO - 2019-05-30 14:19:06 --> Hooks Class Initialized
DEBUG - 2019-05-30 14:19:06 --> UTF-8 Support Enabled
INFO - 2019-05-30 14:19:06 --> Utf8 Class Initialized
INFO - 2019-05-30 14:19:06 --> URI Class Initialized
INFO - 2019-05-30 14:19:06 --> Router Class Initialized
INFO - 2019-05-30 14:19:06 --> Output Class Initialized
INFO - 2019-05-30 14:19:06 --> Security Class Initialized
DEBUG - 2019-05-30 14:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 14:19:06 --> Input Class Initialized
INFO - 2019-05-30 14:19:06 --> Language Class Initialized
ERROR - 2019-05-30 14:19:06 --> 404 Page Not Found: /index
INFO - 2019-05-30 14:19:16 --> Config Class Initialized
INFO - 2019-05-30 14:19:16 --> Hooks Class Initialized
DEBUG - 2019-05-30 14:19:16 --> UTF-8 Support Enabled
INFO - 2019-05-30 14:19:16 --> Utf8 Class Initialized
INFO - 2019-05-30 14:19:16 --> URI Class Initialized
INFO - 2019-05-30 14:19:16 --> Router Class Initialized
INFO - 2019-05-30 14:19:16 --> Output Class Initialized
INFO - 2019-05-30 14:19:16 --> Security Class Initialized
DEBUG - 2019-05-30 14:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 14:19:16 --> Input Class Initialized
INFO - 2019-05-30 14:19:16 --> Language Class Initialized
INFO - 2019-05-30 14:19:16 --> Language Class Initialized
INFO - 2019-05-30 14:19:16 --> Config Class Initialized
INFO - 2019-05-30 14:19:16 --> Loader Class Initialized
INFO - 2019-05-30 14:19:16 --> Helper loaded: form_helper
INFO - 2019-05-30 14:19:16 --> Helper loaded: url_helper
INFO - 2019-05-30 14:19:16 --> Helper loaded: cookie_helper
INFO - 2019-05-30 14:19:16 --> Database Driver Class Initialized
DEBUG - 2019-05-30 14:19:16 --> Template library initialized
INFO - 2019-05-30 14:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-30 14:19:16 --> Controller Class Initialized
DEBUG - 2019-05-30 14:19:16 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-30 14:19:16 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-30 14:19:16 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/transport.php
DEBUG - 2019-05-30 14:19:16 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-30 14:19:16 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-30 14:19:16 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-30 14:19:16 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-30 14:19:17 --> Final output sent to browser
DEBUG - 2019-05-30 14:19:17 --> Total execution time: 0.0445
INFO - 2019-05-30 14:19:17 --> Config Class Initialized
INFO - 2019-05-30 14:19:17 --> Hooks Class Initialized
DEBUG - 2019-05-30 14:19:17 --> UTF-8 Support Enabled
INFO - 2019-05-30 14:19:17 --> Utf8 Class Initialized
INFO - 2019-05-30 14:19:17 --> URI Class Initialized
INFO - 2019-05-30 14:19:17 --> Router Class Initialized
INFO - 2019-05-30 14:19:17 --> Output Class Initialized
INFO - 2019-05-30 14:19:17 --> Security Class Initialized
DEBUG - 2019-05-30 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 14:19:17 --> Input Class Initialized
INFO - 2019-05-30 14:19:17 --> Language Class Initialized
ERROR - 2019-05-30 14:19:17 --> 404 Page Not Found: /index
INFO - 2019-05-30 14:19:17 --> Config Class Initialized
INFO - 2019-05-30 14:19:17 --> Hooks Class Initialized
DEBUG - 2019-05-30 14:19:17 --> UTF-8 Support Enabled
INFO - 2019-05-30 14:19:17 --> Utf8 Class Initialized
INFO - 2019-05-30 14:19:17 --> URI Class Initialized
INFO - 2019-05-30 14:19:17 --> Config Class Initialized
INFO - 2019-05-30 14:19:17 --> Hooks Class Initialized
DEBUG - 2019-05-30 14:19:17 --> UTF-8 Support Enabled
INFO - 2019-05-30 14:19:17 --> Utf8 Class Initialized
INFO - 2019-05-30 14:19:17 --> URI Class Initialized
INFO - 2019-05-30 14:19:17 --> Router Class Initialized
INFO - 2019-05-30 14:19:17 --> Output Class Initialized
INFO - 2019-05-30 14:19:17 --> Security Class Initialized
DEBUG - 2019-05-30 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 14:19:17 --> Input Class Initialized
INFO - 2019-05-30 14:19:17 --> Language Class Initialized
ERROR - 2019-05-30 14:19:17 --> 404 Page Not Found: /index
INFO - 2019-05-30 14:19:17 --> Router Class Initialized
INFO - 2019-05-30 14:19:17 --> Output Class Initialized
INFO - 2019-05-30 14:19:17 --> Security Class Initialized
DEBUG - 2019-05-30 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 14:19:17 --> Input Class Initialized
INFO - 2019-05-30 14:19:17 --> Language Class Initialized
ERROR - 2019-05-30 14:19:17 --> 404 Page Not Found: /index
INFO - 2019-05-30 14:19:18 --> Config Class Initialized
INFO - 2019-05-30 14:19:18 --> Hooks Class Initialized
DEBUG - 2019-05-30 14:19:18 --> UTF-8 Support Enabled
INFO - 2019-05-30 14:19:18 --> Utf8 Class Initialized
INFO - 2019-05-30 14:19:18 --> URI Class Initialized
INFO - 2019-05-30 14:19:18 --> Router Class Initialized
INFO - 2019-05-30 14:19:18 --> Output Class Initialized
INFO - 2019-05-30 14:19:18 --> Security Class Initialized
DEBUG - 2019-05-30 14:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-30 14:19:18 --> Input Class Initialized
INFO - 2019-05-30 14:19:18 --> Language Class Initialized
ERROR - 2019-05-30 14:19:18 --> 404 Page Not Found: /index
