<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-05-28 03:15:04 --> Config Class Initialized
INFO - 2019-05-28 03:15:04 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:15:04 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:15:04 --> Utf8 Class Initialized
INFO - 2019-05-28 03:15:04 --> URI Class Initialized
DEBUG - 2019-05-28 03:15:04 --> No URI present. Default controller set.
INFO - 2019-05-28 03:15:04 --> Router Class Initialized
INFO - 2019-05-28 03:15:04 --> Output Class Initialized
INFO - 2019-05-28 03:15:04 --> Security Class Initialized
DEBUG - 2019-05-28 03:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:15:04 --> Input Class Initialized
INFO - 2019-05-28 03:15:04 --> Language Class Initialized
INFO - 2019-05-28 03:15:04 --> Language Class Initialized
INFO - 2019-05-28 03:15:04 --> Config Class Initialized
INFO - 2019-05-28 03:15:04 --> Loader Class Initialized
INFO - 2019-05-28 03:15:04 --> Helper loaded: form_helper
INFO - 2019-05-28 03:15:04 --> Helper loaded: url_helper
INFO - 2019-05-28 03:15:04 --> Helper loaded: cookie_helper
INFO - 2019-05-28 03:15:04 --> Database Driver Class Initialized
DEBUG - 2019-05-28 03:15:04 --> Template library initialized
INFO - 2019-05-28 03:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 03:15:04 --> Controller Class Initialized
DEBUG - 2019-05-28 03:15:04 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 03:15:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 03:15:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 03:15:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 03:15:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 03:15:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 03:15:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 03:15:04 --> Final output sent to browser
DEBUG - 2019-05-28 03:15:04 --> Total execution time: 0.0456
INFO - 2019-05-28 03:15:09 --> Config Class Initialized
INFO - 2019-05-28 03:15:09 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:15:09 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:15:09 --> Utf8 Class Initialized
INFO - 2019-05-28 03:15:09 --> URI Class Initialized
INFO - 2019-05-28 03:15:09 --> Router Class Initialized
INFO - 2019-05-28 03:15:09 --> Output Class Initialized
INFO - 2019-05-28 03:15:09 --> Security Class Initialized
DEBUG - 2019-05-28 03:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:15:09 --> Input Class Initialized
INFO - 2019-05-28 03:15:09 --> Language Class Initialized
ERROR - 2019-05-28 03:15:09 --> 404 Page Not Found: /index
INFO - 2019-05-28 03:15:09 --> Config Class Initialized
INFO - 2019-05-28 03:15:09 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:15:09 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:15:09 --> Utf8 Class Initialized
INFO - 2019-05-28 03:15:09 --> URI Class Initialized
INFO - 2019-05-28 03:15:09 --> Router Class Initialized
INFO - 2019-05-28 03:15:09 --> Output Class Initialized
INFO - 2019-05-28 03:15:09 --> Security Class Initialized
DEBUG - 2019-05-28 03:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:15:09 --> Input Class Initialized
INFO - 2019-05-28 03:15:09 --> Language Class Initialized
ERROR - 2019-05-28 03:15:09 --> 404 Page Not Found: /index
INFO - 2019-05-28 03:15:10 --> Config Class Initialized
INFO - 2019-05-28 03:15:10 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:15:10 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:15:10 --> Utf8 Class Initialized
INFO - 2019-05-28 03:15:10 --> URI Class Initialized
INFO - 2019-05-28 03:15:10 --> Router Class Initialized
INFO - 2019-05-28 03:15:10 --> Output Class Initialized
INFO - 2019-05-28 03:15:10 --> Security Class Initialized
DEBUG - 2019-05-28 03:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:15:10 --> Input Class Initialized
INFO - 2019-05-28 03:15:10 --> Language Class Initialized
ERROR - 2019-05-28 03:15:10 --> 404 Page Not Found: /index
INFO - 2019-05-28 03:15:10 --> Config Class Initialized
INFO - 2019-05-28 03:15:10 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:15:10 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:15:10 --> Utf8 Class Initialized
INFO - 2019-05-28 03:15:10 --> URI Class Initialized
INFO - 2019-05-28 03:15:10 --> Router Class Initialized
INFO - 2019-05-28 03:15:10 --> Output Class Initialized
INFO - 2019-05-28 03:15:10 --> Security Class Initialized
DEBUG - 2019-05-28 03:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:15:10 --> Input Class Initialized
INFO - 2019-05-28 03:15:10 --> Language Class Initialized
ERROR - 2019-05-28 03:15:10 --> 404 Page Not Found: /index
INFO - 2019-05-28 03:15:19 --> Config Class Initialized
INFO - 2019-05-28 03:15:19 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:15:19 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:15:19 --> Utf8 Class Initialized
INFO - 2019-05-28 03:15:19 --> URI Class Initialized
INFO - 2019-05-28 03:15:19 --> Router Class Initialized
INFO - 2019-05-28 03:15:19 --> Output Class Initialized
INFO - 2019-05-28 03:15:19 --> Security Class Initialized
DEBUG - 2019-05-28 03:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:15:19 --> Input Class Initialized
INFO - 2019-05-28 03:15:19 --> Language Class Initialized
INFO - 2019-05-28 03:15:19 --> Language Class Initialized
INFO - 2019-05-28 03:15:19 --> Config Class Initialized
INFO - 2019-05-28 03:15:19 --> Loader Class Initialized
INFO - 2019-05-28 03:15:19 --> Helper loaded: form_helper
INFO - 2019-05-28 03:15:19 --> Helper loaded: url_helper
INFO - 2019-05-28 03:15:19 --> Helper loaded: cookie_helper
INFO - 2019-05-28 03:15:19 --> Database Driver Class Initialized
DEBUG - 2019-05-28 03:15:19 --> Template library initialized
INFO - 2019-05-28 03:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 03:15:19 --> Controller Class Initialized
DEBUG - 2019-05-28 03:15:19 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 03:15:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 03:15:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/dth.php
DEBUG - 2019-05-28 03:15:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 03:15:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 03:15:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 03:15:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 03:15:19 --> Config Class Initialized
INFO - 2019-05-28 03:15:19 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:15:19 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:15:19 --> Utf8 Class Initialized
INFO - 2019-05-28 03:15:19 --> URI Class Initialized
INFO - 2019-05-28 03:15:19 --> Router Class Initialized
INFO - 2019-05-28 03:15:19 --> Output Class Initialized
INFO - 2019-05-28 03:15:19 --> Security Class Initialized
DEBUG - 2019-05-28 03:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:15:19 --> Input Class Initialized
INFO - 2019-05-28 03:15:19 --> Language Class Initialized
INFO - 2019-05-28 03:15:19 --> Language Class Initialized
INFO - 2019-05-28 03:15:19 --> Config Class Initialized
INFO - 2019-05-28 03:15:19 --> Loader Class Initialized
INFO - 2019-05-28 03:15:19 --> Helper loaded: form_helper
INFO - 2019-05-28 03:15:19 --> Helper loaded: url_helper
INFO - 2019-05-28 03:15:19 --> Helper loaded: cookie_helper
INFO - 2019-05-28 03:15:19 --> Database Driver Class Initialized
DEBUG - 2019-05-28 03:15:19 --> Template library initialized
INFO - 2019-05-28 03:15:20 --> Config Class Initialized
INFO - 2019-05-28 03:15:20 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:15:20 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:15:20 --> Utf8 Class Initialized
INFO - 2019-05-28 03:15:20 --> URI Class Initialized
INFO - 2019-05-28 03:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 03:15:20 --> Controller Class Initialized
DEBUG - 2019-05-28 03:15:20 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 03:15:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
INFO - 2019-05-28 03:15:20 --> Router Class Initialized
INFO - 2019-05-28 03:15:20 --> Output Class Initialized
INFO - 2019-05-28 03:15:20 --> Security Class Initialized
DEBUG - 2019-05-28 03:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:15:20 --> Input Class Initialized
INFO - 2019-05-28 03:15:20 --> Language Class Initialized
INFO - 2019-05-28 03:15:20 --> Language Class Initialized
INFO - 2019-05-28 03:15:20 --> Config Class Initialized
INFO - 2019-05-28 03:15:20 --> Loader Class Initialized
DEBUG - 2019-05-28 03:15:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/dth.php
DEBUG - 2019-05-28 03:15:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 03:15:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 03:15:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 03:15:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 03:15:20 --> Helper loaded: form_helper
INFO - 2019-05-28 03:15:20 --> Helper loaded: url_helper
INFO - 2019-05-28 03:15:20 --> Helper loaded: cookie_helper
INFO - 2019-05-28 03:15:20 --> Database Driver Class Initialized
DEBUG - 2019-05-28 03:15:20 --> Template library initialized
INFO - 2019-05-28 03:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 03:15:20 --> Controller Class Initialized
DEBUG - 2019-05-28 03:15:20 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 03:15:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 03:15:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/datacard.php
DEBUG - 2019-05-28 03:15:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 03:15:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 03:15:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 03:15:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 03:15:20 --> Config Class Initialized
INFO - 2019-05-28 03:15:20 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:15:20 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:15:20 --> Utf8 Class Initialized
INFO - 2019-05-28 03:15:20 --> URI Class Initialized
INFO - 2019-05-28 03:15:20 --> Router Class Initialized
INFO - 2019-05-28 03:15:20 --> Output Class Initialized
INFO - 2019-05-28 03:15:20 --> Security Class Initialized
DEBUG - 2019-05-28 03:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:15:20 --> Input Class Initialized
INFO - 2019-05-28 03:15:20 --> Language Class Initialized
INFO - 2019-05-28 03:15:20 --> Language Class Initialized
INFO - 2019-05-28 03:15:20 --> Config Class Initialized
INFO - 2019-05-28 03:15:20 --> Loader Class Initialized
INFO - 2019-05-28 03:15:20 --> Helper loaded: form_helper
INFO - 2019-05-28 03:15:20 --> Helper loaded: url_helper
INFO - 2019-05-28 03:15:20 --> Helper loaded: cookie_helper
INFO - 2019-05-28 03:15:20 --> Database Driver Class Initialized
DEBUG - 2019-05-28 03:15:20 --> Template library initialized
INFO - 2019-05-28 03:15:20 --> Config Class Initialized
INFO - 2019-05-28 03:15:20 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:15:20 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:15:20 --> Utf8 Class Initialized
INFO - 2019-05-28 03:15:20 --> URI Class Initialized
INFO - 2019-05-28 03:15:20 --> Router Class Initialized
INFO - 2019-05-28 03:15:20 --> Output Class Initialized
INFO - 2019-05-28 03:15:20 --> Security Class Initialized
DEBUG - 2019-05-28 03:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:15:20 --> Input Class Initialized
INFO - 2019-05-28 03:15:20 --> Language Class Initialized
INFO - 2019-05-28 03:15:20 --> Language Class Initialized
INFO - 2019-05-28 03:15:20 --> Config Class Initialized
INFO - 2019-05-28 03:15:20 --> Loader Class Initialized
INFO - 2019-05-28 03:15:20 --> Helper loaded: form_helper
INFO - 2019-05-28 03:15:20 --> Helper loaded: url_helper
INFO - 2019-05-28 03:15:20 --> Helper loaded: cookie_helper
INFO - 2019-05-28 03:15:20 --> Database Driver Class Initialized
DEBUG - 2019-05-28 03:15:20 --> Template library initialized
INFO - 2019-05-28 03:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 03:15:20 --> Controller Class Initialized
DEBUG - 2019-05-28 03:15:20 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 03:15:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 03:15:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/electricity.php
DEBUG - 2019-05-28 03:15:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 03:15:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 03:15:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 03:15:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 03:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 03:15:21 --> Controller Class Initialized
DEBUG - 2019-05-28 03:15:21 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 03:15:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 03:15:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/broadband.php
DEBUG - 2019-05-28 03:15:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 03:15:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 03:15:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 03:15:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 03:15:21 --> Final output sent to browser
DEBUG - 2019-05-28 03:15:21 --> Total execution time: 0.3779
INFO - 2019-05-28 03:15:22 --> Config Class Initialized
INFO - 2019-05-28 03:15:22 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:15:22 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:15:22 --> Utf8 Class Initialized
INFO - 2019-05-28 03:15:22 --> URI Class Initialized
INFO - 2019-05-28 03:15:22 --> Router Class Initialized
INFO - 2019-05-28 03:15:22 --> Output Class Initialized
INFO - 2019-05-28 03:15:22 --> Security Class Initialized
DEBUG - 2019-05-28 03:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:15:22 --> Input Class Initialized
INFO - 2019-05-28 03:15:22 --> Language Class Initialized
ERROR - 2019-05-28 03:15:22 --> 404 Page Not Found: /index
INFO - 2019-05-28 03:15:22 --> Config Class Initialized
INFO - 2019-05-28 03:15:22 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:15:22 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:15:22 --> Utf8 Class Initialized
INFO - 2019-05-28 03:15:22 --> URI Class Initialized
INFO - 2019-05-28 03:15:22 --> Router Class Initialized
INFO - 2019-05-28 03:15:22 --> Output Class Initialized
INFO - 2019-05-28 03:15:22 --> Security Class Initialized
DEBUG - 2019-05-28 03:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:15:22 --> Input Class Initialized
INFO - 2019-05-28 03:15:22 --> Language Class Initialized
ERROR - 2019-05-28 03:15:22 --> 404 Page Not Found: /index
INFO - 2019-05-28 03:15:22 --> Config Class Initialized
INFO - 2019-05-28 03:15:22 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:15:22 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:15:22 --> Utf8 Class Initialized
INFO - 2019-05-28 03:15:22 --> URI Class Initialized
INFO - 2019-05-28 03:15:22 --> Router Class Initialized
INFO - 2019-05-28 03:15:22 --> Output Class Initialized
INFO - 2019-05-28 03:15:22 --> Security Class Initialized
DEBUG - 2019-05-28 03:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:15:22 --> Input Class Initialized
INFO - 2019-05-28 03:15:22 --> Language Class Initialized
ERROR - 2019-05-28 03:15:22 --> 404 Page Not Found: /index
INFO - 2019-05-28 03:15:29 --> Config Class Initialized
INFO - 2019-05-28 03:15:29 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:15:29 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:15:29 --> Utf8 Class Initialized
INFO - 2019-05-28 03:15:29 --> URI Class Initialized
INFO - 2019-05-28 03:15:29 --> Router Class Initialized
INFO - 2019-05-28 03:15:29 --> Output Class Initialized
INFO - 2019-05-28 03:15:29 --> Security Class Initialized
DEBUG - 2019-05-28 03:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:15:29 --> Input Class Initialized
INFO - 2019-05-28 03:15:29 --> Language Class Initialized
INFO - 2019-05-28 03:15:29 --> Language Class Initialized
INFO - 2019-05-28 03:15:29 --> Config Class Initialized
INFO - 2019-05-28 03:15:29 --> Loader Class Initialized
INFO - 2019-05-28 03:15:29 --> Helper loaded: form_helper
INFO - 2019-05-28 03:15:29 --> Helper loaded: url_helper
INFO - 2019-05-28 03:15:29 --> Helper loaded: cookie_helper
INFO - 2019-05-28 03:15:29 --> Database Driver Class Initialized
DEBUG - 2019-05-28 03:15:29 --> Template library initialized
INFO - 2019-05-28 03:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 03:15:29 --> Controller Class Initialized
DEBUG - 2019-05-28 03:15:29 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 03:15:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 03:15:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/broadband.php
DEBUG - 2019-05-28 03:15:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 03:15:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 03:15:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 03:15:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 03:15:30 --> Final output sent to browser
DEBUG - 2019-05-28 03:15:30 --> Total execution time: 0.0478
INFO - 2019-05-28 03:15:31 --> Config Class Initialized
INFO - 2019-05-28 03:15:31 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:15:31 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:15:31 --> Utf8 Class Initialized
INFO - 2019-05-28 03:15:31 --> URI Class Initialized
INFO - 2019-05-28 03:15:31 --> Router Class Initialized
INFO - 2019-05-28 03:15:31 --> Output Class Initialized
INFO - 2019-05-28 03:15:31 --> Security Class Initialized
DEBUG - 2019-05-28 03:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:15:31 --> Input Class Initialized
INFO - 2019-05-28 03:15:31 --> Language Class Initialized
ERROR - 2019-05-28 03:15:31 --> 404 Page Not Found: /index
INFO - 2019-05-28 03:15:31 --> Config Class Initialized
INFO - 2019-05-28 03:15:31 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:15:31 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:15:31 --> Utf8 Class Initialized
INFO - 2019-05-28 03:15:31 --> URI Class Initialized
INFO - 2019-05-28 03:15:31 --> Router Class Initialized
INFO - 2019-05-28 03:15:31 --> Output Class Initialized
INFO - 2019-05-28 03:15:31 --> Security Class Initialized
DEBUG - 2019-05-28 03:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:15:31 --> Input Class Initialized
INFO - 2019-05-28 03:15:31 --> Language Class Initialized
ERROR - 2019-05-28 03:15:31 --> 404 Page Not Found: /index
INFO - 2019-05-28 03:15:31 --> Config Class Initialized
INFO - 2019-05-28 03:15:31 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:15:31 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:15:31 --> Utf8 Class Initialized
INFO - 2019-05-28 03:15:31 --> URI Class Initialized
INFO - 2019-05-28 03:15:31 --> Router Class Initialized
INFO - 2019-05-28 03:15:31 --> Output Class Initialized
INFO - 2019-05-28 03:15:31 --> Security Class Initialized
DEBUG - 2019-05-28 03:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:15:31 --> Input Class Initialized
INFO - 2019-05-28 03:15:31 --> Language Class Initialized
ERROR - 2019-05-28 03:15:31 --> 404 Page Not Found: /index
INFO - 2019-05-28 03:15:57 --> Config Class Initialized
INFO - 2019-05-28 03:15:57 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:15:57 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:15:57 --> Utf8 Class Initialized
INFO - 2019-05-28 03:15:57 --> URI Class Initialized
INFO - 2019-05-28 03:15:57 --> Router Class Initialized
INFO - 2019-05-28 03:15:57 --> Output Class Initialized
INFO - 2019-05-28 03:15:57 --> Security Class Initialized
DEBUG - 2019-05-28 03:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:15:57 --> Input Class Initialized
INFO - 2019-05-28 03:15:57 --> Language Class Initialized
INFO - 2019-05-28 03:15:57 --> Language Class Initialized
INFO - 2019-05-28 03:15:57 --> Config Class Initialized
INFO - 2019-05-28 03:15:57 --> Loader Class Initialized
INFO - 2019-05-28 03:15:57 --> Helper loaded: form_helper
INFO - 2019-05-28 03:15:57 --> Helper loaded: url_helper
INFO - 2019-05-28 03:15:57 --> Helper loaded: cookie_helper
INFO - 2019-05-28 03:15:57 --> Database Driver Class Initialized
DEBUG - 2019-05-28 03:15:57 --> Template library initialized
INFO - 2019-05-28 03:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 03:15:57 --> Controller Class Initialized
DEBUG - 2019-05-28 03:15:57 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 03:15:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 03:15:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/landline.php
DEBUG - 2019-05-28 03:15:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 03:15:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 03:15:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 03:15:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 03:15:58 --> Final output sent to browser
DEBUG - 2019-05-28 03:15:58 --> Total execution time: 0.0467
INFO - 2019-05-28 03:15:58 --> Config Class Initialized
INFO - 2019-05-28 03:15:58 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:15:58 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:15:58 --> Utf8 Class Initialized
INFO - 2019-05-28 03:15:58 --> URI Class Initialized
INFO - 2019-05-28 03:15:58 --> Router Class Initialized
INFO - 2019-05-28 03:15:58 --> Output Class Initialized
INFO - 2019-05-28 03:15:58 --> Security Class Initialized
DEBUG - 2019-05-28 03:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:15:58 --> Input Class Initialized
INFO - 2019-05-28 03:15:58 --> Language Class Initialized
ERROR - 2019-05-28 03:15:58 --> 404 Page Not Found: /index
INFO - 2019-05-28 03:15:58 --> Config Class Initialized
INFO - 2019-05-28 03:15:58 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:15:58 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:15:58 --> Utf8 Class Initialized
INFO - 2019-05-28 03:15:58 --> URI Class Initialized
INFO - 2019-05-28 03:15:58 --> Router Class Initialized
INFO - 2019-05-28 03:15:58 --> Output Class Initialized
INFO - 2019-05-28 03:15:58 --> Security Class Initialized
DEBUG - 2019-05-28 03:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:15:58 --> Input Class Initialized
INFO - 2019-05-28 03:15:58 --> Language Class Initialized
ERROR - 2019-05-28 03:15:58 --> 404 Page Not Found: /index
INFO - 2019-05-28 03:15:58 --> Config Class Initialized
INFO - 2019-05-28 03:15:58 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:15:58 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:15:58 --> Utf8 Class Initialized
INFO - 2019-05-28 03:15:58 --> URI Class Initialized
INFO - 2019-05-28 03:15:58 --> Router Class Initialized
INFO - 2019-05-28 03:15:58 --> Output Class Initialized
INFO - 2019-05-28 03:15:58 --> Security Class Initialized
DEBUG - 2019-05-28 03:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:15:58 --> Input Class Initialized
INFO - 2019-05-28 03:15:58 --> Language Class Initialized
ERROR - 2019-05-28 03:15:58 --> 404 Page Not Found: /index
INFO - 2019-05-28 03:16:22 --> Config Class Initialized
INFO - 2019-05-28 03:16:22 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:16:22 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:16:22 --> Utf8 Class Initialized
INFO - 2019-05-28 03:16:22 --> URI Class Initialized
INFO - 2019-05-28 03:16:22 --> Router Class Initialized
INFO - 2019-05-28 03:16:22 --> Output Class Initialized
INFO - 2019-05-28 03:16:22 --> Security Class Initialized
DEBUG - 2019-05-28 03:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:16:22 --> Input Class Initialized
INFO - 2019-05-28 03:16:22 --> Language Class Initialized
INFO - 2019-05-28 03:16:22 --> Language Class Initialized
INFO - 2019-05-28 03:16:22 --> Config Class Initialized
INFO - 2019-05-28 03:16:22 --> Loader Class Initialized
INFO - 2019-05-28 03:16:22 --> Helper loaded: form_helper
INFO - 2019-05-28 03:16:22 --> Helper loaded: url_helper
INFO - 2019-05-28 03:16:22 --> Helper loaded: cookie_helper
INFO - 2019-05-28 03:16:22 --> Database Driver Class Initialized
DEBUG - 2019-05-28 03:16:22 --> Template library initialized
INFO - 2019-05-28 03:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 03:16:22 --> Controller Class Initialized
DEBUG - 2019-05-28 03:16:22 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 03:16:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 03:16:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/landline.php
DEBUG - 2019-05-28 03:16:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 03:16:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 03:16:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 03:16:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 03:16:23 --> Final output sent to browser
DEBUG - 2019-05-28 03:16:23 --> Total execution time: 0.0439
INFO - 2019-05-28 03:16:23 --> Config Class Initialized
INFO - 2019-05-28 03:16:23 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:16:23 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:16:23 --> Utf8 Class Initialized
INFO - 2019-05-28 03:16:23 --> URI Class Initialized
INFO - 2019-05-28 03:16:23 --> Config Class Initialized
INFO - 2019-05-28 03:16:23 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:16:23 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:16:23 --> Utf8 Class Initialized
INFO - 2019-05-28 03:16:23 --> URI Class Initialized
INFO - 2019-05-28 03:16:23 --> Router Class Initialized
INFO - 2019-05-28 03:16:23 --> Output Class Initialized
INFO - 2019-05-28 03:16:23 --> Security Class Initialized
DEBUG - 2019-05-28 03:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:16:23 --> Input Class Initialized
INFO - 2019-05-28 03:16:23 --> Language Class Initialized
ERROR - 2019-05-28 03:16:23 --> 404 Page Not Found: /index
INFO - 2019-05-28 03:16:23 --> Router Class Initialized
INFO - 2019-05-28 03:16:23 --> Output Class Initialized
INFO - 2019-05-28 03:16:23 --> Security Class Initialized
DEBUG - 2019-05-28 03:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:16:23 --> Input Class Initialized
INFO - 2019-05-28 03:16:23 --> Language Class Initialized
ERROR - 2019-05-28 03:16:23 --> 404 Page Not Found: /index
INFO - 2019-05-28 03:16:23 --> Config Class Initialized
INFO - 2019-05-28 03:16:23 --> Hooks Class Initialized
DEBUG - 2019-05-28 03:16:23 --> UTF-8 Support Enabled
INFO - 2019-05-28 03:16:23 --> Utf8 Class Initialized
INFO - 2019-05-28 03:16:23 --> URI Class Initialized
INFO - 2019-05-28 03:16:23 --> Router Class Initialized
INFO - 2019-05-28 03:16:23 --> Output Class Initialized
INFO - 2019-05-28 03:16:23 --> Security Class Initialized
DEBUG - 2019-05-28 03:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 03:16:23 --> Input Class Initialized
INFO - 2019-05-28 03:16:23 --> Language Class Initialized
ERROR - 2019-05-28 03:16:23 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:10:37 --> Config Class Initialized
INFO - 2019-05-28 07:10:37 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:10:37 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:10:37 --> Utf8 Class Initialized
INFO - 2019-05-28 07:10:37 --> URI Class Initialized
DEBUG - 2019-05-28 07:10:37 --> No URI present. Default controller set.
INFO - 2019-05-28 07:10:37 --> Router Class Initialized
INFO - 2019-05-28 07:10:37 --> Output Class Initialized
INFO - 2019-05-28 07:10:37 --> Security Class Initialized
DEBUG - 2019-05-28 07:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:10:37 --> Input Class Initialized
INFO - 2019-05-28 07:10:37 --> Language Class Initialized
INFO - 2019-05-28 07:10:37 --> Language Class Initialized
INFO - 2019-05-28 07:10:37 --> Config Class Initialized
INFO - 2019-05-28 07:10:37 --> Loader Class Initialized
INFO - 2019-05-28 07:10:37 --> Helper loaded: form_helper
INFO - 2019-05-28 07:10:37 --> Helper loaded: url_helper
INFO - 2019-05-28 07:10:37 --> Helper loaded: cookie_helper
INFO - 2019-05-28 07:10:37 --> Database Driver Class Initialized
DEBUG - 2019-05-28 07:10:37 --> Template library initialized
INFO - 2019-05-28 07:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 07:10:37 --> Controller Class Initialized
DEBUG - 2019-05-28 07:10:37 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 07:10:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 07:10:38 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 07:10:38 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 07:10:38 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 07:10:38 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 07:10:38 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 07:10:38 --> Final output sent to browser
DEBUG - 2019-05-28 07:10:38 --> Total execution time: 0.0464
INFO - 2019-05-28 07:10:42 --> Config Class Initialized
INFO - 2019-05-28 07:10:42 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:10:42 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:10:42 --> Utf8 Class Initialized
INFO - 2019-05-28 07:10:42 --> URI Class Initialized
INFO - 2019-05-28 07:10:42 --> Router Class Initialized
INFO - 2019-05-28 07:10:42 --> Output Class Initialized
INFO - 2019-05-28 07:10:42 --> Security Class Initialized
DEBUG - 2019-05-28 07:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:10:42 --> Input Class Initialized
INFO - 2019-05-28 07:10:42 --> Language Class Initialized
ERROR - 2019-05-28 07:10:42 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:10:42 --> Config Class Initialized
INFO - 2019-05-28 07:10:42 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:10:42 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:10:42 --> Utf8 Class Initialized
INFO - 2019-05-28 07:10:42 --> URI Class Initialized
INFO - 2019-05-28 07:10:42 --> Router Class Initialized
INFO - 2019-05-28 07:10:42 --> Output Class Initialized
INFO - 2019-05-28 07:10:42 --> Security Class Initialized
DEBUG - 2019-05-28 07:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:10:42 --> Input Class Initialized
INFO - 2019-05-28 07:10:42 --> Language Class Initialized
ERROR - 2019-05-28 07:10:42 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:10:43 --> Config Class Initialized
INFO - 2019-05-28 07:10:43 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:10:43 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:10:43 --> Utf8 Class Initialized
INFO - 2019-05-28 07:10:43 --> URI Class Initialized
INFO - 2019-05-28 07:10:43 --> Router Class Initialized
INFO - 2019-05-28 07:10:43 --> Output Class Initialized
INFO - 2019-05-28 07:10:43 --> Security Class Initialized
DEBUG - 2019-05-28 07:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:10:43 --> Input Class Initialized
INFO - 2019-05-28 07:10:43 --> Language Class Initialized
ERROR - 2019-05-28 07:10:43 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:10:43 --> Config Class Initialized
INFO - 2019-05-28 07:10:43 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:10:43 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:10:43 --> Utf8 Class Initialized
INFO - 2019-05-28 07:10:43 --> URI Class Initialized
INFO - 2019-05-28 07:10:43 --> Router Class Initialized
INFO - 2019-05-28 07:10:43 --> Output Class Initialized
INFO - 2019-05-28 07:10:43 --> Security Class Initialized
DEBUG - 2019-05-28 07:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:10:43 --> Input Class Initialized
INFO - 2019-05-28 07:10:43 --> Language Class Initialized
ERROR - 2019-05-28 07:10:43 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:11:00 --> Config Class Initialized
INFO - 2019-05-28 07:11:00 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:11:00 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:11:00 --> Utf8 Class Initialized
INFO - 2019-05-28 07:11:00 --> URI Class Initialized
INFO - 2019-05-28 07:11:00 --> Router Class Initialized
INFO - 2019-05-28 07:11:00 --> Output Class Initialized
INFO - 2019-05-28 07:11:00 --> Security Class Initialized
DEBUG - 2019-05-28 07:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:11:00 --> Input Class Initialized
INFO - 2019-05-28 07:11:00 --> Language Class Initialized
INFO - 2019-05-28 07:11:00 --> Language Class Initialized
INFO - 2019-05-28 07:11:00 --> Config Class Initialized
INFO - 2019-05-28 07:11:00 --> Loader Class Initialized
INFO - 2019-05-28 07:11:00 --> Helper loaded: form_helper
INFO - 2019-05-28 07:11:00 --> Helper loaded: url_helper
INFO - 2019-05-28 07:11:00 --> Helper loaded: cookie_helper
INFO - 2019-05-28 07:11:00 --> Database Driver Class Initialized
DEBUG - 2019-05-28 07:11:00 --> Template library initialized
INFO - 2019-05-28 07:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 07:11:00 --> Controller Class Initialized
DEBUG - 2019-05-28 07:11:00 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 07:11:00 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 07:11:00 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/dth.php
DEBUG - 2019-05-28 07:11:00 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 07:11:00 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 07:11:00 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 07:11:00 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 07:11:00 --> Final output sent to browser
DEBUG - 2019-05-28 07:11:00 --> Total execution time: 0.0500
INFO - 2019-05-28 07:11:00 --> Config Class Initialized
INFO - 2019-05-28 07:11:00 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:11:00 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:11:00 --> Utf8 Class Initialized
INFO - 2019-05-28 07:11:00 --> URI Class Initialized
INFO - 2019-05-28 07:11:00 --> Router Class Initialized
INFO - 2019-05-28 07:11:00 --> Output Class Initialized
INFO - 2019-05-28 07:11:00 --> Security Class Initialized
DEBUG - 2019-05-28 07:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:11:00 --> Input Class Initialized
INFO - 2019-05-28 07:11:00 --> Language Class Initialized
ERROR - 2019-05-28 07:11:00 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:11:01 --> Config Class Initialized
INFO - 2019-05-28 07:11:01 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:11:01 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:11:01 --> Utf8 Class Initialized
INFO - 2019-05-28 07:11:01 --> URI Class Initialized
INFO - 2019-05-28 07:11:01 --> Router Class Initialized
INFO - 2019-05-28 07:11:01 --> Output Class Initialized
INFO - 2019-05-28 07:11:01 --> Security Class Initialized
DEBUG - 2019-05-28 07:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:11:01 --> Input Class Initialized
INFO - 2019-05-28 07:11:01 --> Language Class Initialized
ERROR - 2019-05-28 07:11:01 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:11:01 --> Config Class Initialized
INFO - 2019-05-28 07:11:01 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:11:01 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:11:01 --> Utf8 Class Initialized
INFO - 2019-05-28 07:11:01 --> URI Class Initialized
INFO - 2019-05-28 07:11:01 --> Router Class Initialized
INFO - 2019-05-28 07:11:01 --> Output Class Initialized
INFO - 2019-05-28 07:11:01 --> Security Class Initialized
DEBUG - 2019-05-28 07:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:11:01 --> Input Class Initialized
INFO - 2019-05-28 07:11:01 --> Language Class Initialized
ERROR - 2019-05-28 07:11:01 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:12:07 --> Config Class Initialized
INFO - 2019-05-28 07:12:07 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:12:07 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:12:07 --> Utf8 Class Initialized
INFO - 2019-05-28 07:12:07 --> URI Class Initialized
INFO - 2019-05-28 07:12:07 --> Router Class Initialized
INFO - 2019-05-28 07:12:07 --> Output Class Initialized
INFO - 2019-05-28 07:12:07 --> Security Class Initialized
DEBUG - 2019-05-28 07:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:12:07 --> Input Class Initialized
INFO - 2019-05-28 07:12:07 --> Language Class Initialized
INFO - 2019-05-28 07:12:07 --> Language Class Initialized
INFO - 2019-05-28 07:12:07 --> Config Class Initialized
INFO - 2019-05-28 07:12:07 --> Loader Class Initialized
INFO - 2019-05-28 07:12:07 --> Helper loaded: form_helper
INFO - 2019-05-28 07:12:07 --> Helper loaded: url_helper
INFO - 2019-05-28 07:12:07 --> Helper loaded: cookie_helper
INFO - 2019-05-28 07:12:07 --> Database Driver Class Initialized
DEBUG - 2019-05-28 07:12:07 --> Template library initialized
INFO - 2019-05-28 07:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 07:12:07 --> Controller Class Initialized
DEBUG - 2019-05-28 07:12:07 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 07:12:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 07:12:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/insurance.php
DEBUG - 2019-05-28 07:12:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 07:12:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 07:12:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 07:12:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 07:12:07 --> Final output sent to browser
DEBUG - 2019-05-28 07:12:07 --> Total execution time: 0.0469
INFO - 2019-05-28 07:12:07 --> Config Class Initialized
INFO - 2019-05-28 07:12:07 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:12:07 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:12:07 --> Utf8 Class Initialized
INFO - 2019-05-28 07:12:07 --> URI Class Initialized
INFO - 2019-05-28 07:12:07 --> Router Class Initialized
INFO - 2019-05-28 07:12:07 --> Output Class Initialized
INFO - 2019-05-28 07:12:07 --> Security Class Initialized
DEBUG - 2019-05-28 07:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:12:07 --> Input Class Initialized
INFO - 2019-05-28 07:12:07 --> Language Class Initialized
ERROR - 2019-05-28 07:12:07 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:12:07 --> Config Class Initialized
INFO - 2019-05-28 07:12:07 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:12:07 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:12:07 --> Utf8 Class Initialized
INFO - 2019-05-28 07:12:07 --> URI Class Initialized
INFO - 2019-05-28 07:12:07 --> Router Class Initialized
INFO - 2019-05-28 07:12:07 --> Output Class Initialized
INFO - 2019-05-28 07:12:07 --> Security Class Initialized
DEBUG - 2019-05-28 07:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:12:07 --> Input Class Initialized
INFO - 2019-05-28 07:12:07 --> Language Class Initialized
ERROR - 2019-05-28 07:12:07 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:12:08 --> Config Class Initialized
INFO - 2019-05-28 07:12:08 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:12:08 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:12:08 --> Utf8 Class Initialized
INFO - 2019-05-28 07:12:08 --> URI Class Initialized
INFO - 2019-05-28 07:12:08 --> Router Class Initialized
INFO - 2019-05-28 07:12:08 --> Output Class Initialized
INFO - 2019-05-28 07:12:08 --> Security Class Initialized
DEBUG - 2019-05-28 07:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:12:08 --> Input Class Initialized
INFO - 2019-05-28 07:12:08 --> Language Class Initialized
ERROR - 2019-05-28 07:12:08 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:12:13 --> Config Class Initialized
INFO - 2019-05-28 07:12:13 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:12:13 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:12:13 --> Utf8 Class Initialized
INFO - 2019-05-28 07:12:13 --> URI Class Initialized
DEBUG - 2019-05-28 07:12:13 --> No URI present. Default controller set.
INFO - 2019-05-28 07:12:13 --> Router Class Initialized
INFO - 2019-05-28 07:12:13 --> Output Class Initialized
INFO - 2019-05-28 07:12:13 --> Security Class Initialized
DEBUG - 2019-05-28 07:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:12:13 --> Input Class Initialized
INFO - 2019-05-28 07:12:13 --> Language Class Initialized
INFO - 2019-05-28 07:12:13 --> Language Class Initialized
INFO - 2019-05-28 07:12:13 --> Config Class Initialized
INFO - 2019-05-28 07:12:13 --> Loader Class Initialized
INFO - 2019-05-28 07:12:13 --> Helper loaded: form_helper
INFO - 2019-05-28 07:12:13 --> Helper loaded: url_helper
INFO - 2019-05-28 07:12:13 --> Helper loaded: cookie_helper
INFO - 2019-05-28 07:12:13 --> Database Driver Class Initialized
DEBUG - 2019-05-28 07:12:13 --> Template library initialized
INFO - 2019-05-28 07:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 07:12:13 --> Controller Class Initialized
DEBUG - 2019-05-28 07:12:13 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 07:12:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 07:12:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 07:12:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 07:12:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 07:12:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 07:12:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 07:12:13 --> Final output sent to browser
DEBUG - 2019-05-28 07:12:13 --> Total execution time: 0.0456
INFO - 2019-05-28 07:12:14 --> Config Class Initialized
INFO - 2019-05-28 07:12:14 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:12:14 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:12:14 --> Utf8 Class Initialized
INFO - 2019-05-28 07:12:14 --> URI Class Initialized
INFO - 2019-05-28 07:12:14 --> Router Class Initialized
INFO - 2019-05-28 07:12:14 --> Output Class Initialized
INFO - 2019-05-28 07:12:14 --> Security Class Initialized
DEBUG - 2019-05-28 07:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:12:14 --> Input Class Initialized
INFO - 2019-05-28 07:12:14 --> Language Class Initialized
ERROR - 2019-05-28 07:12:14 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:12:14 --> Config Class Initialized
INFO - 2019-05-28 07:12:14 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:12:14 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:12:14 --> Utf8 Class Initialized
INFO - 2019-05-28 07:12:14 --> URI Class Initialized
INFO - 2019-05-28 07:12:14 --> Router Class Initialized
INFO - 2019-05-28 07:12:14 --> Output Class Initialized
INFO - 2019-05-28 07:12:14 --> Security Class Initialized
DEBUG - 2019-05-28 07:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:12:14 --> Input Class Initialized
INFO - 2019-05-28 07:12:14 --> Language Class Initialized
ERROR - 2019-05-28 07:12:14 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:12:14 --> Config Class Initialized
INFO - 2019-05-28 07:12:14 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:12:14 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:12:14 --> Utf8 Class Initialized
INFO - 2019-05-28 07:12:14 --> URI Class Initialized
INFO - 2019-05-28 07:12:14 --> Router Class Initialized
INFO - 2019-05-28 07:12:14 --> Output Class Initialized
INFO - 2019-05-28 07:12:14 --> Security Class Initialized
DEBUG - 2019-05-28 07:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:12:14 --> Input Class Initialized
INFO - 2019-05-28 07:12:14 --> Language Class Initialized
ERROR - 2019-05-28 07:12:14 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:12:40 --> Config Class Initialized
INFO - 2019-05-28 07:12:40 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:12:40 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:12:40 --> Utf8 Class Initialized
INFO - 2019-05-28 07:12:40 --> URI Class Initialized
DEBUG - 2019-05-28 07:12:40 --> No URI present. Default controller set.
INFO - 2019-05-28 07:12:40 --> Router Class Initialized
INFO - 2019-05-28 07:12:40 --> Output Class Initialized
INFO - 2019-05-28 07:12:40 --> Security Class Initialized
DEBUG - 2019-05-28 07:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:12:40 --> Input Class Initialized
INFO - 2019-05-28 07:12:40 --> Language Class Initialized
INFO - 2019-05-28 07:12:40 --> Language Class Initialized
INFO - 2019-05-28 07:12:40 --> Config Class Initialized
INFO - 2019-05-28 07:12:40 --> Loader Class Initialized
INFO - 2019-05-28 07:12:40 --> Helper loaded: form_helper
INFO - 2019-05-28 07:12:40 --> Helper loaded: url_helper
INFO - 2019-05-28 07:12:40 --> Helper loaded: cookie_helper
INFO - 2019-05-28 07:12:40 --> Database Driver Class Initialized
DEBUG - 2019-05-28 07:12:40 --> Template library initialized
INFO - 2019-05-28 07:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 07:12:40 --> Controller Class Initialized
DEBUG - 2019-05-28 07:12:40 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 07:12:40 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 07:12:40 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 07:12:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 07:12:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 07:12:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 07:12:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 07:12:41 --> Final output sent to browser
DEBUG - 2019-05-28 07:12:41 --> Total execution time: 0.0529
INFO - 2019-05-28 07:12:41 --> Config Class Initialized
INFO - 2019-05-28 07:12:41 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:12:41 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:12:41 --> Utf8 Class Initialized
INFO - 2019-05-28 07:12:41 --> URI Class Initialized
INFO - 2019-05-28 07:12:41 --> Router Class Initialized
INFO - 2019-05-28 07:12:41 --> Output Class Initialized
INFO - 2019-05-28 07:12:41 --> Security Class Initialized
DEBUG - 2019-05-28 07:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:12:41 --> Input Class Initialized
INFO - 2019-05-28 07:12:41 --> Language Class Initialized
ERROR - 2019-05-28 07:12:41 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:12:41 --> Config Class Initialized
INFO - 2019-05-28 07:12:41 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:12:41 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:12:41 --> Utf8 Class Initialized
INFO - 2019-05-28 07:12:41 --> URI Class Initialized
INFO - 2019-05-28 07:12:41 --> Router Class Initialized
INFO - 2019-05-28 07:12:41 --> Output Class Initialized
INFO - 2019-05-28 07:12:41 --> Security Class Initialized
DEBUG - 2019-05-28 07:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:12:41 --> Input Class Initialized
INFO - 2019-05-28 07:12:41 --> Language Class Initialized
ERROR - 2019-05-28 07:12:41 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:12:41 --> Config Class Initialized
INFO - 2019-05-28 07:12:41 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:12:41 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:12:41 --> Utf8 Class Initialized
INFO - 2019-05-28 07:12:41 --> URI Class Initialized
INFO - 2019-05-28 07:12:41 --> Router Class Initialized
INFO - 2019-05-28 07:12:41 --> Output Class Initialized
INFO - 2019-05-28 07:12:41 --> Security Class Initialized
DEBUG - 2019-05-28 07:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:12:41 --> Input Class Initialized
INFO - 2019-05-28 07:12:41 --> Language Class Initialized
ERROR - 2019-05-28 07:12:41 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:13:35 --> Config Class Initialized
INFO - 2019-05-28 07:13:35 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:13:35 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:13:35 --> Utf8 Class Initialized
INFO - 2019-05-28 07:13:35 --> URI Class Initialized
INFO - 2019-05-28 07:13:35 --> Router Class Initialized
INFO - 2019-05-28 07:13:35 --> Output Class Initialized
INFO - 2019-05-28 07:13:35 --> Security Class Initialized
DEBUG - 2019-05-28 07:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:13:35 --> Input Class Initialized
INFO - 2019-05-28 07:13:35 --> Language Class Initialized
INFO - 2019-05-28 07:13:35 --> Language Class Initialized
INFO - 2019-05-28 07:13:35 --> Config Class Initialized
INFO - 2019-05-28 07:13:35 --> Loader Class Initialized
INFO - 2019-05-28 07:13:35 --> Helper loaded: form_helper
INFO - 2019-05-28 07:13:35 --> Helper loaded: url_helper
INFO - 2019-05-28 07:13:35 --> Helper loaded: cookie_helper
INFO - 2019-05-28 07:13:35 --> Database Driver Class Initialized
DEBUG - 2019-05-28 07:13:35 --> Template library initialized
INFO - 2019-05-28 07:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 07:13:35 --> Controller Class Initialized
DEBUG - 2019-05-28 07:13:35 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 07:13:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 07:13:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/landline.php
DEBUG - 2019-05-28 07:13:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 07:13:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 07:13:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 07:13:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 07:13:36 --> Final output sent to browser
DEBUG - 2019-05-28 07:13:36 --> Total execution time: 0.0459
INFO - 2019-05-28 07:13:37 --> Config Class Initialized
INFO - 2019-05-28 07:13:37 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:13:37 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:13:37 --> Utf8 Class Initialized
INFO - 2019-05-28 07:13:37 --> URI Class Initialized
INFO - 2019-05-28 07:13:37 --> Router Class Initialized
INFO - 2019-05-28 07:13:37 --> Output Class Initialized
INFO - 2019-05-28 07:13:37 --> Security Class Initialized
DEBUG - 2019-05-28 07:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:13:37 --> Input Class Initialized
INFO - 2019-05-28 07:13:37 --> Language Class Initialized
ERROR - 2019-05-28 07:13:37 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:35:16 --> Config Class Initialized
INFO - 2019-05-28 07:35:16 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:35:16 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:35:16 --> Utf8 Class Initialized
INFO - 2019-05-28 07:35:16 --> URI Class Initialized
DEBUG - 2019-05-28 07:35:16 --> No URI present. Default controller set.
INFO - 2019-05-28 07:35:16 --> Router Class Initialized
INFO - 2019-05-28 07:35:16 --> Output Class Initialized
INFO - 2019-05-28 07:35:16 --> Security Class Initialized
DEBUG - 2019-05-28 07:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:35:16 --> Input Class Initialized
INFO - 2019-05-28 07:35:16 --> Language Class Initialized
INFO - 2019-05-28 07:35:16 --> Language Class Initialized
INFO - 2019-05-28 07:35:16 --> Config Class Initialized
INFO - 2019-05-28 07:35:16 --> Loader Class Initialized
INFO - 2019-05-28 07:35:16 --> Helper loaded: form_helper
INFO - 2019-05-28 07:35:16 --> Helper loaded: url_helper
INFO - 2019-05-28 07:35:16 --> Helper loaded: cookie_helper
INFO - 2019-05-28 07:35:16 --> Database Driver Class Initialized
DEBUG - 2019-05-28 07:35:16 --> Template library initialized
INFO - 2019-05-28 07:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 07:35:16 --> Controller Class Initialized
DEBUG - 2019-05-28 07:35:16 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 07:35:16 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 07:35:16 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 07:35:16 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 07:35:16 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 07:35:16 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 07:35:16 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 07:35:17 --> Final output sent to browser
DEBUG - 2019-05-28 07:35:17 --> Total execution time: 0.0448
INFO - 2019-05-28 07:35:17 --> Config Class Initialized
INFO - 2019-05-28 07:35:17 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:35:17 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:35:17 --> Utf8 Class Initialized
INFO - 2019-05-28 07:35:17 --> URI Class Initialized
INFO - 2019-05-28 07:35:17 --> Router Class Initialized
INFO - 2019-05-28 07:35:17 --> Output Class Initialized
INFO - 2019-05-28 07:35:17 --> Security Class Initialized
DEBUG - 2019-05-28 07:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:35:17 --> Input Class Initialized
INFO - 2019-05-28 07:35:17 --> Language Class Initialized
ERROR - 2019-05-28 07:35:17 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:35:17 --> Config Class Initialized
INFO - 2019-05-28 07:35:17 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:35:17 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:35:17 --> Utf8 Class Initialized
INFO - 2019-05-28 07:35:17 --> URI Class Initialized
INFO - 2019-05-28 07:35:17 --> Router Class Initialized
INFO - 2019-05-28 07:35:17 --> Output Class Initialized
INFO - 2019-05-28 07:35:17 --> Security Class Initialized
DEBUG - 2019-05-28 07:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:35:17 --> Input Class Initialized
INFO - 2019-05-28 07:35:17 --> Language Class Initialized
ERROR - 2019-05-28 07:35:17 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:35:17 --> Config Class Initialized
INFO - 2019-05-28 07:35:17 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:35:17 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:35:17 --> Utf8 Class Initialized
INFO - 2019-05-28 07:35:17 --> URI Class Initialized
INFO - 2019-05-28 07:35:17 --> Router Class Initialized
INFO - 2019-05-28 07:35:17 --> Output Class Initialized
INFO - 2019-05-28 07:35:17 --> Security Class Initialized
DEBUG - 2019-05-28 07:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:35:17 --> Input Class Initialized
INFO - 2019-05-28 07:35:17 --> Language Class Initialized
ERROR - 2019-05-28 07:35:17 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:35:31 --> Config Class Initialized
INFO - 2019-05-28 07:35:31 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:35:31 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:35:31 --> Utf8 Class Initialized
INFO - 2019-05-28 07:35:31 --> URI Class Initialized
DEBUG - 2019-05-28 07:35:31 --> No URI present. Default controller set.
INFO - 2019-05-28 07:35:31 --> Router Class Initialized
INFO - 2019-05-28 07:35:31 --> Output Class Initialized
INFO - 2019-05-28 07:35:31 --> Security Class Initialized
DEBUG - 2019-05-28 07:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:35:31 --> Input Class Initialized
INFO - 2019-05-28 07:35:31 --> Language Class Initialized
INFO - 2019-05-28 07:35:31 --> Language Class Initialized
INFO - 2019-05-28 07:35:31 --> Config Class Initialized
INFO - 2019-05-28 07:35:31 --> Loader Class Initialized
INFO - 2019-05-28 07:35:31 --> Helper loaded: form_helper
INFO - 2019-05-28 07:35:31 --> Helper loaded: url_helper
INFO - 2019-05-28 07:35:31 --> Helper loaded: cookie_helper
INFO - 2019-05-28 07:35:31 --> Database Driver Class Initialized
DEBUG - 2019-05-28 07:35:31 --> Template library initialized
INFO - 2019-05-28 07:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 07:35:31 --> Controller Class Initialized
DEBUG - 2019-05-28 07:35:31 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 07:35:31 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 07:35:31 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 07:35:31 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 07:35:31 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 07:35:31 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 07:35:31 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 07:35:32 --> Final output sent to browser
DEBUG - 2019-05-28 07:35:32 --> Total execution time: 0.0460
INFO - 2019-05-28 07:35:32 --> Config Class Initialized
INFO - 2019-05-28 07:35:32 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:35:32 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:35:32 --> Utf8 Class Initialized
INFO - 2019-05-28 07:35:32 --> URI Class Initialized
INFO - 2019-05-28 07:35:32 --> Router Class Initialized
INFO - 2019-05-28 07:35:32 --> Output Class Initialized
INFO - 2019-05-28 07:35:32 --> Security Class Initialized
DEBUG - 2019-05-28 07:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:35:32 --> Input Class Initialized
INFO - 2019-05-28 07:35:32 --> Language Class Initialized
ERROR - 2019-05-28 07:35:32 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:35:32 --> Config Class Initialized
INFO - 2019-05-28 07:35:32 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:35:32 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:35:32 --> Utf8 Class Initialized
INFO - 2019-05-28 07:35:32 --> URI Class Initialized
INFO - 2019-05-28 07:35:32 --> Router Class Initialized
INFO - 2019-05-28 07:35:32 --> Output Class Initialized
INFO - 2019-05-28 07:35:32 --> Security Class Initialized
DEBUG - 2019-05-28 07:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:35:32 --> Input Class Initialized
INFO - 2019-05-28 07:35:32 --> Language Class Initialized
ERROR - 2019-05-28 07:35:32 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:35:32 --> Config Class Initialized
INFO - 2019-05-28 07:35:32 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:35:32 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:35:32 --> Utf8 Class Initialized
INFO - 2019-05-28 07:35:32 --> URI Class Initialized
INFO - 2019-05-28 07:35:32 --> Router Class Initialized
INFO - 2019-05-28 07:35:32 --> Output Class Initialized
INFO - 2019-05-28 07:35:32 --> Security Class Initialized
DEBUG - 2019-05-28 07:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:35:32 --> Input Class Initialized
INFO - 2019-05-28 07:35:32 --> Language Class Initialized
ERROR - 2019-05-28 07:35:32 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:40:45 --> Config Class Initialized
INFO - 2019-05-28 07:40:45 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:40:45 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:40:45 --> Utf8 Class Initialized
INFO - 2019-05-28 07:40:45 --> URI Class Initialized
DEBUG - 2019-05-28 07:40:45 --> No URI present. Default controller set.
INFO - 2019-05-28 07:40:45 --> Router Class Initialized
INFO - 2019-05-28 07:40:45 --> Output Class Initialized
INFO - 2019-05-28 07:40:45 --> Security Class Initialized
DEBUG - 2019-05-28 07:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:40:45 --> Input Class Initialized
INFO - 2019-05-28 07:40:45 --> Language Class Initialized
INFO - 2019-05-28 07:40:45 --> Language Class Initialized
INFO - 2019-05-28 07:40:45 --> Config Class Initialized
INFO - 2019-05-28 07:40:45 --> Loader Class Initialized
INFO - 2019-05-28 07:40:45 --> Helper loaded: form_helper
INFO - 2019-05-28 07:40:45 --> Helper loaded: url_helper
INFO - 2019-05-28 07:40:45 --> Helper loaded: cookie_helper
INFO - 2019-05-28 07:40:45 --> Database Driver Class Initialized
DEBUG - 2019-05-28 07:40:45 --> Template library initialized
INFO - 2019-05-28 07:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 07:40:45 --> Controller Class Initialized
DEBUG - 2019-05-28 07:40:45 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 07:40:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 07:40:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 07:40:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 07:40:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 07:40:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 07:40:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 07:40:45 --> Final output sent to browser
DEBUG - 2019-05-28 07:40:45 --> Total execution time: 0.0502
INFO - 2019-05-28 07:40:45 --> Config Class Initialized
INFO - 2019-05-28 07:40:45 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:40:45 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:40:45 --> Utf8 Class Initialized
INFO - 2019-05-28 07:40:45 --> URI Class Initialized
INFO - 2019-05-28 07:40:45 --> Router Class Initialized
INFO - 2019-05-28 07:40:45 --> Output Class Initialized
INFO - 2019-05-28 07:40:45 --> Security Class Initialized
DEBUG - 2019-05-28 07:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:40:45 --> Input Class Initialized
INFO - 2019-05-28 07:40:45 --> Language Class Initialized
ERROR - 2019-05-28 07:40:45 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:40:45 --> Config Class Initialized
INFO - 2019-05-28 07:40:45 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:40:45 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:40:45 --> Utf8 Class Initialized
INFO - 2019-05-28 07:40:45 --> URI Class Initialized
INFO - 2019-05-28 07:40:45 --> Router Class Initialized
INFO - 2019-05-28 07:40:45 --> Output Class Initialized
INFO - 2019-05-28 07:40:45 --> Security Class Initialized
DEBUG - 2019-05-28 07:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:40:45 --> Input Class Initialized
INFO - 2019-05-28 07:40:45 --> Language Class Initialized
ERROR - 2019-05-28 07:40:45 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:40:46 --> Config Class Initialized
INFO - 2019-05-28 07:40:46 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:40:46 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:40:46 --> Utf8 Class Initialized
INFO - 2019-05-28 07:40:46 --> URI Class Initialized
INFO - 2019-05-28 07:40:46 --> Router Class Initialized
INFO - 2019-05-28 07:40:46 --> Output Class Initialized
INFO - 2019-05-28 07:40:46 --> Security Class Initialized
DEBUG - 2019-05-28 07:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:40:46 --> Input Class Initialized
INFO - 2019-05-28 07:40:46 --> Language Class Initialized
ERROR - 2019-05-28 07:40:46 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:48:06 --> Config Class Initialized
INFO - 2019-05-28 07:48:06 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:48:06 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:48:06 --> Utf8 Class Initialized
INFO - 2019-05-28 07:48:06 --> URI Class Initialized
DEBUG - 2019-05-28 07:48:06 --> No URI present. Default controller set.
INFO - 2019-05-28 07:48:06 --> Router Class Initialized
INFO - 2019-05-28 07:48:06 --> Output Class Initialized
INFO - 2019-05-28 07:48:06 --> Security Class Initialized
DEBUG - 2019-05-28 07:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:48:06 --> Input Class Initialized
INFO - 2019-05-28 07:48:06 --> Language Class Initialized
INFO - 2019-05-28 07:48:06 --> Language Class Initialized
INFO - 2019-05-28 07:48:06 --> Config Class Initialized
INFO - 2019-05-28 07:48:06 --> Loader Class Initialized
INFO - 2019-05-28 07:48:06 --> Helper loaded: form_helper
INFO - 2019-05-28 07:48:06 --> Helper loaded: url_helper
INFO - 2019-05-28 07:48:06 --> Helper loaded: cookie_helper
INFO - 2019-05-28 07:48:06 --> Database Driver Class Initialized
DEBUG - 2019-05-28 07:48:06 --> Template library initialized
INFO - 2019-05-28 07:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 07:48:06 --> Controller Class Initialized
DEBUG - 2019-05-28 07:48:06 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 07:48:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 07:48:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 07:48:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 07:48:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 07:48:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 07:48:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 07:48:07 --> Final output sent to browser
DEBUG - 2019-05-28 07:48:07 --> Total execution time: 0.0501
INFO - 2019-05-28 07:48:07 --> Config Class Initialized
INFO - 2019-05-28 07:48:07 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:48:07 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:48:07 --> Utf8 Class Initialized
INFO - 2019-05-28 07:48:07 --> URI Class Initialized
INFO - 2019-05-28 07:48:07 --> Router Class Initialized
INFO - 2019-05-28 07:48:07 --> Output Class Initialized
INFO - 2019-05-28 07:48:07 --> Security Class Initialized
DEBUG - 2019-05-28 07:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:48:07 --> Input Class Initialized
INFO - 2019-05-28 07:48:07 --> Language Class Initialized
ERROR - 2019-05-28 07:48:07 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:48:07 --> Config Class Initialized
INFO - 2019-05-28 07:48:07 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:48:07 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:48:07 --> Utf8 Class Initialized
INFO - 2019-05-28 07:48:07 --> URI Class Initialized
INFO - 2019-05-28 07:48:07 --> Router Class Initialized
INFO - 2019-05-28 07:48:07 --> Output Class Initialized
INFO - 2019-05-28 07:48:07 --> Security Class Initialized
DEBUG - 2019-05-28 07:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:48:07 --> Input Class Initialized
INFO - 2019-05-28 07:48:07 --> Language Class Initialized
ERROR - 2019-05-28 07:48:07 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:48:07 --> Config Class Initialized
INFO - 2019-05-28 07:48:07 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:48:07 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:48:07 --> Utf8 Class Initialized
INFO - 2019-05-28 07:48:07 --> URI Class Initialized
INFO - 2019-05-28 07:48:07 --> Router Class Initialized
INFO - 2019-05-28 07:48:07 --> Output Class Initialized
INFO - 2019-05-28 07:48:07 --> Security Class Initialized
DEBUG - 2019-05-28 07:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:48:07 --> Input Class Initialized
INFO - 2019-05-28 07:48:07 --> Language Class Initialized
ERROR - 2019-05-28 07:48:07 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:48:07 --> Config Class Initialized
INFO - 2019-05-28 07:48:07 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:48:07 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:48:07 --> Utf8 Class Initialized
INFO - 2019-05-28 07:48:07 --> URI Class Initialized
DEBUG - 2019-05-28 07:48:07 --> No URI present. Default controller set.
INFO - 2019-05-28 07:48:07 --> Router Class Initialized
INFO - 2019-05-28 07:48:07 --> Output Class Initialized
INFO - 2019-05-28 07:48:07 --> Security Class Initialized
DEBUG - 2019-05-28 07:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:48:07 --> Input Class Initialized
INFO - 2019-05-28 07:48:07 --> Language Class Initialized
INFO - 2019-05-28 07:48:07 --> Language Class Initialized
INFO - 2019-05-28 07:48:07 --> Config Class Initialized
INFO - 2019-05-28 07:48:07 --> Loader Class Initialized
INFO - 2019-05-28 07:48:07 --> Helper loaded: form_helper
INFO - 2019-05-28 07:48:07 --> Helper loaded: url_helper
INFO - 2019-05-28 07:48:07 --> Helper loaded: cookie_helper
INFO - 2019-05-28 07:48:07 --> Database Driver Class Initialized
DEBUG - 2019-05-28 07:48:07 --> Template library initialized
INFO - 2019-05-28 07:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 07:48:07 --> Controller Class Initialized
DEBUG - 2019-05-28 07:48:07 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 07:48:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 07:48:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 07:48:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 07:48:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 07:48:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 07:48:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 07:48:08 --> Final output sent to browser
DEBUG - 2019-05-28 07:48:08 --> Total execution time: 0.0447
INFO - 2019-05-28 07:48:11 --> Config Class Initialized
INFO - 2019-05-28 07:48:11 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:48:11 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:48:11 --> Utf8 Class Initialized
INFO - 2019-05-28 07:48:11 --> URI Class Initialized
DEBUG - 2019-05-28 07:48:11 --> No URI present. Default controller set.
INFO - 2019-05-28 07:48:11 --> Router Class Initialized
INFO - 2019-05-28 07:48:11 --> Output Class Initialized
INFO - 2019-05-28 07:48:11 --> Security Class Initialized
DEBUG - 2019-05-28 07:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:48:11 --> Input Class Initialized
INFO - 2019-05-28 07:48:11 --> Language Class Initialized
INFO - 2019-05-28 07:48:11 --> Language Class Initialized
INFO - 2019-05-28 07:48:11 --> Config Class Initialized
INFO - 2019-05-28 07:48:11 --> Loader Class Initialized
INFO - 2019-05-28 07:48:11 --> Helper loaded: form_helper
INFO - 2019-05-28 07:48:11 --> Helper loaded: url_helper
INFO - 2019-05-28 07:48:11 --> Helper loaded: cookie_helper
INFO - 2019-05-28 07:48:11 --> Database Driver Class Initialized
DEBUG - 2019-05-28 07:48:11 --> Template library initialized
INFO - 2019-05-28 07:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 07:48:11 --> Controller Class Initialized
DEBUG - 2019-05-28 07:48:11 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 07:48:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 07:48:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 07:48:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 07:48:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 07:48:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 07:48:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 07:48:11 --> Final output sent to browser
DEBUG - 2019-05-28 07:48:11 --> Total execution time: 0.0441
INFO - 2019-05-28 07:48:12 --> Config Class Initialized
INFO - 2019-05-28 07:48:12 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:48:12 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:48:12 --> Utf8 Class Initialized
INFO - 2019-05-28 07:48:12 --> URI Class Initialized
INFO - 2019-05-28 07:48:12 --> Config Class Initialized
INFO - 2019-05-28 07:48:12 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:48:12 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:48:12 --> Utf8 Class Initialized
INFO - 2019-05-28 07:48:12 --> URI Class Initialized
INFO - 2019-05-28 07:48:12 --> Router Class Initialized
INFO - 2019-05-28 07:48:12 --> Config Class Initialized
INFO - 2019-05-28 07:48:12 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:48:12 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:48:12 --> Utf8 Class Initialized
INFO - 2019-05-28 07:48:12 --> URI Class Initialized
INFO - 2019-05-28 07:48:12 --> Router Class Initialized
INFO - 2019-05-28 07:48:12 --> Router Class Initialized
INFO - 2019-05-28 07:48:12 --> Output Class Initialized
INFO - 2019-05-28 07:48:12 --> Security Class Initialized
DEBUG - 2019-05-28 07:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:48:12 --> Input Class Initialized
INFO - 2019-05-28 07:48:12 --> Language Class Initialized
ERROR - 2019-05-28 07:48:12 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:48:12 --> Output Class Initialized
INFO - 2019-05-28 07:48:12 --> Security Class Initialized
DEBUG - 2019-05-28 07:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:48:12 --> Input Class Initialized
INFO - 2019-05-28 07:48:12 --> Language Class Initialized
ERROR - 2019-05-28 07:48:12 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:48:12 --> Output Class Initialized
INFO - 2019-05-28 07:48:12 --> Security Class Initialized
DEBUG - 2019-05-28 07:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:48:12 --> Input Class Initialized
INFO - 2019-05-28 07:48:12 --> Language Class Initialized
ERROR - 2019-05-28 07:48:12 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:48:13 --> Config Class Initialized
INFO - 2019-05-28 07:48:13 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:48:13 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:48:13 --> Utf8 Class Initialized
INFO - 2019-05-28 07:48:13 --> URI Class Initialized
INFO - 2019-05-28 07:48:13 --> Router Class Initialized
INFO - 2019-05-28 07:48:13 --> Output Class Initialized
INFO - 2019-05-28 07:48:13 --> Security Class Initialized
DEBUG - 2019-05-28 07:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:48:13 --> Input Class Initialized
INFO - 2019-05-28 07:48:13 --> Language Class Initialized
INFO - 2019-05-28 07:48:13 --> Language Class Initialized
INFO - 2019-05-28 07:48:13 --> Config Class Initialized
INFO - 2019-05-28 07:48:13 --> Loader Class Initialized
INFO - 2019-05-28 07:48:13 --> Helper loaded: form_helper
INFO - 2019-05-28 07:48:13 --> Helper loaded: url_helper
INFO - 2019-05-28 07:48:13 --> Helper loaded: cookie_helper
INFO - 2019-05-28 07:48:13 --> Database Driver Class Initialized
DEBUG - 2019-05-28 07:48:13 --> Template library initialized
INFO - 2019-05-28 07:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 07:48:13 --> Controller Class Initialized
DEBUG - 2019-05-28 07:48:13 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 07:48:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 07:48:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/mobile.php
DEBUG - 2019-05-28 07:48:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 07:48:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 07:48:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 07:48:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 07:48:13 --> Final output sent to browser
DEBUG - 2019-05-28 07:48:13 --> Total execution time: 0.0522
INFO - 2019-05-28 07:48:13 --> Config Class Initialized
INFO - 2019-05-28 07:48:13 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:48:13 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:48:13 --> Utf8 Class Initialized
INFO - 2019-05-28 07:48:13 --> URI Class Initialized
INFO - 2019-05-28 07:48:13 --> Config Class Initialized
INFO - 2019-05-28 07:48:13 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:48:13 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:48:13 --> Utf8 Class Initialized
INFO - 2019-05-28 07:48:13 --> URI Class Initialized
INFO - 2019-05-28 07:48:13 --> Config Class Initialized
INFO - 2019-05-28 07:48:13 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:48:13 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:48:13 --> Utf8 Class Initialized
INFO - 2019-05-28 07:48:13 --> URI Class Initialized
INFO - 2019-05-28 07:48:13 --> Router Class Initialized
INFO - 2019-05-28 07:48:13 --> Router Class Initialized
INFO - 2019-05-28 07:48:13 --> Output Class Initialized
INFO - 2019-05-28 07:48:13 --> Security Class Initialized
DEBUG - 2019-05-28 07:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:48:13 --> Input Class Initialized
INFO - 2019-05-28 07:48:13 --> Language Class Initialized
ERROR - 2019-05-28 07:48:13 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:48:13 --> Router Class Initialized
INFO - 2019-05-28 07:48:13 --> Output Class Initialized
INFO - 2019-05-28 07:48:13 --> Security Class Initialized
DEBUG - 2019-05-28 07:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:48:13 --> Input Class Initialized
INFO - 2019-05-28 07:48:13 --> Language Class Initialized
ERROR - 2019-05-28 07:48:13 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:48:13 --> Output Class Initialized
INFO - 2019-05-28 07:48:13 --> Security Class Initialized
DEBUG - 2019-05-28 07:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:48:13 --> Input Class Initialized
INFO - 2019-05-28 07:48:13 --> Language Class Initialized
ERROR - 2019-05-28 07:48:13 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:48:18 --> Config Class Initialized
INFO - 2019-05-28 07:48:18 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:48:18 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:48:18 --> Utf8 Class Initialized
INFO - 2019-05-28 07:48:18 --> URI Class Initialized
INFO - 2019-05-28 07:48:18 --> Router Class Initialized
INFO - 2019-05-28 07:48:18 --> Output Class Initialized
INFO - 2019-05-28 07:48:18 --> Security Class Initialized
DEBUG - 2019-05-28 07:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:48:18 --> Input Class Initialized
INFO - 2019-05-28 07:48:18 --> Language Class Initialized
INFO - 2019-05-28 07:48:18 --> Language Class Initialized
INFO - 2019-05-28 07:48:18 --> Config Class Initialized
INFO - 2019-05-28 07:48:18 --> Loader Class Initialized
INFO - 2019-05-28 07:48:18 --> Helper loaded: form_helper
INFO - 2019-05-28 07:48:18 --> Helper loaded: url_helper
INFO - 2019-05-28 07:48:18 --> Helper loaded: cookie_helper
INFO - 2019-05-28 07:48:18 --> Database Driver Class Initialized
DEBUG - 2019-05-28 07:48:18 --> Template library initialized
INFO - 2019-05-28 07:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 07:48:18 --> Controller Class Initialized
DEBUG - 2019-05-28 07:48:18 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 07:48:18 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 07:48:18 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/pay-institute-fee.php
DEBUG - 2019-05-28 07:48:18 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 07:48:18 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 07:48:18 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 07:48:18 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 07:48:18 --> Final output sent to browser
DEBUG - 2019-05-28 07:48:18 --> Total execution time: 0.0452
INFO - 2019-05-28 07:48:19 --> Config Class Initialized
INFO - 2019-05-28 07:48:19 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:48:19 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:48:19 --> Utf8 Class Initialized
INFO - 2019-05-28 07:48:19 --> URI Class Initialized
INFO - 2019-05-28 07:48:19 --> Router Class Initialized
INFO - 2019-05-28 07:48:19 --> Output Class Initialized
INFO - 2019-05-28 07:48:19 --> Security Class Initialized
DEBUG - 2019-05-28 07:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:48:19 --> Input Class Initialized
INFO - 2019-05-28 07:48:19 --> Language Class Initialized
ERROR - 2019-05-28 07:48:19 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:48:19 --> Config Class Initialized
INFO - 2019-05-28 07:48:19 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:48:19 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:48:19 --> Utf8 Class Initialized
INFO - 2019-05-28 07:48:19 --> URI Class Initialized
INFO - 2019-05-28 07:48:19 --> Config Class Initialized
INFO - 2019-05-28 07:48:19 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:48:19 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:48:19 --> Utf8 Class Initialized
INFO - 2019-05-28 07:48:19 --> URI Class Initialized
INFO - 2019-05-28 07:48:19 --> Router Class Initialized
INFO - 2019-05-28 07:48:19 --> Router Class Initialized
INFO - 2019-05-28 07:48:19 --> Output Class Initialized
INFO - 2019-05-28 07:48:19 --> Security Class Initialized
DEBUG - 2019-05-28 07:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:48:19 --> Input Class Initialized
INFO - 2019-05-28 07:48:19 --> Language Class Initialized
ERROR - 2019-05-28 07:48:19 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:48:19 --> Output Class Initialized
INFO - 2019-05-28 07:48:19 --> Security Class Initialized
DEBUG - 2019-05-28 07:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:48:19 --> Input Class Initialized
INFO - 2019-05-28 07:48:19 --> Language Class Initialized
ERROR - 2019-05-28 07:48:19 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:48:23 --> Config Class Initialized
INFO - 2019-05-28 07:48:23 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:48:23 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:48:23 --> Utf8 Class Initialized
INFO - 2019-05-28 07:48:23 --> URI Class Initialized
INFO - 2019-05-28 07:48:23 --> Router Class Initialized
INFO - 2019-05-28 07:48:23 --> Output Class Initialized
INFO - 2019-05-28 07:48:23 --> Security Class Initialized
DEBUG - 2019-05-28 07:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:48:23 --> Input Class Initialized
INFO - 2019-05-28 07:48:23 --> Language Class Initialized
INFO - 2019-05-28 07:48:23 --> Language Class Initialized
INFO - 2019-05-28 07:48:23 --> Config Class Initialized
INFO - 2019-05-28 07:48:23 --> Loader Class Initialized
INFO - 2019-05-28 07:48:23 --> Helper loaded: form_helper
INFO - 2019-05-28 07:48:23 --> Helper loaded: url_helper
INFO - 2019-05-28 07:48:23 --> Helper loaded: cookie_helper
INFO - 2019-05-28 07:48:23 --> Database Driver Class Initialized
DEBUG - 2019-05-28 07:48:23 --> Template library initialized
INFO - 2019-05-28 07:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 07:48:23 --> Controller Class Initialized
DEBUG - 2019-05-28 07:48:23 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 07:48:23 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 07:48:23 --> Final output sent to browser
DEBUG - 2019-05-28 07:48:23 --> Total execution time: 0.0372
INFO - 2019-05-28 07:58:01 --> Config Class Initialized
INFO - 2019-05-28 07:58:01 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:58:01 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:58:01 --> Utf8 Class Initialized
INFO - 2019-05-28 07:58:01 --> URI Class Initialized
DEBUG - 2019-05-28 07:58:01 --> No URI present. Default controller set.
INFO - 2019-05-28 07:58:01 --> Router Class Initialized
INFO - 2019-05-28 07:58:01 --> Output Class Initialized
INFO - 2019-05-28 07:58:01 --> Security Class Initialized
DEBUG - 2019-05-28 07:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:58:01 --> Input Class Initialized
INFO - 2019-05-28 07:58:01 --> Language Class Initialized
INFO - 2019-05-28 07:58:01 --> Language Class Initialized
INFO - 2019-05-28 07:58:01 --> Config Class Initialized
INFO - 2019-05-28 07:58:01 --> Loader Class Initialized
INFO - 2019-05-28 07:58:01 --> Helper loaded: form_helper
INFO - 2019-05-28 07:58:01 --> Helper loaded: url_helper
INFO - 2019-05-28 07:58:01 --> Helper loaded: cookie_helper
INFO - 2019-05-28 07:58:01 --> Database Driver Class Initialized
DEBUG - 2019-05-28 07:58:01 --> Template library initialized
INFO - 2019-05-28 07:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 07:58:01 --> Controller Class Initialized
DEBUG - 2019-05-28 07:58:01 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 07:58:01 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 07:58:01 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 07:58:01 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 07:58:01 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 07:58:01 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 07:58:01 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 07:58:01 --> Final output sent to browser
DEBUG - 2019-05-28 07:58:01 --> Total execution time: 0.0466
INFO - 2019-05-28 07:58:02 --> Config Class Initialized
INFO - 2019-05-28 07:58:02 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:58:02 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:58:02 --> Utf8 Class Initialized
INFO - 2019-05-28 07:58:02 --> URI Class Initialized
INFO - 2019-05-28 07:58:02 --> Router Class Initialized
INFO - 2019-05-28 07:58:02 --> Output Class Initialized
INFO - 2019-05-28 07:58:02 --> Security Class Initialized
DEBUG - 2019-05-28 07:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:58:02 --> Input Class Initialized
INFO - 2019-05-28 07:58:02 --> Language Class Initialized
ERROR - 2019-05-28 07:58:02 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:58:03 --> Config Class Initialized
INFO - 2019-05-28 07:58:03 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:58:03 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:58:03 --> Utf8 Class Initialized
INFO - 2019-05-28 07:58:03 --> URI Class Initialized
INFO - 2019-05-28 07:58:03 --> Router Class Initialized
INFO - 2019-05-28 07:58:03 --> Output Class Initialized
INFO - 2019-05-28 07:58:03 --> Security Class Initialized
DEBUG - 2019-05-28 07:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:58:03 --> Input Class Initialized
INFO - 2019-05-28 07:58:03 --> Language Class Initialized
ERROR - 2019-05-28 07:58:03 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:58:03 --> Config Class Initialized
INFO - 2019-05-28 07:58:03 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:58:03 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:58:03 --> Utf8 Class Initialized
INFO - 2019-05-28 07:58:03 --> URI Class Initialized
INFO - 2019-05-28 07:58:03 --> Router Class Initialized
INFO - 2019-05-28 07:58:03 --> Output Class Initialized
INFO - 2019-05-28 07:58:03 --> Security Class Initialized
DEBUG - 2019-05-28 07:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:58:03 --> Input Class Initialized
INFO - 2019-05-28 07:58:03 --> Language Class Initialized
ERROR - 2019-05-28 07:58:03 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:58:04 --> Config Class Initialized
INFO - 2019-05-28 07:58:04 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:58:04 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:58:04 --> Utf8 Class Initialized
INFO - 2019-05-28 07:58:04 --> URI Class Initialized
INFO - 2019-05-28 07:58:04 --> Router Class Initialized
INFO - 2019-05-28 07:58:04 --> Output Class Initialized
INFO - 2019-05-28 07:58:04 --> Security Class Initialized
DEBUG - 2019-05-28 07:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:58:04 --> Input Class Initialized
INFO - 2019-05-28 07:58:04 --> Language Class Initialized
ERROR - 2019-05-28 07:58:04 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:58:04 --> Config Class Initialized
INFO - 2019-05-28 07:58:04 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:58:04 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:58:04 --> Utf8 Class Initialized
INFO - 2019-05-28 07:58:04 --> URI Class Initialized
INFO - 2019-05-28 07:58:04 --> Router Class Initialized
INFO - 2019-05-28 07:58:04 --> Output Class Initialized
INFO - 2019-05-28 07:58:04 --> Security Class Initialized
DEBUG - 2019-05-28 07:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:58:04 --> Input Class Initialized
INFO - 2019-05-28 07:58:04 --> Language Class Initialized
ERROR - 2019-05-28 07:58:04 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:58:04 --> Config Class Initialized
INFO - 2019-05-28 07:58:04 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:58:04 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:58:04 --> Utf8 Class Initialized
INFO - 2019-05-28 07:58:04 --> URI Class Initialized
INFO - 2019-05-28 07:58:04 --> Router Class Initialized
INFO - 2019-05-28 07:58:04 --> Output Class Initialized
INFO - 2019-05-28 07:58:04 --> Security Class Initialized
DEBUG - 2019-05-28 07:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:58:04 --> Input Class Initialized
INFO - 2019-05-28 07:58:04 --> Language Class Initialized
ERROR - 2019-05-28 07:58:04 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:58:05 --> Config Class Initialized
INFO - 2019-05-28 07:58:05 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:58:05 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:58:05 --> Utf8 Class Initialized
INFO - 2019-05-28 07:58:05 --> URI Class Initialized
INFO - 2019-05-28 07:58:05 --> Router Class Initialized
INFO - 2019-05-28 07:58:05 --> Output Class Initialized
INFO - 2019-05-28 07:58:05 --> Security Class Initialized
DEBUG - 2019-05-28 07:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:58:05 --> Input Class Initialized
INFO - 2019-05-28 07:58:05 --> Language Class Initialized
ERROR - 2019-05-28 07:58:05 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:58:05 --> Config Class Initialized
INFO - 2019-05-28 07:58:05 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:58:05 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:58:05 --> Utf8 Class Initialized
INFO - 2019-05-28 07:58:05 --> URI Class Initialized
INFO - 2019-05-28 07:58:05 --> Router Class Initialized
INFO - 2019-05-28 07:58:05 --> Output Class Initialized
INFO - 2019-05-28 07:58:05 --> Security Class Initialized
DEBUG - 2019-05-28 07:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:58:05 --> Input Class Initialized
INFO - 2019-05-28 07:58:05 --> Language Class Initialized
ERROR - 2019-05-28 07:58:05 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:58:05 --> Config Class Initialized
INFO - 2019-05-28 07:58:05 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:58:05 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:58:05 --> Utf8 Class Initialized
INFO - 2019-05-28 07:58:05 --> URI Class Initialized
INFO - 2019-05-28 07:58:05 --> Router Class Initialized
INFO - 2019-05-28 07:58:05 --> Output Class Initialized
INFO - 2019-05-28 07:58:05 --> Security Class Initialized
DEBUG - 2019-05-28 07:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:58:05 --> Input Class Initialized
INFO - 2019-05-28 07:58:05 --> Language Class Initialized
ERROR - 2019-05-28 07:58:05 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:58:05 --> Config Class Initialized
INFO - 2019-05-28 07:58:05 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:58:05 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:58:05 --> Utf8 Class Initialized
INFO - 2019-05-28 07:58:05 --> URI Class Initialized
INFO - 2019-05-28 07:58:05 --> Router Class Initialized
INFO - 2019-05-28 07:58:05 --> Output Class Initialized
INFO - 2019-05-28 07:58:05 --> Security Class Initialized
DEBUG - 2019-05-28 07:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:58:05 --> Input Class Initialized
INFO - 2019-05-28 07:58:05 --> Language Class Initialized
ERROR - 2019-05-28 07:58:05 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:58:06 --> Config Class Initialized
INFO - 2019-05-28 07:58:06 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:58:06 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:58:06 --> Utf8 Class Initialized
INFO - 2019-05-28 07:58:06 --> URI Class Initialized
INFO - 2019-05-28 07:58:06 --> Router Class Initialized
INFO - 2019-05-28 07:58:06 --> Output Class Initialized
INFO - 2019-05-28 07:58:06 --> Security Class Initialized
DEBUG - 2019-05-28 07:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:58:06 --> Input Class Initialized
INFO - 2019-05-28 07:58:06 --> Language Class Initialized
ERROR - 2019-05-28 07:58:06 --> 404 Page Not Found: /index
INFO - 2019-05-28 07:58:06 --> Config Class Initialized
INFO - 2019-05-28 07:58:06 --> Hooks Class Initialized
DEBUG - 2019-05-28 07:58:06 --> UTF-8 Support Enabled
INFO - 2019-05-28 07:58:06 --> Utf8 Class Initialized
INFO - 2019-05-28 07:58:06 --> URI Class Initialized
INFO - 2019-05-28 07:58:06 --> Router Class Initialized
INFO - 2019-05-28 07:58:06 --> Output Class Initialized
INFO - 2019-05-28 07:58:06 --> Security Class Initialized
DEBUG - 2019-05-28 07:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 07:58:06 --> Input Class Initialized
INFO - 2019-05-28 07:58:06 --> Language Class Initialized
ERROR - 2019-05-28 07:58:06 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:03:12 --> Config Class Initialized
INFO - 2019-05-28 08:03:12 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:03:12 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:03:12 --> Utf8 Class Initialized
INFO - 2019-05-28 08:03:12 --> URI Class Initialized
DEBUG - 2019-05-28 08:03:12 --> No URI present. Default controller set.
INFO - 2019-05-28 08:03:12 --> Router Class Initialized
INFO - 2019-05-28 08:03:12 --> Output Class Initialized
INFO - 2019-05-28 08:03:12 --> Security Class Initialized
DEBUG - 2019-05-28 08:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:03:12 --> Input Class Initialized
INFO - 2019-05-28 08:03:12 --> Language Class Initialized
INFO - 2019-05-28 08:03:12 --> Language Class Initialized
INFO - 2019-05-28 08:03:12 --> Config Class Initialized
INFO - 2019-05-28 08:03:12 --> Loader Class Initialized
INFO - 2019-05-28 08:03:12 --> Helper loaded: form_helper
INFO - 2019-05-28 08:03:12 --> Helper loaded: url_helper
INFO - 2019-05-28 08:03:12 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:03:12 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:03:12 --> Template library initialized
INFO - 2019-05-28 08:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:03:12 --> Controller Class Initialized
DEBUG - 2019-05-28 08:03:12 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 08:03:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 08:03:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 08:03:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 08:03:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 08:03:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 08:03:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 08:03:12 --> Final output sent to browser
DEBUG - 2019-05-28 08:03:12 --> Total execution time: 0.0457
INFO - 2019-05-28 08:03:13 --> Config Class Initialized
INFO - 2019-05-28 08:03:13 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:03:13 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:03:13 --> Utf8 Class Initialized
INFO - 2019-05-28 08:03:13 --> URI Class Initialized
DEBUG - 2019-05-28 08:03:13 --> No URI present. Default controller set.
INFO - 2019-05-28 08:03:13 --> Router Class Initialized
INFO - 2019-05-28 08:03:13 --> Output Class Initialized
INFO - 2019-05-28 08:03:13 --> Security Class Initialized
DEBUG - 2019-05-28 08:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:03:13 --> Input Class Initialized
INFO - 2019-05-28 08:03:13 --> Language Class Initialized
INFO - 2019-05-28 08:03:13 --> Language Class Initialized
INFO - 2019-05-28 08:03:13 --> Config Class Initialized
INFO - 2019-05-28 08:03:13 --> Loader Class Initialized
INFO - 2019-05-28 08:03:13 --> Helper loaded: form_helper
INFO - 2019-05-28 08:03:13 --> Helper loaded: url_helper
INFO - 2019-05-28 08:03:13 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:03:13 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:03:13 --> Template library initialized
INFO - 2019-05-28 08:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:03:13 --> Controller Class Initialized
DEBUG - 2019-05-28 08:03:13 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 08:03:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 08:03:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 08:03:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 08:03:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 08:03:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 08:03:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 08:03:13 --> Final output sent to browser
DEBUG - 2019-05-28 08:03:13 --> Total execution time: 0.0451
INFO - 2019-05-28 08:03:13 --> Config Class Initialized
INFO - 2019-05-28 08:03:13 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:03:13 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:03:13 --> Utf8 Class Initialized
INFO - 2019-05-28 08:03:13 --> URI Class Initialized
INFO - 2019-05-28 08:03:13 --> Router Class Initialized
INFO - 2019-05-28 08:03:13 --> Output Class Initialized
INFO - 2019-05-28 08:03:13 --> Security Class Initialized
DEBUG - 2019-05-28 08:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:03:13 --> Input Class Initialized
INFO - 2019-05-28 08:03:13 --> Language Class Initialized
ERROR - 2019-05-28 08:03:13 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:03:13 --> Config Class Initialized
INFO - 2019-05-28 08:03:13 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:03:13 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:03:13 --> Utf8 Class Initialized
INFO - 2019-05-28 08:03:14 --> URI Class Initialized
INFO - 2019-05-28 08:03:14 --> Router Class Initialized
INFO - 2019-05-28 08:03:14 --> Output Class Initialized
INFO - 2019-05-28 08:03:14 --> Security Class Initialized
DEBUG - 2019-05-28 08:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:03:14 --> Input Class Initialized
INFO - 2019-05-28 08:03:14 --> Language Class Initialized
ERROR - 2019-05-28 08:03:14 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:03:14 --> Config Class Initialized
INFO - 2019-05-28 08:03:14 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:03:14 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:03:14 --> Utf8 Class Initialized
INFO - 2019-05-28 08:03:14 --> URI Class Initialized
INFO - 2019-05-28 08:03:14 --> Router Class Initialized
INFO - 2019-05-28 08:03:14 --> Output Class Initialized
INFO - 2019-05-28 08:03:14 --> Security Class Initialized
DEBUG - 2019-05-28 08:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:03:14 --> Input Class Initialized
INFO - 2019-05-28 08:03:14 --> Language Class Initialized
ERROR - 2019-05-28 08:03:14 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:04:44 --> Config Class Initialized
INFO - 2019-05-28 08:04:44 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:04:44 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:04:44 --> Utf8 Class Initialized
INFO - 2019-05-28 08:04:44 --> URI Class Initialized
DEBUG - 2019-05-28 08:04:44 --> No URI present. Default controller set.
INFO - 2019-05-28 08:04:44 --> Router Class Initialized
INFO - 2019-05-28 08:04:44 --> Output Class Initialized
INFO - 2019-05-28 08:04:44 --> Security Class Initialized
DEBUG - 2019-05-28 08:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:04:44 --> Input Class Initialized
INFO - 2019-05-28 08:04:44 --> Language Class Initialized
INFO - 2019-05-28 08:04:44 --> Language Class Initialized
INFO - 2019-05-28 08:04:44 --> Config Class Initialized
INFO - 2019-05-28 08:04:44 --> Loader Class Initialized
INFO - 2019-05-28 08:04:44 --> Helper loaded: form_helper
INFO - 2019-05-28 08:04:44 --> Helper loaded: url_helper
INFO - 2019-05-28 08:04:44 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:04:44 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:04:44 --> Template library initialized
INFO - 2019-05-28 08:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:04:44 --> Controller Class Initialized
DEBUG - 2019-05-28 08:04:44 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 08:04:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 08:04:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 08:04:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 08:04:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 08:04:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 08:04:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 08:04:44 --> Final output sent to browser
DEBUG - 2019-05-28 08:04:44 --> Total execution time: 0.0673
INFO - 2019-05-28 08:04:44 --> Config Class Initialized
INFO - 2019-05-28 08:04:44 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:04:44 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:04:44 --> Utf8 Class Initialized
INFO - 2019-05-28 08:04:44 --> URI Class Initialized
INFO - 2019-05-28 08:04:44 --> Router Class Initialized
INFO - 2019-05-28 08:04:44 --> Output Class Initialized
INFO - 2019-05-28 08:04:44 --> Security Class Initialized
DEBUG - 2019-05-28 08:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:04:44 --> Input Class Initialized
INFO - 2019-05-28 08:04:44 --> Language Class Initialized
ERROR - 2019-05-28 08:04:44 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:04:45 --> Config Class Initialized
INFO - 2019-05-28 08:04:45 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:04:45 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:04:45 --> Utf8 Class Initialized
INFO - 2019-05-28 08:04:45 --> URI Class Initialized
INFO - 2019-05-28 08:04:45 --> Router Class Initialized
INFO - 2019-05-28 08:04:45 --> Output Class Initialized
INFO - 2019-05-28 08:04:45 --> Security Class Initialized
DEBUG - 2019-05-28 08:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:04:45 --> Input Class Initialized
INFO - 2019-05-28 08:04:45 --> Language Class Initialized
ERROR - 2019-05-28 08:04:45 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:04:45 --> Config Class Initialized
INFO - 2019-05-28 08:04:45 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:04:45 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:04:45 --> Utf8 Class Initialized
INFO - 2019-05-28 08:04:45 --> URI Class Initialized
INFO - 2019-05-28 08:04:45 --> Router Class Initialized
INFO - 2019-05-28 08:04:45 --> Output Class Initialized
INFO - 2019-05-28 08:04:45 --> Security Class Initialized
DEBUG - 2019-05-28 08:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:04:45 --> Input Class Initialized
INFO - 2019-05-28 08:04:45 --> Language Class Initialized
ERROR - 2019-05-28 08:04:45 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:13:58 --> Config Class Initialized
INFO - 2019-05-28 08:13:58 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:13:58 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:13:58 --> Utf8 Class Initialized
INFO - 2019-05-28 08:13:58 --> URI Class Initialized
INFO - 2019-05-28 08:13:58 --> Router Class Initialized
INFO - 2019-05-28 08:13:58 --> Output Class Initialized
INFO - 2019-05-28 08:13:58 --> Security Class Initialized
DEBUG - 2019-05-28 08:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:13:58 --> Input Class Initialized
INFO - 2019-05-28 08:13:58 --> Language Class Initialized
INFO - 2019-05-28 08:13:58 --> Language Class Initialized
INFO - 2019-05-28 08:13:58 --> Config Class Initialized
INFO - 2019-05-28 08:13:58 --> Loader Class Initialized
INFO - 2019-05-28 08:13:58 --> Helper loaded: form_helper
INFO - 2019-05-28 08:13:58 --> Helper loaded: url_helper
INFO - 2019-05-28 08:13:58 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:13:58 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:13:58 --> Template library initialized
INFO - 2019-05-28 08:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:13:58 --> Controller Class Initialized
DEBUG - 2019-05-28 08:13:58 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:13:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:13:58 --> Final output sent to browser
DEBUG - 2019-05-28 08:13:58 --> Total execution time: 0.0381
INFO - 2019-05-28 08:15:11 --> Config Class Initialized
INFO - 2019-05-28 08:15:11 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:15:11 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:15:11 --> Utf8 Class Initialized
INFO - 2019-05-28 08:15:11 --> URI Class Initialized
DEBUG - 2019-05-28 08:15:11 --> No URI present. Default controller set.
INFO - 2019-05-28 08:15:11 --> Router Class Initialized
INFO - 2019-05-28 08:15:11 --> Output Class Initialized
INFO - 2019-05-28 08:15:11 --> Security Class Initialized
DEBUG - 2019-05-28 08:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:15:11 --> Input Class Initialized
INFO - 2019-05-28 08:15:11 --> Language Class Initialized
INFO - 2019-05-28 08:15:11 --> Language Class Initialized
INFO - 2019-05-28 08:15:11 --> Config Class Initialized
INFO - 2019-05-28 08:15:11 --> Loader Class Initialized
INFO - 2019-05-28 08:15:11 --> Helper loaded: form_helper
INFO - 2019-05-28 08:15:11 --> Helper loaded: url_helper
INFO - 2019-05-28 08:15:11 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:15:11 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:15:11 --> Template library initialized
INFO - 2019-05-28 08:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:15:11 --> Controller Class Initialized
DEBUG - 2019-05-28 08:15:11 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 08:15:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 08:15:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 08:15:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 08:15:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 08:15:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 08:15:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 08:15:12 --> Final output sent to browser
DEBUG - 2019-05-28 08:15:12 --> Total execution time: 0.0454
INFO - 2019-05-28 08:15:12 --> Config Class Initialized
INFO - 2019-05-28 08:15:12 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:15:12 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:15:12 --> Utf8 Class Initialized
INFO - 2019-05-28 08:15:12 --> URI Class Initialized
INFO - 2019-05-28 08:15:12 --> Config Class Initialized
INFO - 2019-05-28 08:15:12 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:15:12 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:15:12 --> Utf8 Class Initialized
INFO - 2019-05-28 08:15:12 --> URI Class Initialized
INFO - 2019-05-28 08:15:12 --> Router Class Initialized
INFO - 2019-05-28 08:15:12 --> Output Class Initialized
INFO - 2019-05-28 08:15:12 --> Security Class Initialized
DEBUG - 2019-05-28 08:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:15:12 --> Input Class Initialized
INFO - 2019-05-28 08:15:12 --> Language Class Initialized
ERROR - 2019-05-28 08:15:12 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:15:12 --> Router Class Initialized
INFO - 2019-05-28 08:15:12 --> Output Class Initialized
INFO - 2019-05-28 08:15:12 --> Security Class Initialized
DEBUG - 2019-05-28 08:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:15:12 --> Input Class Initialized
INFO - 2019-05-28 08:15:12 --> Language Class Initialized
ERROR - 2019-05-28 08:15:12 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:15:12 --> Config Class Initialized
INFO - 2019-05-28 08:15:12 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:15:12 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:15:12 --> Utf8 Class Initialized
INFO - 2019-05-28 08:15:12 --> URI Class Initialized
INFO - 2019-05-28 08:15:12 --> Router Class Initialized
INFO - 2019-05-28 08:15:12 --> Output Class Initialized
INFO - 2019-05-28 08:15:12 --> Security Class Initialized
DEBUG - 2019-05-28 08:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:15:12 --> Input Class Initialized
INFO - 2019-05-28 08:15:12 --> Language Class Initialized
ERROR - 2019-05-28 08:15:12 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:15:37 --> Config Class Initialized
INFO - 2019-05-28 08:15:37 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:15:37 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:15:37 --> Utf8 Class Initialized
INFO - 2019-05-28 08:15:37 --> URI Class Initialized
INFO - 2019-05-28 08:15:37 --> Router Class Initialized
INFO - 2019-05-28 08:15:37 --> Output Class Initialized
INFO - 2019-05-28 08:15:37 --> Security Class Initialized
DEBUG - 2019-05-28 08:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:15:37 --> Input Class Initialized
INFO - 2019-05-28 08:15:37 --> Language Class Initialized
INFO - 2019-05-28 08:15:37 --> Language Class Initialized
INFO - 2019-05-28 08:15:37 --> Config Class Initialized
INFO - 2019-05-28 08:15:37 --> Loader Class Initialized
INFO - 2019-05-28 08:15:37 --> Helper loaded: form_helper
INFO - 2019-05-28 08:15:37 --> Helper loaded: url_helper
INFO - 2019-05-28 08:15:37 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:15:37 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:15:37 --> Template library initialized
INFO - 2019-05-28 08:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:15:37 --> Controller Class Initialized
DEBUG - 2019-05-28 08:15:37 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:15:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:15:37 --> Final output sent to browser
DEBUG - 2019-05-28 08:15:37 --> Total execution time: 0.0367
INFO - 2019-05-28 08:16:26 --> Config Class Initialized
INFO - 2019-05-28 08:16:26 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:16:26 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:16:26 --> Utf8 Class Initialized
INFO - 2019-05-28 08:16:26 --> URI Class Initialized
INFO - 2019-05-28 08:16:26 --> Router Class Initialized
INFO - 2019-05-28 08:16:26 --> Output Class Initialized
INFO - 2019-05-28 08:16:26 --> Security Class Initialized
DEBUG - 2019-05-28 08:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:16:26 --> Input Class Initialized
INFO - 2019-05-28 08:16:26 --> Language Class Initialized
INFO - 2019-05-28 08:16:26 --> Language Class Initialized
INFO - 2019-05-28 08:16:26 --> Config Class Initialized
INFO - 2019-05-28 08:16:26 --> Loader Class Initialized
INFO - 2019-05-28 08:16:26 --> Helper loaded: form_helper
INFO - 2019-05-28 08:16:26 --> Helper loaded: url_helper
INFO - 2019-05-28 08:16:26 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:16:26 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:16:26 --> Template library initialized
INFO - 2019-05-28 08:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:16:26 --> Controller Class Initialized
DEBUG - 2019-05-28 08:16:26 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:16:26 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
ERROR - 2019-05-28 08:16:26 --> Severity: Error --> Call to undefined method Api_model::varifyOtpCodeSignup() /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/controllers/Api.php 18
INFO - 2019-05-28 08:16:30 --> Config Class Initialized
INFO - 2019-05-28 08:16:30 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:16:30 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:16:30 --> Utf8 Class Initialized
INFO - 2019-05-28 08:16:30 --> URI Class Initialized
INFO - 2019-05-28 08:16:30 --> Router Class Initialized
INFO - 2019-05-28 08:16:30 --> Output Class Initialized
INFO - 2019-05-28 08:16:30 --> Security Class Initialized
DEBUG - 2019-05-28 08:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:16:30 --> Input Class Initialized
INFO - 2019-05-28 08:16:30 --> Language Class Initialized
ERROR - 2019-05-28 08:16:30 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:16:30 --> Config Class Initialized
INFO - 2019-05-28 08:16:30 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:16:30 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:16:30 --> Utf8 Class Initialized
INFO - 2019-05-28 08:16:30 --> URI Class Initialized
INFO - 2019-05-28 08:16:30 --> Router Class Initialized
INFO - 2019-05-28 08:16:30 --> Output Class Initialized
INFO - 2019-05-28 08:16:30 --> Security Class Initialized
DEBUG - 2019-05-28 08:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:16:30 --> Input Class Initialized
INFO - 2019-05-28 08:16:30 --> Language Class Initialized
ERROR - 2019-05-28 08:16:30 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:16:30 --> Config Class Initialized
INFO - 2019-05-28 08:16:30 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:16:30 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:16:30 --> Utf8 Class Initialized
INFO - 2019-05-28 08:16:30 --> URI Class Initialized
INFO - 2019-05-28 08:16:30 --> Router Class Initialized
INFO - 2019-05-28 08:16:30 --> Output Class Initialized
INFO - 2019-05-28 08:16:30 --> Security Class Initialized
DEBUG - 2019-05-28 08:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:16:30 --> Input Class Initialized
INFO - 2019-05-28 08:16:30 --> Language Class Initialized
ERROR - 2019-05-28 08:16:30 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:16:35 --> Config Class Initialized
INFO - 2019-05-28 08:16:35 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:16:35 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:16:35 --> Utf8 Class Initialized
INFO - 2019-05-28 08:16:35 --> URI Class Initialized
INFO - 2019-05-28 08:16:35 --> Router Class Initialized
INFO - 2019-05-28 08:16:35 --> Output Class Initialized
INFO - 2019-05-28 08:16:35 --> Security Class Initialized
DEBUG - 2019-05-28 08:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:16:35 --> Input Class Initialized
INFO - 2019-05-28 08:16:35 --> Language Class Initialized
INFO - 2019-05-28 08:16:35 --> Language Class Initialized
INFO - 2019-05-28 08:16:35 --> Config Class Initialized
INFO - 2019-05-28 08:16:35 --> Loader Class Initialized
INFO - 2019-05-28 08:16:35 --> Helper loaded: form_helper
INFO - 2019-05-28 08:16:35 --> Helper loaded: url_helper
INFO - 2019-05-28 08:16:35 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:16:35 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:16:35 --> Template library initialized
INFO - 2019-05-28 08:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:16:35 --> Controller Class Initialized
DEBUG - 2019-05-28 08:16:35 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:16:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
ERROR - 2019-05-28 08:16:35 --> Severity: Error --> Call to undefined method Api_model::varifyOtpCodeSignup() /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/controllers/Api.php 18
INFO - 2019-05-28 08:16:40 --> Config Class Initialized
INFO - 2019-05-28 08:16:40 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:16:40 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:16:40 --> Utf8 Class Initialized
INFO - 2019-05-28 08:16:40 --> URI Class Initialized
INFO - 2019-05-28 08:16:40 --> Router Class Initialized
INFO - 2019-05-28 08:16:40 --> Output Class Initialized
INFO - 2019-05-28 08:16:40 --> Security Class Initialized
DEBUG - 2019-05-28 08:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:16:40 --> Input Class Initialized
INFO - 2019-05-28 08:16:40 --> Language Class Initialized
INFO - 2019-05-28 08:16:40 --> Language Class Initialized
INFO - 2019-05-28 08:16:40 --> Config Class Initialized
INFO - 2019-05-28 08:16:40 --> Loader Class Initialized
INFO - 2019-05-28 08:16:40 --> Helper loaded: form_helper
INFO - 2019-05-28 08:16:40 --> Helper loaded: url_helper
INFO - 2019-05-28 08:16:40 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:16:40 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:16:40 --> Template library initialized
INFO - 2019-05-28 08:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:16:40 --> Controller Class Initialized
DEBUG - 2019-05-28 08:16:40 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:16:40 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
ERROR - 2019-05-28 08:16:40 --> Severity: Error --> Call to undefined method Api_model::varifyOtpCodeSignup() /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/controllers/Api.php 18
INFO - 2019-05-28 08:16:41 --> Config Class Initialized
INFO - 2019-05-28 08:16:41 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:16:41 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:16:41 --> Utf8 Class Initialized
INFO - 2019-05-28 08:16:41 --> URI Class Initialized
INFO - 2019-05-28 08:16:41 --> Router Class Initialized
INFO - 2019-05-28 08:16:41 --> Output Class Initialized
INFO - 2019-05-28 08:16:41 --> Security Class Initialized
DEBUG - 2019-05-28 08:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:16:41 --> Input Class Initialized
INFO - 2019-05-28 08:16:41 --> Language Class Initialized
ERROR - 2019-05-28 08:16:41 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:18:22 --> Config Class Initialized
INFO - 2019-05-28 08:18:22 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:18:22 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:18:22 --> Utf8 Class Initialized
INFO - 2019-05-28 08:18:22 --> URI Class Initialized
INFO - 2019-05-28 08:18:22 --> Router Class Initialized
INFO - 2019-05-28 08:18:22 --> Output Class Initialized
INFO - 2019-05-28 08:18:22 --> Security Class Initialized
DEBUG - 2019-05-28 08:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:18:22 --> Input Class Initialized
INFO - 2019-05-28 08:18:22 --> Language Class Initialized
INFO - 2019-05-28 08:18:22 --> Language Class Initialized
INFO - 2019-05-28 08:18:22 --> Config Class Initialized
INFO - 2019-05-28 08:18:22 --> Loader Class Initialized
INFO - 2019-05-28 08:18:22 --> Helper loaded: form_helper
INFO - 2019-05-28 08:18:22 --> Helper loaded: url_helper
INFO - 2019-05-28 08:18:22 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:18:22 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:18:22 --> Template library initialized
INFO - 2019-05-28 08:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:18:22 --> Controller Class Initialized
DEBUG - 2019-05-28 08:18:22 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:18:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:18:51 --> Config Class Initialized
INFO - 2019-05-28 08:18:51 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:18:51 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:18:51 --> Utf8 Class Initialized
INFO - 2019-05-28 08:18:51 --> URI Class Initialized
INFO - 2019-05-28 08:18:51 --> Router Class Initialized
INFO - 2019-05-28 08:18:51 --> Output Class Initialized
INFO - 2019-05-28 08:18:51 --> Security Class Initialized
DEBUG - 2019-05-28 08:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:18:51 --> Input Class Initialized
INFO - 2019-05-28 08:18:51 --> Language Class Initialized
INFO - 2019-05-28 08:18:51 --> Language Class Initialized
INFO - 2019-05-28 08:18:51 --> Config Class Initialized
INFO - 2019-05-28 08:18:51 --> Loader Class Initialized
INFO - 2019-05-28 08:18:51 --> Helper loaded: form_helper
INFO - 2019-05-28 08:18:51 --> Helper loaded: url_helper
INFO - 2019-05-28 08:18:51 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:18:51 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:18:51 --> Template library initialized
INFO - 2019-05-28 08:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:18:51 --> Controller Class Initialized
DEBUG - 2019-05-28 08:18:51 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:18:51 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:18:56 --> Config Class Initialized
INFO - 2019-05-28 08:18:56 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:18:56 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:18:56 --> Utf8 Class Initialized
INFO - 2019-05-28 08:18:56 --> URI Class Initialized
INFO - 2019-05-28 08:18:56 --> Router Class Initialized
INFO - 2019-05-28 08:18:56 --> Output Class Initialized
INFO - 2019-05-28 08:18:56 --> Security Class Initialized
DEBUG - 2019-05-28 08:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:18:56 --> Input Class Initialized
INFO - 2019-05-28 08:18:56 --> Language Class Initialized
INFO - 2019-05-28 08:18:56 --> Language Class Initialized
INFO - 2019-05-28 08:18:56 --> Config Class Initialized
INFO - 2019-05-28 08:18:56 --> Loader Class Initialized
INFO - 2019-05-28 08:18:56 --> Helper loaded: form_helper
INFO - 2019-05-28 08:18:56 --> Helper loaded: url_helper
INFO - 2019-05-28 08:18:56 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:18:56 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:18:56 --> Template library initialized
INFO - 2019-05-28 08:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:18:56 --> Controller Class Initialized
DEBUG - 2019-05-28 08:18:56 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:18:56 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:19:04 --> Config Class Initialized
INFO - 2019-05-28 08:19:04 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:19:04 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:19:04 --> Utf8 Class Initialized
INFO - 2019-05-28 08:19:04 --> URI Class Initialized
INFO - 2019-05-28 08:19:04 --> Router Class Initialized
INFO - 2019-05-28 08:19:04 --> Output Class Initialized
INFO - 2019-05-28 08:19:04 --> Security Class Initialized
DEBUG - 2019-05-28 08:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:19:04 --> Input Class Initialized
INFO - 2019-05-28 08:19:04 --> Language Class Initialized
INFO - 2019-05-28 08:19:04 --> Language Class Initialized
INFO - 2019-05-28 08:19:04 --> Config Class Initialized
INFO - 2019-05-28 08:19:04 --> Loader Class Initialized
INFO - 2019-05-28 08:19:04 --> Helper loaded: form_helper
INFO - 2019-05-28 08:19:04 --> Helper loaded: url_helper
INFO - 2019-05-28 08:19:04 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:19:04 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:19:04 --> Template library initialized
INFO - 2019-05-28 08:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:19:04 --> Controller Class Initialized
DEBUG - 2019-05-28 08:19:04 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:19:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:19:48 --> Config Class Initialized
INFO - 2019-05-28 08:19:48 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:19:48 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:19:48 --> Utf8 Class Initialized
INFO - 2019-05-28 08:19:48 --> URI Class Initialized
INFO - 2019-05-28 08:19:48 --> Router Class Initialized
INFO - 2019-05-28 08:19:48 --> Output Class Initialized
INFO - 2019-05-28 08:19:48 --> Security Class Initialized
DEBUG - 2019-05-28 08:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:19:48 --> Input Class Initialized
INFO - 2019-05-28 08:19:48 --> Language Class Initialized
INFO - 2019-05-28 08:19:48 --> Language Class Initialized
INFO - 2019-05-28 08:19:48 --> Config Class Initialized
INFO - 2019-05-28 08:19:48 --> Loader Class Initialized
INFO - 2019-05-28 08:19:48 --> Helper loaded: form_helper
INFO - 2019-05-28 08:19:48 --> Helper loaded: url_helper
INFO - 2019-05-28 08:19:48 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:19:48 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:19:48 --> Template library initialized
INFO - 2019-05-28 08:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:19:48 --> Controller Class Initialized
DEBUG - 2019-05-28 08:19:48 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:19:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:20:08 --> Config Class Initialized
INFO - 2019-05-28 08:20:08 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:20:08 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:20:08 --> Utf8 Class Initialized
INFO - 2019-05-28 08:20:08 --> URI Class Initialized
INFO - 2019-05-28 08:20:08 --> Router Class Initialized
INFO - 2019-05-28 08:20:08 --> Output Class Initialized
INFO - 2019-05-28 08:20:08 --> Security Class Initialized
DEBUG - 2019-05-28 08:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:20:08 --> Input Class Initialized
INFO - 2019-05-28 08:20:08 --> Language Class Initialized
INFO - 2019-05-28 08:20:08 --> Language Class Initialized
INFO - 2019-05-28 08:20:08 --> Config Class Initialized
INFO - 2019-05-28 08:20:08 --> Loader Class Initialized
INFO - 2019-05-28 08:20:08 --> Helper loaded: form_helper
INFO - 2019-05-28 08:20:08 --> Helper loaded: url_helper
INFO - 2019-05-28 08:20:08 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:20:08 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:20:08 --> Template library initialized
INFO - 2019-05-28 08:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:20:08 --> Controller Class Initialized
DEBUG - 2019-05-28 08:20:08 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:20:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:20:36 --> Config Class Initialized
INFO - 2019-05-28 08:20:36 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:20:36 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:20:36 --> Utf8 Class Initialized
INFO - 2019-05-28 08:20:36 --> URI Class Initialized
INFO - 2019-05-28 08:20:36 --> Router Class Initialized
INFO - 2019-05-28 08:20:36 --> Output Class Initialized
INFO - 2019-05-28 08:20:36 --> Security Class Initialized
DEBUG - 2019-05-28 08:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:20:36 --> Input Class Initialized
INFO - 2019-05-28 08:20:36 --> Language Class Initialized
INFO - 2019-05-28 08:20:36 --> Language Class Initialized
INFO - 2019-05-28 08:20:36 --> Config Class Initialized
INFO - 2019-05-28 08:20:36 --> Loader Class Initialized
INFO - 2019-05-28 08:20:36 --> Helper loaded: form_helper
INFO - 2019-05-28 08:20:36 --> Helper loaded: url_helper
INFO - 2019-05-28 08:20:36 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:20:36 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:20:36 --> Template library initialized
INFO - 2019-05-28 08:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:20:36 --> Controller Class Initialized
DEBUG - 2019-05-28 08:20:36 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:20:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:20:44 --> Config Class Initialized
INFO - 2019-05-28 08:20:44 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:20:44 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:20:44 --> Utf8 Class Initialized
INFO - 2019-05-28 08:20:44 --> URI Class Initialized
DEBUG - 2019-05-28 08:20:44 --> No URI present. Default controller set.
INFO - 2019-05-28 08:20:44 --> Router Class Initialized
INFO - 2019-05-28 08:20:44 --> Output Class Initialized
INFO - 2019-05-28 08:20:44 --> Security Class Initialized
DEBUG - 2019-05-28 08:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:20:44 --> Input Class Initialized
INFO - 2019-05-28 08:20:44 --> Language Class Initialized
INFO - 2019-05-28 08:20:44 --> Language Class Initialized
INFO - 2019-05-28 08:20:44 --> Config Class Initialized
INFO - 2019-05-28 08:20:44 --> Loader Class Initialized
INFO - 2019-05-28 08:20:44 --> Helper loaded: form_helper
INFO - 2019-05-28 08:20:44 --> Helper loaded: url_helper
INFO - 2019-05-28 08:20:44 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:20:44 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:20:44 --> Template library initialized
INFO - 2019-05-28 08:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:20:44 --> Controller Class Initialized
DEBUG - 2019-05-28 08:20:44 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 08:20:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 08:20:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 08:20:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 08:20:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 08:20:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 08:20:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 08:20:45 --> Final output sent to browser
DEBUG - 2019-05-28 08:20:45 --> Total execution time: 0.0474
INFO - 2019-05-28 08:20:45 --> Config Class Initialized
INFO - 2019-05-28 08:20:45 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:20:45 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:20:45 --> Utf8 Class Initialized
INFO - 2019-05-28 08:20:45 --> URI Class Initialized
INFO - 2019-05-28 08:20:45 --> Config Class Initialized
INFO - 2019-05-28 08:20:45 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:20:45 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:20:45 --> Utf8 Class Initialized
INFO - 2019-05-28 08:20:45 --> URI Class Initialized
INFO - 2019-05-28 08:20:45 --> Router Class Initialized
INFO - 2019-05-28 08:20:45 --> Config Class Initialized
INFO - 2019-05-28 08:20:45 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:20:45 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:20:45 --> Utf8 Class Initialized
INFO - 2019-05-28 08:20:45 --> URI Class Initialized
INFO - 2019-05-28 08:20:45 --> Router Class Initialized
INFO - 2019-05-28 08:20:45 --> Router Class Initialized
INFO - 2019-05-28 08:20:45 --> Output Class Initialized
INFO - 2019-05-28 08:20:45 --> Security Class Initialized
DEBUG - 2019-05-28 08:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:20:45 --> Input Class Initialized
INFO - 2019-05-28 08:20:45 --> Language Class Initialized
ERROR - 2019-05-28 08:20:45 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:20:45 --> Output Class Initialized
INFO - 2019-05-28 08:20:45 --> Security Class Initialized
DEBUG - 2019-05-28 08:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:20:45 --> Input Class Initialized
INFO - 2019-05-28 08:20:45 --> Language Class Initialized
ERROR - 2019-05-28 08:20:45 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:20:45 --> Output Class Initialized
INFO - 2019-05-28 08:20:45 --> Security Class Initialized
DEBUG - 2019-05-28 08:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:20:45 --> Input Class Initialized
INFO - 2019-05-28 08:20:45 --> Language Class Initialized
ERROR - 2019-05-28 08:20:45 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:21:20 --> Config Class Initialized
INFO - 2019-05-28 08:21:20 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:21:20 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:21:20 --> Utf8 Class Initialized
INFO - 2019-05-28 08:21:20 --> URI Class Initialized
INFO - 2019-05-28 08:21:20 --> Router Class Initialized
INFO - 2019-05-28 08:21:20 --> Output Class Initialized
INFO - 2019-05-28 08:21:20 --> Security Class Initialized
DEBUG - 2019-05-28 08:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:21:20 --> Input Class Initialized
INFO - 2019-05-28 08:21:20 --> Language Class Initialized
INFO - 2019-05-28 08:21:20 --> Language Class Initialized
INFO - 2019-05-28 08:21:20 --> Config Class Initialized
INFO - 2019-05-28 08:21:20 --> Loader Class Initialized
INFO - 2019-05-28 08:21:20 --> Helper loaded: form_helper
INFO - 2019-05-28 08:21:20 --> Helper loaded: url_helper
INFO - 2019-05-28 08:21:20 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:21:20 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:21:20 --> Template library initialized
INFO - 2019-05-28 08:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:21:20 --> Controller Class Initialized
DEBUG - 2019-05-28 08:21:20 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:21:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:21:20 --> Final output sent to browser
DEBUG - 2019-05-28 08:21:20 --> Total execution time: 0.0384
INFO - 2019-05-28 08:21:42 --> Config Class Initialized
INFO - 2019-05-28 08:21:42 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:21:42 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:21:42 --> Utf8 Class Initialized
INFO - 2019-05-28 08:21:42 --> URI Class Initialized
INFO - 2019-05-28 08:21:42 --> Router Class Initialized
INFO - 2019-05-28 08:21:42 --> Output Class Initialized
INFO - 2019-05-28 08:21:42 --> Security Class Initialized
DEBUG - 2019-05-28 08:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:21:42 --> Input Class Initialized
INFO - 2019-05-28 08:21:42 --> Language Class Initialized
INFO - 2019-05-28 08:21:42 --> Language Class Initialized
INFO - 2019-05-28 08:21:42 --> Config Class Initialized
INFO - 2019-05-28 08:21:42 --> Loader Class Initialized
INFO - 2019-05-28 08:21:42 --> Helper loaded: form_helper
INFO - 2019-05-28 08:21:42 --> Helper loaded: url_helper
INFO - 2019-05-28 08:21:42 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:21:42 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:21:42 --> Template library initialized
INFO - 2019-05-28 08:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:21:42 --> Controller Class Initialized
DEBUG - 2019-05-28 08:21:42 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:21:42 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:21:46 --> Config Class Initialized
INFO - 2019-05-28 08:21:46 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:21:46 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:21:46 --> Utf8 Class Initialized
INFO - 2019-05-28 08:21:46 --> URI Class Initialized
INFO - 2019-05-28 08:21:46 --> Router Class Initialized
INFO - 2019-05-28 08:21:46 --> Output Class Initialized
INFO - 2019-05-28 08:21:46 --> Security Class Initialized
DEBUG - 2019-05-28 08:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:21:46 --> Input Class Initialized
INFO - 2019-05-28 08:21:46 --> Language Class Initialized
INFO - 2019-05-28 08:21:46 --> Language Class Initialized
INFO - 2019-05-28 08:21:46 --> Config Class Initialized
INFO - 2019-05-28 08:21:46 --> Loader Class Initialized
INFO - 2019-05-28 08:21:46 --> Helper loaded: form_helper
INFO - 2019-05-28 08:21:46 --> Helper loaded: url_helper
INFO - 2019-05-28 08:21:46 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:21:46 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:21:46 --> Template library initialized
INFO - 2019-05-28 08:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:21:46 --> Controller Class Initialized
DEBUG - 2019-05-28 08:21:46 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:21:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:21:54 --> Config Class Initialized
INFO - 2019-05-28 08:21:54 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:21:54 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:21:54 --> Utf8 Class Initialized
INFO - 2019-05-28 08:21:54 --> URI Class Initialized
INFO - 2019-05-28 08:21:54 --> Router Class Initialized
INFO - 2019-05-28 08:21:54 --> Output Class Initialized
INFO - 2019-05-28 08:21:54 --> Security Class Initialized
DEBUG - 2019-05-28 08:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:21:54 --> Input Class Initialized
INFO - 2019-05-28 08:21:54 --> Language Class Initialized
INFO - 2019-05-28 08:21:54 --> Language Class Initialized
INFO - 2019-05-28 08:21:54 --> Config Class Initialized
INFO - 2019-05-28 08:21:54 --> Loader Class Initialized
INFO - 2019-05-28 08:21:54 --> Helper loaded: form_helper
INFO - 2019-05-28 08:21:54 --> Helper loaded: url_helper
INFO - 2019-05-28 08:21:54 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:21:54 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:21:54 --> Template library initialized
INFO - 2019-05-28 08:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:21:54 --> Controller Class Initialized
DEBUG - 2019-05-28 08:21:54 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:21:54 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:22:45 --> Config Class Initialized
INFO - 2019-05-28 08:22:45 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:22:45 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:22:45 --> Utf8 Class Initialized
INFO - 2019-05-28 08:22:45 --> URI Class Initialized
INFO - 2019-05-28 08:22:45 --> Router Class Initialized
INFO - 2019-05-28 08:22:45 --> Output Class Initialized
INFO - 2019-05-28 08:22:45 --> Security Class Initialized
DEBUG - 2019-05-28 08:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:22:45 --> Input Class Initialized
INFO - 2019-05-28 08:22:45 --> Language Class Initialized
INFO - 2019-05-28 08:22:45 --> Language Class Initialized
INFO - 2019-05-28 08:22:45 --> Config Class Initialized
INFO - 2019-05-28 08:22:45 --> Loader Class Initialized
INFO - 2019-05-28 08:22:45 --> Helper loaded: form_helper
INFO - 2019-05-28 08:22:45 --> Helper loaded: url_helper
INFO - 2019-05-28 08:22:45 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:22:45 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:22:45 --> Template library initialized
INFO - 2019-05-28 08:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:22:45 --> Controller Class Initialized
DEBUG - 2019-05-28 08:22:45 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:22:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
ERROR - 2019-05-28 08:22:45 --> Severity: Error --> Call to undefined method Api_model::varifyOtpCodeSignup() /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/controllers/Api.php 18
INFO - 2019-05-28 08:25:06 --> Config Class Initialized
INFO - 2019-05-28 08:25:06 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:25:06 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:25:06 --> Utf8 Class Initialized
INFO - 2019-05-28 08:25:06 --> URI Class Initialized
INFO - 2019-05-28 08:25:06 --> Router Class Initialized
INFO - 2019-05-28 08:25:06 --> Output Class Initialized
INFO - 2019-05-28 08:25:06 --> Security Class Initialized
DEBUG - 2019-05-28 08:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:25:06 --> Input Class Initialized
INFO - 2019-05-28 08:25:06 --> Language Class Initialized
INFO - 2019-05-28 08:25:06 --> Language Class Initialized
INFO - 2019-05-28 08:25:06 --> Config Class Initialized
INFO - 2019-05-28 08:25:06 --> Loader Class Initialized
INFO - 2019-05-28 08:25:06 --> Helper loaded: form_helper
INFO - 2019-05-28 08:25:06 --> Helper loaded: url_helper
INFO - 2019-05-28 08:25:06 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:25:06 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:25:06 --> Template library initialized
INFO - 2019-05-28 08:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:25:06 --> Controller Class Initialized
DEBUG - 2019-05-28 08:25:06 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:25:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
ERROR - 2019-05-28 08:25:06 --> Severity: Error --> Call to undefined method Api_model::updateOtpStatusSignup() /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/controllers/Api.php 21
INFO - 2019-05-28 08:25:32 --> Config Class Initialized
INFO - 2019-05-28 08:25:32 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:25:32 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:25:32 --> Utf8 Class Initialized
INFO - 2019-05-28 08:25:32 --> URI Class Initialized
INFO - 2019-05-28 08:25:32 --> Router Class Initialized
INFO - 2019-05-28 08:25:32 --> Output Class Initialized
INFO - 2019-05-28 08:25:32 --> Security Class Initialized
DEBUG - 2019-05-28 08:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:25:32 --> Input Class Initialized
INFO - 2019-05-28 08:25:32 --> Language Class Initialized
INFO - 2019-05-28 08:25:32 --> Language Class Initialized
INFO - 2019-05-28 08:25:32 --> Config Class Initialized
INFO - 2019-05-28 08:25:32 --> Loader Class Initialized
INFO - 2019-05-28 08:25:32 --> Helper loaded: form_helper
INFO - 2019-05-28 08:25:32 --> Helper loaded: url_helper
INFO - 2019-05-28 08:25:32 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:25:32 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:25:32 --> Template library initialized
INFO - 2019-05-28 08:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:25:32 --> Controller Class Initialized
DEBUG - 2019-05-28 08:25:32 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:25:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:25:32 --> Final output sent to browser
DEBUG - 2019-05-28 08:25:32 --> Total execution time: 0.0371
INFO - 2019-05-28 08:25:38 --> Config Class Initialized
INFO - 2019-05-28 08:25:38 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:25:38 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:25:38 --> Utf8 Class Initialized
INFO - 2019-05-28 08:25:38 --> URI Class Initialized
INFO - 2019-05-28 08:25:38 --> Router Class Initialized
INFO - 2019-05-28 08:25:38 --> Output Class Initialized
INFO - 2019-05-28 08:25:38 --> Security Class Initialized
DEBUG - 2019-05-28 08:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:25:38 --> Input Class Initialized
INFO - 2019-05-28 08:25:38 --> Language Class Initialized
INFO - 2019-05-28 08:25:38 --> Language Class Initialized
INFO - 2019-05-28 08:25:38 --> Config Class Initialized
INFO - 2019-05-28 08:25:38 --> Loader Class Initialized
INFO - 2019-05-28 08:25:38 --> Helper loaded: form_helper
INFO - 2019-05-28 08:25:38 --> Helper loaded: url_helper
INFO - 2019-05-28 08:25:38 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:25:38 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:25:38 --> Template library initialized
INFO - 2019-05-28 08:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:25:38 --> Controller Class Initialized
DEBUG - 2019-05-28 08:25:38 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:25:38 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:25:38 --> Final output sent to browser
DEBUG - 2019-05-28 08:25:38 --> Total execution time: 0.0363
INFO - 2019-05-28 08:25:46 --> Config Class Initialized
INFO - 2019-05-28 08:25:46 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:25:46 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:25:46 --> Utf8 Class Initialized
INFO - 2019-05-28 08:25:46 --> URI Class Initialized
INFO - 2019-05-28 08:25:46 --> Router Class Initialized
INFO - 2019-05-28 08:25:46 --> Output Class Initialized
INFO - 2019-05-28 08:25:46 --> Security Class Initialized
DEBUG - 2019-05-28 08:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:25:46 --> Input Class Initialized
INFO - 2019-05-28 08:25:46 --> Language Class Initialized
INFO - 2019-05-28 08:25:46 --> Language Class Initialized
INFO - 2019-05-28 08:25:46 --> Config Class Initialized
INFO - 2019-05-28 08:25:46 --> Loader Class Initialized
INFO - 2019-05-28 08:25:46 --> Helper loaded: form_helper
INFO - 2019-05-28 08:25:46 --> Helper loaded: url_helper
INFO - 2019-05-28 08:25:46 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:25:46 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:25:46 --> Template library initialized
INFO - 2019-05-28 08:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:25:46 --> Controller Class Initialized
DEBUG - 2019-05-28 08:25:46 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:25:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:25:46 --> Final output sent to browser
DEBUG - 2019-05-28 08:25:46 --> Total execution time: 0.0399
INFO - 2019-05-28 08:25:54 --> Config Class Initialized
INFO - 2019-05-28 08:25:54 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:25:54 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:25:54 --> Utf8 Class Initialized
INFO - 2019-05-28 08:25:54 --> URI Class Initialized
INFO - 2019-05-28 08:25:54 --> Router Class Initialized
INFO - 2019-05-28 08:25:54 --> Output Class Initialized
INFO - 2019-05-28 08:25:54 --> Security Class Initialized
DEBUG - 2019-05-28 08:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:25:54 --> Input Class Initialized
INFO - 2019-05-28 08:25:54 --> Language Class Initialized
INFO - 2019-05-28 08:25:54 --> Language Class Initialized
INFO - 2019-05-28 08:25:54 --> Config Class Initialized
INFO - 2019-05-28 08:25:54 --> Loader Class Initialized
INFO - 2019-05-28 08:25:54 --> Helper loaded: form_helper
INFO - 2019-05-28 08:25:54 --> Helper loaded: url_helper
INFO - 2019-05-28 08:25:54 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:25:54 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:25:54 --> Template library initialized
INFO - 2019-05-28 08:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:25:54 --> Controller Class Initialized
DEBUG - 2019-05-28 08:25:54 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:25:54 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:25:54 --> Final output sent to browser
DEBUG - 2019-05-28 08:25:54 --> Total execution time: 0.0489
INFO - 2019-05-28 08:26:01 --> Config Class Initialized
INFO - 2019-05-28 08:26:01 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:26:01 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:26:01 --> Utf8 Class Initialized
INFO - 2019-05-28 08:26:01 --> URI Class Initialized
INFO - 2019-05-28 08:26:01 --> Router Class Initialized
INFO - 2019-05-28 08:26:01 --> Output Class Initialized
INFO - 2019-05-28 08:26:01 --> Security Class Initialized
DEBUG - 2019-05-28 08:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:26:01 --> Input Class Initialized
INFO - 2019-05-28 08:26:01 --> Language Class Initialized
INFO - 2019-05-28 08:26:01 --> Language Class Initialized
INFO - 2019-05-28 08:26:01 --> Config Class Initialized
INFO - 2019-05-28 08:26:01 --> Loader Class Initialized
INFO - 2019-05-28 08:26:01 --> Helper loaded: form_helper
INFO - 2019-05-28 08:26:01 --> Helper loaded: url_helper
INFO - 2019-05-28 08:26:01 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:26:01 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:26:01 --> Template library initialized
INFO - 2019-05-28 08:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:26:01 --> Controller Class Initialized
DEBUG - 2019-05-28 08:26:01 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:26:01 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:26:01 --> Final output sent to browser
DEBUG - 2019-05-28 08:26:01 --> Total execution time: 0.0357
INFO - 2019-05-28 08:26:07 --> Config Class Initialized
INFO - 2019-05-28 08:26:07 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:26:07 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:26:07 --> Utf8 Class Initialized
INFO - 2019-05-28 08:26:07 --> URI Class Initialized
DEBUG - 2019-05-28 08:26:07 --> No URI present. Default controller set.
INFO - 2019-05-28 08:26:07 --> Router Class Initialized
INFO - 2019-05-28 08:26:07 --> Output Class Initialized
INFO - 2019-05-28 08:26:07 --> Security Class Initialized
DEBUG - 2019-05-28 08:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:26:07 --> Input Class Initialized
INFO - 2019-05-28 08:26:07 --> Language Class Initialized
INFO - 2019-05-28 08:26:07 --> Language Class Initialized
INFO - 2019-05-28 08:26:07 --> Config Class Initialized
INFO - 2019-05-28 08:26:07 --> Loader Class Initialized
INFO - 2019-05-28 08:26:07 --> Helper loaded: form_helper
INFO - 2019-05-28 08:26:07 --> Helper loaded: url_helper
INFO - 2019-05-28 08:26:07 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:26:07 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:26:07 --> Template library initialized
INFO - 2019-05-28 08:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:26:07 --> Controller Class Initialized
DEBUG - 2019-05-28 08:26:07 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 08:26:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 08:26:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 08:26:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 08:26:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 08:26:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 08:26:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 08:26:08 --> Final output sent to browser
DEBUG - 2019-05-28 08:26:08 --> Total execution time: 0.0508
INFO - 2019-05-28 08:26:08 --> Config Class Initialized
INFO - 2019-05-28 08:26:08 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:26:08 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:26:08 --> Utf8 Class Initialized
INFO - 2019-05-28 08:26:08 --> URI Class Initialized
INFO - 2019-05-28 08:26:08 --> Config Class Initialized
INFO - 2019-05-28 08:26:08 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:26:08 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:26:08 --> Utf8 Class Initialized
INFO - 2019-05-28 08:26:08 --> URI Class Initialized
INFO - 2019-05-28 08:26:08 --> Router Class Initialized
INFO - 2019-05-28 08:26:08 --> Router Class Initialized
INFO - 2019-05-28 08:26:08 --> Output Class Initialized
INFO - 2019-05-28 08:26:08 --> Security Class Initialized
DEBUG - 2019-05-28 08:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:26:08 --> Input Class Initialized
INFO - 2019-05-28 08:26:08 --> Language Class Initialized
ERROR - 2019-05-28 08:26:08 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:26:08 --> Output Class Initialized
INFO - 2019-05-28 08:26:08 --> Security Class Initialized
DEBUG - 2019-05-28 08:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:26:08 --> Input Class Initialized
INFO - 2019-05-28 08:26:08 --> Language Class Initialized
ERROR - 2019-05-28 08:26:08 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:26:10 --> Config Class Initialized
INFO - 2019-05-28 08:26:10 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:26:10 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:26:10 --> Utf8 Class Initialized
INFO - 2019-05-28 08:26:10 --> URI Class Initialized
INFO - 2019-05-28 08:26:10 --> Router Class Initialized
INFO - 2019-05-28 08:26:10 --> Output Class Initialized
INFO - 2019-05-28 08:26:10 --> Security Class Initialized
DEBUG - 2019-05-28 08:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:26:10 --> Input Class Initialized
INFO - 2019-05-28 08:26:10 --> Language Class Initialized
ERROR - 2019-05-28 08:26:10 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:26:19 --> Config Class Initialized
INFO - 2019-05-28 08:26:19 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:26:19 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:26:19 --> Utf8 Class Initialized
INFO - 2019-05-28 08:26:19 --> URI Class Initialized
DEBUG - 2019-05-28 08:26:19 --> No URI present. Default controller set.
INFO - 2019-05-28 08:26:19 --> Router Class Initialized
INFO - 2019-05-28 08:26:19 --> Output Class Initialized
INFO - 2019-05-28 08:26:19 --> Security Class Initialized
DEBUG - 2019-05-28 08:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:26:19 --> Input Class Initialized
INFO - 2019-05-28 08:26:19 --> Language Class Initialized
INFO - 2019-05-28 08:26:19 --> Language Class Initialized
INFO - 2019-05-28 08:26:19 --> Config Class Initialized
INFO - 2019-05-28 08:26:19 --> Loader Class Initialized
INFO - 2019-05-28 08:26:19 --> Helper loaded: form_helper
INFO - 2019-05-28 08:26:19 --> Helper loaded: url_helper
INFO - 2019-05-28 08:26:19 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:26:19 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:26:19 --> Template library initialized
INFO - 2019-05-28 08:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:26:19 --> Controller Class Initialized
DEBUG - 2019-05-28 08:26:19 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 08:26:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 08:26:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 08:26:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 08:26:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 08:26:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 08:26:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 08:26:19 --> Config Class Initialized
INFO - 2019-05-28 08:26:19 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:26:19 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:26:19 --> Utf8 Class Initialized
INFO - 2019-05-28 08:26:19 --> URI Class Initialized
DEBUG - 2019-05-28 08:26:19 --> No URI present. Default controller set.
INFO - 2019-05-28 08:26:19 --> Router Class Initialized
INFO - 2019-05-28 08:26:19 --> Output Class Initialized
INFO - 2019-05-28 08:26:19 --> Security Class Initialized
DEBUG - 2019-05-28 08:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:26:19 --> Input Class Initialized
INFO - 2019-05-28 08:26:19 --> Language Class Initialized
INFO - 2019-05-28 08:26:19 --> Language Class Initialized
INFO - 2019-05-28 08:26:19 --> Config Class Initialized
INFO - 2019-05-28 08:26:19 --> Loader Class Initialized
INFO - 2019-05-28 08:26:19 --> Helper loaded: form_helper
INFO - 2019-05-28 08:26:19 --> Helper loaded: url_helper
INFO - 2019-05-28 08:26:19 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:26:19 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:26:19 --> Template library initialized
INFO - 2019-05-28 08:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:26:19 --> Controller Class Initialized
DEBUG - 2019-05-28 08:26:19 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 08:26:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 08:26:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 08:26:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 08:26:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 08:26:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 08:26:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 08:26:20 --> Final output sent to browser
DEBUG - 2019-05-28 08:26:20 --> Total execution time: 0.0446
INFO - 2019-05-28 08:26:20 --> Config Class Initialized
INFO - 2019-05-28 08:26:20 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:26:20 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:26:20 --> Utf8 Class Initialized
INFO - 2019-05-28 08:26:20 --> URI Class Initialized
INFO - 2019-05-28 08:26:20 --> Router Class Initialized
INFO - 2019-05-28 08:26:20 --> Output Class Initialized
INFO - 2019-05-28 08:26:20 --> Security Class Initialized
DEBUG - 2019-05-28 08:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:26:20 --> Input Class Initialized
INFO - 2019-05-28 08:26:20 --> Language Class Initialized
ERROR - 2019-05-28 08:26:20 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:26:21 --> Config Class Initialized
INFO - 2019-05-28 08:26:21 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:26:21 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:26:21 --> Utf8 Class Initialized
INFO - 2019-05-28 08:26:21 --> URI Class Initialized
INFO - 2019-05-28 08:26:21 --> Router Class Initialized
INFO - 2019-05-28 08:26:21 --> Output Class Initialized
INFO - 2019-05-28 08:26:21 --> Security Class Initialized
DEBUG - 2019-05-28 08:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:26:21 --> Input Class Initialized
INFO - 2019-05-28 08:26:21 --> Language Class Initialized
ERROR - 2019-05-28 08:26:21 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:26:21 --> Config Class Initialized
INFO - 2019-05-28 08:26:21 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:26:22 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:26:22 --> Utf8 Class Initialized
INFO - 2019-05-28 08:26:22 --> URI Class Initialized
INFO - 2019-05-28 08:26:22 --> Router Class Initialized
INFO - 2019-05-28 08:26:22 --> Output Class Initialized
INFO - 2019-05-28 08:26:22 --> Security Class Initialized
DEBUG - 2019-05-28 08:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:26:22 --> Input Class Initialized
INFO - 2019-05-28 08:26:22 --> Language Class Initialized
ERROR - 2019-05-28 08:26:22 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:26:23 --> Config Class Initialized
INFO - 2019-05-28 08:26:23 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:26:23 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:26:23 --> Utf8 Class Initialized
INFO - 2019-05-28 08:26:23 --> URI Class Initialized
INFO - 2019-05-28 08:26:23 --> Router Class Initialized
INFO - 2019-05-28 08:26:23 --> Output Class Initialized
INFO - 2019-05-28 08:26:23 --> Security Class Initialized
DEBUG - 2019-05-28 08:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:26:23 --> Input Class Initialized
INFO - 2019-05-28 08:26:23 --> Language Class Initialized
ERROR - 2019-05-28 08:26:23 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:30:12 --> Config Class Initialized
INFO - 2019-05-28 08:30:12 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:30:12 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:30:12 --> Utf8 Class Initialized
INFO - 2019-05-28 08:30:12 --> URI Class Initialized
DEBUG - 2019-05-28 08:30:12 --> No URI present. Default controller set.
INFO - 2019-05-28 08:30:12 --> Router Class Initialized
INFO - 2019-05-28 08:30:12 --> Output Class Initialized
INFO - 2019-05-28 08:30:12 --> Security Class Initialized
DEBUG - 2019-05-28 08:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:30:12 --> Input Class Initialized
INFO - 2019-05-28 08:30:12 --> Language Class Initialized
INFO - 2019-05-28 08:30:12 --> Language Class Initialized
INFO - 2019-05-28 08:30:12 --> Config Class Initialized
INFO - 2019-05-28 08:30:12 --> Loader Class Initialized
INFO - 2019-05-28 08:30:12 --> Helper loaded: form_helper
INFO - 2019-05-28 08:30:12 --> Helper loaded: url_helper
INFO - 2019-05-28 08:30:12 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:30:12 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:30:12 --> Template library initialized
INFO - 2019-05-28 08:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:30:12 --> Controller Class Initialized
DEBUG - 2019-05-28 08:30:12 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 08:30:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 08:30:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 08:30:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 08:30:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 08:30:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 08:30:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 08:30:13 --> Final output sent to browser
DEBUG - 2019-05-28 08:30:13 --> Total execution time: 0.0467
INFO - 2019-05-28 08:30:13 --> Config Class Initialized
INFO - 2019-05-28 08:30:13 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:30:13 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:30:13 --> Utf8 Class Initialized
INFO - 2019-05-28 08:30:13 --> URI Class Initialized
INFO - 2019-05-28 08:30:13 --> Config Class Initialized
INFO - 2019-05-28 08:30:13 --> Hooks Class Initialized
INFO - 2019-05-28 08:30:13 --> Config Class Initialized
INFO - 2019-05-28 08:30:13 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:30:13 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:30:13 --> Utf8 Class Initialized
INFO - 2019-05-28 08:30:13 --> URI Class Initialized
INFO - 2019-05-28 08:30:13 --> Router Class Initialized
INFO - 2019-05-28 08:30:13 --> Output Class Initialized
INFO - 2019-05-28 08:30:13 --> Security Class Initialized
DEBUG - 2019-05-28 08:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:30:13 --> Input Class Initialized
INFO - 2019-05-28 08:30:13 --> Language Class Initialized
INFO - 2019-05-28 08:30:13 --> Router Class Initialized
INFO - 2019-05-28 08:30:13 --> Output Class Initialized
INFO - 2019-05-28 08:30:13 --> Security Class Initialized
DEBUG - 2019-05-28 08:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:30:13 --> Input Class Initialized
INFO - 2019-05-28 08:30:13 --> Language Class Initialized
ERROR - 2019-05-28 08:30:13 --> 404 Page Not Found: /index
DEBUG - 2019-05-28 08:30:13 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:30:13 --> Utf8 Class Initialized
INFO - 2019-05-28 08:30:13 --> URI Class Initialized
INFO - 2019-05-28 08:30:13 --> Router Class Initialized
INFO - 2019-05-28 08:30:13 --> Output Class Initialized
INFO - 2019-05-28 08:30:13 --> Security Class Initialized
DEBUG - 2019-05-28 08:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:30:13 --> Input Class Initialized
ERROR - 2019-05-28 08:30:13 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:30:13 --> Language Class Initialized
ERROR - 2019-05-28 08:30:13 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:30:46 --> Config Class Initialized
INFO - 2019-05-28 08:30:46 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:30:46 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:30:46 --> Utf8 Class Initialized
INFO - 2019-05-28 08:30:46 --> URI Class Initialized
INFO - 2019-05-28 08:30:46 --> Router Class Initialized
INFO - 2019-05-28 08:30:46 --> Output Class Initialized
INFO - 2019-05-28 08:30:46 --> Security Class Initialized
DEBUG - 2019-05-28 08:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:30:46 --> Input Class Initialized
INFO - 2019-05-28 08:30:46 --> Language Class Initialized
INFO - 2019-05-28 08:30:46 --> Language Class Initialized
INFO - 2019-05-28 08:30:46 --> Config Class Initialized
INFO - 2019-05-28 08:30:46 --> Loader Class Initialized
INFO - 2019-05-28 08:30:46 --> Helper loaded: form_helper
INFO - 2019-05-28 08:30:46 --> Helper loaded: url_helper
INFO - 2019-05-28 08:30:46 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:30:46 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:30:46 --> Template library initialized
INFO - 2019-05-28 08:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:30:46 --> Controller Class Initialized
DEBUG - 2019-05-28 08:30:46 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:30:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:30:46 --> Final output sent to browser
DEBUG - 2019-05-28 08:30:46 --> Total execution time: 0.0408
INFO - 2019-05-28 08:31:24 --> Config Class Initialized
INFO - 2019-05-28 08:31:24 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:31:24 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:31:24 --> Utf8 Class Initialized
INFO - 2019-05-28 08:31:24 --> URI Class Initialized
INFO - 2019-05-28 08:31:24 --> Router Class Initialized
INFO - 2019-05-28 08:31:24 --> Output Class Initialized
INFO - 2019-05-28 08:31:24 --> Security Class Initialized
DEBUG - 2019-05-28 08:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:31:24 --> Input Class Initialized
INFO - 2019-05-28 08:31:24 --> Language Class Initialized
INFO - 2019-05-28 08:31:24 --> Language Class Initialized
INFO - 2019-05-28 08:31:24 --> Config Class Initialized
INFO - 2019-05-28 08:31:24 --> Loader Class Initialized
INFO - 2019-05-28 08:31:24 --> Helper loaded: form_helper
INFO - 2019-05-28 08:31:24 --> Helper loaded: url_helper
INFO - 2019-05-28 08:31:24 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:31:24 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:31:24 --> Template library initialized
INFO - 2019-05-28 08:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:31:24 --> Controller Class Initialized
DEBUG - 2019-05-28 08:31:24 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:31:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:31:24 --> Final output sent to browser
DEBUG - 2019-05-28 08:31:24 --> Total execution time: 0.0451
INFO - 2019-05-28 08:31:24 --> Config Class Initialized
INFO - 2019-05-28 08:31:24 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:31:24 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:31:24 --> Utf8 Class Initialized
INFO - 2019-05-28 08:31:24 --> URI Class Initialized
INFO - 2019-05-28 08:31:24 --> Router Class Initialized
INFO - 2019-05-28 08:31:24 --> Output Class Initialized
INFO - 2019-05-28 08:31:24 --> Security Class Initialized
DEBUG - 2019-05-28 08:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:31:24 --> Input Class Initialized
INFO - 2019-05-28 08:31:24 --> Language Class Initialized
INFO - 2019-05-28 08:31:24 --> Language Class Initialized
INFO - 2019-05-28 08:31:24 --> Config Class Initialized
INFO - 2019-05-28 08:31:24 --> Loader Class Initialized
INFO - 2019-05-28 08:31:24 --> Helper loaded: form_helper
INFO - 2019-05-28 08:31:24 --> Helper loaded: url_helper
INFO - 2019-05-28 08:31:24 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:31:24 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:31:24 --> Template library initialized
INFO - 2019-05-28 08:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:31:24 --> Controller Class Initialized
DEBUG - 2019-05-28 08:31:24 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 08:31:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 08:31:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 08:31:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 08:31:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 08:31:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 08:31:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 08:31:25 --> Final output sent to browser
DEBUG - 2019-05-28 08:31:25 --> Total execution time: 0.0460
INFO - 2019-05-28 08:31:25 --> Config Class Initialized
INFO - 2019-05-28 08:31:25 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:31:25 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:31:25 --> Utf8 Class Initialized
INFO - 2019-05-28 08:31:25 --> URI Class Initialized
INFO - 2019-05-28 08:31:25 --> Config Class Initialized
INFO - 2019-05-28 08:31:25 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:31:25 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:31:25 --> Utf8 Class Initialized
INFO - 2019-05-28 08:31:25 --> URI Class Initialized
INFO - 2019-05-28 08:31:25 --> Router Class Initialized
INFO - 2019-05-28 08:31:25 --> Config Class Initialized
INFO - 2019-05-28 08:31:25 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:31:25 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:31:25 --> Utf8 Class Initialized
INFO - 2019-05-28 08:31:25 --> URI Class Initialized
INFO - 2019-05-28 08:31:25 --> Router Class Initialized
INFO - 2019-05-28 08:31:25 --> Router Class Initialized
INFO - 2019-05-28 08:31:25 --> Output Class Initialized
INFO - 2019-05-28 08:31:25 --> Security Class Initialized
DEBUG - 2019-05-28 08:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:31:25 --> Input Class Initialized
INFO - 2019-05-28 08:31:25 --> Language Class Initialized
ERROR - 2019-05-28 08:31:25 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:31:25 --> Output Class Initialized
INFO - 2019-05-28 08:31:25 --> Security Class Initialized
DEBUG - 2019-05-28 08:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:31:25 --> Input Class Initialized
INFO - 2019-05-28 08:31:25 --> Language Class Initialized
ERROR - 2019-05-28 08:31:25 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:31:25 --> Output Class Initialized
INFO - 2019-05-28 08:31:25 --> Security Class Initialized
DEBUG - 2019-05-28 08:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:31:25 --> Input Class Initialized
INFO - 2019-05-28 08:31:25 --> Language Class Initialized
ERROR - 2019-05-28 08:31:25 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:36:19 --> Config Class Initialized
INFO - 2019-05-28 08:36:19 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:36:19 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:36:19 --> Utf8 Class Initialized
INFO - 2019-05-28 08:36:19 --> URI Class Initialized
INFO - 2019-05-28 08:36:19 --> Router Class Initialized
INFO - 2019-05-28 08:36:19 --> Output Class Initialized
INFO - 2019-05-28 08:36:19 --> Security Class Initialized
DEBUG - 2019-05-28 08:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:36:19 --> Input Class Initialized
INFO - 2019-05-28 08:36:19 --> Language Class Initialized
ERROR - 2019-05-28 08:36:19 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:36:22 --> Config Class Initialized
INFO - 2019-05-28 08:36:22 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:36:22 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:36:22 --> Utf8 Class Initialized
INFO - 2019-05-28 08:36:22 --> URI Class Initialized
INFO - 2019-05-28 08:36:22 --> Router Class Initialized
INFO - 2019-05-28 08:36:22 --> Output Class Initialized
INFO - 2019-05-28 08:36:22 --> Security Class Initialized
DEBUG - 2019-05-28 08:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:36:22 --> Input Class Initialized
INFO - 2019-05-28 08:36:22 --> Language Class Initialized
ERROR - 2019-05-28 08:36:22 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:36:28 --> Config Class Initialized
INFO - 2019-05-28 08:36:28 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:36:28 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:36:28 --> Utf8 Class Initialized
INFO - 2019-05-28 08:36:28 --> URI Class Initialized
INFO - 2019-05-28 08:36:28 --> Router Class Initialized
INFO - 2019-05-28 08:36:28 --> Output Class Initialized
INFO - 2019-05-28 08:36:28 --> Security Class Initialized
DEBUG - 2019-05-28 08:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:36:28 --> Input Class Initialized
INFO - 2019-05-28 08:36:28 --> Language Class Initialized
ERROR - 2019-05-28 08:36:28 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:42:58 --> Config Class Initialized
INFO - 2019-05-28 08:42:58 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:42:58 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:42:58 --> Utf8 Class Initialized
INFO - 2019-05-28 08:42:58 --> URI Class Initialized
INFO - 2019-05-28 08:42:58 --> Router Class Initialized
INFO - 2019-05-28 08:42:58 --> Output Class Initialized
INFO - 2019-05-28 08:42:58 --> Security Class Initialized
DEBUG - 2019-05-28 08:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:42:58 --> Input Class Initialized
INFO - 2019-05-28 08:42:58 --> Language Class Initialized
INFO - 2019-05-28 08:42:58 --> Language Class Initialized
INFO - 2019-05-28 08:42:58 --> Config Class Initialized
INFO - 2019-05-28 08:42:58 --> Loader Class Initialized
INFO - 2019-05-28 08:42:58 --> Helper loaded: form_helper
INFO - 2019-05-28 08:42:58 --> Helper loaded: url_helper
INFO - 2019-05-28 08:42:58 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:42:58 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:42:58 --> Template library initialized
INFO - 2019-05-28 08:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:42:58 --> Controller Class Initialized
DEBUG - 2019-05-28 08:42:58 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 08:42:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 08:42:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 08:42:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 08:42:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 08:42:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 08:42:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 08:42:59 --> Final output sent to browser
DEBUG - 2019-05-28 08:42:59 --> Total execution time: 0.0442
INFO - 2019-05-28 08:43:00 --> Config Class Initialized
INFO - 2019-05-28 08:43:00 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:43:00 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:43:00 --> Utf8 Class Initialized
INFO - 2019-05-28 08:43:00 --> URI Class Initialized
INFO - 2019-05-28 08:43:00 --> Config Class Initialized
INFO - 2019-05-28 08:43:00 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:43:00 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:43:00 --> Utf8 Class Initialized
INFO - 2019-05-28 08:43:00 --> URI Class Initialized
INFO - 2019-05-28 08:43:00 --> Router Class Initialized
INFO - 2019-05-28 08:43:00 --> Config Class Initialized
INFO - 2019-05-28 08:43:00 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:43:00 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:43:00 --> Utf8 Class Initialized
INFO - 2019-05-28 08:43:00 --> URI Class Initialized
INFO - 2019-05-28 08:43:00 --> Router Class Initialized
INFO - 2019-05-28 08:43:00 --> Output Class Initialized
INFO - 2019-05-28 08:43:00 --> Security Class Initialized
DEBUG - 2019-05-28 08:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:43:00 --> Input Class Initialized
INFO - 2019-05-28 08:43:00 --> Language Class Initialized
ERROR - 2019-05-28 08:43:00 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:43:00 --> Output Class Initialized
INFO - 2019-05-28 08:43:00 --> Security Class Initialized
DEBUG - 2019-05-28 08:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:43:00 --> Input Class Initialized
INFO - 2019-05-28 08:43:00 --> Language Class Initialized
ERROR - 2019-05-28 08:43:00 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:43:00 --> Router Class Initialized
INFO - 2019-05-28 08:43:00 --> Output Class Initialized
INFO - 2019-05-28 08:43:00 --> Security Class Initialized
DEBUG - 2019-05-28 08:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:43:00 --> Input Class Initialized
INFO - 2019-05-28 08:43:00 --> Language Class Initialized
ERROR - 2019-05-28 08:43:00 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:43:02 --> Config Class Initialized
INFO - 2019-05-28 08:43:02 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:43:02 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:43:02 --> Utf8 Class Initialized
INFO - 2019-05-28 08:43:02 --> URI Class Initialized
INFO - 2019-05-28 08:43:02 --> Router Class Initialized
INFO - 2019-05-28 08:43:02 --> Output Class Initialized
INFO - 2019-05-28 08:43:02 --> Security Class Initialized
DEBUG - 2019-05-28 08:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:43:02 --> Input Class Initialized
INFO - 2019-05-28 08:43:02 --> Language Class Initialized
ERROR - 2019-05-28 08:43:02 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:43:23 --> Config Class Initialized
INFO - 2019-05-28 08:43:23 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:43:23 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:43:23 --> Utf8 Class Initialized
INFO - 2019-05-28 08:43:23 --> URI Class Initialized
INFO - 2019-05-28 08:43:23 --> Router Class Initialized
INFO - 2019-05-28 08:43:23 --> Output Class Initialized
INFO - 2019-05-28 08:43:23 --> Security Class Initialized
DEBUG - 2019-05-28 08:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:43:23 --> Input Class Initialized
INFO - 2019-05-28 08:43:23 --> Language Class Initialized
INFO - 2019-05-28 08:43:23 --> Language Class Initialized
INFO - 2019-05-28 08:43:23 --> Config Class Initialized
INFO - 2019-05-28 08:43:23 --> Loader Class Initialized
INFO - 2019-05-28 08:43:23 --> Helper loaded: form_helper
INFO - 2019-05-28 08:43:23 --> Helper loaded: url_helper
INFO - 2019-05-28 08:43:23 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:43:23 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:43:23 --> Template library initialized
INFO - 2019-05-28 08:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:43:23 --> Controller Class Initialized
DEBUG - 2019-05-28 08:43:23 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:43:23 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
ERROR - 2019-05-28 08:43:23 --> Severity: Notice --> Undefined property: CI::$register_model /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/third_party/MX/Controller.php 59
ERROR - 2019-05-28 08:43:23 --> Severity: Error --> Call to a member function checkExistMobileNumber() on a non-object /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/controllers/Api.php 115
INFO - 2019-05-28 08:43:29 --> Config Class Initialized
INFO - 2019-05-28 08:43:29 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:43:29 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:43:29 --> Utf8 Class Initialized
INFO - 2019-05-28 08:43:29 --> URI Class Initialized
INFO - 2019-05-28 08:43:29 --> Router Class Initialized
INFO - 2019-05-28 08:43:29 --> Output Class Initialized
INFO - 2019-05-28 08:43:29 --> Security Class Initialized
DEBUG - 2019-05-28 08:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:43:29 --> Input Class Initialized
INFO - 2019-05-28 08:43:29 --> Language Class Initialized
INFO - 2019-05-28 08:43:29 --> Language Class Initialized
INFO - 2019-05-28 08:43:29 --> Config Class Initialized
INFO - 2019-05-28 08:43:29 --> Loader Class Initialized
INFO - 2019-05-28 08:43:29 --> Helper loaded: form_helper
INFO - 2019-05-28 08:43:29 --> Helper loaded: url_helper
INFO - 2019-05-28 08:43:29 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:43:29 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:43:29 --> Template library initialized
INFO - 2019-05-28 08:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:43:29 --> Controller Class Initialized
DEBUG - 2019-05-28 08:43:29 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:43:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
ERROR - 2019-05-28 08:43:29 --> Severity: Notice --> Undefined property: CI::$register_model /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/third_party/MX/Controller.php 59
ERROR - 2019-05-28 08:43:29 --> Severity: Error --> Call to a member function checkExistMobileNumber() on a non-object /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/controllers/Api.php 115
INFO - 2019-05-28 08:45:25 --> Config Class Initialized
INFO - 2019-05-28 08:45:25 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:45:25 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:45:25 --> Utf8 Class Initialized
INFO - 2019-05-28 08:45:25 --> URI Class Initialized
INFO - 2019-05-28 08:45:25 --> Router Class Initialized
INFO - 2019-05-28 08:45:25 --> Output Class Initialized
INFO - 2019-05-28 08:45:25 --> Security Class Initialized
DEBUG - 2019-05-28 08:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:45:25 --> Input Class Initialized
INFO - 2019-05-28 08:45:25 --> Language Class Initialized
INFO - 2019-05-28 08:45:25 --> Language Class Initialized
INFO - 2019-05-28 08:45:25 --> Config Class Initialized
INFO - 2019-05-28 08:45:25 --> Loader Class Initialized
INFO - 2019-05-28 08:45:25 --> Helper loaded: form_helper
INFO - 2019-05-28 08:45:25 --> Helper loaded: url_helper
INFO - 2019-05-28 08:45:25 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:45:25 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:45:25 --> Template library initialized
INFO - 2019-05-28 08:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:45:25 --> Controller Class Initialized
DEBUG - 2019-05-28 08:45:25 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:45:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:45:25 --> Final output sent to browser
DEBUG - 2019-05-28 08:45:25 --> Total execution time: 0.0362
INFO - 2019-05-28 08:45:35 --> Config Class Initialized
INFO - 2019-05-28 08:45:35 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:45:35 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:45:35 --> Utf8 Class Initialized
INFO - 2019-05-28 08:45:35 --> URI Class Initialized
INFO - 2019-05-28 08:45:35 --> Router Class Initialized
INFO - 2019-05-28 08:45:35 --> Output Class Initialized
INFO - 2019-05-28 08:45:35 --> Security Class Initialized
DEBUG - 2019-05-28 08:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:45:35 --> Input Class Initialized
INFO - 2019-05-28 08:45:35 --> Language Class Initialized
INFO - 2019-05-28 08:45:35 --> Language Class Initialized
INFO - 2019-05-28 08:45:35 --> Config Class Initialized
INFO - 2019-05-28 08:45:35 --> Loader Class Initialized
INFO - 2019-05-28 08:45:35 --> Helper loaded: form_helper
INFO - 2019-05-28 08:45:35 --> Helper loaded: url_helper
INFO - 2019-05-28 08:45:35 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:45:35 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:45:35 --> Template library initialized
INFO - 2019-05-28 08:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:45:35 --> Controller Class Initialized
DEBUG - 2019-05-28 08:45:35 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:45:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:45:35 --> Final output sent to browser
DEBUG - 2019-05-28 08:45:35 --> Total execution time: 0.0384
INFO - 2019-05-28 08:45:44 --> Config Class Initialized
INFO - 2019-05-28 08:45:44 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:45:44 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:45:44 --> Utf8 Class Initialized
INFO - 2019-05-28 08:45:44 --> URI Class Initialized
INFO - 2019-05-28 08:45:44 --> Router Class Initialized
INFO - 2019-05-28 08:45:44 --> Output Class Initialized
INFO - 2019-05-28 08:45:44 --> Security Class Initialized
DEBUG - 2019-05-28 08:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:45:44 --> Input Class Initialized
INFO - 2019-05-28 08:45:44 --> Language Class Initialized
INFO - 2019-05-28 08:45:44 --> Language Class Initialized
INFO - 2019-05-28 08:45:44 --> Config Class Initialized
INFO - 2019-05-28 08:45:44 --> Loader Class Initialized
INFO - 2019-05-28 08:45:44 --> Helper loaded: form_helper
INFO - 2019-05-28 08:45:44 --> Helper loaded: url_helper
INFO - 2019-05-28 08:45:44 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:45:44 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:45:44 --> Template library initialized
INFO - 2019-05-28 08:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:45:44 --> Controller Class Initialized
DEBUG - 2019-05-28 08:45:44 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:45:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:45:44 --> Final output sent to browser
DEBUG - 2019-05-28 08:45:44 --> Total execution time: 0.0521
INFO - 2019-05-28 08:46:06 --> Config Class Initialized
INFO - 2019-05-28 08:46:06 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:46:06 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:46:06 --> Utf8 Class Initialized
INFO - 2019-05-28 08:46:06 --> URI Class Initialized
INFO - 2019-05-28 08:46:06 --> Router Class Initialized
INFO - 2019-05-28 08:46:06 --> Output Class Initialized
INFO - 2019-05-28 08:46:06 --> Security Class Initialized
DEBUG - 2019-05-28 08:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:46:06 --> Input Class Initialized
INFO - 2019-05-28 08:46:06 --> Language Class Initialized
ERROR - 2019-05-28 08:46:06 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:46:11 --> Config Class Initialized
INFO - 2019-05-28 08:46:11 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:46:11 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:46:11 --> Utf8 Class Initialized
INFO - 2019-05-28 08:46:11 --> URI Class Initialized
INFO - 2019-05-28 08:46:11 --> Router Class Initialized
INFO - 2019-05-28 08:46:11 --> Output Class Initialized
INFO - 2019-05-28 08:46:11 --> Security Class Initialized
DEBUG - 2019-05-28 08:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:46:11 --> Input Class Initialized
INFO - 2019-05-28 08:46:11 --> Language Class Initialized
ERROR - 2019-05-28 08:46:11 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:51:34 --> Config Class Initialized
INFO - 2019-05-28 08:51:34 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:51:34 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:51:34 --> Utf8 Class Initialized
INFO - 2019-05-28 08:51:34 --> URI Class Initialized
INFO - 2019-05-28 08:51:34 --> Router Class Initialized
INFO - 2019-05-28 08:51:34 --> Output Class Initialized
INFO - 2019-05-28 08:51:34 --> Security Class Initialized
DEBUG - 2019-05-28 08:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:51:34 --> Input Class Initialized
INFO - 2019-05-28 08:51:34 --> Language Class Initialized
ERROR - 2019-05-28 08:51:34 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:51:38 --> Config Class Initialized
INFO - 2019-05-28 08:51:38 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:51:38 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:51:38 --> Utf8 Class Initialized
INFO - 2019-05-28 08:51:38 --> URI Class Initialized
INFO - 2019-05-28 08:51:38 --> Router Class Initialized
INFO - 2019-05-28 08:51:38 --> Output Class Initialized
INFO - 2019-05-28 08:51:38 --> Security Class Initialized
DEBUG - 2019-05-28 08:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:51:38 --> Input Class Initialized
INFO - 2019-05-28 08:51:38 --> Language Class Initialized
ERROR - 2019-05-28 08:51:38 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:51:42 --> Config Class Initialized
INFO - 2019-05-28 08:51:42 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:51:42 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:51:42 --> Utf8 Class Initialized
INFO - 2019-05-28 08:51:42 --> URI Class Initialized
INFO - 2019-05-28 08:51:42 --> Router Class Initialized
INFO - 2019-05-28 08:51:42 --> Output Class Initialized
INFO - 2019-05-28 08:51:42 --> Security Class Initialized
DEBUG - 2019-05-28 08:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:51:42 --> Input Class Initialized
INFO - 2019-05-28 08:51:42 --> Language Class Initialized
INFO - 2019-05-28 08:51:42 --> Language Class Initialized
INFO - 2019-05-28 08:51:42 --> Config Class Initialized
INFO - 2019-05-28 08:51:42 --> Loader Class Initialized
INFO - 2019-05-28 08:51:42 --> Helper loaded: form_helper
INFO - 2019-05-28 08:51:42 --> Helper loaded: url_helper
INFO - 2019-05-28 08:51:42 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:51:42 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:51:42 --> Template library initialized
INFO - 2019-05-28 08:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:51:42 --> Controller Class Initialized
DEBUG - 2019-05-28 08:51:42 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 08:51:42 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 08:51:42 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 08:51:42 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 08:51:42 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 08:51:42 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 08:51:42 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 08:51:43 --> Final output sent to browser
DEBUG - 2019-05-28 08:51:43 --> Total execution time: 0.0447
INFO - 2019-05-28 08:51:43 --> Config Class Initialized
INFO - 2019-05-28 08:51:43 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:51:43 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:51:43 --> Utf8 Class Initialized
INFO - 2019-05-28 08:51:43 --> URI Class Initialized
INFO - 2019-05-28 08:51:43 --> Config Class Initialized
INFO - 2019-05-28 08:51:43 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:51:43 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:51:43 --> Utf8 Class Initialized
INFO - 2019-05-28 08:51:43 --> URI Class Initialized
INFO - 2019-05-28 08:51:43 --> Config Class Initialized
INFO - 2019-05-28 08:51:43 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:51:43 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:51:43 --> Utf8 Class Initialized
INFO - 2019-05-28 08:51:43 --> URI Class Initialized
INFO - 2019-05-28 08:51:43 --> Router Class Initialized
INFO - 2019-05-28 08:51:43 --> Router Class Initialized
INFO - 2019-05-28 08:51:43 --> Output Class Initialized
INFO - 2019-05-28 08:51:43 --> Security Class Initialized
DEBUG - 2019-05-28 08:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:51:43 --> Input Class Initialized
INFO - 2019-05-28 08:51:43 --> Language Class Initialized
ERROR - 2019-05-28 08:51:43 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:51:43 --> Output Class Initialized
INFO - 2019-05-28 08:51:43 --> Security Class Initialized
DEBUG - 2019-05-28 08:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:51:43 --> Input Class Initialized
INFO - 2019-05-28 08:51:43 --> Language Class Initialized
ERROR - 2019-05-28 08:51:43 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:51:43 --> Router Class Initialized
INFO - 2019-05-28 08:51:43 --> Output Class Initialized
INFO - 2019-05-28 08:51:43 --> Security Class Initialized
DEBUG - 2019-05-28 08:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:51:43 --> Input Class Initialized
INFO - 2019-05-28 08:51:43 --> Language Class Initialized
ERROR - 2019-05-28 08:51:43 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:52:25 --> Config Class Initialized
INFO - 2019-05-28 08:52:25 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:52:25 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:52:25 --> Utf8 Class Initialized
INFO - 2019-05-28 08:52:25 --> URI Class Initialized
INFO - 2019-05-28 08:52:25 --> Router Class Initialized
INFO - 2019-05-28 08:52:25 --> Output Class Initialized
INFO - 2019-05-28 08:52:25 --> Security Class Initialized
DEBUG - 2019-05-28 08:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:52:25 --> Input Class Initialized
INFO - 2019-05-28 08:52:25 --> Language Class Initialized
INFO - 2019-05-28 08:52:25 --> Language Class Initialized
INFO - 2019-05-28 08:52:25 --> Config Class Initialized
INFO - 2019-05-28 08:52:25 --> Loader Class Initialized
INFO - 2019-05-28 08:52:25 --> Helper loaded: form_helper
INFO - 2019-05-28 08:52:25 --> Helper loaded: url_helper
INFO - 2019-05-28 08:52:25 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:52:25 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:52:25 --> Template library initialized
INFO - 2019-05-28 08:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:52:25 --> Controller Class Initialized
DEBUG - 2019-05-28 08:52:25 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:52:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:52:25 --> Final output sent to browser
DEBUG - 2019-05-28 08:52:25 --> Total execution time: 0.0369
INFO - 2019-05-28 08:52:51 --> Config Class Initialized
INFO - 2019-05-28 08:52:51 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:52:51 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:52:51 --> Utf8 Class Initialized
INFO - 2019-05-28 08:52:51 --> URI Class Initialized
INFO - 2019-05-28 08:52:51 --> Router Class Initialized
INFO - 2019-05-28 08:52:51 --> Output Class Initialized
INFO - 2019-05-28 08:52:51 --> Security Class Initialized
DEBUG - 2019-05-28 08:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:52:51 --> Input Class Initialized
INFO - 2019-05-28 08:52:51 --> Language Class Initialized
INFO - 2019-05-28 08:52:51 --> Language Class Initialized
INFO - 2019-05-28 08:52:51 --> Config Class Initialized
INFO - 2019-05-28 08:52:51 --> Loader Class Initialized
INFO - 2019-05-28 08:52:51 --> Helper loaded: form_helper
INFO - 2019-05-28 08:52:51 --> Helper loaded: url_helper
INFO - 2019-05-28 08:52:51 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:52:51 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:52:51 --> Template library initialized
INFO - 2019-05-28 08:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:52:51 --> Controller Class Initialized
DEBUG - 2019-05-28 08:52:51 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:52:51 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:52:51 --> Final output sent to browser
DEBUG - 2019-05-28 08:52:51 --> Total execution time: 0.0453
INFO - 2019-05-28 08:52:51 --> Config Class Initialized
INFO - 2019-05-28 08:52:51 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:52:51 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:52:51 --> Utf8 Class Initialized
INFO - 2019-05-28 08:52:51 --> URI Class Initialized
DEBUG - 2019-05-28 08:52:51 --> No URI present. Default controller set.
INFO - 2019-05-28 08:52:51 --> Router Class Initialized
INFO - 2019-05-28 08:52:51 --> Output Class Initialized
INFO - 2019-05-28 08:52:51 --> Security Class Initialized
DEBUG - 2019-05-28 08:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:52:51 --> Input Class Initialized
INFO - 2019-05-28 08:52:51 --> Language Class Initialized
INFO - 2019-05-28 08:52:51 --> Language Class Initialized
INFO - 2019-05-28 08:52:51 --> Config Class Initialized
INFO - 2019-05-28 08:52:51 --> Loader Class Initialized
INFO - 2019-05-28 08:52:51 --> Helper loaded: form_helper
INFO - 2019-05-28 08:52:51 --> Helper loaded: url_helper
INFO - 2019-05-28 08:52:51 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:52:51 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:52:51 --> Template library initialized
INFO - 2019-05-28 08:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:52:51 --> Controller Class Initialized
DEBUG - 2019-05-28 08:52:51 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 08:52:51 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 08:52:51 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 08:52:51 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 08:52:51 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 08:52:51 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 08:52:51 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 08:52:51 --> Final output sent to browser
DEBUG - 2019-05-28 08:52:51 --> Total execution time: 0.0465
INFO - 2019-05-28 08:52:52 --> Config Class Initialized
INFO - 2019-05-28 08:52:52 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:52:52 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:52:52 --> Utf8 Class Initialized
INFO - 2019-05-28 08:52:52 --> URI Class Initialized
INFO - 2019-05-28 08:52:52 --> Config Class Initialized
INFO - 2019-05-28 08:52:52 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:52:52 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:52:52 --> Utf8 Class Initialized
INFO - 2019-05-28 08:52:52 --> URI Class Initialized
INFO - 2019-05-28 08:52:52 --> Config Class Initialized
INFO - 2019-05-28 08:52:52 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:52:52 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:52:52 --> Utf8 Class Initialized
INFO - 2019-05-28 08:52:52 --> URI Class Initialized
INFO - 2019-05-28 08:52:52 --> Router Class Initialized
INFO - 2019-05-28 08:52:52 --> Router Class Initialized
INFO - 2019-05-28 08:52:52 --> Output Class Initialized
INFO - 2019-05-28 08:52:52 --> Security Class Initialized
DEBUG - 2019-05-28 08:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:52:52 --> Input Class Initialized
INFO - 2019-05-28 08:52:52 --> Language Class Initialized
ERROR - 2019-05-28 08:52:52 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:52:52 --> Output Class Initialized
INFO - 2019-05-28 08:52:52 --> Security Class Initialized
DEBUG - 2019-05-28 08:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:52:52 --> Input Class Initialized
INFO - 2019-05-28 08:52:52 --> Language Class Initialized
ERROR - 2019-05-28 08:52:52 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:52:52 --> Router Class Initialized
INFO - 2019-05-28 08:52:52 --> Output Class Initialized
INFO - 2019-05-28 08:52:52 --> Security Class Initialized
DEBUG - 2019-05-28 08:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:52:52 --> Input Class Initialized
INFO - 2019-05-28 08:52:52 --> Language Class Initialized
ERROR - 2019-05-28 08:52:52 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:54:50 --> Config Class Initialized
INFO - 2019-05-28 08:54:50 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:54:50 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:54:50 --> Utf8 Class Initialized
INFO - 2019-05-28 08:54:50 --> URI Class Initialized
INFO - 2019-05-28 08:54:50 --> Router Class Initialized
INFO - 2019-05-28 08:54:50 --> Output Class Initialized
INFO - 2019-05-28 08:54:50 --> Security Class Initialized
DEBUG - 2019-05-28 08:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:54:50 --> Input Class Initialized
INFO - 2019-05-28 08:54:50 --> Language Class Initialized
INFO - 2019-05-28 08:54:50 --> Language Class Initialized
INFO - 2019-05-28 08:54:50 --> Config Class Initialized
INFO - 2019-05-28 08:54:50 --> Loader Class Initialized
INFO - 2019-05-28 08:54:50 --> Helper loaded: form_helper
INFO - 2019-05-28 08:54:50 --> Helper loaded: url_helper
INFO - 2019-05-28 08:54:50 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:54:50 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:54:50 --> Template library initialized
INFO - 2019-05-28 08:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:54:50 --> Controller Class Initialized
DEBUG - 2019-05-28 08:54:50 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:54:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:54:50 --> Final output sent to browser
DEBUG - 2019-05-28 08:54:50 --> Total execution time: 0.0370
INFO - 2019-05-28 08:55:06 --> Config Class Initialized
INFO - 2019-05-28 08:55:06 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:55:06 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:55:06 --> Utf8 Class Initialized
INFO - 2019-05-28 08:55:06 --> URI Class Initialized
INFO - 2019-05-28 08:55:06 --> Router Class Initialized
INFO - 2019-05-28 08:55:06 --> Output Class Initialized
INFO - 2019-05-28 08:55:06 --> Security Class Initialized
DEBUG - 2019-05-28 08:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:55:06 --> Input Class Initialized
INFO - 2019-05-28 08:55:06 --> Language Class Initialized
INFO - 2019-05-28 08:55:06 --> Language Class Initialized
INFO - 2019-05-28 08:55:06 --> Config Class Initialized
INFO - 2019-05-28 08:55:06 --> Loader Class Initialized
INFO - 2019-05-28 08:55:06 --> Helper loaded: form_helper
INFO - 2019-05-28 08:55:06 --> Helper loaded: url_helper
INFO - 2019-05-28 08:55:06 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:55:06 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:55:06 --> Template library initialized
INFO - 2019-05-28 08:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:55:06 --> Controller Class Initialized
DEBUG - 2019-05-28 08:55:06 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 08:55:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 08:55:06 --> Final output sent to browser
DEBUG - 2019-05-28 08:55:06 --> Total execution time: 0.0392
INFO - 2019-05-28 08:55:06 --> Config Class Initialized
INFO - 2019-05-28 08:55:06 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:55:06 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:55:06 --> Utf8 Class Initialized
INFO - 2019-05-28 08:55:06 --> URI Class Initialized
DEBUG - 2019-05-28 08:55:06 --> No URI present. Default controller set.
INFO - 2019-05-28 08:55:06 --> Router Class Initialized
INFO - 2019-05-28 08:55:06 --> Output Class Initialized
INFO - 2019-05-28 08:55:06 --> Security Class Initialized
DEBUG - 2019-05-28 08:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:55:06 --> Input Class Initialized
INFO - 2019-05-28 08:55:06 --> Language Class Initialized
INFO - 2019-05-28 08:55:06 --> Language Class Initialized
INFO - 2019-05-28 08:55:06 --> Config Class Initialized
INFO - 2019-05-28 08:55:06 --> Loader Class Initialized
INFO - 2019-05-28 08:55:06 --> Helper loaded: form_helper
INFO - 2019-05-28 08:55:06 --> Helper loaded: url_helper
INFO - 2019-05-28 08:55:06 --> Helper loaded: cookie_helper
INFO - 2019-05-28 08:55:06 --> Database Driver Class Initialized
DEBUG - 2019-05-28 08:55:06 --> Template library initialized
INFO - 2019-05-28 08:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 08:55:06 --> Controller Class Initialized
DEBUG - 2019-05-28 08:55:06 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 08:55:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 08:55:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 08:55:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 08:55:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 08:55:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 08:55:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 08:55:07 --> Final output sent to browser
DEBUG - 2019-05-28 08:55:07 --> Total execution time: 0.0465
INFO - 2019-05-28 08:55:07 --> Config Class Initialized
INFO - 2019-05-28 08:55:07 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:55:07 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:55:07 --> Utf8 Class Initialized
INFO - 2019-05-28 08:55:07 --> URI Class Initialized
INFO - 2019-05-28 08:55:07 --> Router Class Initialized
INFO - 2019-05-28 08:55:07 --> Output Class Initialized
INFO - 2019-05-28 08:55:07 --> Security Class Initialized
DEBUG - 2019-05-28 08:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:55:07 --> Input Class Initialized
INFO - 2019-05-28 08:55:07 --> Language Class Initialized
ERROR - 2019-05-28 08:55:07 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:55:07 --> Config Class Initialized
INFO - 2019-05-28 08:55:07 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:55:07 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:55:07 --> Utf8 Class Initialized
INFO - 2019-05-28 08:55:07 --> URI Class Initialized
INFO - 2019-05-28 08:55:07 --> Config Class Initialized
INFO - 2019-05-28 08:55:07 --> Hooks Class Initialized
DEBUG - 2019-05-28 08:55:07 --> UTF-8 Support Enabled
INFO - 2019-05-28 08:55:07 --> Utf8 Class Initialized
INFO - 2019-05-28 08:55:07 --> URI Class Initialized
INFO - 2019-05-28 08:55:07 --> Router Class Initialized
INFO - 2019-05-28 08:55:07 --> Router Class Initialized
INFO - 2019-05-28 08:55:07 --> Output Class Initialized
INFO - 2019-05-28 08:55:07 --> Security Class Initialized
DEBUG - 2019-05-28 08:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:55:07 --> Input Class Initialized
INFO - 2019-05-28 08:55:07 --> Language Class Initialized
ERROR - 2019-05-28 08:55:07 --> 404 Page Not Found: /index
INFO - 2019-05-28 08:55:07 --> Output Class Initialized
INFO - 2019-05-28 08:55:07 --> Security Class Initialized
DEBUG - 2019-05-28 08:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 08:55:07 --> Input Class Initialized
INFO - 2019-05-28 08:55:07 --> Language Class Initialized
ERROR - 2019-05-28 08:55:07 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:01:41 --> Config Class Initialized
INFO - 2019-05-28 09:01:41 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:01:41 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:01:41 --> Utf8 Class Initialized
INFO - 2019-05-28 09:01:41 --> URI Class Initialized
DEBUG - 2019-05-28 09:01:41 --> No URI present. Default controller set.
INFO - 2019-05-28 09:01:41 --> Router Class Initialized
INFO - 2019-05-28 09:01:41 --> Output Class Initialized
INFO - 2019-05-28 09:01:41 --> Security Class Initialized
DEBUG - 2019-05-28 09:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:01:41 --> Input Class Initialized
INFO - 2019-05-28 09:01:41 --> Language Class Initialized
INFO - 2019-05-28 09:01:41 --> Language Class Initialized
INFO - 2019-05-28 09:01:41 --> Config Class Initialized
INFO - 2019-05-28 09:01:41 --> Loader Class Initialized
INFO - 2019-05-28 09:01:41 --> Helper loaded: form_helper
INFO - 2019-05-28 09:01:41 --> Helper loaded: url_helper
INFO - 2019-05-28 09:01:41 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:01:41 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:01:41 --> Template library initialized
INFO - 2019-05-28 09:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:01:41 --> Controller Class Initialized
DEBUG - 2019-05-28 09:01:41 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 09:01:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 09:01:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 09:01:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 09:01:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 09:01:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 09:01:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 09:01:41 --> Final output sent to browser
DEBUG - 2019-05-28 09:01:41 --> Total execution time: 0.0448
INFO - 2019-05-28 09:01:42 --> Config Class Initialized
INFO - 2019-05-28 09:01:42 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:01:42 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:01:42 --> Utf8 Class Initialized
INFO - 2019-05-28 09:01:42 --> URI Class Initialized
INFO - 2019-05-28 09:01:42 --> Config Class Initialized
INFO - 2019-05-28 09:01:42 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:01:42 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:01:42 --> Utf8 Class Initialized
INFO - 2019-05-28 09:01:42 --> URI Class Initialized
INFO - 2019-05-28 09:01:42 --> Config Class Initialized
INFO - 2019-05-28 09:01:42 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:01:42 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:01:42 --> Utf8 Class Initialized
INFO - 2019-05-28 09:01:42 --> URI Class Initialized
INFO - 2019-05-28 09:01:42 --> Router Class Initialized
INFO - 2019-05-28 09:01:42 --> Output Class Initialized
INFO - 2019-05-28 09:01:42 --> Security Class Initialized
DEBUG - 2019-05-28 09:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:01:42 --> Input Class Initialized
INFO - 2019-05-28 09:01:42 --> Language Class Initialized
ERROR - 2019-05-28 09:01:42 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:01:42 --> Router Class Initialized
INFO - 2019-05-28 09:01:42 --> Output Class Initialized
INFO - 2019-05-28 09:01:42 --> Security Class Initialized
DEBUG - 2019-05-28 09:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:01:42 --> Input Class Initialized
INFO - 2019-05-28 09:01:42 --> Language Class Initialized
ERROR - 2019-05-28 09:01:42 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:01:42 --> Router Class Initialized
INFO - 2019-05-28 09:01:42 --> Output Class Initialized
INFO - 2019-05-28 09:01:42 --> Security Class Initialized
DEBUG - 2019-05-28 09:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:01:42 --> Input Class Initialized
INFO - 2019-05-28 09:01:42 --> Language Class Initialized
ERROR - 2019-05-28 09:01:42 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:02:17 --> Config Class Initialized
INFO - 2019-05-28 09:02:17 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:02:17 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:02:17 --> Utf8 Class Initialized
INFO - 2019-05-28 09:02:17 --> URI Class Initialized
DEBUG - 2019-05-28 09:02:17 --> No URI present. Default controller set.
INFO - 2019-05-28 09:02:17 --> Router Class Initialized
INFO - 2019-05-28 09:02:17 --> Output Class Initialized
INFO - 2019-05-28 09:02:17 --> Security Class Initialized
DEBUG - 2019-05-28 09:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:02:17 --> Input Class Initialized
INFO - 2019-05-28 09:02:17 --> Language Class Initialized
INFO - 2019-05-28 09:02:17 --> Language Class Initialized
INFO - 2019-05-28 09:02:17 --> Config Class Initialized
INFO - 2019-05-28 09:02:17 --> Loader Class Initialized
INFO - 2019-05-28 09:02:17 --> Helper loaded: form_helper
INFO - 2019-05-28 09:02:17 --> Helper loaded: url_helper
INFO - 2019-05-28 09:02:17 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:02:17 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:02:17 --> Template library initialized
INFO - 2019-05-28 09:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:02:17 --> Controller Class Initialized
DEBUG - 2019-05-28 09:02:17 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 09:02:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 09:02:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 09:02:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 09:02:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 09:02:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 09:02:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 09:02:17 --> Final output sent to browser
DEBUG - 2019-05-28 09:02:17 --> Total execution time: 0.0464
INFO - 2019-05-28 09:02:17 --> Config Class Initialized
INFO - 2019-05-28 09:02:17 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:02:17 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:02:17 --> Utf8 Class Initialized
INFO - 2019-05-28 09:02:17 --> URI Class Initialized
INFO - 2019-05-28 09:02:17 --> Config Class Initialized
INFO - 2019-05-28 09:02:17 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:02:17 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:02:17 --> Utf8 Class Initialized
INFO - 2019-05-28 09:02:17 --> URI Class Initialized
INFO - 2019-05-28 09:02:17 --> Router Class Initialized
INFO - 2019-05-28 09:02:17 --> Config Class Initialized
INFO - 2019-05-28 09:02:17 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:02:17 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:02:17 --> Utf8 Class Initialized
INFO - 2019-05-28 09:02:17 --> URI Class Initialized
INFO - 2019-05-28 09:02:17 --> Router Class Initialized
INFO - 2019-05-28 09:02:17 --> Output Class Initialized
INFO - 2019-05-28 09:02:17 --> Security Class Initialized
DEBUG - 2019-05-28 09:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:02:17 --> Input Class Initialized
INFO - 2019-05-28 09:02:17 --> Language Class Initialized
ERROR - 2019-05-28 09:02:17 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:02:17 --> Output Class Initialized
INFO - 2019-05-28 09:02:17 --> Security Class Initialized
DEBUG - 2019-05-28 09:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:02:17 --> Input Class Initialized
INFO - 2019-05-28 09:02:17 --> Language Class Initialized
ERROR - 2019-05-28 09:02:17 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:02:17 --> Router Class Initialized
INFO - 2019-05-28 09:02:17 --> Output Class Initialized
INFO - 2019-05-28 09:02:17 --> Security Class Initialized
DEBUG - 2019-05-28 09:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:02:17 --> Input Class Initialized
INFO - 2019-05-28 09:02:17 --> Language Class Initialized
ERROR - 2019-05-28 09:02:17 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:03:09 --> Config Class Initialized
INFO - 2019-05-28 09:03:09 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:03:09 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:03:09 --> Utf8 Class Initialized
INFO - 2019-05-28 09:03:09 --> URI Class Initialized
DEBUG - 2019-05-28 09:03:09 --> No URI present. Default controller set.
INFO - 2019-05-28 09:03:09 --> Router Class Initialized
INFO - 2019-05-28 09:03:09 --> Output Class Initialized
INFO - 2019-05-28 09:03:09 --> Security Class Initialized
DEBUG - 2019-05-28 09:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:03:09 --> Input Class Initialized
INFO - 2019-05-28 09:03:09 --> Language Class Initialized
INFO - 2019-05-28 09:03:09 --> Language Class Initialized
INFO - 2019-05-28 09:03:09 --> Config Class Initialized
INFO - 2019-05-28 09:03:09 --> Loader Class Initialized
INFO - 2019-05-28 09:03:09 --> Helper loaded: form_helper
INFO - 2019-05-28 09:03:09 --> Helper loaded: url_helper
INFO - 2019-05-28 09:03:09 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:03:09 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:03:09 --> Template library initialized
INFO - 2019-05-28 09:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:03:09 --> Controller Class Initialized
DEBUG - 2019-05-28 09:03:09 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 09:03:09 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 09:03:09 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 09:03:09 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 09:03:09 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 09:03:09 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 09:03:09 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 09:03:09 --> Final output sent to browser
DEBUG - 2019-05-28 09:03:09 --> Total execution time: 0.0450
INFO - 2019-05-28 09:03:10 --> Config Class Initialized
INFO - 2019-05-28 09:03:10 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:03:10 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:03:10 --> Utf8 Class Initialized
INFO - 2019-05-28 09:03:10 --> Config Class Initialized
INFO - 2019-05-28 09:03:10 --> Hooks Class Initialized
INFO - 2019-05-28 09:03:10 --> Config Class Initialized
INFO - 2019-05-28 09:03:10 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:03:10 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:03:10 --> Utf8 Class Initialized
INFO - 2019-05-28 09:03:10 --> URI Class Initialized
INFO - 2019-05-28 09:03:10 --> Router Class Initialized
INFO - 2019-05-28 09:03:10 --> Output Class Initialized
INFO - 2019-05-28 09:03:10 --> Security Class Initialized
DEBUG - 2019-05-28 09:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:03:10 --> Input Class Initialized
INFO - 2019-05-28 09:03:10 --> Language Class Initialized
ERROR - 2019-05-28 09:03:10 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:03:10 --> URI Class Initialized
INFO - 2019-05-28 09:03:10 --> Router Class Initialized
INFO - 2019-05-28 09:03:10 --> Output Class Initialized
INFO - 2019-05-28 09:03:10 --> Security Class Initialized
DEBUG - 2019-05-28 09:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:03:10 --> Input Class Initialized
INFO - 2019-05-28 09:03:10 --> Language Class Initialized
ERROR - 2019-05-28 09:03:10 --> 404 Page Not Found: /index
DEBUG - 2019-05-28 09:03:10 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:03:10 --> Utf8 Class Initialized
INFO - 2019-05-28 09:03:10 --> URI Class Initialized
INFO - 2019-05-28 09:03:10 --> Router Class Initialized
INFO - 2019-05-28 09:03:10 --> Output Class Initialized
INFO - 2019-05-28 09:03:10 --> Security Class Initialized
DEBUG - 2019-05-28 09:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:03:10 --> Input Class Initialized
INFO - 2019-05-28 09:03:10 --> Language Class Initialized
ERROR - 2019-05-28 09:03:10 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:03:17 --> Config Class Initialized
INFO - 2019-05-28 09:03:17 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:03:17 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:03:17 --> Utf8 Class Initialized
INFO - 2019-05-28 09:03:17 --> URI Class Initialized
DEBUG - 2019-05-28 09:03:17 --> No URI present. Default controller set.
INFO - 2019-05-28 09:03:17 --> Router Class Initialized
INFO - 2019-05-28 09:03:17 --> Output Class Initialized
INFO - 2019-05-28 09:03:17 --> Security Class Initialized
DEBUG - 2019-05-28 09:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:03:17 --> Input Class Initialized
INFO - 2019-05-28 09:03:17 --> Language Class Initialized
INFO - 2019-05-28 09:03:17 --> Language Class Initialized
INFO - 2019-05-28 09:03:17 --> Config Class Initialized
INFO - 2019-05-28 09:03:17 --> Loader Class Initialized
INFO - 2019-05-28 09:03:17 --> Helper loaded: form_helper
INFO - 2019-05-28 09:03:17 --> Helper loaded: url_helper
INFO - 2019-05-28 09:03:17 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:03:17 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:03:17 --> Template library initialized
INFO - 2019-05-28 09:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:03:17 --> Controller Class Initialized
DEBUG - 2019-05-28 09:03:17 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 09:03:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 09:03:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 09:03:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 09:03:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 09:03:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 09:03:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 09:03:18 --> Final output sent to browser
DEBUG - 2019-05-28 09:03:18 --> Total execution time: 0.0485
INFO - 2019-05-28 09:03:18 --> Config Class Initialized
INFO - 2019-05-28 09:03:18 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:03:18 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:03:18 --> Utf8 Class Initialized
INFO - 2019-05-28 09:03:18 --> URI Class Initialized
INFO - 2019-05-28 09:03:18 --> Config Class Initialized
INFO - 2019-05-28 09:03:18 --> Hooks Class Initialized
INFO - 2019-05-28 09:03:18 --> Router Class Initialized
INFO - 2019-05-28 09:03:18 --> Output Class Initialized
INFO - 2019-05-28 09:03:18 --> Security Class Initialized
DEBUG - 2019-05-28 09:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:03:18 --> Input Class Initialized
INFO - 2019-05-28 09:03:18 --> Language Class Initialized
ERROR - 2019-05-28 09:03:18 --> 404 Page Not Found: /index
DEBUG - 2019-05-28 09:03:18 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:03:18 --> Utf8 Class Initialized
INFO - 2019-05-28 09:03:18 --> URI Class Initialized
INFO - 2019-05-28 09:03:18 --> Router Class Initialized
INFO - 2019-05-28 09:03:18 --> Output Class Initialized
INFO - 2019-05-28 09:03:18 --> Security Class Initialized
DEBUG - 2019-05-28 09:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:03:18 --> Input Class Initialized
INFO - 2019-05-28 09:03:18 --> Language Class Initialized
ERROR - 2019-05-28 09:03:18 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:03:20 --> Config Class Initialized
INFO - 2019-05-28 09:03:20 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:03:20 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:03:20 --> Utf8 Class Initialized
INFO - 2019-05-28 09:03:20 --> URI Class Initialized
INFO - 2019-05-28 09:03:20 --> Router Class Initialized
INFO - 2019-05-28 09:03:20 --> Output Class Initialized
INFO - 2019-05-28 09:03:20 --> Security Class Initialized
DEBUG - 2019-05-28 09:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:03:20 --> Input Class Initialized
INFO - 2019-05-28 09:03:20 --> Language Class Initialized
ERROR - 2019-05-28 09:03:20 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:03:31 --> Config Class Initialized
INFO - 2019-05-28 09:03:31 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:03:31 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:03:31 --> Utf8 Class Initialized
INFO - 2019-05-28 09:03:31 --> URI Class Initialized
INFO - 2019-05-28 09:03:31 --> Router Class Initialized
INFO - 2019-05-28 09:03:31 --> Output Class Initialized
INFO - 2019-05-28 09:03:31 --> Security Class Initialized
DEBUG - 2019-05-28 09:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:03:31 --> Input Class Initialized
INFO - 2019-05-28 09:03:31 --> Language Class Initialized
INFO - 2019-05-28 09:03:31 --> Language Class Initialized
INFO - 2019-05-28 09:03:31 --> Config Class Initialized
INFO - 2019-05-28 09:03:31 --> Loader Class Initialized
INFO - 2019-05-28 09:03:31 --> Helper loaded: form_helper
INFO - 2019-05-28 09:03:31 --> Helper loaded: url_helper
INFO - 2019-05-28 09:03:31 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:03:31 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:03:31 --> Template library initialized
INFO - 2019-05-28 09:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:03:31 --> Controller Class Initialized
DEBUG - 2019-05-28 09:03:31 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 09:03:31 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 09:03:31 --> Final output sent to browser
DEBUG - 2019-05-28 09:03:31 --> Total execution time: 0.0369
INFO - 2019-05-28 09:03:35 --> Config Class Initialized
INFO - 2019-05-28 09:03:35 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:03:35 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:03:35 --> Utf8 Class Initialized
INFO - 2019-05-28 09:03:35 --> URI Class Initialized
INFO - 2019-05-28 09:03:35 --> Router Class Initialized
INFO - 2019-05-28 09:03:35 --> Output Class Initialized
INFO - 2019-05-28 09:03:35 --> Security Class Initialized
DEBUG - 2019-05-28 09:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:03:35 --> Input Class Initialized
INFO - 2019-05-28 09:03:35 --> Language Class Initialized
INFO - 2019-05-28 09:03:35 --> Language Class Initialized
INFO - 2019-05-28 09:03:35 --> Config Class Initialized
INFO - 2019-05-28 09:03:35 --> Loader Class Initialized
INFO - 2019-05-28 09:03:35 --> Helper loaded: form_helper
INFO - 2019-05-28 09:03:35 --> Helper loaded: url_helper
INFO - 2019-05-28 09:03:35 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:03:35 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:03:35 --> Template library initialized
INFO - 2019-05-28 09:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:03:35 --> Controller Class Initialized
DEBUG - 2019-05-28 09:03:35 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 09:03:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 09:03:35 --> Final output sent to browser
DEBUG - 2019-05-28 09:03:35 --> Total execution time: 0.0377
INFO - 2019-05-28 09:03:43 --> Config Class Initialized
INFO - 2019-05-28 09:03:43 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:03:43 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:03:43 --> Utf8 Class Initialized
INFO - 2019-05-28 09:03:43 --> URI Class Initialized
INFO - 2019-05-28 09:03:43 --> Router Class Initialized
INFO - 2019-05-28 09:03:43 --> Output Class Initialized
INFO - 2019-05-28 09:03:43 --> Security Class Initialized
DEBUG - 2019-05-28 09:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:03:43 --> Input Class Initialized
INFO - 2019-05-28 09:03:43 --> Language Class Initialized
INFO - 2019-05-28 09:03:43 --> Language Class Initialized
INFO - 2019-05-28 09:03:43 --> Config Class Initialized
INFO - 2019-05-28 09:03:43 --> Loader Class Initialized
INFO - 2019-05-28 09:03:43 --> Helper loaded: form_helper
INFO - 2019-05-28 09:03:43 --> Helper loaded: url_helper
INFO - 2019-05-28 09:03:43 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:03:43 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:03:43 --> Template library initialized
INFO - 2019-05-28 09:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:03:43 --> Controller Class Initialized
DEBUG - 2019-05-28 09:03:43 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 09:03:43 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 09:03:43 --> Final output sent to browser
DEBUG - 2019-05-28 09:03:43 --> Total execution time: 0.0387
INFO - 2019-05-28 09:03:52 --> Config Class Initialized
INFO - 2019-05-28 09:03:52 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:03:52 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:03:52 --> Utf8 Class Initialized
INFO - 2019-05-28 09:03:52 --> URI Class Initialized
INFO - 2019-05-28 09:03:52 --> Router Class Initialized
INFO - 2019-05-28 09:03:52 --> Output Class Initialized
INFO - 2019-05-28 09:03:52 --> Security Class Initialized
DEBUG - 2019-05-28 09:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:03:52 --> Input Class Initialized
INFO - 2019-05-28 09:03:52 --> Language Class Initialized
INFO - 2019-05-28 09:03:52 --> Language Class Initialized
INFO - 2019-05-28 09:03:52 --> Config Class Initialized
INFO - 2019-05-28 09:03:52 --> Loader Class Initialized
INFO - 2019-05-28 09:03:52 --> Helper loaded: form_helper
INFO - 2019-05-28 09:03:52 --> Helper loaded: url_helper
INFO - 2019-05-28 09:03:52 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:03:52 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:03:52 --> Template library initialized
INFO - 2019-05-28 09:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:03:52 --> Controller Class Initialized
DEBUG - 2019-05-28 09:03:52 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 09:03:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 09:03:52 --> Final output sent to browser
DEBUG - 2019-05-28 09:03:52 --> Total execution time: 0.0596
INFO - 2019-05-28 09:03:57 --> Config Class Initialized
INFO - 2019-05-28 09:03:57 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:03:57 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:03:57 --> Utf8 Class Initialized
INFO - 2019-05-28 09:03:57 --> URI Class Initialized
INFO - 2019-05-28 09:03:57 --> Router Class Initialized
INFO - 2019-05-28 09:03:57 --> Output Class Initialized
INFO - 2019-05-28 09:03:57 --> Security Class Initialized
DEBUG - 2019-05-28 09:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:03:57 --> Input Class Initialized
INFO - 2019-05-28 09:03:57 --> Language Class Initialized
ERROR - 2019-05-28 09:03:57 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:03:59 --> Config Class Initialized
INFO - 2019-05-28 09:03:59 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:03:59 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:03:59 --> Utf8 Class Initialized
INFO - 2019-05-28 09:03:59 --> URI Class Initialized
INFO - 2019-05-28 09:03:59 --> Router Class Initialized
INFO - 2019-05-28 09:03:59 --> Output Class Initialized
INFO - 2019-05-28 09:03:59 --> Security Class Initialized
DEBUG - 2019-05-28 09:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:03:59 --> Input Class Initialized
INFO - 2019-05-28 09:03:59 --> Language Class Initialized
ERROR - 2019-05-28 09:03:59 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:03:59 --> Config Class Initialized
INFO - 2019-05-28 09:03:59 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:03:59 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:03:59 --> Utf8 Class Initialized
INFO - 2019-05-28 09:03:59 --> URI Class Initialized
INFO - 2019-05-28 09:03:59 --> Router Class Initialized
INFO - 2019-05-28 09:03:59 --> Output Class Initialized
INFO - 2019-05-28 09:03:59 --> Security Class Initialized
DEBUG - 2019-05-28 09:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:03:59 --> Input Class Initialized
INFO - 2019-05-28 09:03:59 --> Language Class Initialized
ERROR - 2019-05-28 09:03:59 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:03:59 --> Config Class Initialized
INFO - 2019-05-28 09:03:59 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:03:59 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:03:59 --> Utf8 Class Initialized
INFO - 2019-05-28 09:03:59 --> URI Class Initialized
INFO - 2019-05-28 09:03:59 --> Router Class Initialized
INFO - 2019-05-28 09:03:59 --> Output Class Initialized
INFO - 2019-05-28 09:03:59 --> Security Class Initialized
DEBUG - 2019-05-28 09:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:03:59 --> Input Class Initialized
INFO - 2019-05-28 09:03:59 --> Language Class Initialized
ERROR - 2019-05-28 09:03:59 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:03:59 --> Config Class Initialized
INFO - 2019-05-28 09:03:59 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:03:59 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:03:59 --> Utf8 Class Initialized
INFO - 2019-05-28 09:03:59 --> URI Class Initialized
INFO - 2019-05-28 09:03:59 --> Router Class Initialized
INFO - 2019-05-28 09:03:59 --> Output Class Initialized
INFO - 2019-05-28 09:03:59 --> Security Class Initialized
DEBUG - 2019-05-28 09:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:03:59 --> Input Class Initialized
INFO - 2019-05-28 09:03:59 --> Language Class Initialized
ERROR - 2019-05-28 09:03:59 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:04:00 --> Config Class Initialized
INFO - 2019-05-28 09:04:00 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:04:00 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:04:00 --> Utf8 Class Initialized
INFO - 2019-05-28 09:04:00 --> URI Class Initialized
INFO - 2019-05-28 09:04:00 --> Router Class Initialized
INFO - 2019-05-28 09:04:00 --> Output Class Initialized
INFO - 2019-05-28 09:04:00 --> Security Class Initialized
DEBUG - 2019-05-28 09:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:04:00 --> Input Class Initialized
INFO - 2019-05-28 09:04:00 --> Language Class Initialized
ERROR - 2019-05-28 09:04:00 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:04:00 --> Config Class Initialized
INFO - 2019-05-28 09:04:00 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:04:00 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:04:00 --> Utf8 Class Initialized
INFO - 2019-05-28 09:04:00 --> URI Class Initialized
INFO - 2019-05-28 09:04:00 --> Router Class Initialized
INFO - 2019-05-28 09:04:00 --> Output Class Initialized
INFO - 2019-05-28 09:04:00 --> Security Class Initialized
DEBUG - 2019-05-28 09:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:04:00 --> Input Class Initialized
INFO - 2019-05-28 09:04:00 --> Language Class Initialized
ERROR - 2019-05-28 09:04:00 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:04:00 --> Config Class Initialized
INFO - 2019-05-28 09:04:00 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:04:00 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:04:00 --> Utf8 Class Initialized
INFO - 2019-05-28 09:04:00 --> URI Class Initialized
INFO - 2019-05-28 09:04:00 --> Router Class Initialized
INFO - 2019-05-28 09:04:00 --> Output Class Initialized
INFO - 2019-05-28 09:04:00 --> Security Class Initialized
DEBUG - 2019-05-28 09:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:04:00 --> Input Class Initialized
INFO - 2019-05-28 09:04:00 --> Language Class Initialized
ERROR - 2019-05-28 09:04:00 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:04:00 --> Config Class Initialized
INFO - 2019-05-28 09:04:00 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:04:00 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:04:00 --> Utf8 Class Initialized
INFO - 2019-05-28 09:04:00 --> URI Class Initialized
INFO - 2019-05-28 09:04:00 --> Router Class Initialized
INFO - 2019-05-28 09:04:00 --> Output Class Initialized
INFO - 2019-05-28 09:04:00 --> Security Class Initialized
DEBUG - 2019-05-28 09:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:04:00 --> Input Class Initialized
INFO - 2019-05-28 09:04:00 --> Language Class Initialized
ERROR - 2019-05-28 09:04:00 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:04:20 --> Config Class Initialized
INFO - 2019-05-28 09:04:20 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:04:20 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:04:20 --> Utf8 Class Initialized
INFO - 2019-05-28 09:04:20 --> URI Class Initialized
INFO - 2019-05-28 09:04:20 --> Router Class Initialized
INFO - 2019-05-28 09:04:20 --> Output Class Initialized
INFO - 2019-05-28 09:04:20 --> Security Class Initialized
DEBUG - 2019-05-28 09:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:04:20 --> Input Class Initialized
INFO - 2019-05-28 09:04:20 --> Language Class Initialized
INFO - 2019-05-28 09:04:20 --> Language Class Initialized
INFO - 2019-05-28 09:04:20 --> Config Class Initialized
INFO - 2019-05-28 09:04:20 --> Loader Class Initialized
INFO - 2019-05-28 09:04:20 --> Helper loaded: form_helper
INFO - 2019-05-28 09:04:20 --> Helper loaded: url_helper
INFO - 2019-05-28 09:04:20 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:04:20 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:04:20 --> Template library initialized
INFO - 2019-05-28 09:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:04:20 --> Controller Class Initialized
DEBUG - 2019-05-28 09:04:20 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 09:04:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 09:04:20 --> Final output sent to browser
DEBUG - 2019-05-28 09:04:20 --> Total execution time: 0.0376
INFO - 2019-05-28 09:04:23 --> Config Class Initialized
INFO - 2019-05-28 09:04:23 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:04:23 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:04:23 --> Utf8 Class Initialized
INFO - 2019-05-28 09:04:23 --> URI Class Initialized
INFO - 2019-05-28 09:04:23 --> Router Class Initialized
INFO - 2019-05-28 09:04:23 --> Output Class Initialized
INFO - 2019-05-28 09:04:23 --> Security Class Initialized
DEBUG - 2019-05-28 09:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:04:23 --> Input Class Initialized
INFO - 2019-05-28 09:04:23 --> Language Class Initialized
INFO - 2019-05-28 09:04:23 --> Language Class Initialized
INFO - 2019-05-28 09:04:23 --> Config Class Initialized
INFO - 2019-05-28 09:04:23 --> Loader Class Initialized
INFO - 2019-05-28 09:04:23 --> Helper loaded: form_helper
INFO - 2019-05-28 09:04:23 --> Helper loaded: url_helper
INFO - 2019-05-28 09:04:23 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:04:23 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:04:23 --> Template library initialized
INFO - 2019-05-28 09:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:04:23 --> Controller Class Initialized
DEBUG - 2019-05-28 09:04:23 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 09:04:23 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 09:04:23 --> Final output sent to browser
DEBUG - 2019-05-28 09:04:23 --> Total execution time: 0.0378
INFO - 2019-05-28 09:04:29 --> Config Class Initialized
INFO - 2019-05-28 09:04:29 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:04:29 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:04:29 --> Utf8 Class Initialized
INFO - 2019-05-28 09:04:29 --> URI Class Initialized
INFO - 2019-05-28 09:04:29 --> Router Class Initialized
INFO - 2019-05-28 09:04:29 --> Output Class Initialized
INFO - 2019-05-28 09:04:29 --> Security Class Initialized
DEBUG - 2019-05-28 09:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:04:29 --> Input Class Initialized
INFO - 2019-05-28 09:04:29 --> Language Class Initialized
INFO - 2019-05-28 09:04:29 --> Language Class Initialized
INFO - 2019-05-28 09:04:29 --> Config Class Initialized
INFO - 2019-05-28 09:04:29 --> Loader Class Initialized
INFO - 2019-05-28 09:04:29 --> Helper loaded: form_helper
INFO - 2019-05-28 09:04:29 --> Helper loaded: url_helper
INFO - 2019-05-28 09:04:29 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:04:29 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:04:29 --> Template library initialized
INFO - 2019-05-28 09:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:04:29 --> Controller Class Initialized
DEBUG - 2019-05-28 09:04:29 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 09:04:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 09:04:29 --> Final output sent to browser
DEBUG - 2019-05-28 09:04:29 --> Total execution time: 0.0369
INFO - 2019-05-28 09:04:33 --> Config Class Initialized
INFO - 2019-05-28 09:04:33 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:04:33 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:04:33 --> Utf8 Class Initialized
INFO - 2019-05-28 09:04:33 --> URI Class Initialized
INFO - 2019-05-28 09:04:33 --> Router Class Initialized
INFO - 2019-05-28 09:04:33 --> Output Class Initialized
INFO - 2019-05-28 09:04:33 --> Security Class Initialized
DEBUG - 2019-05-28 09:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:04:33 --> Input Class Initialized
INFO - 2019-05-28 09:04:33 --> Language Class Initialized
ERROR - 2019-05-28 09:04:33 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:04:33 --> Config Class Initialized
INFO - 2019-05-28 09:04:33 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:04:33 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:04:33 --> Utf8 Class Initialized
INFO - 2019-05-28 09:04:33 --> URI Class Initialized
INFO - 2019-05-28 09:04:33 --> Router Class Initialized
INFO - 2019-05-28 09:04:33 --> Output Class Initialized
INFO - 2019-05-28 09:04:33 --> Security Class Initialized
DEBUG - 2019-05-28 09:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:04:33 --> Input Class Initialized
INFO - 2019-05-28 09:04:33 --> Language Class Initialized
ERROR - 2019-05-28 09:04:33 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:04:34 --> Config Class Initialized
INFO - 2019-05-28 09:04:34 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:04:34 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:04:34 --> Utf8 Class Initialized
INFO - 2019-05-28 09:04:34 --> URI Class Initialized
INFO - 2019-05-28 09:04:34 --> Router Class Initialized
INFO - 2019-05-28 09:04:34 --> Output Class Initialized
INFO - 2019-05-28 09:04:34 --> Security Class Initialized
DEBUG - 2019-05-28 09:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:04:34 --> Input Class Initialized
INFO - 2019-05-28 09:04:34 --> Language Class Initialized
ERROR - 2019-05-28 09:04:34 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:04:34 --> Config Class Initialized
INFO - 2019-05-28 09:04:34 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:04:34 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:04:34 --> Utf8 Class Initialized
INFO - 2019-05-28 09:04:34 --> URI Class Initialized
INFO - 2019-05-28 09:04:34 --> Router Class Initialized
INFO - 2019-05-28 09:04:34 --> Output Class Initialized
INFO - 2019-05-28 09:04:34 --> Security Class Initialized
DEBUG - 2019-05-28 09:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:04:34 --> Input Class Initialized
INFO - 2019-05-28 09:04:34 --> Language Class Initialized
ERROR - 2019-05-28 09:04:34 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:04:34 --> Config Class Initialized
INFO - 2019-05-28 09:04:34 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:04:34 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:04:34 --> Utf8 Class Initialized
INFO - 2019-05-28 09:04:34 --> URI Class Initialized
INFO - 2019-05-28 09:04:34 --> Router Class Initialized
INFO - 2019-05-28 09:04:34 --> Output Class Initialized
INFO - 2019-05-28 09:04:34 --> Security Class Initialized
DEBUG - 2019-05-28 09:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:04:34 --> Input Class Initialized
INFO - 2019-05-28 09:04:34 --> Language Class Initialized
ERROR - 2019-05-28 09:04:34 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:04:34 --> Config Class Initialized
INFO - 2019-05-28 09:04:34 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:04:34 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:04:34 --> Utf8 Class Initialized
INFO - 2019-05-28 09:04:34 --> URI Class Initialized
INFO - 2019-05-28 09:04:34 --> Router Class Initialized
INFO - 2019-05-28 09:04:34 --> Output Class Initialized
INFO - 2019-05-28 09:04:34 --> Security Class Initialized
DEBUG - 2019-05-28 09:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:04:34 --> Input Class Initialized
INFO - 2019-05-28 09:04:34 --> Language Class Initialized
ERROR - 2019-05-28 09:04:34 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:04:34 --> Config Class Initialized
INFO - 2019-05-28 09:04:34 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:04:34 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:04:34 --> Utf8 Class Initialized
INFO - 2019-05-28 09:04:34 --> URI Class Initialized
INFO - 2019-05-28 09:04:34 --> Router Class Initialized
INFO - 2019-05-28 09:04:34 --> Output Class Initialized
INFO - 2019-05-28 09:04:34 --> Security Class Initialized
DEBUG - 2019-05-28 09:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:04:34 --> Input Class Initialized
INFO - 2019-05-28 09:04:34 --> Language Class Initialized
ERROR - 2019-05-28 09:04:34 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:04:35 --> Config Class Initialized
INFO - 2019-05-28 09:04:35 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:04:35 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:04:35 --> Utf8 Class Initialized
INFO - 2019-05-28 09:04:35 --> URI Class Initialized
INFO - 2019-05-28 09:04:35 --> Router Class Initialized
INFO - 2019-05-28 09:04:35 --> Output Class Initialized
INFO - 2019-05-28 09:04:35 --> Security Class Initialized
DEBUG - 2019-05-28 09:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:04:35 --> Input Class Initialized
INFO - 2019-05-28 09:04:35 --> Language Class Initialized
ERROR - 2019-05-28 09:04:35 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:04:35 --> Config Class Initialized
INFO - 2019-05-28 09:04:35 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:04:35 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:04:35 --> Utf8 Class Initialized
INFO - 2019-05-28 09:04:35 --> URI Class Initialized
INFO - 2019-05-28 09:04:35 --> Router Class Initialized
INFO - 2019-05-28 09:04:35 --> Output Class Initialized
INFO - 2019-05-28 09:04:35 --> Security Class Initialized
DEBUG - 2019-05-28 09:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:04:35 --> Input Class Initialized
INFO - 2019-05-28 09:04:35 --> Language Class Initialized
ERROR - 2019-05-28 09:04:35 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:04:35 --> Config Class Initialized
INFO - 2019-05-28 09:04:35 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:04:35 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:04:35 --> Utf8 Class Initialized
INFO - 2019-05-28 09:04:35 --> URI Class Initialized
INFO - 2019-05-28 09:04:35 --> Router Class Initialized
INFO - 2019-05-28 09:04:35 --> Output Class Initialized
INFO - 2019-05-28 09:04:35 --> Security Class Initialized
DEBUG - 2019-05-28 09:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:04:35 --> Input Class Initialized
INFO - 2019-05-28 09:04:35 --> Language Class Initialized
ERROR - 2019-05-28 09:04:35 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:04:36 --> Config Class Initialized
INFO - 2019-05-28 09:04:36 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:04:36 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:04:36 --> Utf8 Class Initialized
INFO - 2019-05-28 09:04:36 --> URI Class Initialized
INFO - 2019-05-28 09:04:36 --> Router Class Initialized
INFO - 2019-05-28 09:04:36 --> Output Class Initialized
INFO - 2019-05-28 09:04:36 --> Security Class Initialized
DEBUG - 2019-05-28 09:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:04:36 --> Input Class Initialized
INFO - 2019-05-28 09:04:36 --> Language Class Initialized
ERROR - 2019-05-28 09:04:36 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:04:36 --> Config Class Initialized
INFO - 2019-05-28 09:04:36 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:04:36 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:04:36 --> Utf8 Class Initialized
INFO - 2019-05-28 09:04:36 --> URI Class Initialized
INFO - 2019-05-28 09:04:36 --> Router Class Initialized
INFO - 2019-05-28 09:04:36 --> Output Class Initialized
INFO - 2019-05-28 09:04:36 --> Security Class Initialized
DEBUG - 2019-05-28 09:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:04:36 --> Input Class Initialized
INFO - 2019-05-28 09:04:36 --> Language Class Initialized
ERROR - 2019-05-28 09:04:36 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:04:36 --> Config Class Initialized
INFO - 2019-05-28 09:04:36 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:04:36 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:04:36 --> Utf8 Class Initialized
INFO - 2019-05-28 09:04:36 --> URI Class Initialized
INFO - 2019-05-28 09:04:36 --> Router Class Initialized
INFO - 2019-05-28 09:04:36 --> Output Class Initialized
INFO - 2019-05-28 09:04:36 --> Security Class Initialized
DEBUG - 2019-05-28 09:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:04:36 --> Input Class Initialized
INFO - 2019-05-28 09:04:36 --> Language Class Initialized
ERROR - 2019-05-28 09:04:36 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:04:39 --> Config Class Initialized
INFO - 2019-05-28 09:04:39 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:04:39 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:04:39 --> Utf8 Class Initialized
INFO - 2019-05-28 09:04:39 --> URI Class Initialized
INFO - 2019-05-28 09:04:39 --> Router Class Initialized
INFO - 2019-05-28 09:04:39 --> Output Class Initialized
INFO - 2019-05-28 09:04:39 --> Security Class Initialized
DEBUG - 2019-05-28 09:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:04:39 --> Input Class Initialized
INFO - 2019-05-28 09:04:39 --> Language Class Initialized
ERROR - 2019-05-28 09:04:39 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:04:59 --> Config Class Initialized
INFO - 2019-05-28 09:04:59 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:04:59 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:04:59 --> Utf8 Class Initialized
INFO - 2019-05-28 09:04:59 --> URI Class Initialized
DEBUG - 2019-05-28 09:04:59 --> No URI present. Default controller set.
INFO - 2019-05-28 09:04:59 --> Router Class Initialized
INFO - 2019-05-28 09:04:59 --> Output Class Initialized
INFO - 2019-05-28 09:04:59 --> Security Class Initialized
DEBUG - 2019-05-28 09:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:04:59 --> Input Class Initialized
INFO - 2019-05-28 09:04:59 --> Language Class Initialized
INFO - 2019-05-28 09:04:59 --> Language Class Initialized
INFO - 2019-05-28 09:04:59 --> Config Class Initialized
INFO - 2019-05-28 09:04:59 --> Loader Class Initialized
INFO - 2019-05-28 09:04:59 --> Helper loaded: form_helper
INFO - 2019-05-28 09:04:59 --> Helper loaded: url_helper
INFO - 2019-05-28 09:04:59 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:04:59 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:04:59 --> Template library initialized
INFO - 2019-05-28 09:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:04:59 --> Controller Class Initialized
DEBUG - 2019-05-28 09:04:59 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 09:04:59 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 09:04:59 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 09:04:59 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 09:04:59 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 09:04:59 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 09:04:59 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 09:04:59 --> Final output sent to browser
DEBUG - 2019-05-28 09:04:59 --> Total execution time: 0.0465
INFO - 2019-05-28 09:05:00 --> Config Class Initialized
INFO - 2019-05-28 09:05:00 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:05:00 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:05:00 --> Utf8 Class Initialized
INFO - 2019-05-28 09:05:00 --> URI Class Initialized
INFO - 2019-05-28 09:05:00 --> Config Class Initialized
INFO - 2019-05-28 09:05:00 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:05:00 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:05:00 --> Utf8 Class Initialized
INFO - 2019-05-28 09:05:00 --> URI Class Initialized
INFO - 2019-05-28 09:05:00 --> Router Class Initialized
INFO - 2019-05-28 09:05:00 --> Config Class Initialized
INFO - 2019-05-28 09:05:00 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:05:00 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:05:00 --> Utf8 Class Initialized
INFO - 2019-05-28 09:05:00 --> URI Class Initialized
INFO - 2019-05-28 09:05:00 --> Router Class Initialized
INFO - 2019-05-28 09:05:00 --> Output Class Initialized
INFO - 2019-05-28 09:05:00 --> Security Class Initialized
DEBUG - 2019-05-28 09:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:05:00 --> Input Class Initialized
INFO - 2019-05-28 09:05:00 --> Language Class Initialized
ERROR - 2019-05-28 09:05:00 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:05:00 --> Router Class Initialized
INFO - 2019-05-28 09:05:00 --> Output Class Initialized
INFO - 2019-05-28 09:05:00 --> Security Class Initialized
DEBUG - 2019-05-28 09:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:05:00 --> Input Class Initialized
INFO - 2019-05-28 09:05:00 --> Language Class Initialized
ERROR - 2019-05-28 09:05:00 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:05:00 --> Output Class Initialized
INFO - 2019-05-28 09:05:00 --> Security Class Initialized
DEBUG - 2019-05-28 09:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:05:00 --> Input Class Initialized
INFO - 2019-05-28 09:05:00 --> Language Class Initialized
ERROR - 2019-05-28 09:05:00 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:05:12 --> Config Class Initialized
INFO - 2019-05-28 09:05:12 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:05:12 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:05:12 --> Utf8 Class Initialized
INFO - 2019-05-28 09:05:12 --> URI Class Initialized
DEBUG - 2019-05-28 09:05:12 --> No URI present. Default controller set.
INFO - 2019-05-28 09:05:12 --> Router Class Initialized
INFO - 2019-05-28 09:05:12 --> Output Class Initialized
INFO - 2019-05-28 09:05:12 --> Security Class Initialized
DEBUG - 2019-05-28 09:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:05:12 --> Input Class Initialized
INFO - 2019-05-28 09:05:12 --> Language Class Initialized
INFO - 2019-05-28 09:05:12 --> Language Class Initialized
INFO - 2019-05-28 09:05:12 --> Config Class Initialized
INFO - 2019-05-28 09:05:12 --> Loader Class Initialized
INFO - 2019-05-28 09:05:12 --> Helper loaded: form_helper
INFO - 2019-05-28 09:05:12 --> Helper loaded: url_helper
INFO - 2019-05-28 09:05:12 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:05:12 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:05:12 --> Template library initialized
INFO - 2019-05-28 09:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:05:12 --> Controller Class Initialized
DEBUG - 2019-05-28 09:05:12 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 09:05:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 09:05:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 09:05:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 09:05:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 09:05:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 09:05:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 09:05:12 --> Final output sent to browser
DEBUG - 2019-05-28 09:05:12 --> Total execution time: 0.0453
INFO - 2019-05-28 09:05:13 --> Config Class Initialized
INFO - 2019-05-28 09:05:13 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:05:13 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:05:13 --> Utf8 Class Initialized
INFO - 2019-05-28 09:05:13 --> URI Class Initialized
INFO - 2019-05-28 09:05:13 --> Config Class Initialized
INFO - 2019-05-28 09:05:13 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:05:13 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:05:13 --> Utf8 Class Initialized
INFO - 2019-05-28 09:05:13 --> URI Class Initialized
INFO - 2019-05-28 09:05:13 --> Router Class Initialized
INFO - 2019-05-28 09:05:13 --> Config Class Initialized
INFO - 2019-05-28 09:05:13 --> Hooks Class Initialized
INFO - 2019-05-28 09:05:13 --> Router Class Initialized
INFO - 2019-05-28 09:05:13 --> Output Class Initialized
INFO - 2019-05-28 09:05:13 --> Security Class Initialized
DEBUG - 2019-05-28 09:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:05:13 --> Input Class Initialized
INFO - 2019-05-28 09:05:13 --> Language Class Initialized
ERROR - 2019-05-28 09:05:13 --> 404 Page Not Found: /index
DEBUG - 2019-05-28 09:05:13 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:05:13 --> Utf8 Class Initialized
INFO - 2019-05-28 09:05:13 --> URI Class Initialized
INFO - 2019-05-28 09:05:13 --> Router Class Initialized
INFO - 2019-05-28 09:05:13 --> Output Class Initialized
INFO - 2019-05-28 09:05:13 --> Security Class Initialized
DEBUG - 2019-05-28 09:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:05:13 --> Input Class Initialized
INFO - 2019-05-28 09:05:13 --> Language Class Initialized
ERROR - 2019-05-28 09:05:13 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:05:13 --> Output Class Initialized
INFO - 2019-05-28 09:05:13 --> Security Class Initialized
DEBUG - 2019-05-28 09:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:05:13 --> Input Class Initialized
INFO - 2019-05-28 09:05:13 --> Language Class Initialized
ERROR - 2019-05-28 09:05:13 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:08:33 --> Config Class Initialized
INFO - 2019-05-28 09:08:33 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:08:33 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:08:33 --> Utf8 Class Initialized
INFO - 2019-05-28 09:08:33 --> URI Class Initialized
DEBUG - 2019-05-28 09:08:33 --> No URI present. Default controller set.
INFO - 2019-05-28 09:08:33 --> Router Class Initialized
INFO - 2019-05-28 09:08:33 --> Output Class Initialized
INFO - 2019-05-28 09:08:33 --> Security Class Initialized
DEBUG - 2019-05-28 09:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:08:33 --> Input Class Initialized
INFO - 2019-05-28 09:08:33 --> Language Class Initialized
INFO - 2019-05-28 09:08:33 --> Language Class Initialized
INFO - 2019-05-28 09:08:33 --> Config Class Initialized
INFO - 2019-05-28 09:08:33 --> Loader Class Initialized
INFO - 2019-05-28 09:08:33 --> Helper loaded: form_helper
INFO - 2019-05-28 09:08:33 --> Helper loaded: url_helper
INFO - 2019-05-28 09:08:33 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:08:33 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:08:33 --> Template library initialized
INFO - 2019-05-28 09:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:08:33 --> Controller Class Initialized
DEBUG - 2019-05-28 09:08:33 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 09:08:33 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 09:08:33 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 09:08:33 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 09:08:33 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 09:08:33 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 09:08:33 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 09:08:33 --> Final output sent to browser
DEBUG - 2019-05-28 09:08:33 --> Total execution time: 0.0487
INFO - 2019-05-28 09:08:33 --> Config Class Initialized
INFO - 2019-05-28 09:08:33 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:08:33 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:08:33 --> Utf8 Class Initialized
INFO - 2019-05-28 09:08:33 --> URI Class Initialized
INFO - 2019-05-28 09:08:33 --> Config Class Initialized
INFO - 2019-05-28 09:08:33 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:08:33 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:08:33 --> Utf8 Class Initialized
INFO - 2019-05-28 09:08:33 --> URI Class Initialized
INFO - 2019-05-28 09:08:33 --> Router Class Initialized
INFO - 2019-05-28 09:08:33 --> Config Class Initialized
INFO - 2019-05-28 09:08:33 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:08:33 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:08:33 --> Utf8 Class Initialized
INFO - 2019-05-28 09:08:33 --> URI Class Initialized
INFO - 2019-05-28 09:08:33 --> Router Class Initialized
INFO - 2019-05-28 09:08:33 --> Output Class Initialized
INFO - 2019-05-28 09:08:33 --> Security Class Initialized
DEBUG - 2019-05-28 09:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:08:33 --> Input Class Initialized
INFO - 2019-05-28 09:08:33 --> Language Class Initialized
ERROR - 2019-05-28 09:08:33 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:08:33 --> Router Class Initialized
INFO - 2019-05-28 09:08:33 --> Output Class Initialized
INFO - 2019-05-28 09:08:33 --> Security Class Initialized
DEBUG - 2019-05-28 09:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:08:33 --> Input Class Initialized
INFO - 2019-05-28 09:08:33 --> Language Class Initialized
ERROR - 2019-05-28 09:08:33 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:08:33 --> Output Class Initialized
INFO - 2019-05-28 09:08:33 --> Security Class Initialized
DEBUG - 2019-05-28 09:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:08:33 --> Input Class Initialized
INFO - 2019-05-28 09:08:33 --> Language Class Initialized
ERROR - 2019-05-28 09:08:33 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:11:19 --> Config Class Initialized
INFO - 2019-05-28 09:11:19 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:11:19 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:11:19 --> Utf8 Class Initialized
INFO - 2019-05-28 09:11:19 --> URI Class Initialized
DEBUG - 2019-05-28 09:11:19 --> No URI present. Default controller set.
INFO - 2019-05-28 09:11:19 --> Router Class Initialized
INFO - 2019-05-28 09:11:19 --> Output Class Initialized
INFO - 2019-05-28 09:11:19 --> Security Class Initialized
DEBUG - 2019-05-28 09:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:11:19 --> Input Class Initialized
INFO - 2019-05-28 09:11:19 --> Language Class Initialized
INFO - 2019-05-28 09:11:19 --> Language Class Initialized
INFO - 2019-05-28 09:11:19 --> Config Class Initialized
INFO - 2019-05-28 09:11:19 --> Loader Class Initialized
INFO - 2019-05-28 09:11:19 --> Helper loaded: form_helper
INFO - 2019-05-28 09:11:19 --> Helper loaded: url_helper
INFO - 2019-05-28 09:11:19 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:11:19 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:11:19 --> Template library initialized
INFO - 2019-05-28 09:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:11:19 --> Controller Class Initialized
DEBUG - 2019-05-28 09:11:19 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 09:11:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 09:11:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 09:11:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 09:11:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 09:11:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 09:11:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 09:11:19 --> Final output sent to browser
DEBUG - 2019-05-28 09:11:19 --> Total execution time: 0.0519
INFO - 2019-05-28 09:11:19 --> Config Class Initialized
INFO - 2019-05-28 09:11:19 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:11:19 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:11:19 --> Utf8 Class Initialized
INFO - 2019-05-28 09:11:19 --> URI Class Initialized
INFO - 2019-05-28 09:11:19 --> Config Class Initialized
INFO - 2019-05-28 09:11:19 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:11:19 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:11:19 --> Utf8 Class Initialized
INFO - 2019-05-28 09:11:19 --> URI Class Initialized
INFO - 2019-05-28 09:11:19 --> Router Class Initialized
INFO - 2019-05-28 09:11:19 --> Config Class Initialized
INFO - 2019-05-28 09:11:19 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:11:19 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:11:19 --> Utf8 Class Initialized
INFO - 2019-05-28 09:11:19 --> URI Class Initialized
INFO - 2019-05-28 09:11:19 --> Router Class Initialized
INFO - 2019-05-28 09:11:19 --> Output Class Initialized
INFO - 2019-05-28 09:11:19 --> Security Class Initialized
DEBUG - 2019-05-28 09:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:11:19 --> Input Class Initialized
INFO - 2019-05-28 09:11:19 --> Language Class Initialized
ERROR - 2019-05-28 09:11:19 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:11:19 --> Output Class Initialized
INFO - 2019-05-28 09:11:19 --> Security Class Initialized
DEBUG - 2019-05-28 09:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:11:19 --> Input Class Initialized
INFO - 2019-05-28 09:11:19 --> Language Class Initialized
ERROR - 2019-05-28 09:11:19 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:11:19 --> Router Class Initialized
INFO - 2019-05-28 09:11:19 --> Output Class Initialized
INFO - 2019-05-28 09:11:19 --> Security Class Initialized
DEBUG - 2019-05-28 09:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:11:19 --> Input Class Initialized
INFO - 2019-05-28 09:11:19 --> Language Class Initialized
ERROR - 2019-05-28 09:11:19 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:11:26 --> Config Class Initialized
INFO - 2019-05-28 09:11:26 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:11:26 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:11:26 --> Utf8 Class Initialized
INFO - 2019-05-28 09:11:26 --> URI Class Initialized
DEBUG - 2019-05-28 09:11:26 --> No URI present. Default controller set.
INFO - 2019-05-28 09:11:26 --> Router Class Initialized
INFO - 2019-05-28 09:11:26 --> Output Class Initialized
INFO - 2019-05-28 09:11:26 --> Security Class Initialized
DEBUG - 2019-05-28 09:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:11:26 --> Input Class Initialized
INFO - 2019-05-28 09:11:26 --> Language Class Initialized
INFO - 2019-05-28 09:11:26 --> Language Class Initialized
INFO - 2019-05-28 09:11:26 --> Config Class Initialized
INFO - 2019-05-28 09:11:26 --> Loader Class Initialized
INFO - 2019-05-28 09:11:26 --> Helper loaded: form_helper
INFO - 2019-05-28 09:11:26 --> Helper loaded: url_helper
INFO - 2019-05-28 09:11:26 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:11:26 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:11:26 --> Template library initialized
INFO - 2019-05-28 09:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:11:26 --> Controller Class Initialized
DEBUG - 2019-05-28 09:11:26 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 09:11:26 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 09:11:26 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 09:11:26 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 09:11:26 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 09:11:26 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 09:11:26 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 09:11:26 --> Final output sent to browser
DEBUG - 2019-05-28 09:11:26 --> Total execution time: 0.0478
INFO - 2019-05-28 09:11:27 --> Config Class Initialized
INFO - 2019-05-28 09:11:27 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:11:27 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:11:27 --> Utf8 Class Initialized
INFO - 2019-05-28 09:11:27 --> URI Class Initialized
INFO - 2019-05-28 09:11:27 --> Config Class Initialized
INFO - 2019-05-28 09:11:27 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:11:27 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:11:27 --> Utf8 Class Initialized
INFO - 2019-05-28 09:11:27 --> Config Class Initialized
INFO - 2019-05-28 09:11:27 --> Hooks Class Initialized
INFO - 2019-05-28 09:11:27 --> URI Class Initialized
INFO - 2019-05-28 09:11:27 --> Router Class Initialized
INFO - 2019-05-28 09:11:27 --> Output Class Initialized
INFO - 2019-05-28 09:11:27 --> Router Class Initialized
INFO - 2019-05-28 09:11:27 --> Output Class Initialized
INFO - 2019-05-28 09:11:27 --> Security Class Initialized
DEBUG - 2019-05-28 09:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:11:27 --> Input Class Initialized
INFO - 2019-05-28 09:11:27 --> Language Class Initialized
DEBUG - 2019-05-28 09:11:27 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:11:27 --> Utf8 Class Initialized
INFO - 2019-05-28 09:11:27 --> URI Class Initialized
INFO - 2019-05-28 09:11:27 --> Router Class Initialized
INFO - 2019-05-28 09:11:27 --> Output Class Initialized
INFO - 2019-05-28 09:11:27 --> Security Class Initialized
DEBUG - 2019-05-28 09:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:11:27 --> Input Class Initialized
INFO - 2019-05-28 09:11:27 --> Language Class Initialized
ERROR - 2019-05-28 09:11:27 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:11:27 --> Security Class Initialized
DEBUG - 2019-05-28 09:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:11:27 --> Input Class Initialized
INFO - 2019-05-28 09:11:27 --> Language Class Initialized
ERROR - 2019-05-28 09:11:27 --> 404 Page Not Found: /index
ERROR - 2019-05-28 09:11:27 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:13:36 --> Config Class Initialized
INFO - 2019-05-28 09:13:36 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:13:36 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:13:36 --> Utf8 Class Initialized
INFO - 2019-05-28 09:13:36 --> URI Class Initialized
DEBUG - 2019-05-28 09:13:36 --> No URI present. Default controller set.
INFO - 2019-05-28 09:13:36 --> Router Class Initialized
INFO - 2019-05-28 09:13:36 --> Output Class Initialized
INFO - 2019-05-28 09:13:36 --> Security Class Initialized
DEBUG - 2019-05-28 09:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:13:36 --> Input Class Initialized
INFO - 2019-05-28 09:13:36 --> Language Class Initialized
INFO - 2019-05-28 09:13:36 --> Language Class Initialized
INFO - 2019-05-28 09:13:36 --> Config Class Initialized
INFO - 2019-05-28 09:13:36 --> Loader Class Initialized
INFO - 2019-05-28 09:13:36 --> Helper loaded: form_helper
INFO - 2019-05-28 09:13:36 --> Helper loaded: url_helper
INFO - 2019-05-28 09:13:36 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:13:36 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:13:36 --> Template library initialized
INFO - 2019-05-28 09:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:13:36 --> Controller Class Initialized
DEBUG - 2019-05-28 09:13:36 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 09:13:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 09:13:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 09:13:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 09:13:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 09:13:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 09:13:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 09:13:37 --> Final output sent to browser
DEBUG - 2019-05-28 09:13:37 --> Total execution time: 0.0497
INFO - 2019-05-28 09:13:37 --> Config Class Initialized
INFO - 2019-05-28 09:13:37 --> Hooks Class Initialized
INFO - 2019-05-28 09:13:37 --> Config Class Initialized
INFO - 2019-05-28 09:13:37 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:13:37 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:13:37 --> Utf8 Class Initialized
INFO - 2019-05-28 09:13:37 --> URI Class Initialized
INFO - 2019-05-28 09:13:37 --> Router Class Initialized
INFO - 2019-05-28 09:13:37 --> Config Class Initialized
INFO - 2019-05-28 09:13:37 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:13:37 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:13:37 --> Utf8 Class Initialized
INFO - 2019-05-28 09:13:37 --> URI Class Initialized
INFO - 2019-05-28 09:13:37 --> Router Class Initialized
INFO - 2019-05-28 09:13:37 --> Output Class Initialized
INFO - 2019-05-28 09:13:37 --> Security Class Initialized
DEBUG - 2019-05-28 09:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:13:37 --> Input Class Initialized
INFO - 2019-05-28 09:13:37 --> Language Class Initialized
ERROR - 2019-05-28 09:13:37 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:13:37 --> Output Class Initialized
INFO - 2019-05-28 09:13:37 --> Security Class Initialized
DEBUG - 2019-05-28 09:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:13:37 --> Input Class Initialized
INFO - 2019-05-28 09:13:37 --> Language Class Initialized
ERROR - 2019-05-28 09:13:37 --> 404 Page Not Found: /index
DEBUG - 2019-05-28 09:13:37 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:13:37 --> Utf8 Class Initialized
INFO - 2019-05-28 09:13:37 --> URI Class Initialized
INFO - 2019-05-28 09:13:37 --> Router Class Initialized
INFO - 2019-05-28 09:13:37 --> Output Class Initialized
INFO - 2019-05-28 09:13:37 --> Security Class Initialized
DEBUG - 2019-05-28 09:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:13:37 --> Input Class Initialized
INFO - 2019-05-28 09:13:37 --> Language Class Initialized
ERROR - 2019-05-28 09:13:37 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:13:39 --> Config Class Initialized
INFO - 2019-05-28 09:13:39 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:13:39 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:13:39 --> Utf8 Class Initialized
INFO - 2019-05-28 09:13:39 --> URI Class Initialized
DEBUG - 2019-05-28 09:13:39 --> No URI present. Default controller set.
INFO - 2019-05-28 09:13:39 --> Router Class Initialized
INFO - 2019-05-28 09:13:39 --> Output Class Initialized
INFO - 2019-05-28 09:13:39 --> Security Class Initialized
DEBUG - 2019-05-28 09:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:13:39 --> Input Class Initialized
INFO - 2019-05-28 09:13:39 --> Language Class Initialized
INFO - 2019-05-28 09:13:39 --> Language Class Initialized
INFO - 2019-05-28 09:13:39 --> Config Class Initialized
INFO - 2019-05-28 09:13:39 --> Loader Class Initialized
INFO - 2019-05-28 09:13:39 --> Helper loaded: form_helper
INFO - 2019-05-28 09:13:39 --> Helper loaded: url_helper
INFO - 2019-05-28 09:13:39 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:13:39 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:13:39 --> Template library initialized
INFO - 2019-05-28 09:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:13:39 --> Controller Class Initialized
DEBUG - 2019-05-28 09:13:39 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 09:13:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 09:13:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 09:13:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 09:13:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 09:13:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 09:13:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 09:13:39 --> Final output sent to browser
DEBUG - 2019-05-28 09:13:39 --> Total execution time: 0.0457
INFO - 2019-05-28 09:13:40 --> Config Class Initialized
INFO - 2019-05-28 09:13:40 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:13:40 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:13:40 --> Utf8 Class Initialized
INFO - 2019-05-28 09:13:40 --> URI Class Initialized
INFO - 2019-05-28 09:13:40 --> Config Class Initialized
INFO - 2019-05-28 09:13:40 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:13:40 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:13:40 --> Utf8 Class Initialized
INFO - 2019-05-28 09:13:40 --> URI Class Initialized
INFO - 2019-05-28 09:13:40 --> Router Class Initialized
INFO - 2019-05-28 09:13:40 --> Output Class Initialized
INFO - 2019-05-28 09:13:40 --> Security Class Initialized
DEBUG - 2019-05-28 09:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:13:40 --> Input Class Initialized
INFO - 2019-05-28 09:13:40 --> Language Class Initialized
ERROR - 2019-05-28 09:13:40 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:13:40 --> Router Class Initialized
INFO - 2019-05-28 09:13:40 --> Output Class Initialized
INFO - 2019-05-28 09:13:40 --> Security Class Initialized
DEBUG - 2019-05-28 09:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:13:40 --> Input Class Initialized
INFO - 2019-05-28 09:13:40 --> Language Class Initialized
ERROR - 2019-05-28 09:13:40 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:13:42 --> Config Class Initialized
INFO - 2019-05-28 09:13:42 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:13:42 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:13:42 --> Utf8 Class Initialized
INFO - 2019-05-28 09:13:42 --> URI Class Initialized
INFO - 2019-05-28 09:13:42 --> Router Class Initialized
INFO - 2019-05-28 09:13:42 --> Output Class Initialized
INFO - 2019-05-28 09:13:42 --> Security Class Initialized
DEBUG - 2019-05-28 09:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:13:42 --> Input Class Initialized
INFO - 2019-05-28 09:13:42 --> Language Class Initialized
ERROR - 2019-05-28 09:13:42 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:13:56 --> Config Class Initialized
INFO - 2019-05-28 09:13:56 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:13:56 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:13:56 --> Utf8 Class Initialized
INFO - 2019-05-28 09:13:56 --> URI Class Initialized
DEBUG - 2019-05-28 09:13:56 --> No URI present. Default controller set.
INFO - 2019-05-28 09:13:56 --> Router Class Initialized
INFO - 2019-05-28 09:13:56 --> Output Class Initialized
INFO - 2019-05-28 09:13:56 --> Security Class Initialized
DEBUG - 2019-05-28 09:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:13:56 --> Input Class Initialized
INFO - 2019-05-28 09:13:56 --> Language Class Initialized
INFO - 2019-05-28 09:13:56 --> Language Class Initialized
INFO - 2019-05-28 09:13:56 --> Config Class Initialized
INFO - 2019-05-28 09:13:56 --> Loader Class Initialized
INFO - 2019-05-28 09:13:56 --> Helper loaded: form_helper
INFO - 2019-05-28 09:13:56 --> Helper loaded: url_helper
INFO - 2019-05-28 09:13:56 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:13:56 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:13:56 --> Template library initialized
INFO - 2019-05-28 09:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:13:56 --> Controller Class Initialized
DEBUG - 2019-05-28 09:13:56 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 09:13:56 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 09:13:56 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 09:13:56 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 09:13:56 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 09:13:56 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 09:13:56 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 09:13:57 --> Final output sent to browser
DEBUG - 2019-05-28 09:13:57 --> Total execution time: 0.0530
INFO - 2019-05-28 09:13:57 --> Config Class Initialized
INFO - 2019-05-28 09:13:57 --> Hooks Class Initialized
INFO - 2019-05-28 09:13:57 --> Config Class Initialized
INFO - 2019-05-28 09:13:57 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:13:57 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:13:57 --> Utf8 Class Initialized
INFO - 2019-05-28 09:13:57 --> URI Class Initialized
INFO - 2019-05-28 09:13:57 --> Router Class Initialized
INFO - 2019-05-28 09:13:57 --> Config Class Initialized
INFO - 2019-05-28 09:13:57 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:13:57 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:13:57 --> Utf8 Class Initialized
INFO - 2019-05-28 09:13:57 --> Output Class Initialized
INFO - 2019-05-28 09:13:57 --> Security Class Initialized
DEBUG - 2019-05-28 09:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:13:57 --> Input Class Initialized
INFO - 2019-05-28 09:13:57 --> Language Class Initialized
ERROR - 2019-05-28 09:13:57 --> 404 Page Not Found: /index
DEBUG - 2019-05-28 09:13:57 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:13:57 --> Utf8 Class Initialized
INFO - 2019-05-28 09:13:57 --> URI Class Initialized
INFO - 2019-05-28 09:13:57 --> Router Class Initialized
INFO - 2019-05-28 09:13:57 --> Output Class Initialized
INFO - 2019-05-28 09:13:57 --> Security Class Initialized
DEBUG - 2019-05-28 09:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:13:57 --> Input Class Initialized
INFO - 2019-05-28 09:13:57 --> URI Class Initialized
INFO - 2019-05-28 09:13:57 --> Router Class Initialized
INFO - 2019-05-28 09:13:57 --> Output Class Initialized
INFO - 2019-05-28 09:13:57 --> Security Class Initialized
DEBUG - 2019-05-28 09:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:13:57 --> Input Class Initialized
INFO - 2019-05-28 09:13:57 --> Language Class Initialized
ERROR - 2019-05-28 09:13:57 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:13:57 --> Language Class Initialized
ERROR - 2019-05-28 09:13:57 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:13:59 --> Config Class Initialized
INFO - 2019-05-28 09:13:59 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:13:59 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:13:59 --> Utf8 Class Initialized
INFO - 2019-05-28 09:13:59 --> URI Class Initialized
DEBUG - 2019-05-28 09:13:59 --> No URI present. Default controller set.
INFO - 2019-05-28 09:13:59 --> Router Class Initialized
INFO - 2019-05-28 09:13:59 --> Output Class Initialized
INFO - 2019-05-28 09:13:59 --> Security Class Initialized
DEBUG - 2019-05-28 09:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:13:59 --> Input Class Initialized
INFO - 2019-05-28 09:13:59 --> Language Class Initialized
INFO - 2019-05-28 09:13:59 --> Language Class Initialized
INFO - 2019-05-28 09:13:59 --> Config Class Initialized
INFO - 2019-05-28 09:13:59 --> Loader Class Initialized
INFO - 2019-05-28 09:13:59 --> Helper loaded: form_helper
INFO - 2019-05-28 09:13:59 --> Helper loaded: url_helper
INFO - 2019-05-28 09:13:59 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:13:59 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:13:59 --> Template library initialized
INFO - 2019-05-28 09:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:13:59 --> Controller Class Initialized
DEBUG - 2019-05-28 09:13:59 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 09:13:59 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 09:13:59 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 09:13:59 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 09:13:59 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 09:13:59 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 09:13:59 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 09:13:59 --> Final output sent to browser
DEBUG - 2019-05-28 09:13:59 --> Total execution time: 0.0474
INFO - 2019-05-28 09:14:00 --> Config Class Initialized
INFO - 2019-05-28 09:14:00 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:14:00 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:14:00 --> Utf8 Class Initialized
INFO - 2019-05-28 09:14:00 --> URI Class Initialized
INFO - 2019-05-28 09:14:00 --> Config Class Initialized
INFO - 2019-05-28 09:14:00 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:14:00 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:14:00 --> Utf8 Class Initialized
INFO - 2019-05-28 09:14:00 --> URI Class Initialized
INFO - 2019-05-28 09:14:00 --> Config Class Initialized
INFO - 2019-05-28 09:14:00 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:14:00 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:14:00 --> Utf8 Class Initialized
INFO - 2019-05-28 09:14:00 --> URI Class Initialized
INFO - 2019-05-28 09:14:00 --> Router Class Initialized
INFO - 2019-05-28 09:14:00 --> Output Class Initialized
INFO - 2019-05-28 09:14:00 --> Security Class Initialized
DEBUG - 2019-05-28 09:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:14:00 --> Input Class Initialized
INFO - 2019-05-28 09:14:00 --> Language Class Initialized
ERROR - 2019-05-28 09:14:00 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:14:00 --> Router Class Initialized
INFO - 2019-05-28 09:14:00 --> Output Class Initialized
INFO - 2019-05-28 09:14:00 --> Security Class Initialized
DEBUG - 2019-05-28 09:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:14:00 --> Input Class Initialized
INFO - 2019-05-28 09:14:00 --> Language Class Initialized
ERROR - 2019-05-28 09:14:00 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:14:00 --> Router Class Initialized
INFO - 2019-05-28 09:14:00 --> Output Class Initialized
INFO - 2019-05-28 09:14:00 --> Security Class Initialized
DEBUG - 2019-05-28 09:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:14:00 --> Input Class Initialized
INFO - 2019-05-28 09:14:00 --> Language Class Initialized
ERROR - 2019-05-28 09:14:00 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:14:09 --> Config Class Initialized
INFO - 2019-05-28 09:14:09 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:14:09 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:14:09 --> Utf8 Class Initialized
INFO - 2019-05-28 09:14:09 --> URI Class Initialized
DEBUG - 2019-05-28 09:14:09 --> No URI present. Default controller set.
INFO - 2019-05-28 09:14:09 --> Router Class Initialized
INFO - 2019-05-28 09:14:09 --> Output Class Initialized
INFO - 2019-05-28 09:14:09 --> Security Class Initialized
DEBUG - 2019-05-28 09:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:14:09 --> Input Class Initialized
INFO - 2019-05-28 09:14:09 --> Language Class Initialized
INFO - 2019-05-28 09:14:09 --> Language Class Initialized
INFO - 2019-05-28 09:14:09 --> Config Class Initialized
INFO - 2019-05-28 09:14:09 --> Loader Class Initialized
INFO - 2019-05-28 09:14:09 --> Helper loaded: form_helper
INFO - 2019-05-28 09:14:09 --> Helper loaded: url_helper
INFO - 2019-05-28 09:14:09 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:14:09 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:14:09 --> Template library initialized
INFO - 2019-05-28 09:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:14:09 --> Controller Class Initialized
DEBUG - 2019-05-28 09:14:09 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 09:14:09 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 09:14:09 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 09:14:09 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 09:14:09 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 09:14:09 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 09:14:09 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 09:14:09 --> Final output sent to browser
DEBUG - 2019-05-28 09:14:09 --> Total execution time: 0.0461
INFO - 2019-05-28 09:14:10 --> Config Class Initialized
INFO - 2019-05-28 09:14:10 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:14:10 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:14:10 --> Utf8 Class Initialized
INFO - 2019-05-28 09:14:10 --> URI Class Initialized
INFO - 2019-05-28 09:14:10 --> Config Class Initialized
INFO - 2019-05-28 09:14:10 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:14:10 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:14:10 --> Utf8 Class Initialized
INFO - 2019-05-28 09:14:10 --> URI Class Initialized
INFO - 2019-05-28 09:14:10 --> Router Class Initialized
INFO - 2019-05-28 09:14:10 --> Router Class Initialized
INFO - 2019-05-28 09:14:10 --> Output Class Initialized
INFO - 2019-05-28 09:14:10 --> Security Class Initialized
DEBUG - 2019-05-28 09:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:14:10 --> Input Class Initialized
INFO - 2019-05-28 09:14:10 --> Language Class Initialized
ERROR - 2019-05-28 09:14:10 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:14:10 --> Output Class Initialized
INFO - 2019-05-28 09:14:10 --> Security Class Initialized
DEBUG - 2019-05-28 09:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:14:10 --> Input Class Initialized
INFO - 2019-05-28 09:14:10 --> Language Class Initialized
ERROR - 2019-05-28 09:14:10 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:14:12 --> Config Class Initialized
INFO - 2019-05-28 09:14:12 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:14:12 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:14:12 --> Utf8 Class Initialized
INFO - 2019-05-28 09:14:12 --> URI Class Initialized
INFO - 2019-05-28 09:14:12 --> Router Class Initialized
INFO - 2019-05-28 09:14:12 --> Output Class Initialized
INFO - 2019-05-28 09:14:12 --> Security Class Initialized
DEBUG - 2019-05-28 09:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:14:12 --> Input Class Initialized
INFO - 2019-05-28 09:14:12 --> Language Class Initialized
ERROR - 2019-05-28 09:14:12 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:14:19 --> Config Class Initialized
INFO - 2019-05-28 09:14:19 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:14:19 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:14:19 --> Utf8 Class Initialized
INFO - 2019-05-28 09:14:19 --> URI Class Initialized
DEBUG - 2019-05-28 09:14:19 --> No URI present. Default controller set.
INFO - 2019-05-28 09:14:19 --> Router Class Initialized
INFO - 2019-05-28 09:14:19 --> Output Class Initialized
INFO - 2019-05-28 09:14:19 --> Security Class Initialized
DEBUG - 2019-05-28 09:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:14:19 --> Input Class Initialized
INFO - 2019-05-28 09:14:19 --> Language Class Initialized
INFO - 2019-05-28 09:14:19 --> Language Class Initialized
INFO - 2019-05-28 09:14:19 --> Config Class Initialized
INFO - 2019-05-28 09:14:19 --> Loader Class Initialized
INFO - 2019-05-28 09:14:19 --> Helper loaded: form_helper
INFO - 2019-05-28 09:14:20 --> Helper loaded: url_helper
INFO - 2019-05-28 09:14:20 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:14:20 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:14:20 --> Template library initialized
INFO - 2019-05-28 09:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:14:20 --> Controller Class Initialized
DEBUG - 2019-05-28 09:14:20 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 09:14:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 09:14:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 09:14:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 09:14:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 09:14:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 09:14:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 09:14:20 --> Config Class Initialized
INFO - 2019-05-28 09:14:20 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:14:20 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:14:20 --> Utf8 Class Initialized
INFO - 2019-05-28 09:14:20 --> URI Class Initialized
DEBUG - 2019-05-28 09:14:20 --> No URI present. Default controller set.
INFO - 2019-05-28 09:14:20 --> Router Class Initialized
INFO - 2019-05-28 09:14:20 --> Output Class Initialized
INFO - 2019-05-28 09:14:20 --> Security Class Initialized
DEBUG - 2019-05-28 09:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:14:20 --> Input Class Initialized
INFO - 2019-05-28 09:14:20 --> Language Class Initialized
INFO - 2019-05-28 09:14:20 --> Language Class Initialized
INFO - 2019-05-28 09:14:20 --> Config Class Initialized
INFO - 2019-05-28 09:14:20 --> Loader Class Initialized
INFO - 2019-05-28 09:14:20 --> Helper loaded: form_helper
INFO - 2019-05-28 09:14:20 --> Helper loaded: url_helper
INFO - 2019-05-28 09:14:20 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:14:20 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:14:20 --> Template library initialized
INFO - 2019-05-28 09:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:14:20 --> Controller Class Initialized
DEBUG - 2019-05-28 09:14:20 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 09:14:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 09:14:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 09:14:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 09:14:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 09:14:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 09:14:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 09:14:21 --> Final output sent to browser
DEBUG - 2019-05-28 09:14:21 --> Total execution time: 0.0532
INFO - 2019-05-28 09:14:21 --> Config Class Initialized
INFO - 2019-05-28 09:14:21 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:14:21 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:14:21 --> Utf8 Class Initialized
INFO - 2019-05-28 09:14:21 --> URI Class Initialized
INFO - 2019-05-28 09:14:21 --> Router Class Initialized
INFO - 2019-05-28 09:14:21 --> Output Class Initialized
INFO - 2019-05-28 09:14:21 --> Security Class Initialized
DEBUG - 2019-05-28 09:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:14:21 --> Input Class Initialized
INFO - 2019-05-28 09:14:21 --> Language Class Initialized
ERROR - 2019-05-28 09:14:21 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:14:22 --> Config Class Initialized
INFO - 2019-05-28 09:14:22 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:14:22 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:14:22 --> Utf8 Class Initialized
INFO - 2019-05-28 09:14:22 --> URI Class Initialized
INFO - 2019-05-28 09:14:22 --> Router Class Initialized
INFO - 2019-05-28 09:14:22 --> Output Class Initialized
INFO - 2019-05-28 09:14:22 --> Security Class Initialized
DEBUG - 2019-05-28 09:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:14:22 --> Input Class Initialized
INFO - 2019-05-28 09:14:22 --> Language Class Initialized
ERROR - 2019-05-28 09:14:22 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:14:22 --> Config Class Initialized
INFO - 2019-05-28 09:14:22 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:14:22 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:14:22 --> Utf8 Class Initialized
INFO - 2019-05-28 09:14:22 --> URI Class Initialized
INFO - 2019-05-28 09:14:22 --> Router Class Initialized
INFO - 2019-05-28 09:14:22 --> Output Class Initialized
INFO - 2019-05-28 09:14:22 --> Security Class Initialized
DEBUG - 2019-05-28 09:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:14:22 --> Input Class Initialized
INFO - 2019-05-28 09:14:22 --> Language Class Initialized
ERROR - 2019-05-28 09:14:22 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:14:24 --> Config Class Initialized
INFO - 2019-05-28 09:14:24 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:14:24 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:14:24 --> Utf8 Class Initialized
INFO - 2019-05-28 09:14:24 --> URI Class Initialized
INFO - 2019-05-28 09:14:24 --> Router Class Initialized
INFO - 2019-05-28 09:14:24 --> Output Class Initialized
INFO - 2019-05-28 09:14:24 --> Security Class Initialized
DEBUG - 2019-05-28 09:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:14:24 --> Input Class Initialized
INFO - 2019-05-28 09:14:24 --> Language Class Initialized
ERROR - 2019-05-28 09:14:24 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:14:30 --> Config Class Initialized
INFO - 2019-05-28 09:14:30 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:14:30 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:14:30 --> Utf8 Class Initialized
INFO - 2019-05-28 09:14:30 --> URI Class Initialized
DEBUG - 2019-05-28 09:14:30 --> No URI present. Default controller set.
INFO - 2019-05-28 09:14:30 --> Router Class Initialized
INFO - 2019-05-28 09:14:30 --> Output Class Initialized
INFO - 2019-05-28 09:14:30 --> Security Class Initialized
DEBUG - 2019-05-28 09:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:14:30 --> Input Class Initialized
INFO - 2019-05-28 09:14:30 --> Language Class Initialized
INFO - 2019-05-28 09:14:30 --> Language Class Initialized
INFO - 2019-05-28 09:14:30 --> Config Class Initialized
INFO - 2019-05-28 09:14:30 --> Loader Class Initialized
INFO - 2019-05-28 09:14:30 --> Helper loaded: form_helper
INFO - 2019-05-28 09:14:30 --> Helper loaded: url_helper
INFO - 2019-05-28 09:14:30 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:14:30 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:14:30 --> Template library initialized
INFO - 2019-05-28 09:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:14:30 --> Controller Class Initialized
DEBUG - 2019-05-28 09:14:30 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 09:14:30 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 09:14:30 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 09:14:30 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 09:14:30 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 09:14:30 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 09:14:30 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 09:14:30 --> Final output sent to browser
DEBUG - 2019-05-28 09:14:30 --> Total execution time: 0.0500
INFO - 2019-05-28 09:14:30 --> Config Class Initialized
INFO - 2019-05-28 09:14:30 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:14:31 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:14:31 --> Utf8 Class Initialized
INFO - 2019-05-28 09:14:31 --> URI Class Initialized
INFO - 2019-05-28 09:14:31 --> Config Class Initialized
INFO - 2019-05-28 09:14:31 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:14:31 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:14:31 --> Utf8 Class Initialized
INFO - 2019-05-28 09:14:31 --> URI Class Initialized
INFO - 2019-05-28 09:14:31 --> Config Class Initialized
INFO - 2019-05-28 09:14:31 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:14:31 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:14:31 --> Router Class Initialized
INFO - 2019-05-28 09:14:31 --> Output Class Initialized
INFO - 2019-05-28 09:14:31 --> Security Class Initialized
DEBUG - 2019-05-28 09:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:14:31 --> Input Class Initialized
INFO - 2019-05-28 09:14:31 --> Language Class Initialized
ERROR - 2019-05-28 09:14:31 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:14:31 --> Router Class Initialized
INFO - 2019-05-28 09:14:31 --> Output Class Initialized
INFO - 2019-05-28 09:14:31 --> Security Class Initialized
DEBUG - 2019-05-28 09:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:14:31 --> Input Class Initialized
INFO - 2019-05-28 09:14:31 --> Language Class Initialized
ERROR - 2019-05-28 09:14:31 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:14:31 --> Utf8 Class Initialized
INFO - 2019-05-28 09:14:31 --> URI Class Initialized
INFO - 2019-05-28 09:14:31 --> Router Class Initialized
INFO - 2019-05-28 09:14:31 --> Output Class Initialized
INFO - 2019-05-28 09:14:31 --> Security Class Initialized
DEBUG - 2019-05-28 09:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:14:31 --> Input Class Initialized
INFO - 2019-05-28 09:14:31 --> Language Class Initialized
ERROR - 2019-05-28 09:14:31 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:15:05 --> Config Class Initialized
INFO - 2019-05-28 09:15:05 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:15:05 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:15:05 --> Utf8 Class Initialized
INFO - 2019-05-28 09:15:05 --> URI Class Initialized
DEBUG - 2019-05-28 09:15:05 --> No URI present. Default controller set.
INFO - 2019-05-28 09:15:05 --> Router Class Initialized
INFO - 2019-05-28 09:15:05 --> Output Class Initialized
INFO - 2019-05-28 09:15:05 --> Security Class Initialized
DEBUG - 2019-05-28 09:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:15:05 --> Input Class Initialized
INFO - 2019-05-28 09:15:05 --> Language Class Initialized
INFO - 2019-05-28 09:15:05 --> Language Class Initialized
INFO - 2019-05-28 09:15:05 --> Config Class Initialized
INFO - 2019-05-28 09:15:05 --> Loader Class Initialized
INFO - 2019-05-28 09:15:05 --> Helper loaded: form_helper
INFO - 2019-05-28 09:15:05 --> Helper loaded: url_helper
INFO - 2019-05-28 09:15:05 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:15:05 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:15:05 --> Template library initialized
INFO - 2019-05-28 09:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:15:05 --> Controller Class Initialized
DEBUG - 2019-05-28 09:15:05 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 09:15:05 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 09:15:05 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 09:15:05 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 09:15:05 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 09:15:05 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 09:15:05 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 09:15:05 --> Final output sent to browser
DEBUG - 2019-05-28 09:15:05 --> Total execution time: 0.0493
INFO - 2019-05-28 09:15:06 --> Config Class Initialized
INFO - 2019-05-28 09:15:06 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:15:06 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:15:06 --> Utf8 Class Initialized
INFO - 2019-05-28 09:15:06 --> URI Class Initialized
INFO - 2019-05-28 09:15:06 --> Config Class Initialized
INFO - 2019-05-28 09:15:06 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:15:06 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:15:06 --> Utf8 Class Initialized
INFO - 2019-05-28 09:15:06 --> URI Class Initialized
INFO - 2019-05-28 09:15:06 --> Config Class Initialized
INFO - 2019-05-28 09:15:06 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:15:06 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:15:06 --> Utf8 Class Initialized
INFO - 2019-05-28 09:15:06 --> URI Class Initialized
INFO - 2019-05-28 09:15:06 --> Router Class Initialized
INFO - 2019-05-28 09:15:06 --> Output Class Initialized
INFO - 2019-05-28 09:15:06 --> Security Class Initialized
DEBUG - 2019-05-28 09:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:15:06 --> Input Class Initialized
INFO - 2019-05-28 09:15:06 --> Language Class Initialized
ERROR - 2019-05-28 09:15:06 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:15:06 --> Router Class Initialized
INFO - 2019-05-28 09:15:06 --> Output Class Initialized
INFO - 2019-05-28 09:15:06 --> Security Class Initialized
DEBUG - 2019-05-28 09:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:15:06 --> Input Class Initialized
INFO - 2019-05-28 09:15:06 --> Language Class Initialized
ERROR - 2019-05-28 09:15:06 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:15:06 --> Router Class Initialized
INFO - 2019-05-28 09:15:06 --> Output Class Initialized
INFO - 2019-05-28 09:15:06 --> Security Class Initialized
DEBUG - 2019-05-28 09:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:15:06 --> Input Class Initialized
INFO - 2019-05-28 09:15:06 --> Language Class Initialized
ERROR - 2019-05-28 09:15:06 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:15:13 --> Config Class Initialized
INFO - 2019-05-28 09:15:13 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:15:13 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:15:13 --> Utf8 Class Initialized
INFO - 2019-05-28 09:15:13 --> URI Class Initialized
DEBUG - 2019-05-28 09:15:13 --> No URI present. Default controller set.
INFO - 2019-05-28 09:15:13 --> Router Class Initialized
INFO - 2019-05-28 09:15:13 --> Output Class Initialized
INFO - 2019-05-28 09:15:13 --> Security Class Initialized
DEBUG - 2019-05-28 09:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:15:13 --> Input Class Initialized
INFO - 2019-05-28 09:15:13 --> Language Class Initialized
INFO - 2019-05-28 09:15:13 --> Language Class Initialized
INFO - 2019-05-28 09:15:13 --> Config Class Initialized
INFO - 2019-05-28 09:15:13 --> Loader Class Initialized
INFO - 2019-05-28 09:15:13 --> Helper loaded: form_helper
INFO - 2019-05-28 09:15:13 --> Helper loaded: url_helper
INFO - 2019-05-28 09:15:13 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:15:13 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:15:13 --> Template library initialized
INFO - 2019-05-28 09:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:15:13 --> Controller Class Initialized
DEBUG - 2019-05-28 09:15:13 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 09:15:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 09:15:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 09:15:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 09:15:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 09:15:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 09:15:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 09:15:14 --> Final output sent to browser
DEBUG - 2019-05-28 09:15:14 --> Total execution time: 0.0487
INFO - 2019-05-28 09:15:14 --> Config Class Initialized
INFO - 2019-05-28 09:15:14 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:15:14 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:15:14 --> Utf8 Class Initialized
INFO - 2019-05-28 09:15:14 --> URI Class Initialized
INFO - 2019-05-28 09:15:14 --> Config Class Initialized
INFO - 2019-05-28 09:15:14 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:15:14 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:15:14 --> Utf8 Class Initialized
INFO - 2019-05-28 09:15:14 --> URI Class Initialized
INFO - 2019-05-28 09:15:14 --> Config Class Initialized
INFO - 2019-05-28 09:15:14 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:15:14 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:15:14 --> Router Class Initialized
INFO - 2019-05-28 09:15:14 --> Output Class Initialized
INFO - 2019-05-28 09:15:14 --> Security Class Initialized
DEBUG - 2019-05-28 09:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:15:14 --> Input Class Initialized
INFO - 2019-05-28 09:15:14 --> Language Class Initialized
ERROR - 2019-05-28 09:15:14 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:15:14 --> Router Class Initialized
INFO - 2019-05-28 09:15:14 --> Output Class Initialized
INFO - 2019-05-28 09:15:14 --> Security Class Initialized
DEBUG - 2019-05-28 09:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:15:14 --> Input Class Initialized
INFO - 2019-05-28 09:15:14 --> Language Class Initialized
ERROR - 2019-05-28 09:15:14 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:15:14 --> Utf8 Class Initialized
INFO - 2019-05-28 09:15:14 --> URI Class Initialized
INFO - 2019-05-28 09:15:14 --> Router Class Initialized
INFO - 2019-05-28 09:15:14 --> Output Class Initialized
INFO - 2019-05-28 09:15:14 --> Security Class Initialized
DEBUG - 2019-05-28 09:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:15:14 --> Input Class Initialized
INFO - 2019-05-28 09:15:14 --> Language Class Initialized
ERROR - 2019-05-28 09:15:14 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:17:06 --> Config Class Initialized
INFO - 2019-05-28 09:17:06 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:17:06 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:17:06 --> Utf8 Class Initialized
INFO - 2019-05-28 09:17:06 --> URI Class Initialized
DEBUG - 2019-05-28 09:17:06 --> No URI present. Default controller set.
INFO - 2019-05-28 09:17:06 --> Router Class Initialized
INFO - 2019-05-28 09:17:06 --> Output Class Initialized
INFO - 2019-05-28 09:17:06 --> Security Class Initialized
DEBUG - 2019-05-28 09:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:17:06 --> Input Class Initialized
INFO - 2019-05-28 09:17:06 --> Language Class Initialized
INFO - 2019-05-28 09:17:06 --> Language Class Initialized
INFO - 2019-05-28 09:17:06 --> Config Class Initialized
INFO - 2019-05-28 09:17:06 --> Loader Class Initialized
INFO - 2019-05-28 09:17:06 --> Helper loaded: form_helper
INFO - 2019-05-28 09:17:06 --> Helper loaded: url_helper
INFO - 2019-05-28 09:17:06 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:17:06 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:17:06 --> Template library initialized
INFO - 2019-05-28 09:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:17:06 --> Controller Class Initialized
DEBUG - 2019-05-28 09:17:06 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 09:17:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 09:17:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 09:17:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 09:17:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 09:17:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 09:17:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 09:17:07 --> Final output sent to browser
DEBUG - 2019-05-28 09:17:07 --> Total execution time: 0.0518
INFO - 2019-05-28 09:17:07 --> Config Class Initialized
INFO - 2019-05-28 09:17:07 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:17:07 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:17:07 --> Utf8 Class Initialized
INFO - 2019-05-28 09:17:07 --> URI Class Initialized
INFO - 2019-05-28 09:17:07 --> Config Class Initialized
INFO - 2019-05-28 09:17:07 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:17:07 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:17:07 --> Utf8 Class Initialized
INFO - 2019-05-28 09:17:07 --> URI Class Initialized
INFO - 2019-05-28 09:17:07 --> Router Class Initialized
INFO - 2019-05-28 09:17:07 --> Output Class Initialized
INFO - 2019-05-28 09:17:07 --> Security Class Initialized
DEBUG - 2019-05-28 09:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:17:07 --> Input Class Initialized
INFO - 2019-05-28 09:17:07 --> Language Class Initialized
ERROR - 2019-05-28 09:17:07 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:17:07 --> Router Class Initialized
INFO - 2019-05-28 09:17:07 --> Output Class Initialized
INFO - 2019-05-28 09:17:07 --> Security Class Initialized
DEBUG - 2019-05-28 09:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:17:07 --> Input Class Initialized
INFO - 2019-05-28 09:17:07 --> Language Class Initialized
ERROR - 2019-05-28 09:17:07 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:17:09 --> Config Class Initialized
INFO - 2019-05-28 09:17:09 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:17:09 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:17:09 --> Utf8 Class Initialized
INFO - 2019-05-28 09:17:09 --> URI Class Initialized
INFO - 2019-05-28 09:17:09 --> Router Class Initialized
INFO - 2019-05-28 09:17:09 --> Output Class Initialized
INFO - 2019-05-28 09:17:09 --> Security Class Initialized
DEBUG - 2019-05-28 09:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:17:09 --> Input Class Initialized
INFO - 2019-05-28 09:17:09 --> Language Class Initialized
ERROR - 2019-05-28 09:17:09 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:17:36 --> Config Class Initialized
INFO - 2019-05-28 09:17:36 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:17:36 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:17:36 --> Utf8 Class Initialized
INFO - 2019-05-28 09:17:36 --> URI Class Initialized
INFO - 2019-05-28 09:17:36 --> Router Class Initialized
INFO - 2019-05-28 09:17:36 --> Output Class Initialized
INFO - 2019-05-28 09:17:36 --> Security Class Initialized
DEBUG - 2019-05-28 09:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:17:36 --> Input Class Initialized
INFO - 2019-05-28 09:17:36 --> Language Class Initialized
ERROR - 2019-05-28 09:17:36 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:17:38 --> Config Class Initialized
INFO - 2019-05-28 09:17:38 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:17:38 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:17:38 --> Utf8 Class Initialized
INFO - 2019-05-28 09:17:38 --> URI Class Initialized
INFO - 2019-05-28 09:17:38 --> Router Class Initialized
INFO - 2019-05-28 09:17:38 --> Output Class Initialized
INFO - 2019-05-28 09:17:38 --> Security Class Initialized
DEBUG - 2019-05-28 09:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:17:38 --> Input Class Initialized
INFO - 2019-05-28 09:17:38 --> Language Class Initialized
ERROR - 2019-05-28 09:17:38 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:17:38 --> Config Class Initialized
INFO - 2019-05-28 09:17:38 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:17:38 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:17:38 --> Utf8 Class Initialized
INFO - 2019-05-28 09:17:38 --> URI Class Initialized
INFO - 2019-05-28 09:17:38 --> Router Class Initialized
INFO - 2019-05-28 09:17:38 --> Output Class Initialized
INFO - 2019-05-28 09:17:38 --> Security Class Initialized
DEBUG - 2019-05-28 09:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:17:38 --> Input Class Initialized
INFO - 2019-05-28 09:17:38 --> Language Class Initialized
ERROR - 2019-05-28 09:17:38 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:17:38 --> Config Class Initialized
INFO - 2019-05-28 09:17:38 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:17:38 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:17:38 --> Utf8 Class Initialized
INFO - 2019-05-28 09:17:38 --> URI Class Initialized
INFO - 2019-05-28 09:17:38 --> Router Class Initialized
INFO - 2019-05-28 09:17:38 --> Output Class Initialized
INFO - 2019-05-28 09:17:38 --> Security Class Initialized
DEBUG - 2019-05-28 09:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:17:38 --> Input Class Initialized
INFO - 2019-05-28 09:17:38 --> Language Class Initialized
ERROR - 2019-05-28 09:17:38 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:17:38 --> Config Class Initialized
INFO - 2019-05-28 09:17:38 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:17:38 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:17:38 --> Utf8 Class Initialized
INFO - 2019-05-28 09:17:38 --> URI Class Initialized
INFO - 2019-05-28 09:17:38 --> Router Class Initialized
INFO - 2019-05-28 09:17:38 --> Output Class Initialized
INFO - 2019-05-28 09:17:38 --> Security Class Initialized
DEBUG - 2019-05-28 09:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:17:38 --> Input Class Initialized
INFO - 2019-05-28 09:17:38 --> Language Class Initialized
ERROR - 2019-05-28 09:17:38 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:17:39 --> Config Class Initialized
INFO - 2019-05-28 09:17:39 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:17:39 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:17:39 --> Utf8 Class Initialized
INFO - 2019-05-28 09:17:39 --> URI Class Initialized
INFO - 2019-05-28 09:17:39 --> Router Class Initialized
INFO - 2019-05-28 09:17:39 --> Output Class Initialized
INFO - 2019-05-28 09:17:39 --> Security Class Initialized
DEBUG - 2019-05-28 09:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:17:39 --> Input Class Initialized
INFO - 2019-05-28 09:17:39 --> Language Class Initialized
ERROR - 2019-05-28 09:17:39 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:17:39 --> Config Class Initialized
INFO - 2019-05-28 09:17:39 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:17:39 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:17:39 --> Utf8 Class Initialized
INFO - 2019-05-28 09:17:39 --> URI Class Initialized
INFO - 2019-05-28 09:17:39 --> Router Class Initialized
INFO - 2019-05-28 09:17:39 --> Output Class Initialized
INFO - 2019-05-28 09:17:39 --> Security Class Initialized
DEBUG - 2019-05-28 09:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:17:39 --> Input Class Initialized
INFO - 2019-05-28 09:17:39 --> Language Class Initialized
ERROR - 2019-05-28 09:17:39 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:17:39 --> Config Class Initialized
INFO - 2019-05-28 09:17:39 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:17:39 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:17:39 --> Utf8 Class Initialized
INFO - 2019-05-28 09:17:39 --> URI Class Initialized
INFO - 2019-05-28 09:17:39 --> Router Class Initialized
INFO - 2019-05-28 09:17:39 --> Output Class Initialized
INFO - 2019-05-28 09:17:39 --> Security Class Initialized
DEBUG - 2019-05-28 09:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:17:39 --> Input Class Initialized
INFO - 2019-05-28 09:17:39 --> Language Class Initialized
ERROR - 2019-05-28 09:17:39 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:17:39 --> Config Class Initialized
INFO - 2019-05-28 09:17:39 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:17:39 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:17:39 --> Utf8 Class Initialized
INFO - 2019-05-28 09:17:39 --> URI Class Initialized
INFO - 2019-05-28 09:17:39 --> Router Class Initialized
INFO - 2019-05-28 09:17:39 --> Output Class Initialized
INFO - 2019-05-28 09:17:39 --> Security Class Initialized
DEBUG - 2019-05-28 09:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:17:39 --> Input Class Initialized
INFO - 2019-05-28 09:17:39 --> Language Class Initialized
ERROR - 2019-05-28 09:17:39 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:17:39 --> Config Class Initialized
INFO - 2019-05-28 09:17:39 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:17:39 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:17:39 --> Utf8 Class Initialized
INFO - 2019-05-28 09:17:39 --> URI Class Initialized
INFO - 2019-05-28 09:17:39 --> Router Class Initialized
INFO - 2019-05-28 09:17:39 --> Output Class Initialized
INFO - 2019-05-28 09:17:39 --> Security Class Initialized
DEBUG - 2019-05-28 09:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:17:39 --> Input Class Initialized
INFO - 2019-05-28 09:17:39 --> Language Class Initialized
ERROR - 2019-05-28 09:17:39 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:17:40 --> Config Class Initialized
INFO - 2019-05-28 09:17:40 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:17:40 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:17:40 --> Utf8 Class Initialized
INFO - 2019-05-28 09:17:40 --> URI Class Initialized
INFO - 2019-05-28 09:17:40 --> Router Class Initialized
INFO - 2019-05-28 09:17:40 --> Output Class Initialized
INFO - 2019-05-28 09:17:40 --> Security Class Initialized
DEBUG - 2019-05-28 09:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:17:40 --> Input Class Initialized
INFO - 2019-05-28 09:17:40 --> Language Class Initialized
ERROR - 2019-05-28 09:17:40 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:17:40 --> Config Class Initialized
INFO - 2019-05-28 09:17:40 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:17:40 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:17:40 --> Utf8 Class Initialized
INFO - 2019-05-28 09:17:40 --> URI Class Initialized
INFO - 2019-05-28 09:17:40 --> Router Class Initialized
INFO - 2019-05-28 09:17:40 --> Output Class Initialized
INFO - 2019-05-28 09:17:40 --> Security Class Initialized
DEBUG - 2019-05-28 09:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:17:40 --> Input Class Initialized
INFO - 2019-05-28 09:17:40 --> Language Class Initialized
ERROR - 2019-05-28 09:17:40 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:17:40 --> Config Class Initialized
INFO - 2019-05-28 09:17:40 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:17:40 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:17:40 --> Utf8 Class Initialized
INFO - 2019-05-28 09:17:40 --> URI Class Initialized
INFO - 2019-05-28 09:17:40 --> Router Class Initialized
INFO - 2019-05-28 09:17:40 --> Output Class Initialized
INFO - 2019-05-28 09:17:40 --> Security Class Initialized
DEBUG - 2019-05-28 09:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:17:40 --> Input Class Initialized
INFO - 2019-05-28 09:17:40 --> Language Class Initialized
ERROR - 2019-05-28 09:17:40 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:17:40 --> Config Class Initialized
INFO - 2019-05-28 09:17:40 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:17:40 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:17:40 --> Utf8 Class Initialized
INFO - 2019-05-28 09:17:40 --> URI Class Initialized
INFO - 2019-05-28 09:17:40 --> Router Class Initialized
INFO - 2019-05-28 09:17:40 --> Output Class Initialized
INFO - 2019-05-28 09:17:40 --> Security Class Initialized
DEBUG - 2019-05-28 09:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:17:40 --> Input Class Initialized
INFO - 2019-05-28 09:17:40 --> Language Class Initialized
ERROR - 2019-05-28 09:17:40 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:17:40 --> Config Class Initialized
INFO - 2019-05-28 09:17:40 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:17:40 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:17:40 --> Utf8 Class Initialized
INFO - 2019-05-28 09:17:40 --> URI Class Initialized
INFO - 2019-05-28 09:17:41 --> Router Class Initialized
INFO - 2019-05-28 09:17:41 --> Output Class Initialized
INFO - 2019-05-28 09:17:41 --> Security Class Initialized
DEBUG - 2019-05-28 09:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:17:41 --> Input Class Initialized
INFO - 2019-05-28 09:17:41 --> Language Class Initialized
ERROR - 2019-05-28 09:17:41 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:17:41 --> Config Class Initialized
INFO - 2019-05-28 09:17:41 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:17:41 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:17:41 --> Utf8 Class Initialized
INFO - 2019-05-28 09:17:41 --> URI Class Initialized
INFO - 2019-05-28 09:17:41 --> Router Class Initialized
INFO - 2019-05-28 09:17:41 --> Output Class Initialized
INFO - 2019-05-28 09:17:41 --> Security Class Initialized
DEBUG - 2019-05-28 09:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:17:41 --> Input Class Initialized
INFO - 2019-05-28 09:17:41 --> Language Class Initialized
ERROR - 2019-05-28 09:17:41 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:17:44 --> Config Class Initialized
INFO - 2019-05-28 09:17:44 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:17:44 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:17:44 --> Utf8 Class Initialized
INFO - 2019-05-28 09:17:44 --> URI Class Initialized
INFO - 2019-05-28 09:17:44 --> Router Class Initialized
INFO - 2019-05-28 09:17:44 --> Output Class Initialized
INFO - 2019-05-28 09:17:44 --> Security Class Initialized
DEBUG - 2019-05-28 09:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:17:44 --> Input Class Initialized
INFO - 2019-05-28 09:17:44 --> Language Class Initialized
ERROR - 2019-05-28 09:17:44 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:17:49 --> Config Class Initialized
INFO - 2019-05-28 09:17:49 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:17:49 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:17:49 --> Utf8 Class Initialized
INFO - 2019-05-28 09:17:49 --> URI Class Initialized
INFO - 2019-05-28 09:17:49 --> Router Class Initialized
INFO - 2019-05-28 09:17:49 --> Output Class Initialized
INFO - 2019-05-28 09:17:49 --> Security Class Initialized
DEBUG - 2019-05-28 09:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:17:49 --> Input Class Initialized
INFO - 2019-05-28 09:17:49 --> Language Class Initialized
ERROR - 2019-05-28 09:17:49 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:37:57 --> Config Class Initialized
INFO - 2019-05-28 09:37:57 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:37:57 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:37:57 --> Utf8 Class Initialized
INFO - 2019-05-28 09:37:57 --> URI Class Initialized
DEBUG - 2019-05-28 09:37:57 --> No URI present. Default controller set.
INFO - 2019-05-28 09:37:57 --> Router Class Initialized
INFO - 2019-05-28 09:37:57 --> Output Class Initialized
INFO - 2019-05-28 09:37:57 --> Security Class Initialized
DEBUG - 2019-05-28 09:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:37:57 --> Input Class Initialized
INFO - 2019-05-28 09:37:57 --> Language Class Initialized
INFO - 2019-05-28 09:37:57 --> Language Class Initialized
INFO - 2019-05-28 09:37:57 --> Config Class Initialized
INFO - 2019-05-28 09:37:57 --> Loader Class Initialized
INFO - 2019-05-28 09:37:57 --> Helper loaded: form_helper
INFO - 2019-05-28 09:37:57 --> Helper loaded: url_helper
INFO - 2019-05-28 09:37:57 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:37:57 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:37:57 --> Template library initialized
INFO - 2019-05-28 09:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:37:57 --> Controller Class Initialized
DEBUG - 2019-05-28 09:37:57 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 09:37:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 09:37:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 09:37:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 09:37:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 09:37:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 09:37:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 09:37:57 --> Final output sent to browser
DEBUG - 2019-05-28 09:37:57 --> Total execution time: 0.0465
INFO - 2019-05-28 09:37:58 --> Config Class Initialized
INFO - 2019-05-28 09:37:58 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:37:58 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:37:58 --> Utf8 Class Initialized
INFO - 2019-05-28 09:37:58 --> URI Class Initialized
INFO - 2019-05-28 09:37:58 --> Router Class Initialized
INFO - 2019-05-28 09:37:58 --> Output Class Initialized
INFO - 2019-05-28 09:37:58 --> Security Class Initialized
DEBUG - 2019-05-28 09:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:37:58 --> Input Class Initialized
INFO - 2019-05-28 09:37:58 --> Language Class Initialized
ERROR - 2019-05-28 09:37:58 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:37:58 --> Config Class Initialized
INFO - 2019-05-28 09:37:58 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:37:58 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:37:58 --> Utf8 Class Initialized
INFO - 2019-05-28 09:37:58 --> URI Class Initialized
INFO - 2019-05-28 09:37:58 --> Config Class Initialized
INFO - 2019-05-28 09:37:58 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:37:58 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:37:58 --> Utf8 Class Initialized
INFO - 2019-05-28 09:37:58 --> URI Class Initialized
INFO - 2019-05-28 09:37:58 --> Router Class Initialized
INFO - 2019-05-28 09:37:58 --> Output Class Initialized
INFO - 2019-05-28 09:37:58 --> Security Class Initialized
DEBUG - 2019-05-28 09:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:37:58 --> Input Class Initialized
INFO - 2019-05-28 09:37:58 --> Language Class Initialized
ERROR - 2019-05-28 09:37:58 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:37:58 --> Router Class Initialized
INFO - 2019-05-28 09:37:58 --> Output Class Initialized
INFO - 2019-05-28 09:37:58 --> Security Class Initialized
DEBUG - 2019-05-28 09:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:37:58 --> Input Class Initialized
INFO - 2019-05-28 09:37:58 --> Language Class Initialized
ERROR - 2019-05-28 09:37:58 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:40:04 --> Config Class Initialized
INFO - 2019-05-28 09:40:04 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:40:04 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:40:04 --> Utf8 Class Initialized
INFO - 2019-05-28 09:40:04 --> URI Class Initialized
DEBUG - 2019-05-28 09:40:04 --> No URI present. Default controller set.
INFO - 2019-05-28 09:40:04 --> Router Class Initialized
INFO - 2019-05-28 09:40:04 --> Output Class Initialized
INFO - 2019-05-28 09:40:04 --> Security Class Initialized
DEBUG - 2019-05-28 09:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:40:04 --> Input Class Initialized
INFO - 2019-05-28 09:40:04 --> Language Class Initialized
INFO - 2019-05-28 09:40:04 --> Language Class Initialized
INFO - 2019-05-28 09:40:04 --> Config Class Initialized
INFO - 2019-05-28 09:40:04 --> Loader Class Initialized
INFO - 2019-05-28 09:40:04 --> Helper loaded: form_helper
INFO - 2019-05-28 09:40:04 --> Helper loaded: url_helper
INFO - 2019-05-28 09:40:04 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:40:04 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:40:04 --> Template library initialized
INFO - 2019-05-28 09:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:40:04 --> Controller Class Initialized
DEBUG - 2019-05-28 09:40:04 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 09:40:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 09:40:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 09:40:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 09:40:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 09:40:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 09:40:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 09:40:04 --> Config Class Initialized
INFO - 2019-05-28 09:40:04 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:40:04 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:40:04 --> Utf8 Class Initialized
INFO - 2019-05-28 09:40:04 --> URI Class Initialized
DEBUG - 2019-05-28 09:40:04 --> No URI present. Default controller set.
INFO - 2019-05-28 09:40:04 --> Router Class Initialized
INFO - 2019-05-28 09:40:04 --> Output Class Initialized
INFO - 2019-05-28 09:40:04 --> Security Class Initialized
DEBUG - 2019-05-28 09:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:40:04 --> Input Class Initialized
INFO - 2019-05-28 09:40:04 --> Language Class Initialized
INFO - 2019-05-28 09:40:04 --> Language Class Initialized
INFO - 2019-05-28 09:40:04 --> Config Class Initialized
INFO - 2019-05-28 09:40:04 --> Loader Class Initialized
INFO - 2019-05-28 09:40:04 --> Helper loaded: form_helper
INFO - 2019-05-28 09:40:04 --> Helper loaded: url_helper
INFO - 2019-05-28 09:40:04 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:40:04 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:40:04 --> Template library initialized
INFO - 2019-05-28 09:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:40:04 --> Controller Class Initialized
DEBUG - 2019-05-28 09:40:04 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 09:40:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 09:40:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 09:40:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 09:40:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 09:40:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 09:40:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 09:40:05 --> Final output sent to browser
DEBUG - 2019-05-28 09:40:05 --> Total execution time: 0.0453
INFO - 2019-05-28 09:40:06 --> Config Class Initialized
INFO - 2019-05-28 09:40:06 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:40:06 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:40:06 --> Utf8 Class Initialized
INFO - 2019-05-28 09:40:06 --> URI Class Initialized
INFO - 2019-05-28 09:40:06 --> Config Class Initialized
INFO - 2019-05-28 09:40:06 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:40:06 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:40:06 --> Utf8 Class Initialized
INFO - 2019-05-28 09:40:06 --> URI Class Initialized
INFO - 2019-05-28 09:40:06 --> Router Class Initialized
INFO - 2019-05-28 09:40:06 --> Config Class Initialized
INFO - 2019-05-28 09:40:06 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:40:06 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:40:06 --> Utf8 Class Initialized
INFO - 2019-05-28 09:40:06 --> URI Class Initialized
INFO - 2019-05-28 09:40:06 --> Router Class Initialized
INFO - 2019-05-28 09:40:06 --> Router Class Initialized
INFO - 2019-05-28 09:40:06 --> Output Class Initialized
INFO - 2019-05-28 09:40:06 --> Security Class Initialized
DEBUG - 2019-05-28 09:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:40:06 --> Input Class Initialized
INFO - 2019-05-28 09:40:06 --> Language Class Initialized
ERROR - 2019-05-28 09:40:06 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:40:06 --> Output Class Initialized
INFO - 2019-05-28 09:40:06 --> Security Class Initialized
DEBUG - 2019-05-28 09:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:40:06 --> Input Class Initialized
INFO - 2019-05-28 09:40:06 --> Language Class Initialized
ERROR - 2019-05-28 09:40:06 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:40:06 --> Output Class Initialized
INFO - 2019-05-28 09:40:06 --> Security Class Initialized
DEBUG - 2019-05-28 09:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:40:06 --> Input Class Initialized
INFO - 2019-05-28 09:40:06 --> Language Class Initialized
ERROR - 2019-05-28 09:40:06 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:40:08 --> Config Class Initialized
INFO - 2019-05-28 09:40:08 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:40:08 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:40:08 --> Utf8 Class Initialized
INFO - 2019-05-28 09:40:08 --> URI Class Initialized
INFO - 2019-05-28 09:40:08 --> Router Class Initialized
INFO - 2019-05-28 09:40:08 --> Output Class Initialized
INFO - 2019-05-28 09:40:08 --> Security Class Initialized
DEBUG - 2019-05-28 09:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:40:08 --> Input Class Initialized
INFO - 2019-05-28 09:40:08 --> Language Class Initialized
ERROR - 2019-05-28 09:40:08 --> 404 Page Not Found: /index
INFO - 2019-05-28 09:40:42 --> Config Class Initialized
INFO - 2019-05-28 09:40:42 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:40:42 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:40:42 --> Utf8 Class Initialized
INFO - 2019-05-28 09:40:42 --> URI Class Initialized
INFO - 2019-05-28 09:40:42 --> Router Class Initialized
INFO - 2019-05-28 09:40:42 --> Output Class Initialized
INFO - 2019-05-28 09:40:42 --> Security Class Initialized
DEBUG - 2019-05-28 09:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:40:42 --> Input Class Initialized
INFO - 2019-05-28 09:40:42 --> Language Class Initialized
INFO - 2019-05-28 09:40:42 --> Language Class Initialized
INFO - 2019-05-28 09:40:42 --> Config Class Initialized
INFO - 2019-05-28 09:40:42 --> Loader Class Initialized
INFO - 2019-05-28 09:40:42 --> Helper loaded: form_helper
INFO - 2019-05-28 09:40:42 --> Helper loaded: url_helper
INFO - 2019-05-28 09:40:42 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:40:42 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:40:42 --> Template library initialized
INFO - 2019-05-28 09:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:40:42 --> Controller Class Initialized
DEBUG - 2019-05-28 09:40:42 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 09:40:42 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 09:40:42 --> Final output sent to browser
DEBUG - 2019-05-28 09:40:42 --> Total execution time: 0.0372
INFO - 2019-05-28 09:40:50 --> Config Class Initialized
INFO - 2019-05-28 09:40:50 --> Hooks Class Initialized
DEBUG - 2019-05-28 09:40:50 --> UTF-8 Support Enabled
INFO - 2019-05-28 09:40:50 --> Utf8 Class Initialized
INFO - 2019-05-28 09:40:50 --> URI Class Initialized
INFO - 2019-05-28 09:40:50 --> Router Class Initialized
INFO - 2019-05-28 09:40:50 --> Output Class Initialized
INFO - 2019-05-28 09:40:50 --> Security Class Initialized
DEBUG - 2019-05-28 09:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 09:40:50 --> Input Class Initialized
INFO - 2019-05-28 09:40:50 --> Language Class Initialized
INFO - 2019-05-28 09:40:50 --> Language Class Initialized
INFO - 2019-05-28 09:40:50 --> Config Class Initialized
INFO - 2019-05-28 09:40:50 --> Loader Class Initialized
INFO - 2019-05-28 09:40:50 --> Helper loaded: form_helper
INFO - 2019-05-28 09:40:50 --> Helper loaded: url_helper
INFO - 2019-05-28 09:40:50 --> Helper loaded: cookie_helper
INFO - 2019-05-28 09:40:50 --> Database Driver Class Initialized
DEBUG - 2019-05-28 09:40:50 --> Template library initialized
INFO - 2019-05-28 09:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 09:40:50 --> Controller Class Initialized
DEBUG - 2019-05-28 09:40:50 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 09:40:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 09:40:50 --> Final output sent to browser
DEBUG - 2019-05-28 09:40:50 --> Total execution time: 0.0411
INFO - 2019-05-28 10:35:45 --> Config Class Initialized
INFO - 2019-05-28 10:35:45 --> Hooks Class Initialized
DEBUG - 2019-05-28 10:35:45 --> UTF-8 Support Enabled
INFO - 2019-05-28 10:35:45 --> Utf8 Class Initialized
INFO - 2019-05-28 10:35:45 --> URI Class Initialized
DEBUG - 2019-05-28 10:35:45 --> No URI present. Default controller set.
INFO - 2019-05-28 10:35:45 --> Router Class Initialized
INFO - 2019-05-28 10:35:45 --> Output Class Initialized
INFO - 2019-05-28 10:35:45 --> Security Class Initialized
DEBUG - 2019-05-28 10:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 10:35:45 --> Input Class Initialized
INFO - 2019-05-28 10:35:45 --> Language Class Initialized
INFO - 2019-05-28 10:35:45 --> Language Class Initialized
INFO - 2019-05-28 10:35:45 --> Config Class Initialized
INFO - 2019-05-28 10:35:45 --> Loader Class Initialized
INFO - 2019-05-28 10:35:45 --> Helper loaded: form_helper
INFO - 2019-05-28 10:35:45 --> Helper loaded: url_helper
INFO - 2019-05-28 10:35:45 --> Helper loaded: cookie_helper
INFO - 2019-05-28 10:35:45 --> Database Driver Class Initialized
DEBUG - 2019-05-28 10:35:45 --> Template library initialized
INFO - 2019-05-28 10:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 10:35:45 --> Controller Class Initialized
DEBUG - 2019-05-28 10:35:45 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 10:35:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 10:35:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 10:35:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 10:35:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 10:35:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 10:35:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 10:35:46 --> Final output sent to browser
DEBUG - 2019-05-28 10:35:46 --> Total execution time: 0.0559
INFO - 2019-05-28 10:35:50 --> Config Class Initialized
INFO - 2019-05-28 10:35:50 --> Hooks Class Initialized
DEBUG - 2019-05-28 10:35:50 --> UTF-8 Support Enabled
INFO - 2019-05-28 10:35:50 --> Utf8 Class Initialized
INFO - 2019-05-28 10:35:50 --> URI Class Initialized
DEBUG - 2019-05-28 10:35:50 --> No URI present. Default controller set.
INFO - 2019-05-28 10:35:50 --> Router Class Initialized
INFO - 2019-05-28 10:35:50 --> Output Class Initialized
INFO - 2019-05-28 10:35:50 --> Security Class Initialized
DEBUG - 2019-05-28 10:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 10:35:50 --> Input Class Initialized
INFO - 2019-05-28 10:35:50 --> Language Class Initialized
INFO - 2019-05-28 10:35:50 --> Language Class Initialized
INFO - 2019-05-28 10:35:50 --> Config Class Initialized
INFO - 2019-05-28 10:35:50 --> Loader Class Initialized
INFO - 2019-05-28 10:35:50 --> Helper loaded: form_helper
INFO - 2019-05-28 10:35:50 --> Helper loaded: url_helper
INFO - 2019-05-28 10:35:50 --> Helper loaded: cookie_helper
INFO - 2019-05-28 10:35:50 --> Database Driver Class Initialized
DEBUG - 2019-05-28 10:35:50 --> Template library initialized
INFO - 2019-05-28 10:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 10:35:50 --> Controller Class Initialized
DEBUG - 2019-05-28 10:35:50 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 10:35:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 10:35:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 10:35:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 10:35:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 10:35:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 10:35:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 10:35:50 --> Final output sent to browser
DEBUG - 2019-05-28 10:35:50 --> Total execution time: 0.0486
INFO - 2019-05-28 10:35:51 --> Config Class Initialized
INFO - 2019-05-28 10:35:51 --> Hooks Class Initialized
INFO - 2019-05-28 10:35:51 --> Config Class Initialized
INFO - 2019-05-28 10:35:51 --> Hooks Class Initialized
INFO - 2019-05-28 10:35:51 --> Config Class Initialized
INFO - 2019-05-28 10:35:51 --> Hooks Class Initialized
DEBUG - 2019-05-28 10:35:51 --> UTF-8 Support Enabled
INFO - 2019-05-28 10:35:51 --> Utf8 Class Initialized
INFO - 2019-05-28 10:35:51 --> URI Class Initialized
INFO - 2019-05-28 10:35:51 --> Router Class Initialized
INFO - 2019-05-28 10:35:51 --> Output Class Initialized
DEBUG - 2019-05-28 10:35:51 --> UTF-8 Support Enabled
INFO - 2019-05-28 10:35:51 --> Utf8 Class Initialized
INFO - 2019-05-28 10:35:51 --> URI Class Initialized
INFO - 2019-05-28 10:35:51 --> Router Class Initialized
INFO - 2019-05-28 10:35:51 --> Output Class Initialized
INFO - 2019-05-28 10:35:51 --> Security Class Initialized
DEBUG - 2019-05-28 10:35:51 --> UTF-8 Support Enabled
INFO - 2019-05-28 10:35:51 --> Utf8 Class Initialized
INFO - 2019-05-28 10:35:51 --> URI Class Initialized
INFO - 2019-05-28 10:35:51 --> Router Class Initialized
INFO - 2019-05-28 10:35:51 --> Output Class Initialized
INFO - 2019-05-28 10:35:51 --> Security Class Initialized
DEBUG - 2019-05-28 10:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 10:35:51 --> Input Class Initialized
INFO - 2019-05-28 10:35:51 --> Language Class Initialized
ERROR - 2019-05-28 10:35:51 --> 404 Page Not Found: /index
INFO - 2019-05-28 10:35:51 --> Security Class Initialized
DEBUG - 2019-05-28 10:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 10:35:51 --> Input Class Initialized
INFO - 2019-05-28 10:35:51 --> Language Class Initialized
ERROR - 2019-05-28 10:35:51 --> 404 Page Not Found: /index
DEBUG - 2019-05-28 10:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 10:35:51 --> Input Class Initialized
INFO - 2019-05-28 10:35:51 --> Language Class Initialized
ERROR - 2019-05-28 10:35:51 --> 404 Page Not Found: /index
INFO - 2019-05-28 10:35:55 --> Config Class Initialized
INFO - 2019-05-28 10:35:55 --> Hooks Class Initialized
DEBUG - 2019-05-28 10:35:55 --> UTF-8 Support Enabled
INFO - 2019-05-28 10:35:55 --> Utf8 Class Initialized
INFO - 2019-05-28 10:35:55 --> URI Class Initialized
DEBUG - 2019-05-28 10:35:55 --> No URI present. Default controller set.
INFO - 2019-05-28 10:35:55 --> Router Class Initialized
INFO - 2019-05-28 10:35:55 --> Output Class Initialized
INFO - 2019-05-28 10:35:55 --> Security Class Initialized
DEBUG - 2019-05-28 10:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 10:35:55 --> Input Class Initialized
INFO - 2019-05-28 10:35:55 --> Language Class Initialized
INFO - 2019-05-28 10:35:55 --> Language Class Initialized
INFO - 2019-05-28 10:35:55 --> Config Class Initialized
INFO - 2019-05-28 10:35:55 --> Loader Class Initialized
INFO - 2019-05-28 10:35:55 --> Helper loaded: form_helper
INFO - 2019-05-28 10:35:55 --> Helper loaded: url_helper
INFO - 2019-05-28 10:35:55 --> Helper loaded: cookie_helper
INFO - 2019-05-28 10:35:55 --> Database Driver Class Initialized
DEBUG - 2019-05-28 10:35:55 --> Template library initialized
INFO - 2019-05-28 10:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 10:35:55 --> Controller Class Initialized
DEBUG - 2019-05-28 10:35:55 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 10:35:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 10:35:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 10:35:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 10:35:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 10:35:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 10:35:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 10:35:55 --> Final output sent to browser
DEBUG - 2019-05-28 10:35:55 --> Total execution time: 0.0451
INFO - 2019-05-28 10:35:56 --> Config Class Initialized
INFO - 2019-05-28 10:35:56 --> Hooks Class Initialized
INFO - 2019-05-28 10:35:56 --> Config Class Initialized
INFO - 2019-05-28 10:35:56 --> Hooks Class Initialized
DEBUG - 2019-05-28 10:35:56 --> UTF-8 Support Enabled
INFO - 2019-05-28 10:35:56 --> Utf8 Class Initialized
INFO - 2019-05-28 10:35:56 --> URI Class Initialized
INFO - 2019-05-28 10:35:56 --> Router Class Initialized
INFO - 2019-05-28 10:35:56 --> Config Class Initialized
INFO - 2019-05-28 10:35:56 --> Hooks Class Initialized
DEBUG - 2019-05-28 10:35:56 --> UTF-8 Support Enabled
INFO - 2019-05-28 10:35:56 --> Utf8 Class Initialized
INFO - 2019-05-28 10:35:56 --> URI Class Initialized
INFO - 2019-05-28 10:35:56 --> Router Class Initialized
DEBUG - 2019-05-28 10:35:56 --> UTF-8 Support Enabled
INFO - 2019-05-28 10:35:56 --> Utf8 Class Initialized
INFO - 2019-05-28 10:35:56 --> URI Class Initialized
INFO - 2019-05-28 10:35:56 --> Router Class Initialized
INFO - 2019-05-28 10:35:56 --> Output Class Initialized
INFO - 2019-05-28 10:35:56 --> Security Class Initialized
DEBUG - 2019-05-28 10:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 10:35:56 --> Input Class Initialized
INFO - 2019-05-28 10:35:56 --> Language Class Initialized
ERROR - 2019-05-28 10:35:56 --> 404 Page Not Found: /index
INFO - 2019-05-28 10:35:56 --> Output Class Initialized
INFO - 2019-05-28 10:35:56 --> Security Class Initialized
DEBUG - 2019-05-28 10:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 10:35:56 --> Input Class Initialized
INFO - 2019-05-28 10:35:56 --> Language Class Initialized
ERROR - 2019-05-28 10:35:56 --> 404 Page Not Found: /index
INFO - 2019-05-28 10:35:56 --> Output Class Initialized
INFO - 2019-05-28 10:35:56 --> Security Class Initialized
DEBUG - 2019-05-28 10:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 10:35:56 --> Input Class Initialized
INFO - 2019-05-28 10:35:56 --> Language Class Initialized
ERROR - 2019-05-28 10:35:56 --> 404 Page Not Found: /index
INFO - 2019-05-28 10:36:35 --> Config Class Initialized
INFO - 2019-05-28 10:36:35 --> Hooks Class Initialized
DEBUG - 2019-05-28 10:36:35 --> UTF-8 Support Enabled
INFO - 2019-05-28 10:36:35 --> Utf8 Class Initialized
INFO - 2019-05-28 10:36:35 --> URI Class Initialized
INFO - 2019-05-28 10:36:35 --> Router Class Initialized
INFO - 2019-05-28 10:36:35 --> Output Class Initialized
INFO - 2019-05-28 10:36:35 --> Security Class Initialized
DEBUG - 2019-05-28 10:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 10:36:35 --> Input Class Initialized
INFO - 2019-05-28 10:36:35 --> Language Class Initialized
INFO - 2019-05-28 10:36:35 --> Language Class Initialized
INFO - 2019-05-28 10:36:35 --> Config Class Initialized
INFO - 2019-05-28 10:36:35 --> Loader Class Initialized
INFO - 2019-05-28 10:36:35 --> Helper loaded: form_helper
INFO - 2019-05-28 10:36:35 --> Helper loaded: url_helper
INFO - 2019-05-28 10:36:35 --> Helper loaded: cookie_helper
INFO - 2019-05-28 10:36:35 --> Database Driver Class Initialized
DEBUG - 2019-05-28 10:36:35 --> Template library initialized
INFO - 2019-05-28 10:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 10:36:35 --> Controller Class Initialized
DEBUG - 2019-05-28 10:36:35 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 10:36:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 10:36:35 --> Final output sent to browser
DEBUG - 2019-05-28 10:36:35 --> Total execution time: 0.0395
INFO - 2019-05-28 10:37:15 --> Config Class Initialized
INFO - 2019-05-28 10:37:15 --> Hooks Class Initialized
DEBUG - 2019-05-28 10:37:15 --> UTF-8 Support Enabled
INFO - 2019-05-28 10:37:15 --> Utf8 Class Initialized
INFO - 2019-05-28 10:37:15 --> URI Class Initialized
INFO - 2019-05-28 10:37:15 --> Router Class Initialized
INFO - 2019-05-28 10:37:15 --> Output Class Initialized
INFO - 2019-05-28 10:37:15 --> Security Class Initialized
DEBUG - 2019-05-28 10:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 10:37:15 --> Input Class Initialized
INFO - 2019-05-28 10:37:15 --> Language Class Initialized
INFO - 2019-05-28 10:37:15 --> Language Class Initialized
INFO - 2019-05-28 10:37:15 --> Config Class Initialized
INFO - 2019-05-28 10:37:15 --> Loader Class Initialized
INFO - 2019-05-28 10:37:15 --> Helper loaded: form_helper
INFO - 2019-05-28 10:37:15 --> Helper loaded: url_helper
INFO - 2019-05-28 10:37:15 --> Helper loaded: cookie_helper
INFO - 2019-05-28 10:37:15 --> Database Driver Class Initialized
DEBUG - 2019-05-28 10:37:15 --> Template library initialized
INFO - 2019-05-28 10:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 10:37:15 --> Controller Class Initialized
DEBUG - 2019-05-28 10:37:15 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 10:37:15 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 10:37:15 --> Final output sent to browser
DEBUG - 2019-05-28 10:37:15 --> Total execution time: 0.0434
INFO - 2019-05-28 10:37:15 --> Config Class Initialized
INFO - 2019-05-28 10:37:15 --> Hooks Class Initialized
DEBUG - 2019-05-28 10:37:15 --> UTF-8 Support Enabled
INFO - 2019-05-28 10:37:15 --> Utf8 Class Initialized
INFO - 2019-05-28 10:37:15 --> URI Class Initialized
DEBUG - 2019-05-28 10:37:15 --> No URI present. Default controller set.
INFO - 2019-05-28 10:37:15 --> Router Class Initialized
INFO - 2019-05-28 10:37:15 --> Output Class Initialized
INFO - 2019-05-28 10:37:15 --> Security Class Initialized
DEBUG - 2019-05-28 10:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 10:37:15 --> Input Class Initialized
INFO - 2019-05-28 10:37:15 --> Language Class Initialized
INFO - 2019-05-28 10:37:15 --> Language Class Initialized
INFO - 2019-05-28 10:37:15 --> Config Class Initialized
INFO - 2019-05-28 10:37:15 --> Loader Class Initialized
INFO - 2019-05-28 10:37:15 --> Helper loaded: form_helper
INFO - 2019-05-28 10:37:15 --> Helper loaded: url_helper
INFO - 2019-05-28 10:37:15 --> Helper loaded: cookie_helper
INFO - 2019-05-28 10:37:15 --> Database Driver Class Initialized
DEBUG - 2019-05-28 10:37:15 --> Template library initialized
INFO - 2019-05-28 10:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 10:37:15 --> Controller Class Initialized
DEBUG - 2019-05-28 10:37:15 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 10:37:15 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 10:37:15 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 10:37:15 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 10:37:15 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 10:37:15 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 10:37:15 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 10:37:16 --> Final output sent to browser
DEBUG - 2019-05-28 10:37:16 --> Total execution time: 0.0476
INFO - 2019-05-28 10:37:16 --> Config Class Initialized
INFO - 2019-05-28 10:37:16 --> Hooks Class Initialized
DEBUG - 2019-05-28 10:37:16 --> UTF-8 Support Enabled
INFO - 2019-05-28 10:37:16 --> Utf8 Class Initialized
INFO - 2019-05-28 10:37:16 --> URI Class Initialized
INFO - 2019-05-28 10:37:16 --> Config Class Initialized
INFO - 2019-05-28 10:37:16 --> Hooks Class Initialized
INFO - 2019-05-28 10:37:16 --> Config Class Initialized
INFO - 2019-05-28 10:37:16 --> Hooks Class Initialized
DEBUG - 2019-05-28 10:37:16 --> UTF-8 Support Enabled
INFO - 2019-05-28 10:37:16 --> Utf8 Class Initialized
INFO - 2019-05-28 10:37:16 --> URI Class Initialized
INFO - 2019-05-28 10:37:16 --> Router Class Initialized
INFO - 2019-05-28 10:37:16 --> Router Class Initialized
INFO - 2019-05-28 10:37:16 --> Output Class Initialized
INFO - 2019-05-28 10:37:16 --> Security Class Initialized
DEBUG - 2019-05-28 10:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 10:37:16 --> Input Class Initialized
INFO - 2019-05-28 10:37:16 --> Language Class Initialized
ERROR - 2019-05-28 10:37:16 --> 404 Page Not Found: /index
DEBUG - 2019-05-28 10:37:16 --> UTF-8 Support Enabled
INFO - 2019-05-28 10:37:16 --> Utf8 Class Initialized
INFO - 2019-05-28 10:37:16 --> URI Class Initialized
INFO - 2019-05-28 10:37:16 --> Router Class Initialized
INFO - 2019-05-28 10:37:16 --> Output Class Initialized
INFO - 2019-05-28 10:37:16 --> Security Class Initialized
DEBUG - 2019-05-28 10:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 10:37:16 --> Input Class Initialized
INFO - 2019-05-28 10:37:16 --> Language Class Initialized
ERROR - 2019-05-28 10:37:16 --> 404 Page Not Found: /index
INFO - 2019-05-28 10:37:16 --> Output Class Initialized
INFO - 2019-05-28 10:37:16 --> Security Class Initialized
DEBUG - 2019-05-28 10:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 10:37:16 --> Input Class Initialized
INFO - 2019-05-28 10:37:16 --> Language Class Initialized
ERROR - 2019-05-28 10:37:16 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:03:02 --> Config Class Initialized
INFO - 2019-05-28 11:03:02 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:03:02 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:03:02 --> Utf8 Class Initialized
INFO - 2019-05-28 11:03:02 --> URI Class Initialized
DEBUG - 2019-05-28 11:03:02 --> No URI present. Default controller set.
INFO - 2019-05-28 11:03:02 --> Router Class Initialized
INFO - 2019-05-28 11:03:02 --> Output Class Initialized
INFO - 2019-05-28 11:03:02 --> Security Class Initialized
DEBUG - 2019-05-28 11:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:03:02 --> Input Class Initialized
INFO - 2019-05-28 11:03:02 --> Language Class Initialized
INFO - 2019-05-28 11:03:02 --> Language Class Initialized
INFO - 2019-05-28 11:03:02 --> Config Class Initialized
INFO - 2019-05-28 11:03:02 --> Loader Class Initialized
INFO - 2019-05-28 11:03:02 --> Helper loaded: form_helper
INFO - 2019-05-28 11:03:02 --> Helper loaded: url_helper
INFO - 2019-05-28 11:03:02 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:03:02 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:03:02 --> Template library initialized
INFO - 2019-05-28 11:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:03:02 --> Controller Class Initialized
DEBUG - 2019-05-28 11:03:02 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:03:02 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:03:02 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:03:02 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:03:02 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:03:02 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:03:02 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:03:02 --> Final output sent to browser
DEBUG - 2019-05-28 11:03:02 --> Total execution time: 0.0459
INFO - 2019-05-28 11:03:03 --> Config Class Initialized
INFO - 2019-05-28 11:03:03 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:03:03 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:03:03 --> Utf8 Class Initialized
INFO - 2019-05-28 11:03:03 --> URI Class Initialized
INFO - 2019-05-28 11:03:03 --> Router Class Initialized
INFO - 2019-05-28 11:03:03 --> Output Class Initialized
INFO - 2019-05-28 11:03:03 --> Security Class Initialized
DEBUG - 2019-05-28 11:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:03:03 --> Input Class Initialized
INFO - 2019-05-28 11:03:03 --> Language Class Initialized
ERROR - 2019-05-28 11:03:03 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:03:03 --> Config Class Initialized
INFO - 2019-05-28 11:03:03 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:03:03 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:03:03 --> Utf8 Class Initialized
INFO - 2019-05-28 11:03:03 --> URI Class Initialized
INFO - 2019-05-28 11:03:03 --> Router Class Initialized
INFO - 2019-05-28 11:03:03 --> Output Class Initialized
INFO - 2019-05-28 11:03:03 --> Security Class Initialized
DEBUG - 2019-05-28 11:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:03:03 --> Input Class Initialized
INFO - 2019-05-28 11:03:03 --> Language Class Initialized
ERROR - 2019-05-28 11:03:03 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:03:03 --> Config Class Initialized
INFO - 2019-05-28 11:03:03 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:03:03 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:03:03 --> Utf8 Class Initialized
INFO - 2019-05-28 11:03:03 --> URI Class Initialized
INFO - 2019-05-28 11:03:03 --> Router Class Initialized
INFO - 2019-05-28 11:03:03 --> Output Class Initialized
INFO - 2019-05-28 11:03:03 --> Security Class Initialized
DEBUG - 2019-05-28 11:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:03:03 --> Input Class Initialized
INFO - 2019-05-28 11:03:03 --> Language Class Initialized
ERROR - 2019-05-28 11:03:03 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:03:06 --> Config Class Initialized
INFO - 2019-05-28 11:03:06 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:03:06 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:03:06 --> Utf8 Class Initialized
INFO - 2019-05-28 11:03:06 --> URI Class Initialized
INFO - 2019-05-28 11:03:06 --> Router Class Initialized
INFO - 2019-05-28 11:03:06 --> Output Class Initialized
INFO - 2019-05-28 11:03:06 --> Security Class Initialized
DEBUG - 2019-05-28 11:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:03:06 --> Input Class Initialized
INFO - 2019-05-28 11:03:06 --> Language Class Initialized
ERROR - 2019-05-28 11:03:06 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:03:43 --> Config Class Initialized
INFO - 2019-05-28 11:03:43 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:03:43 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:03:43 --> Utf8 Class Initialized
INFO - 2019-05-28 11:03:43 --> URI Class Initialized
DEBUG - 2019-05-28 11:03:43 --> No URI present. Default controller set.
INFO - 2019-05-28 11:03:43 --> Router Class Initialized
INFO - 2019-05-28 11:03:43 --> Output Class Initialized
INFO - 2019-05-28 11:03:43 --> Security Class Initialized
DEBUG - 2019-05-28 11:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:03:43 --> Input Class Initialized
INFO - 2019-05-28 11:03:43 --> Language Class Initialized
INFO - 2019-05-28 11:03:43 --> Language Class Initialized
INFO - 2019-05-28 11:03:43 --> Config Class Initialized
INFO - 2019-05-28 11:03:43 --> Loader Class Initialized
INFO - 2019-05-28 11:03:43 --> Helper loaded: form_helper
INFO - 2019-05-28 11:03:43 --> Helper loaded: url_helper
INFO - 2019-05-28 11:03:43 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:03:43 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:03:43 --> Template library initialized
INFO - 2019-05-28 11:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:03:43 --> Controller Class Initialized
DEBUG - 2019-05-28 11:03:43 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:03:43 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:03:43 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:03:43 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:03:43 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:03:43 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:03:43 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:03:44 --> Final output sent to browser
DEBUG - 2019-05-28 11:03:44 --> Total execution time: 0.0508
INFO - 2019-05-28 11:03:45 --> Config Class Initialized
INFO - 2019-05-28 11:03:45 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:03:45 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:03:45 --> Utf8 Class Initialized
INFO - 2019-05-28 11:03:45 --> URI Class Initialized
INFO - 2019-05-28 11:03:45 --> Router Class Initialized
INFO - 2019-05-28 11:03:45 --> Output Class Initialized
INFO - 2019-05-28 11:03:45 --> Security Class Initialized
DEBUG - 2019-05-28 11:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:03:45 --> Input Class Initialized
INFO - 2019-05-28 11:03:45 --> Language Class Initialized
ERROR - 2019-05-28 11:03:45 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:03:47 --> Config Class Initialized
INFO - 2019-05-28 11:03:47 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:03:47 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:03:47 --> Utf8 Class Initialized
INFO - 2019-05-28 11:03:47 --> URI Class Initialized
DEBUG - 2019-05-28 11:03:47 --> No URI present. Default controller set.
INFO - 2019-05-28 11:03:47 --> Router Class Initialized
INFO - 2019-05-28 11:03:47 --> Output Class Initialized
INFO - 2019-05-28 11:03:47 --> Security Class Initialized
DEBUG - 2019-05-28 11:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:03:47 --> Input Class Initialized
INFO - 2019-05-28 11:03:47 --> Language Class Initialized
INFO - 2019-05-28 11:03:47 --> Language Class Initialized
INFO - 2019-05-28 11:03:47 --> Config Class Initialized
INFO - 2019-05-28 11:03:47 --> Loader Class Initialized
INFO - 2019-05-28 11:03:47 --> Helper loaded: form_helper
INFO - 2019-05-28 11:03:47 --> Helper loaded: url_helper
INFO - 2019-05-28 11:03:47 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:03:47 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:03:47 --> Template library initialized
INFO - 2019-05-28 11:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:03:47 --> Controller Class Initialized
DEBUG - 2019-05-28 11:03:47 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:03:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:03:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:03:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:03:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:03:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:03:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:03:47 --> Config Class Initialized
INFO - 2019-05-28 11:03:47 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:03:47 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:03:47 --> Utf8 Class Initialized
INFO - 2019-05-28 11:03:47 --> URI Class Initialized
DEBUG - 2019-05-28 11:03:47 --> No URI present. Default controller set.
INFO - 2019-05-28 11:03:47 --> Router Class Initialized
INFO - 2019-05-28 11:03:47 --> Output Class Initialized
INFO - 2019-05-28 11:03:47 --> Security Class Initialized
DEBUG - 2019-05-28 11:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:03:47 --> Input Class Initialized
INFO - 2019-05-28 11:03:47 --> Language Class Initialized
INFO - 2019-05-28 11:03:47 --> Language Class Initialized
INFO - 2019-05-28 11:03:47 --> Config Class Initialized
INFO - 2019-05-28 11:03:47 --> Loader Class Initialized
INFO - 2019-05-28 11:03:47 --> Helper loaded: form_helper
INFO - 2019-05-28 11:03:47 --> Helper loaded: url_helper
INFO - 2019-05-28 11:03:47 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:03:47 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:03:47 --> Template library initialized
INFO - 2019-05-28 11:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:03:47 --> Controller Class Initialized
DEBUG - 2019-05-28 11:03:47 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:03:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:03:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:03:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:03:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:03:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:03:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:03:48 --> Final output sent to browser
DEBUG - 2019-05-28 11:03:48 --> Total execution time: 0.0469
INFO - 2019-05-28 11:03:53 --> Config Class Initialized
INFO - 2019-05-28 11:03:53 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:03:53 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:03:53 --> Utf8 Class Initialized
INFO - 2019-05-28 11:03:53 --> URI Class Initialized
INFO - 2019-05-28 11:03:53 --> Router Class Initialized
INFO - 2019-05-28 11:03:53 --> Output Class Initialized
INFO - 2019-05-28 11:03:53 --> Security Class Initialized
DEBUG - 2019-05-28 11:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:03:53 --> Input Class Initialized
INFO - 2019-05-28 11:03:53 --> Language Class Initialized
ERROR - 2019-05-28 11:03:53 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:03:54 --> Config Class Initialized
INFO - 2019-05-28 11:03:54 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:03:54 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:03:54 --> Utf8 Class Initialized
INFO - 2019-05-28 11:03:54 --> URI Class Initialized
INFO - 2019-05-28 11:03:54 --> Router Class Initialized
INFO - 2019-05-28 11:03:54 --> Output Class Initialized
INFO - 2019-05-28 11:03:54 --> Security Class Initialized
DEBUG - 2019-05-28 11:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:03:54 --> Input Class Initialized
INFO - 2019-05-28 11:03:54 --> Language Class Initialized
ERROR - 2019-05-28 11:03:54 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:03:54 --> Config Class Initialized
INFO - 2019-05-28 11:03:54 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:03:54 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:03:54 --> Utf8 Class Initialized
INFO - 2019-05-28 11:03:54 --> URI Class Initialized
INFO - 2019-05-28 11:03:54 --> Router Class Initialized
INFO - 2019-05-28 11:03:54 --> Output Class Initialized
INFO - 2019-05-28 11:03:54 --> Security Class Initialized
DEBUG - 2019-05-28 11:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:03:54 --> Input Class Initialized
INFO - 2019-05-28 11:03:54 --> Language Class Initialized
ERROR - 2019-05-28 11:03:54 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:03:55 --> Config Class Initialized
INFO - 2019-05-28 11:03:55 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:03:55 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:03:55 --> Utf8 Class Initialized
INFO - 2019-05-28 11:03:55 --> URI Class Initialized
INFO - 2019-05-28 11:03:55 --> Router Class Initialized
INFO - 2019-05-28 11:03:55 --> Output Class Initialized
INFO - 2019-05-28 11:03:55 --> Security Class Initialized
DEBUG - 2019-05-28 11:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:03:55 --> Input Class Initialized
INFO - 2019-05-28 11:03:55 --> Language Class Initialized
ERROR - 2019-05-28 11:03:55 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:05:39 --> Config Class Initialized
INFO - 2019-05-28 11:05:39 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:05:39 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:05:39 --> Utf8 Class Initialized
INFO - 2019-05-28 11:05:39 --> URI Class Initialized
DEBUG - 2019-05-28 11:05:39 --> No URI present. Default controller set.
INFO - 2019-05-28 11:05:39 --> Router Class Initialized
INFO - 2019-05-28 11:05:39 --> Output Class Initialized
INFO - 2019-05-28 11:05:39 --> Security Class Initialized
DEBUG - 2019-05-28 11:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:05:39 --> Input Class Initialized
INFO - 2019-05-28 11:05:39 --> Language Class Initialized
INFO - 2019-05-28 11:05:39 --> Language Class Initialized
INFO - 2019-05-28 11:05:39 --> Config Class Initialized
INFO - 2019-05-28 11:05:39 --> Loader Class Initialized
INFO - 2019-05-28 11:05:39 --> Helper loaded: form_helper
INFO - 2019-05-28 11:05:39 --> Helper loaded: url_helper
INFO - 2019-05-28 11:05:39 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:05:39 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:05:39 --> Template library initialized
INFO - 2019-05-28 11:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:05:39 --> Controller Class Initialized
DEBUG - 2019-05-28 11:05:39 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:05:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:05:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:05:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:05:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:05:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:05:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:05:39 --> Final output sent to browser
DEBUG - 2019-05-28 11:05:39 --> Total execution time: 0.0600
INFO - 2019-05-28 11:05:40 --> Config Class Initialized
INFO - 2019-05-28 11:05:40 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:05:40 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:05:40 --> Utf8 Class Initialized
INFO - 2019-05-28 11:05:40 --> URI Class Initialized
INFO - 2019-05-28 11:05:40 --> Router Class Initialized
INFO - 2019-05-28 11:05:40 --> Config Class Initialized
INFO - 2019-05-28 11:05:40 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:05:40 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:05:40 --> Utf8 Class Initialized
INFO - 2019-05-28 11:05:40 --> URI Class Initialized
INFO - 2019-05-28 11:05:40 --> Router Class Initialized
INFO - 2019-05-28 11:05:40 --> Config Class Initialized
INFO - 2019-05-28 11:05:40 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:05:40 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:05:40 --> Utf8 Class Initialized
INFO - 2019-05-28 11:05:40 --> URI Class Initialized
INFO - 2019-05-28 11:05:40 --> Router Class Initialized
INFO - 2019-05-28 11:05:40 --> Output Class Initialized
INFO - 2019-05-28 11:05:40 --> Security Class Initialized
INFO - 2019-05-28 11:05:40 --> Output Class Initialized
INFO - 2019-05-28 11:05:40 --> Security Class Initialized
DEBUG - 2019-05-28 11:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:05:40 --> Input Class Initialized
INFO - 2019-05-28 11:05:40 --> Language Class Initialized
ERROR - 2019-05-28 11:05:40 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:05:40 --> Output Class Initialized
INFO - 2019-05-28 11:05:40 --> Security Class Initialized
DEBUG - 2019-05-28 11:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:05:40 --> Input Class Initialized
INFO - 2019-05-28 11:05:40 --> Language Class Initialized
ERROR - 2019-05-28 11:05:40 --> 404 Page Not Found: /index
DEBUG - 2019-05-28 11:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:05:40 --> Input Class Initialized
INFO - 2019-05-28 11:05:40 --> Language Class Initialized
ERROR - 2019-05-28 11:05:40 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:05:42 --> Config Class Initialized
INFO - 2019-05-28 11:05:42 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:05:42 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:05:42 --> Utf8 Class Initialized
INFO - 2019-05-28 11:05:42 --> URI Class Initialized
DEBUG - 2019-05-28 11:05:42 --> No URI present. Default controller set.
INFO - 2019-05-28 11:05:42 --> Router Class Initialized
INFO - 2019-05-28 11:05:42 --> Output Class Initialized
INFO - 2019-05-28 11:05:42 --> Security Class Initialized
DEBUG - 2019-05-28 11:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:05:42 --> Input Class Initialized
INFO - 2019-05-28 11:05:42 --> Language Class Initialized
INFO - 2019-05-28 11:05:42 --> Language Class Initialized
INFO - 2019-05-28 11:05:42 --> Config Class Initialized
INFO - 2019-05-28 11:05:42 --> Loader Class Initialized
INFO - 2019-05-28 11:05:42 --> Helper loaded: form_helper
INFO - 2019-05-28 11:05:42 --> Helper loaded: url_helper
INFO - 2019-05-28 11:05:42 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:05:42 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:05:42 --> Template library initialized
INFO - 2019-05-28 11:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:05:42 --> Controller Class Initialized
DEBUG - 2019-05-28 11:05:42 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:05:42 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:05:42 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
ERROR - 2019-05-28 11:05:42 --> Severity: Error --> Call to undefined method MY_Loader::userdata() /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php 12
INFO - 2019-05-28 11:05:43 --> Config Class Initialized
INFO - 2019-05-28 11:05:43 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:05:43 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:05:43 --> Utf8 Class Initialized
INFO - 2019-05-28 11:05:43 --> URI Class Initialized
INFO - 2019-05-28 11:05:43 --> Router Class Initialized
INFO - 2019-05-28 11:05:43 --> Output Class Initialized
INFO - 2019-05-28 11:05:43 --> Security Class Initialized
DEBUG - 2019-05-28 11:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:05:43 --> Input Class Initialized
INFO - 2019-05-28 11:05:43 --> Language Class Initialized
ERROR - 2019-05-28 11:05:43 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:06:09 --> Config Class Initialized
INFO - 2019-05-28 11:06:09 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:06:09 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:06:09 --> Utf8 Class Initialized
INFO - 2019-05-28 11:06:09 --> URI Class Initialized
DEBUG - 2019-05-28 11:06:09 --> No URI present. Default controller set.
INFO - 2019-05-28 11:06:09 --> Router Class Initialized
INFO - 2019-05-28 11:06:09 --> Output Class Initialized
INFO - 2019-05-28 11:06:09 --> Security Class Initialized
DEBUG - 2019-05-28 11:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:06:09 --> Input Class Initialized
INFO - 2019-05-28 11:06:09 --> Language Class Initialized
INFO - 2019-05-28 11:06:09 --> Language Class Initialized
INFO - 2019-05-28 11:06:09 --> Config Class Initialized
INFO - 2019-05-28 11:06:09 --> Loader Class Initialized
INFO - 2019-05-28 11:06:09 --> Helper loaded: form_helper
INFO - 2019-05-28 11:06:09 --> Helper loaded: url_helper
INFO - 2019-05-28 11:06:09 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:06:09 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:06:09 --> Template library initialized
INFO - 2019-05-28 11:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:06:09 --> Controller Class Initialized
DEBUG - 2019-05-28 11:06:09 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:06:09 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:06:09 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:06:09 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:06:09 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:06:09 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:06:09 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:06:10 --> Config Class Initialized
INFO - 2019-05-28 11:06:10 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:06:10 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:06:10 --> Utf8 Class Initialized
INFO - 2019-05-28 11:06:10 --> URI Class Initialized
DEBUG - 2019-05-28 11:06:10 --> No URI present. Default controller set.
INFO - 2019-05-28 11:06:10 --> Router Class Initialized
INFO - 2019-05-28 11:06:10 --> Output Class Initialized
INFO - 2019-05-28 11:06:10 --> Security Class Initialized
DEBUG - 2019-05-28 11:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:06:10 --> Input Class Initialized
INFO - 2019-05-28 11:06:10 --> Language Class Initialized
INFO - 2019-05-28 11:06:10 --> Language Class Initialized
INFO - 2019-05-28 11:06:10 --> Config Class Initialized
INFO - 2019-05-28 11:06:10 --> Loader Class Initialized
INFO - 2019-05-28 11:06:10 --> Helper loaded: form_helper
INFO - 2019-05-28 11:06:10 --> Helper loaded: url_helper
INFO - 2019-05-28 11:06:10 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:06:10 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:06:10 --> Template library initialized
INFO - 2019-05-28 11:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:06:10 --> Controller Class Initialized
DEBUG - 2019-05-28 11:06:10 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:06:10 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:06:10 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:06:10 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:06:10 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:06:10 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:06:10 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:06:11 --> Final output sent to browser
DEBUG - 2019-05-28 11:06:11 --> Total execution time: 0.0493
INFO - 2019-05-28 11:06:13 --> Config Class Initialized
INFO - 2019-05-28 11:06:13 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:06:13 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:06:13 --> Utf8 Class Initialized
INFO - 2019-05-28 11:06:13 --> URI Class Initialized
INFO - 2019-05-28 11:06:13 --> Router Class Initialized
INFO - 2019-05-28 11:06:13 --> Output Class Initialized
INFO - 2019-05-28 11:06:13 --> Security Class Initialized
DEBUG - 2019-05-28 11:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:06:13 --> Input Class Initialized
INFO - 2019-05-28 11:06:13 --> Language Class Initialized
ERROR - 2019-05-28 11:06:13 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:06:14 --> Config Class Initialized
INFO - 2019-05-28 11:06:14 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:06:14 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:06:14 --> Utf8 Class Initialized
INFO - 2019-05-28 11:06:14 --> URI Class Initialized
INFO - 2019-05-28 11:06:14 --> Router Class Initialized
INFO - 2019-05-28 11:06:14 --> Output Class Initialized
INFO - 2019-05-28 11:06:14 --> Security Class Initialized
DEBUG - 2019-05-28 11:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:06:14 --> Input Class Initialized
INFO - 2019-05-28 11:06:14 --> Language Class Initialized
ERROR - 2019-05-28 11:06:14 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:06:14 --> Config Class Initialized
INFO - 2019-05-28 11:06:14 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:06:14 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:06:14 --> Utf8 Class Initialized
INFO - 2019-05-28 11:06:14 --> URI Class Initialized
INFO - 2019-05-28 11:06:14 --> Router Class Initialized
INFO - 2019-05-28 11:06:14 --> Output Class Initialized
INFO - 2019-05-28 11:06:14 --> Security Class Initialized
DEBUG - 2019-05-28 11:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:06:14 --> Input Class Initialized
INFO - 2019-05-28 11:06:14 --> Language Class Initialized
ERROR - 2019-05-28 11:06:14 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:06:15 --> Config Class Initialized
INFO - 2019-05-28 11:06:15 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:06:15 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:06:15 --> Utf8 Class Initialized
INFO - 2019-05-28 11:06:15 --> URI Class Initialized
INFO - 2019-05-28 11:06:15 --> Router Class Initialized
INFO - 2019-05-28 11:06:15 --> Output Class Initialized
INFO - 2019-05-28 11:06:15 --> Security Class Initialized
DEBUG - 2019-05-28 11:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:06:15 --> Input Class Initialized
INFO - 2019-05-28 11:06:15 --> Language Class Initialized
ERROR - 2019-05-28 11:06:15 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:07:17 --> Config Class Initialized
INFO - 2019-05-28 11:07:17 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:07:17 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:07:17 --> Utf8 Class Initialized
INFO - 2019-05-28 11:07:17 --> URI Class Initialized
DEBUG - 2019-05-28 11:07:17 --> No URI present. Default controller set.
INFO - 2019-05-28 11:07:17 --> Router Class Initialized
INFO - 2019-05-28 11:07:17 --> Output Class Initialized
INFO - 2019-05-28 11:07:17 --> Security Class Initialized
DEBUG - 2019-05-28 11:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:07:17 --> Input Class Initialized
INFO - 2019-05-28 11:07:17 --> Language Class Initialized
INFO - 2019-05-28 11:07:17 --> Language Class Initialized
INFO - 2019-05-28 11:07:17 --> Config Class Initialized
INFO - 2019-05-28 11:07:17 --> Loader Class Initialized
INFO - 2019-05-28 11:07:17 --> Helper loaded: form_helper
INFO - 2019-05-28 11:07:17 --> Helper loaded: url_helper
INFO - 2019-05-28 11:07:17 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:07:17 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:07:17 --> Template library initialized
INFO - 2019-05-28 11:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:07:17 --> Controller Class Initialized
DEBUG - 2019-05-28 11:07:17 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:07:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:07:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
ERROR - 2019-05-28 11:07:17 --> Severity: Error --> Call to undefined method CI_Session::user_data() /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php 12
INFO - 2019-05-28 11:07:18 --> Config Class Initialized
INFO - 2019-05-28 11:07:18 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:07:18 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:07:18 --> Utf8 Class Initialized
INFO - 2019-05-28 11:07:18 --> URI Class Initialized
DEBUG - 2019-05-28 11:07:18 --> No URI present. Default controller set.
INFO - 2019-05-28 11:07:18 --> Router Class Initialized
INFO - 2019-05-28 11:07:18 --> Output Class Initialized
INFO - 2019-05-28 11:07:18 --> Security Class Initialized
DEBUG - 2019-05-28 11:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:07:18 --> Input Class Initialized
INFO - 2019-05-28 11:07:18 --> Language Class Initialized
INFO - 2019-05-28 11:07:18 --> Language Class Initialized
INFO - 2019-05-28 11:07:18 --> Config Class Initialized
INFO - 2019-05-28 11:07:18 --> Loader Class Initialized
INFO - 2019-05-28 11:07:18 --> Helper loaded: form_helper
INFO - 2019-05-28 11:07:18 --> Helper loaded: url_helper
INFO - 2019-05-28 11:07:18 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:07:18 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:07:18 --> Template library initialized
INFO - 2019-05-28 11:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:07:18 --> Controller Class Initialized
DEBUG - 2019-05-28 11:07:18 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:07:18 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:07:18 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
ERROR - 2019-05-28 11:07:18 --> Severity: Error --> Call to undefined method CI_Session::user_data() /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php 12
INFO - 2019-05-28 11:07:19 --> Config Class Initialized
INFO - 2019-05-28 11:07:19 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:07:19 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:07:19 --> Utf8 Class Initialized
INFO - 2019-05-28 11:07:19 --> URI Class Initialized
INFO - 2019-05-28 11:07:19 --> Router Class Initialized
INFO - 2019-05-28 11:07:19 --> Output Class Initialized
INFO - 2019-05-28 11:07:19 --> Security Class Initialized
DEBUG - 2019-05-28 11:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:07:19 --> Input Class Initialized
INFO - 2019-05-28 11:07:19 --> Language Class Initialized
ERROR - 2019-05-28 11:07:19 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:07:20 --> Config Class Initialized
INFO - 2019-05-28 11:07:20 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:07:20 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:07:20 --> Utf8 Class Initialized
INFO - 2019-05-28 11:07:20 --> URI Class Initialized
DEBUG - 2019-05-28 11:07:20 --> No URI present. Default controller set.
INFO - 2019-05-28 11:07:20 --> Router Class Initialized
INFO - 2019-05-28 11:07:20 --> Output Class Initialized
INFO - 2019-05-28 11:07:20 --> Security Class Initialized
DEBUG - 2019-05-28 11:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:07:20 --> Input Class Initialized
INFO - 2019-05-28 11:07:20 --> Language Class Initialized
INFO - 2019-05-28 11:07:20 --> Language Class Initialized
INFO - 2019-05-28 11:07:20 --> Config Class Initialized
INFO - 2019-05-28 11:07:20 --> Loader Class Initialized
INFO - 2019-05-28 11:07:20 --> Helper loaded: form_helper
INFO - 2019-05-28 11:07:20 --> Helper loaded: url_helper
INFO - 2019-05-28 11:07:20 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:07:20 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:07:20 --> Template library initialized
INFO - 2019-05-28 11:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:07:20 --> Controller Class Initialized
DEBUG - 2019-05-28 11:07:20 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:07:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:07:20 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
ERROR - 2019-05-28 11:07:20 --> Severity: Error --> Call to undefined method CI_Session::user_data() /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php 12
INFO - 2019-05-28 11:07:21 --> Config Class Initialized
INFO - 2019-05-28 11:07:21 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:07:21 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:07:21 --> Utf8 Class Initialized
INFO - 2019-05-28 11:07:21 --> URI Class Initialized
DEBUG - 2019-05-28 11:07:21 --> No URI present. Default controller set.
INFO - 2019-05-28 11:07:21 --> Router Class Initialized
INFO - 2019-05-28 11:07:21 --> Output Class Initialized
INFO - 2019-05-28 11:07:21 --> Security Class Initialized
DEBUG - 2019-05-28 11:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:07:21 --> Input Class Initialized
INFO - 2019-05-28 11:07:21 --> Language Class Initialized
INFO - 2019-05-28 11:07:21 --> Language Class Initialized
INFO - 2019-05-28 11:07:21 --> Config Class Initialized
INFO - 2019-05-28 11:07:21 --> Loader Class Initialized
INFO - 2019-05-28 11:07:21 --> Helper loaded: form_helper
INFO - 2019-05-28 11:07:21 --> Helper loaded: url_helper
INFO - 2019-05-28 11:07:21 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:07:21 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:07:21 --> Template library initialized
INFO - 2019-05-28 11:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:07:21 --> Controller Class Initialized
DEBUG - 2019-05-28 11:07:21 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:07:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:07:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
ERROR - 2019-05-28 11:07:21 --> Severity: Error --> Call to undefined method CI_Session::user_data() /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php 12
INFO - 2019-05-28 11:07:23 --> Config Class Initialized
INFO - 2019-05-28 11:07:23 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:07:23 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:07:23 --> Utf8 Class Initialized
INFO - 2019-05-28 11:07:23 --> URI Class Initialized
INFO - 2019-05-28 11:07:23 --> Router Class Initialized
INFO - 2019-05-28 11:07:23 --> Output Class Initialized
INFO - 2019-05-28 11:07:23 --> Security Class Initialized
DEBUG - 2019-05-28 11:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:07:23 --> Input Class Initialized
INFO - 2019-05-28 11:07:23 --> Language Class Initialized
ERROR - 2019-05-28 11:07:23 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:08:34 --> Config Class Initialized
INFO - 2019-05-28 11:08:34 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:08:34 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:08:34 --> Utf8 Class Initialized
INFO - 2019-05-28 11:08:34 --> URI Class Initialized
DEBUG - 2019-05-28 11:08:34 --> No URI present. Default controller set.
INFO - 2019-05-28 11:08:34 --> Router Class Initialized
INFO - 2019-05-28 11:08:34 --> Output Class Initialized
INFO - 2019-05-28 11:08:34 --> Security Class Initialized
DEBUG - 2019-05-28 11:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:08:34 --> Input Class Initialized
INFO - 2019-05-28 11:08:34 --> Language Class Initialized
INFO - 2019-05-28 11:08:34 --> Language Class Initialized
INFO - 2019-05-28 11:08:34 --> Config Class Initialized
INFO - 2019-05-28 11:08:34 --> Loader Class Initialized
INFO - 2019-05-28 11:08:34 --> Helper loaded: form_helper
INFO - 2019-05-28 11:08:34 --> Helper loaded: url_helper
INFO - 2019-05-28 11:08:34 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:08:34 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:08:34 --> Template library initialized
INFO - 2019-05-28 11:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:08:34 --> Controller Class Initialized
DEBUG - 2019-05-28 11:08:34 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:08:34 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:08:34 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:08:34 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:08:34 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:08:34 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:08:34 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:08:35 --> Config Class Initialized
INFO - 2019-05-28 11:08:35 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:08:35 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:08:35 --> Utf8 Class Initialized
INFO - 2019-05-28 11:08:35 --> URI Class Initialized
DEBUG - 2019-05-28 11:08:35 --> No URI present. Default controller set.
INFO - 2019-05-28 11:08:35 --> Router Class Initialized
INFO - 2019-05-28 11:08:35 --> Output Class Initialized
INFO - 2019-05-28 11:08:35 --> Security Class Initialized
DEBUG - 2019-05-28 11:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:08:35 --> Input Class Initialized
INFO - 2019-05-28 11:08:35 --> Language Class Initialized
INFO - 2019-05-28 11:08:35 --> Language Class Initialized
INFO - 2019-05-28 11:08:35 --> Config Class Initialized
INFO - 2019-05-28 11:08:35 --> Loader Class Initialized
INFO - 2019-05-28 11:08:35 --> Helper loaded: form_helper
INFO - 2019-05-28 11:08:35 --> Helper loaded: url_helper
INFO - 2019-05-28 11:08:35 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:08:35 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:08:35 --> Template library initialized
INFO - 2019-05-28 11:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:08:35 --> Controller Class Initialized
DEBUG - 2019-05-28 11:08:35 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:08:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:08:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:08:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:08:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:08:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:08:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:08:35 --> Final output sent to browser
DEBUG - 2019-05-28 11:08:35 --> Total execution time: 0.0446
INFO - 2019-05-28 11:08:39 --> Config Class Initialized
INFO - 2019-05-28 11:08:39 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:08:39 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:08:39 --> Utf8 Class Initialized
INFO - 2019-05-28 11:08:39 --> URI Class Initialized
INFO - 2019-05-28 11:08:39 --> Router Class Initialized
INFO - 2019-05-28 11:08:39 --> Output Class Initialized
INFO - 2019-05-28 11:08:39 --> Security Class Initialized
DEBUG - 2019-05-28 11:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:08:39 --> Input Class Initialized
INFO - 2019-05-28 11:08:39 --> Language Class Initialized
ERROR - 2019-05-28 11:08:39 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:08:39 --> Config Class Initialized
INFO - 2019-05-28 11:08:39 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:08:39 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:08:39 --> Utf8 Class Initialized
INFO - 2019-05-28 11:08:39 --> URI Class Initialized
INFO - 2019-05-28 11:08:39 --> Router Class Initialized
INFO - 2019-05-28 11:08:39 --> Output Class Initialized
INFO - 2019-05-28 11:08:39 --> Security Class Initialized
DEBUG - 2019-05-28 11:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:08:39 --> Input Class Initialized
INFO - 2019-05-28 11:08:39 --> Language Class Initialized
ERROR - 2019-05-28 11:08:39 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:08:39 --> Config Class Initialized
INFO - 2019-05-28 11:08:39 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:08:39 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:08:39 --> Utf8 Class Initialized
INFO - 2019-05-28 11:08:39 --> URI Class Initialized
INFO - 2019-05-28 11:08:39 --> Router Class Initialized
INFO - 2019-05-28 11:08:39 --> Output Class Initialized
INFO - 2019-05-28 11:08:39 --> Security Class Initialized
DEBUG - 2019-05-28 11:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:08:39 --> Input Class Initialized
INFO - 2019-05-28 11:08:39 --> Language Class Initialized
ERROR - 2019-05-28 11:08:39 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:08:40 --> Config Class Initialized
INFO - 2019-05-28 11:08:40 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:08:40 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:08:40 --> Utf8 Class Initialized
INFO - 2019-05-28 11:08:40 --> URI Class Initialized
INFO - 2019-05-28 11:08:40 --> Router Class Initialized
INFO - 2019-05-28 11:08:40 --> Output Class Initialized
INFO - 2019-05-28 11:08:40 --> Security Class Initialized
DEBUG - 2019-05-28 11:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:08:40 --> Input Class Initialized
INFO - 2019-05-28 11:08:40 --> Language Class Initialized
ERROR - 2019-05-28 11:08:40 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:09:25 --> Config Class Initialized
INFO - 2019-05-28 11:09:25 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:09:25 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:09:25 --> Utf8 Class Initialized
INFO - 2019-05-28 11:09:25 --> URI Class Initialized
DEBUG - 2019-05-28 11:09:25 --> No URI present. Default controller set.
INFO - 2019-05-28 11:09:25 --> Router Class Initialized
INFO - 2019-05-28 11:09:25 --> Output Class Initialized
INFO - 2019-05-28 11:09:25 --> Security Class Initialized
DEBUG - 2019-05-28 11:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:09:25 --> Input Class Initialized
INFO - 2019-05-28 11:09:25 --> Language Class Initialized
INFO - 2019-05-28 11:09:25 --> Language Class Initialized
INFO - 2019-05-28 11:09:25 --> Config Class Initialized
INFO - 2019-05-28 11:09:25 --> Loader Class Initialized
INFO - 2019-05-28 11:09:25 --> Helper loaded: form_helper
INFO - 2019-05-28 11:09:25 --> Helper loaded: url_helper
INFO - 2019-05-28 11:09:25 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:09:25 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:09:25 --> Template library initialized
INFO - 2019-05-28 11:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:09:25 --> Controller Class Initialized
DEBUG - 2019-05-28 11:09:25 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:09:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:09:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:09:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:09:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:09:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:09:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:09:25 --> Config Class Initialized
INFO - 2019-05-28 11:09:25 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:09:25 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:09:25 --> Utf8 Class Initialized
INFO - 2019-05-28 11:09:25 --> URI Class Initialized
DEBUG - 2019-05-28 11:09:25 --> No URI present. Default controller set.
INFO - 2019-05-28 11:09:25 --> Router Class Initialized
INFO - 2019-05-28 11:09:25 --> Output Class Initialized
INFO - 2019-05-28 11:09:25 --> Security Class Initialized
DEBUG - 2019-05-28 11:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:09:25 --> Input Class Initialized
INFO - 2019-05-28 11:09:25 --> Language Class Initialized
INFO - 2019-05-28 11:09:25 --> Language Class Initialized
INFO - 2019-05-28 11:09:25 --> Config Class Initialized
INFO - 2019-05-28 11:09:25 --> Loader Class Initialized
INFO - 2019-05-28 11:09:25 --> Helper loaded: form_helper
INFO - 2019-05-28 11:09:25 --> Helper loaded: url_helper
INFO - 2019-05-28 11:09:25 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:09:25 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:09:25 --> Template library initialized
INFO - 2019-05-28 11:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:09:25 --> Controller Class Initialized
DEBUG - 2019-05-28 11:09:25 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:09:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:09:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:09:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:09:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:09:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:09:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:09:26 --> Final output sent to browser
DEBUG - 2019-05-28 11:09:26 --> Total execution time: 0.0525
INFO - 2019-05-28 11:09:27 --> Config Class Initialized
INFO - 2019-05-28 11:09:27 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:09:27 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:09:27 --> Utf8 Class Initialized
INFO - 2019-05-28 11:09:27 --> URI Class Initialized
INFO - 2019-05-28 11:09:27 --> Config Class Initialized
INFO - 2019-05-28 11:09:27 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:09:27 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:09:27 --> Utf8 Class Initialized
INFO - 2019-05-28 11:09:27 --> URI Class Initialized
INFO - 2019-05-28 11:09:27 --> Router Class Initialized
INFO - 2019-05-28 11:09:27 --> Router Class Initialized
INFO - 2019-05-28 11:09:27 --> Output Class Initialized
INFO - 2019-05-28 11:09:27 --> Security Class Initialized
DEBUG - 2019-05-28 11:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:09:27 --> Input Class Initialized
INFO - 2019-05-28 11:09:27 --> Language Class Initialized
ERROR - 2019-05-28 11:09:27 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:09:27 --> Output Class Initialized
INFO - 2019-05-28 11:09:27 --> Security Class Initialized
DEBUG - 2019-05-28 11:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:09:27 --> Input Class Initialized
INFO - 2019-05-28 11:09:27 --> Language Class Initialized
ERROR - 2019-05-28 11:09:27 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:09:27 --> Config Class Initialized
INFO - 2019-05-28 11:09:27 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:09:27 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:09:27 --> Utf8 Class Initialized
INFO - 2019-05-28 11:09:27 --> URI Class Initialized
INFO - 2019-05-28 11:09:27 --> Router Class Initialized
INFO - 2019-05-28 11:09:27 --> Output Class Initialized
INFO - 2019-05-28 11:09:27 --> Security Class Initialized
DEBUG - 2019-05-28 11:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:09:27 --> Input Class Initialized
INFO - 2019-05-28 11:09:27 --> Language Class Initialized
ERROR - 2019-05-28 11:09:27 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:09:30 --> Config Class Initialized
INFO - 2019-05-28 11:09:30 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:09:30 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:09:30 --> Utf8 Class Initialized
INFO - 2019-05-28 11:09:30 --> URI Class Initialized
INFO - 2019-05-28 11:09:30 --> Router Class Initialized
INFO - 2019-05-28 11:09:30 --> Output Class Initialized
INFO - 2019-05-28 11:09:30 --> Security Class Initialized
DEBUG - 2019-05-28 11:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:09:30 --> Input Class Initialized
INFO - 2019-05-28 11:09:30 --> Language Class Initialized
ERROR - 2019-05-28 11:09:30 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:11:37 --> Config Class Initialized
INFO - 2019-05-28 11:11:37 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:11:37 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:11:37 --> Utf8 Class Initialized
INFO - 2019-05-28 11:11:37 --> URI Class Initialized
DEBUG - 2019-05-28 11:11:37 --> No URI present. Default controller set.
INFO - 2019-05-28 11:11:37 --> Router Class Initialized
INFO - 2019-05-28 11:11:37 --> Output Class Initialized
INFO - 2019-05-28 11:11:37 --> Security Class Initialized
DEBUG - 2019-05-28 11:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:11:37 --> Input Class Initialized
INFO - 2019-05-28 11:11:37 --> Language Class Initialized
INFO - 2019-05-28 11:11:37 --> Language Class Initialized
INFO - 2019-05-28 11:11:37 --> Config Class Initialized
INFO - 2019-05-28 11:11:37 --> Loader Class Initialized
INFO - 2019-05-28 11:11:37 --> Helper loaded: form_helper
INFO - 2019-05-28 11:11:37 --> Helper loaded: url_helper
INFO - 2019-05-28 11:11:37 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:11:37 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:11:37 --> Template library initialized
INFO - 2019-05-28 11:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:11:37 --> Controller Class Initialized
DEBUG - 2019-05-28 11:11:37 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:11:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:11:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:11:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:11:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:11:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:11:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:11:37 --> Final output sent to browser
DEBUG - 2019-05-28 11:11:37 --> Total execution time: 0.0478
INFO - 2019-05-28 11:11:39 --> Config Class Initialized
INFO - 2019-05-28 11:11:39 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:11:39 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:11:39 --> Utf8 Class Initialized
INFO - 2019-05-28 11:11:39 --> Config Class Initialized
INFO - 2019-05-28 11:11:39 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:11:39 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:11:39 --> Utf8 Class Initialized
INFO - 2019-05-28 11:11:39 --> URI Class Initialized
INFO - 2019-05-28 11:11:39 --> Router Class Initialized
INFO - 2019-05-28 11:11:39 --> URI Class Initialized
INFO - 2019-05-28 11:11:39 --> Router Class Initialized
INFO - 2019-05-28 11:11:39 --> Output Class Initialized
INFO - 2019-05-28 11:11:39 --> Security Class Initialized
DEBUG - 2019-05-28 11:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:11:39 --> Input Class Initialized
INFO - 2019-05-28 11:11:39 --> Language Class Initialized
ERROR - 2019-05-28 11:11:39 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:11:39 --> Config Class Initialized
INFO - 2019-05-28 11:11:39 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:11:39 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:11:39 --> Utf8 Class Initialized
INFO - 2019-05-28 11:11:39 --> URI Class Initialized
INFO - 2019-05-28 11:11:39 --> Output Class Initialized
INFO - 2019-05-28 11:11:39 --> Security Class Initialized
DEBUG - 2019-05-28 11:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:11:39 --> Input Class Initialized
INFO - 2019-05-28 11:11:39 --> Language Class Initialized
ERROR - 2019-05-28 11:11:39 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:11:39 --> Router Class Initialized
INFO - 2019-05-28 11:11:39 --> Output Class Initialized
INFO - 2019-05-28 11:11:39 --> Security Class Initialized
DEBUG - 2019-05-28 11:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:11:39 --> Input Class Initialized
INFO - 2019-05-28 11:11:39 --> Language Class Initialized
ERROR - 2019-05-28 11:11:39 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:11:41 --> Config Class Initialized
INFO - 2019-05-28 11:11:41 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:11:41 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:11:41 --> Utf8 Class Initialized
INFO - 2019-05-28 11:11:41 --> URI Class Initialized
INFO - 2019-05-28 11:11:41 --> Router Class Initialized
INFO - 2019-05-28 11:11:41 --> Output Class Initialized
INFO - 2019-05-28 11:11:41 --> Security Class Initialized
DEBUG - 2019-05-28 11:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:11:41 --> Input Class Initialized
INFO - 2019-05-28 11:11:41 --> Language Class Initialized
ERROR - 2019-05-28 11:11:41 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:16:32 --> Config Class Initialized
INFO - 2019-05-28 11:16:32 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:16:32 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:16:32 --> Utf8 Class Initialized
INFO - 2019-05-28 11:16:32 --> URI Class Initialized
DEBUG - 2019-05-28 11:16:32 --> No URI present. Default controller set.
INFO - 2019-05-28 11:16:32 --> Router Class Initialized
INFO - 2019-05-28 11:16:32 --> Output Class Initialized
INFO - 2019-05-28 11:16:32 --> Security Class Initialized
DEBUG - 2019-05-28 11:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:16:32 --> Input Class Initialized
INFO - 2019-05-28 11:16:32 --> Language Class Initialized
INFO - 2019-05-28 11:16:32 --> Language Class Initialized
INFO - 2019-05-28 11:16:32 --> Config Class Initialized
INFO - 2019-05-28 11:16:32 --> Loader Class Initialized
INFO - 2019-05-28 11:16:32 --> Helper loaded: form_helper
INFO - 2019-05-28 11:16:32 --> Helper loaded: url_helper
INFO - 2019-05-28 11:16:32 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:16:32 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:16:32 --> Template library initialized
INFO - 2019-05-28 11:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:16:32 --> Controller Class Initialized
DEBUG - 2019-05-28 11:16:32 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:16:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:16:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:16:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:16:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:16:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:16:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:16:33 --> Final output sent to browser
DEBUG - 2019-05-28 11:16:33 --> Total execution time: 0.0539
INFO - 2019-05-28 11:16:34 --> Config Class Initialized
INFO - 2019-05-28 11:16:34 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:16:34 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:16:34 --> Utf8 Class Initialized
INFO - 2019-05-28 11:16:34 --> URI Class Initialized
INFO - 2019-05-28 11:16:34 --> Config Class Initialized
INFO - 2019-05-28 11:16:34 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:16:34 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:16:34 --> Utf8 Class Initialized
INFO - 2019-05-28 11:16:34 --> URI Class Initialized
INFO - 2019-05-28 11:16:34 --> Router Class Initialized
INFO - 2019-05-28 11:16:34 --> Config Class Initialized
INFO - 2019-05-28 11:16:34 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:16:34 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:16:34 --> Utf8 Class Initialized
INFO - 2019-05-28 11:16:34 --> URI Class Initialized
INFO - 2019-05-28 11:16:34 --> Router Class Initialized
INFO - 2019-05-28 11:16:34 --> Router Class Initialized
INFO - 2019-05-28 11:16:34 --> Output Class Initialized
INFO - 2019-05-28 11:16:34 --> Security Class Initialized
DEBUG - 2019-05-28 11:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:16:34 --> Input Class Initialized
INFO - 2019-05-28 11:16:34 --> Language Class Initialized
ERROR - 2019-05-28 11:16:34 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:16:34 --> Output Class Initialized
INFO - 2019-05-28 11:16:34 --> Security Class Initialized
DEBUG - 2019-05-28 11:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:16:34 --> Input Class Initialized
INFO - 2019-05-28 11:16:34 --> Language Class Initialized
ERROR - 2019-05-28 11:16:34 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:16:34 --> Output Class Initialized
INFO - 2019-05-28 11:16:34 --> Security Class Initialized
DEBUG - 2019-05-28 11:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:16:34 --> Input Class Initialized
INFO - 2019-05-28 11:16:34 --> Language Class Initialized
ERROR - 2019-05-28 11:16:34 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:16:37 --> Config Class Initialized
INFO - 2019-05-28 11:16:37 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:16:37 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:16:37 --> Utf8 Class Initialized
INFO - 2019-05-28 11:16:37 --> URI Class Initialized
DEBUG - 2019-05-28 11:16:37 --> No URI present. Default controller set.
INFO - 2019-05-28 11:16:37 --> Router Class Initialized
INFO - 2019-05-28 11:16:37 --> Output Class Initialized
INFO - 2019-05-28 11:16:37 --> Security Class Initialized
DEBUG - 2019-05-28 11:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:16:37 --> Input Class Initialized
INFO - 2019-05-28 11:16:37 --> Language Class Initialized
INFO - 2019-05-28 11:16:37 --> Language Class Initialized
INFO - 2019-05-28 11:16:37 --> Config Class Initialized
INFO - 2019-05-28 11:16:37 --> Loader Class Initialized
INFO - 2019-05-28 11:16:37 --> Helper loaded: form_helper
INFO - 2019-05-28 11:16:37 --> Helper loaded: url_helper
INFO - 2019-05-28 11:16:37 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:16:37 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:16:37 --> Template library initialized
INFO - 2019-05-28 11:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:16:37 --> Controller Class Initialized
DEBUG - 2019-05-28 11:16:37 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:16:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:16:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:16:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:16:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:16:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:16:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:16:37 --> Config Class Initialized
INFO - 2019-05-28 11:16:37 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:16:37 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:16:37 --> Utf8 Class Initialized
INFO - 2019-05-28 11:16:37 --> URI Class Initialized
DEBUG - 2019-05-28 11:16:37 --> No URI present. Default controller set.
INFO - 2019-05-28 11:16:37 --> Router Class Initialized
INFO - 2019-05-28 11:16:37 --> Output Class Initialized
INFO - 2019-05-28 11:16:37 --> Security Class Initialized
DEBUG - 2019-05-28 11:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:16:37 --> Input Class Initialized
INFO - 2019-05-28 11:16:37 --> Language Class Initialized
INFO - 2019-05-28 11:16:37 --> Language Class Initialized
INFO - 2019-05-28 11:16:37 --> Config Class Initialized
INFO - 2019-05-28 11:16:37 --> Loader Class Initialized
INFO - 2019-05-28 11:16:37 --> Helper loaded: form_helper
INFO - 2019-05-28 11:16:37 --> Helper loaded: url_helper
INFO - 2019-05-28 11:16:37 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:16:37 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:16:37 --> Template library initialized
INFO - 2019-05-28 11:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:16:37 --> Controller Class Initialized
DEBUG - 2019-05-28 11:16:37 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:16:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:16:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:16:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:16:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:16:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:16:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:16:37 --> Final output sent to browser
DEBUG - 2019-05-28 11:16:37 --> Total execution time: 0.0496
INFO - 2019-05-28 11:16:38 --> Config Class Initialized
INFO - 2019-05-28 11:16:38 --> Config Class Initialized
INFO - 2019-05-28 11:16:38 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:16:38 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:16:38 --> Utf8 Class Initialized
INFO - 2019-05-28 11:16:38 --> URI Class Initialized
INFO - 2019-05-28 11:16:38 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:16:38 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:16:38 --> Utf8 Class Initialized
INFO - 2019-05-28 11:16:38 --> URI Class Initialized
INFO - 2019-05-28 11:16:38 --> Router Class Initialized
INFO - 2019-05-28 11:16:38 --> Output Class Initialized
INFO - 2019-05-28 11:16:38 --> Router Class Initialized
INFO - 2019-05-28 11:16:38 --> Output Class Initialized
INFO - 2019-05-28 11:16:38 --> Security Class Initialized
DEBUG - 2019-05-28 11:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:16:38 --> Input Class Initialized
INFO - 2019-05-28 11:16:38 --> Language Class Initialized
ERROR - 2019-05-28 11:16:38 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:16:38 --> Security Class Initialized
DEBUG - 2019-05-28 11:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:16:38 --> Input Class Initialized
INFO - 2019-05-28 11:16:38 --> Language Class Initialized
ERROR - 2019-05-28 11:16:38 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:16:40 --> Config Class Initialized
INFO - 2019-05-28 11:16:40 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:16:40 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:16:40 --> Utf8 Class Initialized
INFO - 2019-05-28 11:16:40 --> URI Class Initialized
INFO - 2019-05-28 11:16:40 --> Router Class Initialized
INFO - 2019-05-28 11:16:40 --> Output Class Initialized
INFO - 2019-05-28 11:16:40 --> Security Class Initialized
DEBUG - 2019-05-28 11:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:16:40 --> Input Class Initialized
INFO - 2019-05-28 11:16:40 --> Language Class Initialized
ERROR - 2019-05-28 11:16:40 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:16:42 --> Config Class Initialized
INFO - 2019-05-28 11:16:42 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:16:42 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:16:42 --> Utf8 Class Initialized
INFO - 2019-05-28 11:16:42 --> URI Class Initialized
INFO - 2019-05-28 11:16:42 --> Router Class Initialized
INFO - 2019-05-28 11:16:42 --> Output Class Initialized
INFO - 2019-05-28 11:16:42 --> Security Class Initialized
DEBUG - 2019-05-28 11:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:16:42 --> Input Class Initialized
INFO - 2019-05-28 11:16:42 --> Language Class Initialized
ERROR - 2019-05-28 11:16:42 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:18:02 --> Config Class Initialized
INFO - 2019-05-28 11:18:02 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:18:02 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:18:02 --> Utf8 Class Initialized
INFO - 2019-05-28 11:18:02 --> URI Class Initialized
DEBUG - 2019-05-28 11:18:02 --> No URI present. Default controller set.
INFO - 2019-05-28 11:18:02 --> Router Class Initialized
INFO - 2019-05-28 11:18:02 --> Output Class Initialized
INFO - 2019-05-28 11:18:02 --> Security Class Initialized
DEBUG - 2019-05-28 11:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:18:02 --> Input Class Initialized
INFO - 2019-05-28 11:18:02 --> Language Class Initialized
INFO - 2019-05-28 11:18:02 --> Language Class Initialized
INFO - 2019-05-28 11:18:02 --> Config Class Initialized
INFO - 2019-05-28 11:18:03 --> Loader Class Initialized
INFO - 2019-05-28 11:18:03 --> Helper loaded: form_helper
INFO - 2019-05-28 11:18:03 --> Helper loaded: url_helper
INFO - 2019-05-28 11:18:03 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:18:03 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:18:03 --> Template library initialized
INFO - 2019-05-28 11:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:18:03 --> Controller Class Initialized
DEBUG - 2019-05-28 11:18:03 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:18:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:18:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:18:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:18:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:18:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:18:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:18:03 --> Config Class Initialized
INFO - 2019-05-28 11:18:03 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:18:03 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:18:03 --> Utf8 Class Initialized
INFO - 2019-05-28 11:18:03 --> URI Class Initialized
DEBUG - 2019-05-28 11:18:03 --> No URI present. Default controller set.
INFO - 2019-05-28 11:18:03 --> Router Class Initialized
INFO - 2019-05-28 11:18:03 --> Output Class Initialized
INFO - 2019-05-28 11:18:03 --> Security Class Initialized
DEBUG - 2019-05-28 11:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:18:03 --> Input Class Initialized
INFO - 2019-05-28 11:18:03 --> Language Class Initialized
INFO - 2019-05-28 11:18:03 --> Language Class Initialized
INFO - 2019-05-28 11:18:03 --> Config Class Initialized
INFO - 2019-05-28 11:18:03 --> Loader Class Initialized
INFO - 2019-05-28 11:18:03 --> Helper loaded: form_helper
INFO - 2019-05-28 11:18:03 --> Helper loaded: url_helper
INFO - 2019-05-28 11:18:03 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:18:03 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:18:03 --> Template library initialized
INFO - 2019-05-28 11:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:18:03 --> Controller Class Initialized
DEBUG - 2019-05-28 11:18:03 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:18:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:18:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:18:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:18:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:18:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:18:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:18:04 --> Final output sent to browser
DEBUG - 2019-05-28 11:18:04 --> Total execution time: 0.0452
INFO - 2019-05-28 11:18:04 --> Config Class Initialized
INFO - 2019-05-28 11:18:04 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:18:04 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:18:04 --> Utf8 Class Initialized
INFO - 2019-05-28 11:18:04 --> URI Class Initialized
INFO - 2019-05-28 11:18:04 --> Router Class Initialized
INFO - 2019-05-28 11:18:04 --> Output Class Initialized
INFO - 2019-05-28 11:18:04 --> Security Class Initialized
DEBUG - 2019-05-28 11:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:18:04 --> Input Class Initialized
INFO - 2019-05-28 11:18:04 --> Language Class Initialized
ERROR - 2019-05-28 11:18:04 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:18:04 --> Config Class Initialized
INFO - 2019-05-28 11:18:04 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:18:04 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:18:04 --> Utf8 Class Initialized
INFO - 2019-05-28 11:18:04 --> URI Class Initialized
INFO - 2019-05-28 11:18:04 --> Router Class Initialized
INFO - 2019-05-28 11:18:04 --> Output Class Initialized
INFO - 2019-05-28 11:18:04 --> Security Class Initialized
DEBUG - 2019-05-28 11:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:18:04 --> Input Class Initialized
INFO - 2019-05-28 11:18:04 --> Language Class Initialized
ERROR - 2019-05-28 11:18:04 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:18:04 --> Config Class Initialized
INFO - 2019-05-28 11:18:04 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:18:04 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:18:04 --> Utf8 Class Initialized
INFO - 2019-05-28 11:18:04 --> URI Class Initialized
INFO - 2019-05-28 11:18:04 --> Router Class Initialized
INFO - 2019-05-28 11:18:04 --> Output Class Initialized
INFO - 2019-05-28 11:18:04 --> Security Class Initialized
DEBUG - 2019-05-28 11:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:18:04 --> Input Class Initialized
INFO - 2019-05-28 11:18:04 --> Language Class Initialized
ERROR - 2019-05-28 11:18:04 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:18:07 --> Config Class Initialized
INFO - 2019-05-28 11:18:07 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:18:07 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:18:07 --> Utf8 Class Initialized
INFO - 2019-05-28 11:18:07 --> URI Class Initialized
DEBUG - 2019-05-28 11:18:07 --> No URI present. Default controller set.
INFO - 2019-05-28 11:18:07 --> Router Class Initialized
INFO - 2019-05-28 11:18:07 --> Output Class Initialized
INFO - 2019-05-28 11:18:07 --> Security Class Initialized
DEBUG - 2019-05-28 11:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:18:07 --> Input Class Initialized
INFO - 2019-05-28 11:18:07 --> Language Class Initialized
INFO - 2019-05-28 11:18:07 --> Language Class Initialized
INFO - 2019-05-28 11:18:07 --> Config Class Initialized
INFO - 2019-05-28 11:18:07 --> Loader Class Initialized
INFO - 2019-05-28 11:18:07 --> Helper loaded: form_helper
INFO - 2019-05-28 11:18:07 --> Helper loaded: url_helper
INFO - 2019-05-28 11:18:07 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:18:07 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:18:07 --> Template library initialized
INFO - 2019-05-28 11:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:18:07 --> Controller Class Initialized
DEBUG - 2019-05-28 11:18:07 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:18:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:18:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:18:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:18:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:18:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:18:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:18:07 --> Config Class Initialized
INFO - 2019-05-28 11:18:07 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:18:07 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:18:07 --> Utf8 Class Initialized
INFO - 2019-05-28 11:18:07 --> URI Class Initialized
DEBUG - 2019-05-28 11:18:07 --> No URI present. Default controller set.
INFO - 2019-05-28 11:18:07 --> Router Class Initialized
INFO - 2019-05-28 11:18:07 --> Output Class Initialized
INFO - 2019-05-28 11:18:07 --> Security Class Initialized
DEBUG - 2019-05-28 11:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:18:07 --> Input Class Initialized
INFO - 2019-05-28 11:18:07 --> Language Class Initialized
INFO - 2019-05-28 11:18:07 --> Language Class Initialized
INFO - 2019-05-28 11:18:07 --> Config Class Initialized
INFO - 2019-05-28 11:18:07 --> Loader Class Initialized
INFO - 2019-05-28 11:18:07 --> Helper loaded: form_helper
INFO - 2019-05-28 11:18:07 --> Helper loaded: url_helper
INFO - 2019-05-28 11:18:07 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:18:07 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:18:07 --> Template library initialized
INFO - 2019-05-28 11:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:18:07 --> Controller Class Initialized
DEBUG - 2019-05-28 11:18:07 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:18:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:18:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:18:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:18:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:18:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:18:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:18:08 --> Final output sent to browser
DEBUG - 2019-05-28 11:18:08 --> Total execution time: 0.0452
INFO - 2019-05-28 11:18:10 --> Config Class Initialized
INFO - 2019-05-28 11:18:10 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:18:10 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:18:10 --> Utf8 Class Initialized
INFO - 2019-05-28 11:18:10 --> URI Class Initialized
INFO - 2019-05-28 11:18:10 --> Router Class Initialized
INFO - 2019-05-28 11:18:10 --> Output Class Initialized
INFO - 2019-05-28 11:18:10 --> Security Class Initialized
DEBUG - 2019-05-28 11:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:18:10 --> Input Class Initialized
INFO - 2019-05-28 11:18:10 --> Language Class Initialized
ERROR - 2019-05-28 11:18:10 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:18:11 --> Config Class Initialized
INFO - 2019-05-28 11:18:11 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:18:11 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:18:11 --> Utf8 Class Initialized
INFO - 2019-05-28 11:18:11 --> URI Class Initialized
INFO - 2019-05-28 11:18:11 --> Router Class Initialized
INFO - 2019-05-28 11:18:11 --> Output Class Initialized
INFO - 2019-05-28 11:18:11 --> Security Class Initialized
DEBUG - 2019-05-28 11:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:18:11 --> Input Class Initialized
INFO - 2019-05-28 11:18:11 --> Language Class Initialized
ERROR - 2019-05-28 11:18:11 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:18:11 --> Config Class Initialized
INFO - 2019-05-28 11:18:11 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:18:11 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:18:11 --> Utf8 Class Initialized
INFO - 2019-05-28 11:18:11 --> URI Class Initialized
INFO - 2019-05-28 11:18:11 --> Router Class Initialized
INFO - 2019-05-28 11:18:11 --> Output Class Initialized
INFO - 2019-05-28 11:18:11 --> Security Class Initialized
DEBUG - 2019-05-28 11:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:18:11 --> Input Class Initialized
INFO - 2019-05-28 11:18:11 --> Language Class Initialized
ERROR - 2019-05-28 11:18:11 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:18:12 --> Config Class Initialized
INFO - 2019-05-28 11:18:12 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:18:12 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:18:12 --> Utf8 Class Initialized
INFO - 2019-05-28 11:18:12 --> URI Class Initialized
INFO - 2019-05-28 11:18:12 --> Router Class Initialized
INFO - 2019-05-28 11:18:12 --> Output Class Initialized
INFO - 2019-05-28 11:18:12 --> Security Class Initialized
DEBUG - 2019-05-28 11:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:18:12 --> Input Class Initialized
INFO - 2019-05-28 11:18:12 --> Language Class Initialized
ERROR - 2019-05-28 11:18:12 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:26:22 --> Config Class Initialized
INFO - 2019-05-28 11:26:22 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:26:22 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:26:22 --> Utf8 Class Initialized
INFO - 2019-05-28 11:26:22 --> URI Class Initialized
DEBUG - 2019-05-28 11:26:22 --> No URI present. Default controller set.
INFO - 2019-05-28 11:26:22 --> Router Class Initialized
INFO - 2019-05-28 11:26:22 --> Output Class Initialized
INFO - 2019-05-28 11:26:22 --> Security Class Initialized
DEBUG - 2019-05-28 11:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:26:22 --> Input Class Initialized
INFO - 2019-05-28 11:26:22 --> Language Class Initialized
INFO - 2019-05-28 11:26:22 --> Language Class Initialized
INFO - 2019-05-28 11:26:22 --> Config Class Initialized
INFO - 2019-05-28 11:26:22 --> Loader Class Initialized
INFO - 2019-05-28 11:26:22 --> Helper loaded: form_helper
INFO - 2019-05-28 11:26:22 --> Helper loaded: url_helper
INFO - 2019-05-28 11:26:22 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:26:22 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:26:22 --> Template library initialized
INFO - 2019-05-28 11:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:26:22 --> Controller Class Initialized
DEBUG - 2019-05-28 11:26:22 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:26:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:26:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:26:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:26:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:26:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:26:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:26:22 --> Final output sent to browser
DEBUG - 2019-05-28 11:26:22 --> Total execution time: 0.0458
INFO - 2019-05-28 11:26:23 --> Config Class Initialized
INFO - 2019-05-28 11:26:23 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:26:23 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:26:23 --> Utf8 Class Initialized
INFO - 2019-05-28 11:26:23 --> URI Class Initialized
INFO - 2019-05-28 11:26:23 --> Router Class Initialized
INFO - 2019-05-28 11:26:23 --> Output Class Initialized
INFO - 2019-05-28 11:26:23 --> Security Class Initialized
DEBUG - 2019-05-28 11:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:26:23 --> Input Class Initialized
INFO - 2019-05-28 11:26:23 --> Language Class Initialized
ERROR - 2019-05-28 11:26:23 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:26:23 --> Config Class Initialized
INFO - 2019-05-28 11:26:23 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:26:23 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:26:23 --> Utf8 Class Initialized
INFO - 2019-05-28 11:26:23 --> URI Class Initialized
INFO - 2019-05-28 11:26:23 --> Config Class Initialized
INFO - 2019-05-28 11:26:23 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:26:23 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:26:23 --> Utf8 Class Initialized
INFO - 2019-05-28 11:26:23 --> URI Class Initialized
INFO - 2019-05-28 11:26:23 --> Router Class Initialized
INFO - 2019-05-28 11:26:23 --> Output Class Initialized
INFO - 2019-05-28 11:26:23 --> Security Class Initialized
DEBUG - 2019-05-28 11:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:26:23 --> Input Class Initialized
INFO - 2019-05-28 11:26:23 --> Language Class Initialized
ERROR - 2019-05-28 11:26:23 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:26:23 --> Router Class Initialized
INFO - 2019-05-28 11:26:23 --> Output Class Initialized
INFO - 2019-05-28 11:26:23 --> Security Class Initialized
DEBUG - 2019-05-28 11:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:26:23 --> Input Class Initialized
INFO - 2019-05-28 11:26:23 --> Language Class Initialized
ERROR - 2019-05-28 11:26:23 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:27:20 --> Config Class Initialized
INFO - 2019-05-28 11:27:20 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:27:20 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:27:20 --> Utf8 Class Initialized
INFO - 2019-05-28 11:27:20 --> URI Class Initialized
INFO - 2019-05-28 11:27:20 --> Router Class Initialized
INFO - 2019-05-28 11:27:20 --> Output Class Initialized
INFO - 2019-05-28 11:27:20 --> Security Class Initialized
DEBUG - 2019-05-28 11:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:27:20 --> Input Class Initialized
INFO - 2019-05-28 11:27:20 --> Language Class Initialized
ERROR - 2019-05-28 11:27:20 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:31:07 --> Config Class Initialized
INFO - 2019-05-28 11:31:07 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:31:07 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:31:07 --> Utf8 Class Initialized
INFO - 2019-05-28 11:31:07 --> URI Class Initialized
DEBUG - 2019-05-28 11:31:07 --> No URI present. Default controller set.
INFO - 2019-05-28 11:31:07 --> Router Class Initialized
INFO - 2019-05-28 11:31:07 --> Output Class Initialized
INFO - 2019-05-28 11:31:07 --> Security Class Initialized
DEBUG - 2019-05-28 11:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:31:07 --> Input Class Initialized
INFO - 2019-05-28 11:31:07 --> Language Class Initialized
INFO - 2019-05-28 11:31:07 --> Language Class Initialized
INFO - 2019-05-28 11:31:07 --> Config Class Initialized
INFO - 2019-05-28 11:31:07 --> Loader Class Initialized
INFO - 2019-05-28 11:31:07 --> Helper loaded: form_helper
INFO - 2019-05-28 11:31:07 --> Helper loaded: url_helper
INFO - 2019-05-28 11:31:07 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:31:07 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:31:07 --> Template library initialized
INFO - 2019-05-28 11:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:31:07 --> Controller Class Initialized
DEBUG - 2019-05-28 11:31:07 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:31:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:31:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:31:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:31:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:31:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:31:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:31:08 --> Config Class Initialized
INFO - 2019-05-28 11:31:08 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:31:08 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:31:08 --> Utf8 Class Initialized
INFO - 2019-05-28 11:31:08 --> URI Class Initialized
DEBUG - 2019-05-28 11:31:08 --> No URI present. Default controller set.
INFO - 2019-05-28 11:31:08 --> Router Class Initialized
INFO - 2019-05-28 11:31:08 --> Output Class Initialized
INFO - 2019-05-28 11:31:08 --> Security Class Initialized
DEBUG - 2019-05-28 11:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:31:08 --> Input Class Initialized
INFO - 2019-05-28 11:31:08 --> Language Class Initialized
INFO - 2019-05-28 11:31:08 --> Language Class Initialized
INFO - 2019-05-28 11:31:08 --> Config Class Initialized
INFO - 2019-05-28 11:31:08 --> Loader Class Initialized
INFO - 2019-05-28 11:31:08 --> Helper loaded: form_helper
INFO - 2019-05-28 11:31:08 --> Helper loaded: url_helper
INFO - 2019-05-28 11:31:08 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:31:08 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:31:08 --> Template library initialized
INFO - 2019-05-28 11:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:31:08 --> Controller Class Initialized
DEBUG - 2019-05-28 11:31:08 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:31:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:31:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:31:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:31:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:31:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:31:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:31:08 --> Final output sent to browser
DEBUG - 2019-05-28 11:31:08 --> Total execution time: 0.0453
INFO - 2019-05-28 11:31:10 --> Config Class Initialized
INFO - 2019-05-28 11:31:10 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:31:10 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:31:10 --> Utf8 Class Initialized
INFO - 2019-05-28 11:31:10 --> URI Class Initialized
INFO - 2019-05-28 11:31:10 --> Router Class Initialized
INFO - 2019-05-28 11:31:10 --> Output Class Initialized
INFO - 2019-05-28 11:31:10 --> Security Class Initialized
DEBUG - 2019-05-28 11:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:31:10 --> Input Class Initialized
INFO - 2019-05-28 11:31:10 --> Language Class Initialized
ERROR - 2019-05-28 11:31:10 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:31:10 --> Config Class Initialized
INFO - 2019-05-28 11:31:10 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:31:10 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:31:10 --> Utf8 Class Initialized
INFO - 2019-05-28 11:31:10 --> URI Class Initialized
INFO - 2019-05-28 11:31:10 --> Router Class Initialized
INFO - 2019-05-28 11:31:10 --> Output Class Initialized
INFO - 2019-05-28 11:31:10 --> Security Class Initialized
DEBUG - 2019-05-28 11:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:31:10 --> Input Class Initialized
INFO - 2019-05-28 11:31:10 --> Language Class Initialized
ERROR - 2019-05-28 11:31:10 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:31:12 --> Config Class Initialized
INFO - 2019-05-28 11:31:12 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:31:12 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:31:12 --> Utf8 Class Initialized
INFO - 2019-05-28 11:31:12 --> URI Class Initialized
DEBUG - 2019-05-28 11:31:12 --> No URI present. Default controller set.
INFO - 2019-05-28 11:31:12 --> Router Class Initialized
INFO - 2019-05-28 11:31:12 --> Output Class Initialized
INFO - 2019-05-28 11:31:12 --> Security Class Initialized
DEBUG - 2019-05-28 11:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:31:12 --> Input Class Initialized
INFO - 2019-05-28 11:31:12 --> Language Class Initialized
INFO - 2019-05-28 11:31:12 --> Language Class Initialized
INFO - 2019-05-28 11:31:12 --> Config Class Initialized
INFO - 2019-05-28 11:31:12 --> Loader Class Initialized
INFO - 2019-05-28 11:31:12 --> Helper loaded: form_helper
INFO - 2019-05-28 11:31:12 --> Helper loaded: url_helper
INFO - 2019-05-28 11:31:12 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:31:12 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:31:12 --> Template library initialized
INFO - 2019-05-28 11:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:31:12 --> Controller Class Initialized
DEBUG - 2019-05-28 11:31:12 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:31:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:31:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:31:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:31:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:31:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:31:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:31:12 --> Final output sent to browser
DEBUG - 2019-05-28 11:31:12 --> Total execution time: 0.0456
INFO - 2019-05-28 11:31:13 --> Config Class Initialized
INFO - 2019-05-28 11:31:13 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:31:13 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:31:13 --> Utf8 Class Initialized
INFO - 2019-05-28 11:31:13 --> URI Class Initialized
INFO - 2019-05-28 11:31:13 --> Router Class Initialized
INFO - 2019-05-28 11:31:13 --> Output Class Initialized
INFO - 2019-05-28 11:31:13 --> Security Class Initialized
DEBUG - 2019-05-28 11:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:31:13 --> Input Class Initialized
INFO - 2019-05-28 11:31:13 --> Language Class Initialized
ERROR - 2019-05-28 11:31:13 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:31:13 --> Config Class Initialized
INFO - 2019-05-28 11:31:13 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:31:13 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:31:13 --> Utf8 Class Initialized
INFO - 2019-05-28 11:31:13 --> URI Class Initialized
INFO - 2019-05-28 11:31:13 --> Router Class Initialized
INFO - 2019-05-28 11:31:13 --> Output Class Initialized
INFO - 2019-05-28 11:31:13 --> Security Class Initialized
DEBUG - 2019-05-28 11:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:31:13 --> Input Class Initialized
INFO - 2019-05-28 11:31:13 --> Language Class Initialized
ERROR - 2019-05-28 11:31:13 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:31:14 --> Config Class Initialized
INFO - 2019-05-28 11:31:14 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:31:14 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:31:14 --> Utf8 Class Initialized
INFO - 2019-05-28 11:31:14 --> URI Class Initialized
INFO - 2019-05-28 11:31:14 --> Router Class Initialized
INFO - 2019-05-28 11:31:14 --> Output Class Initialized
INFO - 2019-05-28 11:31:14 --> Security Class Initialized
DEBUG - 2019-05-28 11:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:31:14 --> Input Class Initialized
INFO - 2019-05-28 11:31:14 --> Language Class Initialized
ERROR - 2019-05-28 11:31:14 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:31:15 --> Config Class Initialized
INFO - 2019-05-28 11:31:15 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:31:15 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:31:15 --> Utf8 Class Initialized
INFO - 2019-05-28 11:31:15 --> URI Class Initialized
INFO - 2019-05-28 11:31:15 --> Router Class Initialized
INFO - 2019-05-28 11:31:15 --> Output Class Initialized
INFO - 2019-05-28 11:31:15 --> Security Class Initialized
DEBUG - 2019-05-28 11:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:31:15 --> Input Class Initialized
INFO - 2019-05-28 11:31:15 --> Language Class Initialized
ERROR - 2019-05-28 11:31:15 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:31:18 --> Config Class Initialized
INFO - 2019-05-28 11:31:18 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:31:18 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:31:18 --> Utf8 Class Initialized
INFO - 2019-05-28 11:31:18 --> URI Class Initialized
DEBUG - 2019-05-28 11:31:18 --> No URI present. Default controller set.
INFO - 2019-05-28 11:31:18 --> Router Class Initialized
INFO - 2019-05-28 11:31:18 --> Output Class Initialized
INFO - 2019-05-28 11:31:18 --> Security Class Initialized
DEBUG - 2019-05-28 11:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:31:18 --> Input Class Initialized
INFO - 2019-05-28 11:31:18 --> Language Class Initialized
INFO - 2019-05-28 11:31:18 --> Language Class Initialized
INFO - 2019-05-28 11:31:18 --> Config Class Initialized
INFO - 2019-05-28 11:31:18 --> Loader Class Initialized
INFO - 2019-05-28 11:31:18 --> Helper loaded: form_helper
INFO - 2019-05-28 11:31:18 --> Helper loaded: url_helper
INFO - 2019-05-28 11:31:18 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:31:18 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:31:18 --> Template library initialized
INFO - 2019-05-28 11:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:31:18 --> Controller Class Initialized
DEBUG - 2019-05-28 11:31:18 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:31:18 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:31:18 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:31:18 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:31:18 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:31:18 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:31:18 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:31:18 --> Final output sent to browser
DEBUG - 2019-05-28 11:31:18 --> Total execution time: 0.0483
INFO - 2019-05-28 11:31:19 --> Config Class Initialized
INFO - 2019-05-28 11:31:19 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:31:19 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:31:19 --> Utf8 Class Initialized
INFO - 2019-05-28 11:31:19 --> URI Class Initialized
INFO - 2019-05-28 11:31:19 --> Router Class Initialized
INFO - 2019-05-28 11:31:19 --> Output Class Initialized
INFO - 2019-05-28 11:31:19 --> Security Class Initialized
DEBUG - 2019-05-28 11:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:31:19 --> Input Class Initialized
INFO - 2019-05-28 11:31:19 --> Language Class Initialized
ERROR - 2019-05-28 11:31:19 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:31:19 --> Config Class Initialized
INFO - 2019-05-28 11:31:19 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:31:19 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:31:19 --> Utf8 Class Initialized
INFO - 2019-05-28 11:31:19 --> URI Class Initialized
INFO - 2019-05-28 11:31:19 --> Router Class Initialized
INFO - 2019-05-28 11:31:19 --> Output Class Initialized
INFO - 2019-05-28 11:31:19 --> Security Class Initialized
DEBUG - 2019-05-28 11:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:31:19 --> Input Class Initialized
INFO - 2019-05-28 11:31:19 --> Language Class Initialized
ERROR - 2019-05-28 11:31:19 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:31:19 --> Config Class Initialized
INFO - 2019-05-28 11:31:19 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:31:19 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:31:19 --> Utf8 Class Initialized
INFO - 2019-05-28 11:31:19 --> URI Class Initialized
INFO - 2019-05-28 11:31:19 --> Router Class Initialized
INFO - 2019-05-28 11:31:19 --> Output Class Initialized
INFO - 2019-05-28 11:31:19 --> Security Class Initialized
DEBUG - 2019-05-28 11:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:31:19 --> Input Class Initialized
INFO - 2019-05-28 11:31:19 --> Language Class Initialized
ERROR - 2019-05-28 11:31:19 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:31:21 --> Config Class Initialized
INFO - 2019-05-28 11:31:21 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:31:21 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:31:21 --> Utf8 Class Initialized
INFO - 2019-05-28 11:31:21 --> URI Class Initialized
INFO - 2019-05-28 11:31:21 --> Router Class Initialized
INFO - 2019-05-28 11:31:21 --> Output Class Initialized
INFO - 2019-05-28 11:31:21 --> Security Class Initialized
DEBUG - 2019-05-28 11:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:31:21 --> Input Class Initialized
INFO - 2019-05-28 11:31:21 --> Language Class Initialized
ERROR - 2019-05-28 11:31:21 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:32:25 --> Config Class Initialized
INFO - 2019-05-28 11:32:25 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:32:25 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:32:25 --> Utf8 Class Initialized
INFO - 2019-05-28 11:32:25 --> URI Class Initialized
DEBUG - 2019-05-28 11:32:25 --> No URI present. Default controller set.
INFO - 2019-05-28 11:32:25 --> Router Class Initialized
INFO - 2019-05-28 11:32:25 --> Output Class Initialized
INFO - 2019-05-28 11:32:25 --> Security Class Initialized
DEBUG - 2019-05-28 11:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:32:25 --> Input Class Initialized
INFO - 2019-05-28 11:32:25 --> Language Class Initialized
INFO - 2019-05-28 11:32:25 --> Language Class Initialized
INFO - 2019-05-28 11:32:25 --> Config Class Initialized
INFO - 2019-05-28 11:32:25 --> Loader Class Initialized
INFO - 2019-05-28 11:32:25 --> Helper loaded: form_helper
INFO - 2019-05-28 11:32:25 --> Helper loaded: url_helper
INFO - 2019-05-28 11:32:25 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:32:25 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:32:25 --> Template library initialized
INFO - 2019-05-28 11:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:32:25 --> Controller Class Initialized
DEBUG - 2019-05-28 11:32:25 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:32:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:32:25 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
ERROR - 2019-05-28 11:32:25 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php 42
INFO - 2019-05-28 11:32:26 --> Config Class Initialized
INFO - 2019-05-28 11:32:26 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:32:26 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:32:26 --> Utf8 Class Initialized
INFO - 2019-05-28 11:32:26 --> URI Class Initialized
INFO - 2019-05-28 11:32:26 --> Router Class Initialized
INFO - 2019-05-28 11:32:26 --> Output Class Initialized
INFO - 2019-05-28 11:32:26 --> Security Class Initialized
DEBUG - 2019-05-28 11:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:32:26 --> Input Class Initialized
INFO - 2019-05-28 11:32:26 --> Language Class Initialized
ERROR - 2019-05-28 11:32:26 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:32:28 --> Config Class Initialized
INFO - 2019-05-28 11:32:28 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:32:28 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:32:28 --> Utf8 Class Initialized
INFO - 2019-05-28 11:32:28 --> URI Class Initialized
DEBUG - 2019-05-28 11:32:28 --> No URI present. Default controller set.
INFO - 2019-05-28 11:32:28 --> Router Class Initialized
INFO - 2019-05-28 11:32:28 --> Output Class Initialized
INFO - 2019-05-28 11:32:28 --> Security Class Initialized
DEBUG - 2019-05-28 11:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:32:28 --> Input Class Initialized
INFO - 2019-05-28 11:32:28 --> Language Class Initialized
INFO - 2019-05-28 11:32:28 --> Language Class Initialized
INFO - 2019-05-28 11:32:28 --> Config Class Initialized
INFO - 2019-05-28 11:32:28 --> Loader Class Initialized
INFO - 2019-05-28 11:32:28 --> Helper loaded: form_helper
INFO - 2019-05-28 11:32:28 --> Helper loaded: url_helper
INFO - 2019-05-28 11:32:28 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:32:28 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:32:28 --> Template library initialized
INFO - 2019-05-28 11:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:32:28 --> Controller Class Initialized
DEBUG - 2019-05-28 11:32:28 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:32:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:32:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:32:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:32:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:32:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:32:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:32:29 --> Final output sent to browser
DEBUG - 2019-05-28 11:32:29 --> Total execution time: 0.0453
INFO - 2019-05-28 11:32:30 --> Config Class Initialized
INFO - 2019-05-28 11:32:30 --> Hooks Class Initialized
INFO - 2019-05-28 11:32:30 --> Config Class Initialized
INFO - 2019-05-28 11:32:30 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:32:30 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:32:30 --> Utf8 Class Initialized
INFO - 2019-05-28 11:32:30 --> URI Class Initialized
INFO - 2019-05-28 11:32:30 --> Router Class Initialized
DEBUG - 2019-05-28 11:32:30 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:32:30 --> Utf8 Class Initialized
INFO - 2019-05-28 11:32:30 --> URI Class Initialized
INFO - 2019-05-28 11:32:30 --> Router Class Initialized
INFO - 2019-05-28 11:32:30 --> Output Class Initialized
INFO - 2019-05-28 11:32:30 --> Security Class Initialized
DEBUG - 2019-05-28 11:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:32:30 --> Input Class Initialized
INFO - 2019-05-28 11:32:30 --> Language Class Initialized
ERROR - 2019-05-28 11:32:30 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:32:30 --> Output Class Initialized
INFO - 2019-05-28 11:32:30 --> Security Class Initialized
DEBUG - 2019-05-28 11:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:32:30 --> Input Class Initialized
INFO - 2019-05-28 11:32:30 --> Language Class Initialized
ERROR - 2019-05-28 11:32:30 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:32:30 --> Config Class Initialized
INFO - 2019-05-28 11:32:30 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:32:30 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:32:30 --> Utf8 Class Initialized
INFO - 2019-05-28 11:32:30 --> URI Class Initialized
INFO - 2019-05-28 11:32:30 --> Router Class Initialized
INFO - 2019-05-28 11:32:30 --> Output Class Initialized
INFO - 2019-05-28 11:32:30 --> Security Class Initialized
DEBUG - 2019-05-28 11:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:32:30 --> Input Class Initialized
INFO - 2019-05-28 11:32:30 --> Language Class Initialized
ERROR - 2019-05-28 11:32:30 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:32:33 --> Config Class Initialized
INFO - 2019-05-28 11:32:33 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:32:33 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:32:33 --> Utf8 Class Initialized
INFO - 2019-05-28 11:32:33 --> URI Class Initialized
INFO - 2019-05-28 11:32:33 --> Router Class Initialized
INFO - 2019-05-28 11:32:33 --> Output Class Initialized
INFO - 2019-05-28 11:32:33 --> Security Class Initialized
DEBUG - 2019-05-28 11:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:32:33 --> Input Class Initialized
INFO - 2019-05-28 11:32:33 --> Language Class Initialized
ERROR - 2019-05-28 11:32:33 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:32:52 --> Config Class Initialized
INFO - 2019-05-28 11:32:52 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:32:52 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:32:52 --> Utf8 Class Initialized
INFO - 2019-05-28 11:32:52 --> URI Class Initialized
DEBUG - 2019-05-28 11:32:52 --> No URI present. Default controller set.
INFO - 2019-05-28 11:32:52 --> Router Class Initialized
INFO - 2019-05-28 11:32:52 --> Output Class Initialized
INFO - 2019-05-28 11:32:52 --> Security Class Initialized
DEBUG - 2019-05-28 11:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:32:52 --> Input Class Initialized
INFO - 2019-05-28 11:32:52 --> Language Class Initialized
INFO - 2019-05-28 11:32:52 --> Language Class Initialized
INFO - 2019-05-28 11:32:52 --> Config Class Initialized
INFO - 2019-05-28 11:32:52 --> Loader Class Initialized
INFO - 2019-05-28 11:32:52 --> Helper loaded: form_helper
INFO - 2019-05-28 11:32:52 --> Helper loaded: url_helper
INFO - 2019-05-28 11:32:52 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:32:52 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:32:52 --> Template library initialized
INFO - 2019-05-28 11:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:32:52 --> Controller Class Initialized
DEBUG - 2019-05-28 11:32:52 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:32:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:32:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:32:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:32:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:32:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:32:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:32:52 --> Final output sent to browser
DEBUG - 2019-05-28 11:32:52 --> Total execution time: 0.0517
INFO - 2019-05-28 11:32:53 --> Config Class Initialized
INFO - 2019-05-28 11:32:53 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:32:53 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:32:53 --> Utf8 Class Initialized
INFO - 2019-05-28 11:32:53 --> URI Class Initialized
INFO - 2019-05-28 11:32:53 --> Router Class Initialized
INFO - 2019-05-28 11:32:53 --> Output Class Initialized
INFO - 2019-05-28 11:32:53 --> Security Class Initialized
DEBUG - 2019-05-28 11:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:32:53 --> Input Class Initialized
INFO - 2019-05-28 11:32:53 --> Language Class Initialized
ERROR - 2019-05-28 11:32:53 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:32:53 --> Config Class Initialized
INFO - 2019-05-28 11:32:53 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:32:53 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:32:53 --> Utf8 Class Initialized
INFO - 2019-05-28 11:32:53 --> URI Class Initialized
INFO - 2019-05-28 11:32:53 --> Router Class Initialized
INFO - 2019-05-28 11:32:53 --> Output Class Initialized
INFO - 2019-05-28 11:32:53 --> Security Class Initialized
DEBUG - 2019-05-28 11:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:32:53 --> Input Class Initialized
INFO - 2019-05-28 11:32:53 --> Language Class Initialized
ERROR - 2019-05-28 11:32:53 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:32:53 --> Config Class Initialized
INFO - 2019-05-28 11:32:53 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:32:53 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:32:53 --> Utf8 Class Initialized
INFO - 2019-05-28 11:32:53 --> URI Class Initialized
INFO - 2019-05-28 11:32:53 --> Router Class Initialized
INFO - 2019-05-28 11:32:53 --> Output Class Initialized
INFO - 2019-05-28 11:32:53 --> Security Class Initialized
DEBUG - 2019-05-28 11:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:32:53 --> Input Class Initialized
INFO - 2019-05-28 11:32:53 --> Language Class Initialized
ERROR - 2019-05-28 11:32:53 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:34:10 --> Config Class Initialized
INFO - 2019-05-28 11:34:10 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:34:10 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:34:10 --> Utf8 Class Initialized
INFO - 2019-05-28 11:34:10 --> URI Class Initialized
DEBUG - 2019-05-28 11:34:10 --> No URI present. Default controller set.
INFO - 2019-05-28 11:34:10 --> Router Class Initialized
INFO - 2019-05-28 11:34:10 --> Output Class Initialized
INFO - 2019-05-28 11:34:10 --> Security Class Initialized
DEBUG - 2019-05-28 11:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:34:10 --> Input Class Initialized
INFO - 2019-05-28 11:34:10 --> Language Class Initialized
INFO - 2019-05-28 11:34:10 --> Language Class Initialized
INFO - 2019-05-28 11:34:10 --> Config Class Initialized
INFO - 2019-05-28 11:34:11 --> Loader Class Initialized
INFO - 2019-05-28 11:34:11 --> Helper loaded: form_helper
INFO - 2019-05-28 11:34:11 --> Helper loaded: url_helper
INFO - 2019-05-28 11:34:11 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:34:11 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:34:11 --> Template library initialized
INFO - 2019-05-28 11:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:34:11 --> Controller Class Initialized
DEBUG - 2019-05-28 11:34:11 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:34:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:34:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:34:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:34:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:34:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:34:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:34:11 --> Final output sent to browser
DEBUG - 2019-05-28 11:34:11 --> Total execution time: 0.0468
INFO - 2019-05-28 11:34:12 --> Config Class Initialized
INFO - 2019-05-28 11:34:12 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:34:12 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:34:12 --> Utf8 Class Initialized
INFO - 2019-05-28 11:34:12 --> URI Class Initialized
INFO - 2019-05-28 11:34:12 --> Router Class Initialized
INFO - 2019-05-28 11:34:12 --> Output Class Initialized
INFO - 2019-05-28 11:34:12 --> Security Class Initialized
DEBUG - 2019-05-28 11:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:34:12 --> Input Class Initialized
INFO - 2019-05-28 11:34:12 --> Language Class Initialized
ERROR - 2019-05-28 11:34:12 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:34:12 --> Config Class Initialized
INFO - 2019-05-28 11:34:12 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:34:12 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:34:12 --> Utf8 Class Initialized
INFO - 2019-05-28 11:34:12 --> URI Class Initialized
INFO - 2019-05-28 11:34:12 --> Router Class Initialized
INFO - 2019-05-28 11:34:12 --> Output Class Initialized
INFO - 2019-05-28 11:34:12 --> Security Class Initialized
DEBUG - 2019-05-28 11:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:34:12 --> Input Class Initialized
INFO - 2019-05-28 11:34:12 --> Language Class Initialized
INFO - 2019-05-28 11:34:12 --> Config Class Initialized
INFO - 2019-05-28 11:34:12 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:34:12 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:34:12 --> Utf8 Class Initialized
INFO - 2019-05-28 11:34:12 --> URI Class Initialized
ERROR - 2019-05-28 11:34:12 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:34:12 --> Router Class Initialized
INFO - 2019-05-28 11:34:12 --> Output Class Initialized
INFO - 2019-05-28 11:34:12 --> Security Class Initialized
DEBUG - 2019-05-28 11:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:34:12 --> Input Class Initialized
INFO - 2019-05-28 11:34:12 --> Language Class Initialized
ERROR - 2019-05-28 11:34:12 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:34:15 --> Config Class Initialized
INFO - 2019-05-28 11:34:15 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:34:15 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:34:15 --> Utf8 Class Initialized
INFO - 2019-05-28 11:34:15 --> URI Class Initialized
INFO - 2019-05-28 11:34:15 --> Router Class Initialized
INFO - 2019-05-28 11:34:15 --> Output Class Initialized
INFO - 2019-05-28 11:34:15 --> Security Class Initialized
DEBUG - 2019-05-28 11:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:34:15 --> Input Class Initialized
INFO - 2019-05-28 11:34:15 --> Language Class Initialized
ERROR - 2019-05-28 11:34:15 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:34:16 --> Config Class Initialized
INFO - 2019-05-28 11:34:16 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:34:16 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:34:16 --> Utf8 Class Initialized
INFO - 2019-05-28 11:34:16 --> URI Class Initialized
INFO - 2019-05-28 11:34:16 --> Router Class Initialized
INFO - 2019-05-28 11:34:16 --> Output Class Initialized
INFO - 2019-05-28 11:34:16 --> Security Class Initialized
DEBUG - 2019-05-28 11:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:34:16 --> Input Class Initialized
INFO - 2019-05-28 11:34:16 --> Language Class Initialized
ERROR - 2019-05-28 11:34:16 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:36:44 --> Config Class Initialized
INFO - 2019-05-28 11:36:44 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:36:44 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:36:44 --> Utf8 Class Initialized
INFO - 2019-05-28 11:36:44 --> URI Class Initialized
INFO - 2019-05-28 11:36:44 --> Router Class Initialized
INFO - 2019-05-28 11:36:44 --> Output Class Initialized
INFO - 2019-05-28 11:36:44 --> Security Class Initialized
DEBUG - 2019-05-28 11:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:36:44 --> Input Class Initialized
INFO - 2019-05-28 11:36:44 --> Language Class Initialized
ERROR - 2019-05-28 11:36:44 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:36:44 --> Config Class Initialized
INFO - 2019-05-28 11:36:44 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:36:44 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:36:44 --> Utf8 Class Initialized
INFO - 2019-05-28 11:36:44 --> URI Class Initialized
INFO - 2019-05-28 11:36:44 --> Router Class Initialized
INFO - 2019-05-28 11:36:44 --> Output Class Initialized
INFO - 2019-05-28 11:36:44 --> Security Class Initialized
DEBUG - 2019-05-28 11:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:36:44 --> Input Class Initialized
INFO - 2019-05-28 11:36:44 --> Language Class Initialized
ERROR - 2019-05-28 11:36:44 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:36:46 --> Config Class Initialized
INFO - 2019-05-28 11:36:46 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:36:46 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:36:46 --> Utf8 Class Initialized
INFO - 2019-05-28 11:36:46 --> URI Class Initialized
DEBUG - 2019-05-28 11:36:46 --> No URI present. Default controller set.
INFO - 2019-05-28 11:36:46 --> Router Class Initialized
INFO - 2019-05-28 11:36:46 --> Output Class Initialized
INFO - 2019-05-28 11:36:46 --> Security Class Initialized
DEBUG - 2019-05-28 11:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:36:46 --> Input Class Initialized
INFO - 2019-05-28 11:36:46 --> Language Class Initialized
INFO - 2019-05-28 11:36:46 --> Language Class Initialized
INFO - 2019-05-28 11:36:46 --> Config Class Initialized
INFO - 2019-05-28 11:36:46 --> Loader Class Initialized
INFO - 2019-05-28 11:36:46 --> Helper loaded: form_helper
INFO - 2019-05-28 11:36:46 --> Helper loaded: url_helper
INFO - 2019-05-28 11:36:46 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:36:46 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:36:46 --> Template library initialized
INFO - 2019-05-28 11:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:36:46 --> Controller Class Initialized
DEBUG - 2019-05-28 11:36:46 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:36:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:36:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:36:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:36:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:36:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:36:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:36:47 --> Final output sent to browser
DEBUG - 2019-05-28 11:36:47 --> Total execution time: 0.0479
INFO - 2019-05-28 11:39:03 --> Config Class Initialized
INFO - 2019-05-28 11:39:03 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:39:03 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:39:03 --> Utf8 Class Initialized
INFO - 2019-05-28 11:39:03 --> URI Class Initialized
DEBUG - 2019-05-28 11:39:03 --> No URI present. Default controller set.
INFO - 2019-05-28 11:39:03 --> Router Class Initialized
INFO - 2019-05-28 11:39:03 --> Output Class Initialized
INFO - 2019-05-28 11:39:03 --> Security Class Initialized
DEBUG - 2019-05-28 11:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:39:03 --> Input Class Initialized
INFO - 2019-05-28 11:39:03 --> Language Class Initialized
INFO - 2019-05-28 11:39:03 --> Language Class Initialized
INFO - 2019-05-28 11:39:03 --> Config Class Initialized
INFO - 2019-05-28 11:39:03 --> Loader Class Initialized
INFO - 2019-05-28 11:39:03 --> Helper loaded: form_helper
INFO - 2019-05-28 11:39:03 --> Helper loaded: url_helper
INFO - 2019-05-28 11:39:03 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:39:03 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:39:03 --> Template library initialized
INFO - 2019-05-28 11:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:39:03 --> Controller Class Initialized
DEBUG - 2019-05-28 11:39:03 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:39:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:39:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:39:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:39:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:39:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:39:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:39:04 --> Final output sent to browser
DEBUG - 2019-05-28 11:39:04 --> Total execution time: 0.0449
INFO - 2019-05-28 11:39:05 --> Config Class Initialized
INFO - 2019-05-28 11:39:05 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:39:05 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:39:05 --> Utf8 Class Initialized
INFO - 2019-05-28 11:39:05 --> URI Class Initialized
INFO - 2019-05-28 11:39:05 --> Router Class Initialized
INFO - 2019-05-28 11:39:05 --> Output Class Initialized
INFO - 2019-05-28 11:39:05 --> Security Class Initialized
DEBUG - 2019-05-28 11:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:39:05 --> Input Class Initialized
INFO - 2019-05-28 11:39:05 --> Language Class Initialized
ERROR - 2019-05-28 11:39:05 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:39:05 --> Config Class Initialized
INFO - 2019-05-28 11:39:05 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:39:05 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:39:05 --> Utf8 Class Initialized
INFO - 2019-05-28 11:39:05 --> URI Class Initialized
INFO - 2019-05-28 11:39:05 --> Router Class Initialized
INFO - 2019-05-28 11:39:05 --> Output Class Initialized
INFO - 2019-05-28 11:39:05 --> Security Class Initialized
DEBUG - 2019-05-28 11:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:39:05 --> Input Class Initialized
INFO - 2019-05-28 11:39:05 --> Language Class Initialized
ERROR - 2019-05-28 11:39:05 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:39:05 --> Config Class Initialized
INFO - 2019-05-28 11:39:05 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:39:05 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:39:05 --> Utf8 Class Initialized
INFO - 2019-05-28 11:39:05 --> URI Class Initialized
INFO - 2019-05-28 11:39:05 --> Router Class Initialized
INFO - 2019-05-28 11:39:05 --> Output Class Initialized
INFO - 2019-05-28 11:39:05 --> Security Class Initialized
DEBUG - 2019-05-28 11:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:39:05 --> Input Class Initialized
INFO - 2019-05-28 11:39:05 --> Language Class Initialized
ERROR - 2019-05-28 11:39:05 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:39:34 --> Config Class Initialized
INFO - 2019-05-28 11:39:34 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:39:34 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:39:34 --> Utf8 Class Initialized
INFO - 2019-05-28 11:39:34 --> URI Class Initialized
DEBUG - 2019-05-28 11:39:34 --> No URI present. Default controller set.
INFO - 2019-05-28 11:39:34 --> Router Class Initialized
INFO - 2019-05-28 11:39:34 --> Output Class Initialized
INFO - 2019-05-28 11:39:34 --> Security Class Initialized
DEBUG - 2019-05-28 11:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:39:34 --> Input Class Initialized
INFO - 2019-05-28 11:39:34 --> Language Class Initialized
INFO - 2019-05-28 11:39:34 --> Language Class Initialized
INFO - 2019-05-28 11:39:34 --> Config Class Initialized
INFO - 2019-05-28 11:39:34 --> Loader Class Initialized
INFO - 2019-05-28 11:39:34 --> Helper loaded: form_helper
INFO - 2019-05-28 11:39:34 --> Helper loaded: url_helper
INFO - 2019-05-28 11:39:34 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:39:34 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:39:34 --> Template library initialized
INFO - 2019-05-28 11:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:39:34 --> Controller Class Initialized
DEBUG - 2019-05-28 11:39:34 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:39:34 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:39:34 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:39:34 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:39:34 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:39:34 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:39:34 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:39:34 --> Final output sent to browser
DEBUG - 2019-05-28 11:39:34 --> Total execution time: 0.0530
INFO - 2019-05-28 11:39:35 --> Config Class Initialized
INFO - 2019-05-28 11:39:35 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:39:35 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:39:35 --> Utf8 Class Initialized
INFO - 2019-05-28 11:39:35 --> URI Class Initialized
INFO - 2019-05-28 11:39:35 --> Config Class Initialized
INFO - 2019-05-28 11:39:35 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:39:35 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:39:35 --> Utf8 Class Initialized
INFO - 2019-05-28 11:39:35 --> URI Class Initialized
INFO - 2019-05-28 11:39:35 --> Router Class Initialized
INFO - 2019-05-28 11:39:35 --> Config Class Initialized
INFO - 2019-05-28 11:39:35 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:39:35 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:39:35 --> Utf8 Class Initialized
INFO - 2019-05-28 11:39:35 --> URI Class Initialized
INFO - 2019-05-28 11:39:35 --> Router Class Initialized
INFO - 2019-05-28 11:39:35 --> Router Class Initialized
INFO - 2019-05-28 11:39:35 --> Output Class Initialized
INFO - 2019-05-28 11:39:35 --> Security Class Initialized
DEBUG - 2019-05-28 11:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:39:35 --> Input Class Initialized
INFO - 2019-05-28 11:39:35 --> Language Class Initialized
ERROR - 2019-05-28 11:39:35 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:39:35 --> Output Class Initialized
INFO - 2019-05-28 11:39:35 --> Security Class Initialized
DEBUG - 2019-05-28 11:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:39:35 --> Input Class Initialized
INFO - 2019-05-28 11:39:35 --> Language Class Initialized
ERROR - 2019-05-28 11:39:35 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:39:35 --> Output Class Initialized
INFO - 2019-05-28 11:39:35 --> Security Class Initialized
DEBUG - 2019-05-28 11:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:39:35 --> Input Class Initialized
INFO - 2019-05-28 11:39:35 --> Language Class Initialized
ERROR - 2019-05-28 11:39:35 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:39:39 --> Config Class Initialized
INFO - 2019-05-28 11:39:39 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:39:39 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:39:39 --> Utf8 Class Initialized
INFO - 2019-05-28 11:39:39 --> URI Class Initialized
DEBUG - 2019-05-28 11:39:39 --> No URI present. Default controller set.
INFO - 2019-05-28 11:39:39 --> Router Class Initialized
INFO - 2019-05-28 11:39:39 --> Output Class Initialized
INFO - 2019-05-28 11:39:39 --> Security Class Initialized
DEBUG - 2019-05-28 11:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:39:39 --> Input Class Initialized
INFO - 2019-05-28 11:39:39 --> Language Class Initialized
INFO - 2019-05-28 11:39:39 --> Language Class Initialized
INFO - 2019-05-28 11:39:39 --> Config Class Initialized
INFO - 2019-05-28 11:39:39 --> Loader Class Initialized
INFO - 2019-05-28 11:39:39 --> Helper loaded: form_helper
INFO - 2019-05-28 11:39:39 --> Helper loaded: url_helper
INFO - 2019-05-28 11:39:39 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:39:39 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:39:39 --> Template library initialized
INFO - 2019-05-28 11:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:39:39 --> Controller Class Initialized
DEBUG - 2019-05-28 11:39:39 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:39:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:39:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:39:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:39:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:39:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:39:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:39:39 --> Final output sent to browser
DEBUG - 2019-05-28 11:39:39 --> Total execution time: 0.0451
INFO - 2019-05-28 11:39:40 --> Config Class Initialized
INFO - 2019-05-28 11:39:40 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:39:40 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:39:40 --> Utf8 Class Initialized
INFO - 2019-05-28 11:39:40 --> URI Class Initialized
INFO - 2019-05-28 11:39:40 --> Router Class Initialized
INFO - 2019-05-28 11:39:40 --> Output Class Initialized
INFO - 2019-05-28 11:39:40 --> Security Class Initialized
DEBUG - 2019-05-28 11:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:39:40 --> Input Class Initialized
INFO - 2019-05-28 11:39:40 --> Language Class Initialized
ERROR - 2019-05-28 11:39:40 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:39:40 --> Config Class Initialized
INFO - 2019-05-28 11:39:40 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:39:40 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:39:40 --> Utf8 Class Initialized
INFO - 2019-05-28 11:39:40 --> URI Class Initialized
INFO - 2019-05-28 11:39:40 --> Router Class Initialized
INFO - 2019-05-28 11:39:40 --> Config Class Initialized
INFO - 2019-05-28 11:39:40 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:39:40 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:39:40 --> Utf8 Class Initialized
INFO - 2019-05-28 11:39:40 --> URI Class Initialized
INFO - 2019-05-28 11:39:40 --> Router Class Initialized
INFO - 2019-05-28 11:39:40 --> Output Class Initialized
INFO - 2019-05-28 11:39:40 --> Security Class Initialized
DEBUG - 2019-05-28 11:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:39:40 --> Input Class Initialized
INFO - 2019-05-28 11:39:40 --> Language Class Initialized
ERROR - 2019-05-28 11:39:40 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:39:40 --> Output Class Initialized
INFO - 2019-05-28 11:39:40 --> Security Class Initialized
DEBUG - 2019-05-28 11:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:39:40 --> Input Class Initialized
INFO - 2019-05-28 11:39:40 --> Language Class Initialized
ERROR - 2019-05-28 11:39:40 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:40:07 --> Config Class Initialized
INFO - 2019-05-28 11:40:07 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:40:07 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:40:07 --> Utf8 Class Initialized
INFO - 2019-05-28 11:40:07 --> URI Class Initialized
DEBUG - 2019-05-28 11:40:07 --> No URI present. Default controller set.
INFO - 2019-05-28 11:40:07 --> Router Class Initialized
INFO - 2019-05-28 11:40:07 --> Output Class Initialized
INFO - 2019-05-28 11:40:07 --> Security Class Initialized
DEBUG - 2019-05-28 11:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:40:07 --> Input Class Initialized
INFO - 2019-05-28 11:40:07 --> Language Class Initialized
INFO - 2019-05-28 11:40:07 --> Language Class Initialized
INFO - 2019-05-28 11:40:07 --> Config Class Initialized
INFO - 2019-05-28 11:40:07 --> Loader Class Initialized
INFO - 2019-05-28 11:40:07 --> Helper loaded: form_helper
INFO - 2019-05-28 11:40:07 --> Helper loaded: url_helper
INFO - 2019-05-28 11:40:07 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:40:07 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:40:07 --> Template library initialized
INFO - 2019-05-28 11:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:40:07 --> Controller Class Initialized
DEBUG - 2019-05-28 11:40:07 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:40:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:40:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:40:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:40:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:40:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:40:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:40:07 --> Final output sent to browser
DEBUG - 2019-05-28 11:40:07 --> Total execution time: 0.0490
INFO - 2019-05-28 11:40:09 --> Config Class Initialized
INFO - 2019-05-28 11:40:09 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:40:09 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:40:09 --> Utf8 Class Initialized
INFO - 2019-05-28 11:40:09 --> URI Class Initialized
INFO - 2019-05-28 11:40:09 --> Router Class Initialized
INFO - 2019-05-28 11:40:09 --> Output Class Initialized
INFO - 2019-05-28 11:40:09 --> Security Class Initialized
DEBUG - 2019-05-28 11:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:40:09 --> Input Class Initialized
INFO - 2019-05-28 11:40:09 --> Language Class Initialized
ERROR - 2019-05-28 11:40:09 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:40:09 --> Config Class Initialized
INFO - 2019-05-28 11:40:09 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:40:09 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:40:09 --> Utf8 Class Initialized
INFO - 2019-05-28 11:40:09 --> URI Class Initialized
INFO - 2019-05-28 11:40:09 --> Config Class Initialized
INFO - 2019-05-28 11:40:09 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:40:09 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:40:09 --> Utf8 Class Initialized
INFO - 2019-05-28 11:40:09 --> URI Class Initialized
INFO - 2019-05-28 11:40:09 --> Router Class Initialized
INFO - 2019-05-28 11:40:09 --> Output Class Initialized
INFO - 2019-05-28 11:40:09 --> Security Class Initialized
DEBUG - 2019-05-28 11:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:40:09 --> Input Class Initialized
INFO - 2019-05-28 11:40:09 --> Language Class Initialized
ERROR - 2019-05-28 11:40:09 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:40:09 --> Router Class Initialized
INFO - 2019-05-28 11:40:09 --> Output Class Initialized
INFO - 2019-05-28 11:40:09 --> Security Class Initialized
DEBUG - 2019-05-28 11:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:40:09 --> Input Class Initialized
INFO - 2019-05-28 11:40:09 --> Language Class Initialized
ERROR - 2019-05-28 11:40:09 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:40:22 --> Config Class Initialized
INFO - 2019-05-28 11:40:22 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:40:22 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:40:22 --> Utf8 Class Initialized
INFO - 2019-05-28 11:40:22 --> URI Class Initialized
DEBUG - 2019-05-28 11:40:22 --> No URI present. Default controller set.
INFO - 2019-05-28 11:40:22 --> Router Class Initialized
INFO - 2019-05-28 11:40:22 --> Output Class Initialized
INFO - 2019-05-28 11:40:22 --> Security Class Initialized
DEBUG - 2019-05-28 11:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:40:22 --> Input Class Initialized
INFO - 2019-05-28 11:40:22 --> Language Class Initialized
INFO - 2019-05-28 11:40:22 --> Language Class Initialized
INFO - 2019-05-28 11:40:22 --> Config Class Initialized
INFO - 2019-05-28 11:40:22 --> Loader Class Initialized
INFO - 2019-05-28 11:40:22 --> Helper loaded: form_helper
INFO - 2019-05-28 11:40:22 --> Helper loaded: url_helper
INFO - 2019-05-28 11:40:22 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:40:22 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:40:22 --> Template library initialized
INFO - 2019-05-28 11:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:40:22 --> Controller Class Initialized
DEBUG - 2019-05-28 11:40:22 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:40:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:40:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:40:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:40:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:40:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:40:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:40:22 --> Final output sent to browser
DEBUG - 2019-05-28 11:40:22 --> Total execution time: 0.0484
INFO - 2019-05-28 11:40:23 --> Config Class Initialized
INFO - 2019-05-28 11:40:23 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:40:23 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:40:23 --> Utf8 Class Initialized
INFO - 2019-05-28 11:40:23 --> URI Class Initialized
INFO - 2019-05-28 11:40:23 --> Router Class Initialized
INFO - 2019-05-28 11:40:23 --> Output Class Initialized
INFO - 2019-05-28 11:40:23 --> Security Class Initialized
DEBUG - 2019-05-28 11:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:40:23 --> Input Class Initialized
INFO - 2019-05-28 11:40:23 --> Language Class Initialized
ERROR - 2019-05-28 11:40:23 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:40:23 --> Config Class Initialized
INFO - 2019-05-28 11:40:23 --> Hooks Class Initialized
INFO - 2019-05-28 11:40:23 --> Config Class Initialized
INFO - 2019-05-28 11:40:23 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:40:23 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:40:23 --> Utf8 Class Initialized
INFO - 2019-05-28 11:40:23 --> URI Class Initialized
INFO - 2019-05-28 11:40:23 --> Router Class Initialized
INFO - 2019-05-28 11:40:23 --> Output Class Initialized
INFO - 2019-05-28 11:40:23 --> Security Class Initialized
DEBUG - 2019-05-28 11:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:40:23 --> Input Class Initialized
INFO - 2019-05-28 11:40:23 --> Language Class Initialized
ERROR - 2019-05-28 11:40:23 --> 404 Page Not Found: /index
DEBUG - 2019-05-28 11:40:23 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:40:23 --> Utf8 Class Initialized
INFO - 2019-05-28 11:40:23 --> URI Class Initialized
INFO - 2019-05-28 11:40:23 --> Router Class Initialized
INFO - 2019-05-28 11:40:23 --> Output Class Initialized
INFO - 2019-05-28 11:40:23 --> Security Class Initialized
DEBUG - 2019-05-28 11:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:40:23 --> Input Class Initialized
INFO - 2019-05-28 11:40:23 --> Language Class Initialized
ERROR - 2019-05-28 11:40:23 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:40:39 --> Config Class Initialized
INFO - 2019-05-28 11:40:39 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:40:39 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:40:39 --> Utf8 Class Initialized
INFO - 2019-05-28 11:40:39 --> URI Class Initialized
DEBUG - 2019-05-28 11:40:39 --> No URI present. Default controller set.
INFO - 2019-05-28 11:40:39 --> Router Class Initialized
INFO - 2019-05-28 11:40:39 --> Output Class Initialized
INFO - 2019-05-28 11:40:39 --> Security Class Initialized
DEBUG - 2019-05-28 11:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:40:39 --> Input Class Initialized
INFO - 2019-05-28 11:40:39 --> Language Class Initialized
INFO - 2019-05-28 11:40:39 --> Language Class Initialized
INFO - 2019-05-28 11:40:39 --> Config Class Initialized
INFO - 2019-05-28 11:40:39 --> Loader Class Initialized
INFO - 2019-05-28 11:40:39 --> Helper loaded: form_helper
INFO - 2019-05-28 11:40:39 --> Helper loaded: url_helper
INFO - 2019-05-28 11:40:39 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:40:39 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:40:39 --> Template library initialized
INFO - 2019-05-28 11:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:40:39 --> Controller Class Initialized
DEBUG - 2019-05-28 11:40:39 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:40:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:40:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:40:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:40:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:40:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:40:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:40:39 --> Final output sent to browser
DEBUG - 2019-05-28 11:40:39 --> Total execution time: 0.0537
INFO - 2019-05-28 11:40:40 --> Config Class Initialized
INFO - 2019-05-28 11:40:40 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:40:40 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:40:40 --> Utf8 Class Initialized
INFO - 2019-05-28 11:40:40 --> URI Class Initialized
INFO - 2019-05-28 11:40:40 --> Router Class Initialized
INFO - 2019-05-28 11:40:40 --> Output Class Initialized
INFO - 2019-05-28 11:40:40 --> Security Class Initialized
DEBUG - 2019-05-28 11:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:40:40 --> Input Class Initialized
INFO - 2019-05-28 11:40:40 --> Language Class Initialized
ERROR - 2019-05-28 11:40:40 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:40:40 --> Config Class Initialized
INFO - 2019-05-28 11:40:40 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:40:40 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:40:40 --> Utf8 Class Initialized
INFO - 2019-05-28 11:40:40 --> URI Class Initialized
INFO - 2019-05-28 11:40:40 --> Config Class Initialized
INFO - 2019-05-28 11:40:40 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:40:40 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:40:40 --> Utf8 Class Initialized
INFO - 2019-05-28 11:40:40 --> URI Class Initialized
INFO - 2019-05-28 11:40:40 --> Router Class Initialized
INFO - 2019-05-28 11:40:40 --> Output Class Initialized
INFO - 2019-05-28 11:40:40 --> Security Class Initialized
DEBUG - 2019-05-28 11:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:40:40 --> Input Class Initialized
INFO - 2019-05-28 11:40:40 --> Language Class Initialized
ERROR - 2019-05-28 11:40:40 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:40:40 --> Router Class Initialized
INFO - 2019-05-28 11:40:40 --> Output Class Initialized
INFO - 2019-05-28 11:40:40 --> Security Class Initialized
DEBUG - 2019-05-28 11:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:40:40 --> Input Class Initialized
INFO - 2019-05-28 11:40:40 --> Language Class Initialized
ERROR - 2019-05-28 11:40:40 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:44:33 --> Config Class Initialized
INFO - 2019-05-28 11:44:33 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:44:33 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:44:33 --> Utf8 Class Initialized
INFO - 2019-05-28 11:44:33 --> URI Class Initialized
DEBUG - 2019-05-28 11:44:33 --> No URI present. Default controller set.
INFO - 2019-05-28 11:44:33 --> Router Class Initialized
INFO - 2019-05-28 11:44:33 --> Output Class Initialized
INFO - 2019-05-28 11:44:33 --> Security Class Initialized
DEBUG - 2019-05-28 11:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:44:33 --> Input Class Initialized
INFO - 2019-05-28 11:44:33 --> Language Class Initialized
INFO - 2019-05-28 11:44:33 --> Language Class Initialized
INFO - 2019-05-28 11:44:33 --> Config Class Initialized
INFO - 2019-05-28 11:44:33 --> Loader Class Initialized
INFO - 2019-05-28 11:44:33 --> Helper loaded: form_helper
INFO - 2019-05-28 11:44:33 --> Helper loaded: url_helper
INFO - 2019-05-28 11:44:33 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:44:33 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:44:33 --> Template library initialized
INFO - 2019-05-28 11:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:44:33 --> Controller Class Initialized
DEBUG - 2019-05-28 11:44:33 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:44:33 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:44:33 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:44:33 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:44:33 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:44:33 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:44:33 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:44:33 --> Config Class Initialized
INFO - 2019-05-28 11:44:33 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:44:33 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:44:33 --> Utf8 Class Initialized
INFO - 2019-05-28 11:44:33 --> URI Class Initialized
DEBUG - 2019-05-28 11:44:33 --> No URI present. Default controller set.
INFO - 2019-05-28 11:44:33 --> Router Class Initialized
INFO - 2019-05-28 11:44:33 --> Output Class Initialized
INFO - 2019-05-28 11:44:33 --> Security Class Initialized
DEBUG - 2019-05-28 11:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:44:33 --> Input Class Initialized
INFO - 2019-05-28 11:44:33 --> Language Class Initialized
INFO - 2019-05-28 11:44:33 --> Language Class Initialized
INFO - 2019-05-28 11:44:33 --> Config Class Initialized
INFO - 2019-05-28 11:44:33 --> Loader Class Initialized
INFO - 2019-05-28 11:44:33 --> Helper loaded: form_helper
INFO - 2019-05-28 11:44:33 --> Helper loaded: url_helper
INFO - 2019-05-28 11:44:33 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:44:33 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:44:33 --> Template library initialized
INFO - 2019-05-28 11:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:44:33 --> Controller Class Initialized
DEBUG - 2019-05-28 11:44:33 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:44:33 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:44:33 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:44:33 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:44:33 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:44:33 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:44:33 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:44:34 --> Final output sent to browser
DEBUG - 2019-05-28 11:44:34 --> Total execution time: 0.0481
INFO - 2019-05-28 11:44:35 --> Config Class Initialized
INFO - 2019-05-28 11:44:35 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:44:35 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:44:35 --> Utf8 Class Initialized
INFO - 2019-05-28 11:44:35 --> URI Class Initialized
INFO - 2019-05-28 11:44:35 --> Config Class Initialized
INFO - 2019-05-28 11:44:35 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:44:35 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:44:35 --> Utf8 Class Initialized
INFO - 2019-05-28 11:44:35 --> URI Class Initialized
INFO - 2019-05-28 11:44:35 --> Router Class Initialized
INFO - 2019-05-28 11:44:35 --> Output Class Initialized
INFO - 2019-05-28 11:44:35 --> Security Class Initialized
DEBUG - 2019-05-28 11:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:44:35 --> Input Class Initialized
INFO - 2019-05-28 11:44:35 --> Language Class Initialized
ERROR - 2019-05-28 11:44:35 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:44:35 --> Config Class Initialized
INFO - 2019-05-28 11:44:35 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:44:35 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:44:35 --> Utf8 Class Initialized
INFO - 2019-05-28 11:44:35 --> URI Class Initialized
INFO - 2019-05-28 11:44:35 --> Router Class Initialized
INFO - 2019-05-28 11:44:35 --> Output Class Initialized
INFO - 2019-05-28 11:44:35 --> Security Class Initialized
DEBUG - 2019-05-28 11:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:44:35 --> Input Class Initialized
INFO - 2019-05-28 11:44:35 --> Language Class Initialized
ERROR - 2019-05-28 11:44:35 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:44:35 --> Router Class Initialized
INFO - 2019-05-28 11:44:35 --> Output Class Initialized
INFO - 2019-05-28 11:44:35 --> Security Class Initialized
DEBUG - 2019-05-28 11:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:44:35 --> Input Class Initialized
INFO - 2019-05-28 11:44:35 --> Language Class Initialized
ERROR - 2019-05-28 11:44:35 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:44:36 --> Config Class Initialized
INFO - 2019-05-28 11:44:36 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:44:36 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:44:36 --> Utf8 Class Initialized
INFO - 2019-05-28 11:44:36 --> URI Class Initialized
DEBUG - 2019-05-28 11:44:36 --> No URI present. Default controller set.
INFO - 2019-05-28 11:44:36 --> Router Class Initialized
INFO - 2019-05-28 11:44:36 --> Output Class Initialized
INFO - 2019-05-28 11:44:36 --> Security Class Initialized
DEBUG - 2019-05-28 11:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:44:36 --> Input Class Initialized
INFO - 2019-05-28 11:44:36 --> Language Class Initialized
INFO - 2019-05-28 11:44:36 --> Language Class Initialized
INFO - 2019-05-28 11:44:36 --> Config Class Initialized
INFO - 2019-05-28 11:44:36 --> Loader Class Initialized
INFO - 2019-05-28 11:44:36 --> Helper loaded: form_helper
INFO - 2019-05-28 11:44:36 --> Helper loaded: url_helper
INFO - 2019-05-28 11:44:36 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:44:36 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:44:36 --> Template library initialized
INFO - 2019-05-28 11:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:44:36 --> Controller Class Initialized
DEBUG - 2019-05-28 11:44:36 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:44:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:44:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:44:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:44:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:44:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:44:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:44:37 --> Config Class Initialized
INFO - 2019-05-28 11:44:37 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:44:37 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:44:37 --> Utf8 Class Initialized
INFO - 2019-05-28 11:44:37 --> URI Class Initialized
DEBUG - 2019-05-28 11:44:37 --> No URI present. Default controller set.
INFO - 2019-05-28 11:44:37 --> Router Class Initialized
INFO - 2019-05-28 11:44:37 --> Output Class Initialized
INFO - 2019-05-28 11:44:37 --> Security Class Initialized
DEBUG - 2019-05-28 11:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:44:37 --> Input Class Initialized
INFO - 2019-05-28 11:44:37 --> Language Class Initialized
INFO - 2019-05-28 11:44:37 --> Language Class Initialized
INFO - 2019-05-28 11:44:37 --> Config Class Initialized
INFO - 2019-05-28 11:44:37 --> Loader Class Initialized
INFO - 2019-05-28 11:44:37 --> Helper loaded: form_helper
INFO - 2019-05-28 11:44:37 --> Helper loaded: url_helper
INFO - 2019-05-28 11:44:37 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:44:37 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:44:37 --> Template library initialized
INFO - 2019-05-28 11:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:44:37 --> Controller Class Initialized
DEBUG - 2019-05-28 11:44:37 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:44:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:44:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:44:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:44:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:44:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:44:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:44:37 --> Final output sent to browser
DEBUG - 2019-05-28 11:44:37 --> Total execution time: 0.0450
INFO - 2019-05-28 11:44:41 --> Config Class Initialized
INFO - 2019-05-28 11:44:41 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:44:41 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:44:41 --> Utf8 Class Initialized
INFO - 2019-05-28 11:44:41 --> URI Class Initialized
INFO - 2019-05-28 11:44:41 --> Router Class Initialized
INFO - 2019-05-28 11:44:41 --> Output Class Initialized
INFO - 2019-05-28 11:44:41 --> Security Class Initialized
DEBUG - 2019-05-28 11:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:44:41 --> Input Class Initialized
INFO - 2019-05-28 11:44:41 --> Language Class Initialized
ERROR - 2019-05-28 11:44:41 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:44:41 --> Config Class Initialized
INFO - 2019-05-28 11:44:41 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:44:41 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:44:41 --> Utf8 Class Initialized
INFO - 2019-05-28 11:44:41 --> URI Class Initialized
INFO - 2019-05-28 11:44:41 --> Router Class Initialized
INFO - 2019-05-28 11:44:41 --> Output Class Initialized
INFO - 2019-05-28 11:44:41 --> Security Class Initialized
DEBUG - 2019-05-28 11:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:44:41 --> Input Class Initialized
INFO - 2019-05-28 11:44:41 --> Language Class Initialized
ERROR - 2019-05-28 11:44:41 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:44:41 --> Config Class Initialized
INFO - 2019-05-28 11:44:41 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:44:41 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:44:41 --> Utf8 Class Initialized
INFO - 2019-05-28 11:44:41 --> URI Class Initialized
INFO - 2019-05-28 11:44:41 --> Router Class Initialized
INFO - 2019-05-28 11:44:41 --> Output Class Initialized
INFO - 2019-05-28 11:44:41 --> Security Class Initialized
DEBUG - 2019-05-28 11:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:44:41 --> Input Class Initialized
INFO - 2019-05-28 11:44:41 --> Language Class Initialized
ERROR - 2019-05-28 11:44:41 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:44:42 --> Config Class Initialized
INFO - 2019-05-28 11:44:42 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:44:42 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:44:42 --> Utf8 Class Initialized
INFO - 2019-05-28 11:44:42 --> URI Class Initialized
INFO - 2019-05-28 11:44:42 --> Router Class Initialized
INFO - 2019-05-28 11:44:42 --> Output Class Initialized
INFO - 2019-05-28 11:44:42 --> Security Class Initialized
DEBUG - 2019-05-28 11:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:44:42 --> Input Class Initialized
INFO - 2019-05-28 11:44:42 --> Language Class Initialized
ERROR - 2019-05-28 11:44:42 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:44:44 --> Config Class Initialized
INFO - 2019-05-28 11:44:44 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:44:44 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:44:44 --> Utf8 Class Initialized
INFO - 2019-05-28 11:44:44 --> URI Class Initialized
DEBUG - 2019-05-28 11:44:44 --> No URI present. Default controller set.
INFO - 2019-05-28 11:44:44 --> Router Class Initialized
INFO - 2019-05-28 11:44:44 --> Output Class Initialized
INFO - 2019-05-28 11:44:44 --> Security Class Initialized
DEBUG - 2019-05-28 11:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:44:44 --> Input Class Initialized
INFO - 2019-05-28 11:44:44 --> Language Class Initialized
INFO - 2019-05-28 11:44:44 --> Language Class Initialized
INFO - 2019-05-28 11:44:44 --> Config Class Initialized
INFO - 2019-05-28 11:44:44 --> Loader Class Initialized
INFO - 2019-05-28 11:44:44 --> Helper loaded: form_helper
INFO - 2019-05-28 11:44:44 --> Helper loaded: url_helper
INFO - 2019-05-28 11:44:44 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:44:44 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:44:44 --> Template library initialized
INFO - 2019-05-28 11:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:44:44 --> Controller Class Initialized
DEBUG - 2019-05-28 11:44:44 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:44:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:44:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:44:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:44:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:44:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:44:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:44:44 --> Final output sent to browser
DEBUG - 2019-05-28 11:44:44 --> Total execution time: 0.0711
INFO - 2019-05-28 11:44:45 --> Config Class Initialized
INFO - 2019-05-28 11:44:45 --> Hooks Class Initialized
INFO - 2019-05-28 11:44:45 --> Config Class Initialized
INFO - 2019-05-28 11:44:45 --> Hooks Class Initialized
INFO - 2019-05-28 11:44:45 --> Config Class Initialized
INFO - 2019-05-28 11:44:45 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:44:45 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:44:45 --> Utf8 Class Initialized
INFO - 2019-05-28 11:44:45 --> URI Class Initialized
INFO - 2019-05-28 11:44:45 --> Router Class Initialized
INFO - 2019-05-28 11:44:45 --> Output Class Initialized
INFO - 2019-05-28 11:44:45 --> Security Class Initialized
DEBUG - 2019-05-28 11:44:45 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:44:45 --> Utf8 Class Initialized
INFO - 2019-05-28 11:44:45 --> URI Class Initialized
INFO - 2019-05-28 11:44:45 --> Router Class Initialized
INFO - 2019-05-28 11:44:45 --> Output Class Initialized
INFO - 2019-05-28 11:44:45 --> Security Class Initialized
DEBUG - 2019-05-28 11:44:45 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:44:45 --> Utf8 Class Initialized
INFO - 2019-05-28 11:44:45 --> URI Class Initialized
INFO - 2019-05-28 11:44:45 --> Router Class Initialized
INFO - 2019-05-28 11:44:45 --> Output Class Initialized
INFO - 2019-05-28 11:44:45 --> Security Class Initialized
DEBUG - 2019-05-28 11:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:44:45 --> Input Class Initialized
INFO - 2019-05-28 11:44:45 --> Language Class Initialized
ERROR - 2019-05-28 11:44:45 --> 404 Page Not Found: /index
DEBUG - 2019-05-28 11:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:44:45 --> Input Class Initialized
INFO - 2019-05-28 11:44:45 --> Language Class Initialized
ERROR - 2019-05-28 11:44:45 --> 404 Page Not Found: /index
DEBUG - 2019-05-28 11:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:44:45 --> Input Class Initialized
INFO - 2019-05-28 11:44:45 --> Language Class Initialized
ERROR - 2019-05-28 11:44:45 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:45:08 --> Config Class Initialized
INFO - 2019-05-28 11:45:08 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:45:08 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:45:08 --> Utf8 Class Initialized
INFO - 2019-05-28 11:45:08 --> URI Class Initialized
DEBUG - 2019-05-28 11:45:08 --> No URI present. Default controller set.
INFO - 2019-05-28 11:45:08 --> Router Class Initialized
INFO - 2019-05-28 11:45:08 --> Output Class Initialized
INFO - 2019-05-28 11:45:08 --> Security Class Initialized
DEBUG - 2019-05-28 11:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:45:08 --> Input Class Initialized
INFO - 2019-05-28 11:45:08 --> Language Class Initialized
INFO - 2019-05-28 11:45:08 --> Language Class Initialized
INFO - 2019-05-28 11:45:08 --> Config Class Initialized
INFO - 2019-05-28 11:45:08 --> Loader Class Initialized
INFO - 2019-05-28 11:45:08 --> Helper loaded: form_helper
INFO - 2019-05-28 11:45:08 --> Helper loaded: url_helper
INFO - 2019-05-28 11:45:08 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:45:08 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:45:08 --> Template library initialized
INFO - 2019-05-28 11:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:45:08 --> Controller Class Initialized
DEBUG - 2019-05-28 11:45:08 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:45:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:45:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:45:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:45:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:45:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:45:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:45:09 --> Final output sent to browser
DEBUG - 2019-05-28 11:45:09 --> Total execution time: 0.0468
INFO - 2019-05-28 11:45:10 --> Config Class Initialized
INFO - 2019-05-28 11:45:10 --> Hooks Class Initialized
INFO - 2019-05-28 11:45:10 --> Config Class Initialized
INFO - 2019-05-28 11:45:10 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:45:10 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:45:10 --> Utf8 Class Initialized
DEBUG - 2019-05-28 11:45:10 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:45:10 --> Utf8 Class Initialized
INFO - 2019-05-28 11:45:10 --> URI Class Initialized
INFO - 2019-05-28 11:45:10 --> Router Class Initialized
INFO - 2019-05-28 11:45:10 --> Output Class Initialized
INFO - 2019-05-28 11:45:10 --> URI Class Initialized
INFO - 2019-05-28 11:45:10 --> Router Class Initialized
INFO - 2019-05-28 11:45:10 --> Output Class Initialized
INFO - 2019-05-28 11:45:10 --> Security Class Initialized
INFO - 2019-05-28 11:45:10 --> Security Class Initialized
DEBUG - 2019-05-28 11:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:45:10 --> Input Class Initialized
INFO - 2019-05-28 11:45:10 --> Language Class Initialized
ERROR - 2019-05-28 11:45:10 --> 404 Page Not Found: /index
DEBUG - 2019-05-28 11:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:45:10 --> Input Class Initialized
INFO - 2019-05-28 11:45:10 --> Language Class Initialized
ERROR - 2019-05-28 11:45:10 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:45:10 --> Config Class Initialized
INFO - 2019-05-28 11:45:10 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:45:10 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:45:10 --> Utf8 Class Initialized
INFO - 2019-05-28 11:45:10 --> URI Class Initialized
INFO - 2019-05-28 11:45:10 --> Router Class Initialized
INFO - 2019-05-28 11:45:10 --> Output Class Initialized
INFO - 2019-05-28 11:45:10 --> Security Class Initialized
DEBUG - 2019-05-28 11:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:45:10 --> Input Class Initialized
INFO - 2019-05-28 11:45:10 --> Language Class Initialized
ERROR - 2019-05-28 11:45:10 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:45:11 --> Config Class Initialized
INFO - 2019-05-28 11:45:11 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:45:11 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:45:11 --> Utf8 Class Initialized
INFO - 2019-05-28 11:45:11 --> URI Class Initialized
DEBUG - 2019-05-28 11:45:11 --> No URI present. Default controller set.
INFO - 2019-05-28 11:45:11 --> Router Class Initialized
INFO - 2019-05-28 11:45:11 --> Output Class Initialized
INFO - 2019-05-28 11:45:11 --> Security Class Initialized
DEBUG - 2019-05-28 11:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:45:11 --> Input Class Initialized
INFO - 2019-05-28 11:45:11 --> Language Class Initialized
INFO - 2019-05-28 11:45:11 --> Language Class Initialized
INFO - 2019-05-28 11:45:11 --> Config Class Initialized
INFO - 2019-05-28 11:45:11 --> Loader Class Initialized
INFO - 2019-05-28 11:45:11 --> Helper loaded: form_helper
INFO - 2019-05-28 11:45:11 --> Helper loaded: url_helper
INFO - 2019-05-28 11:45:11 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:45:11 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:45:11 --> Template library initialized
INFO - 2019-05-28 11:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:45:11 --> Controller Class Initialized
DEBUG - 2019-05-28 11:45:11 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:45:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:45:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:45:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:45:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:45:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:45:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:45:12 --> Final output sent to browser
DEBUG - 2019-05-28 11:45:12 --> Total execution time: 0.0451
INFO - 2019-05-28 11:45:14 --> Config Class Initialized
INFO - 2019-05-28 11:45:14 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:45:14 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:45:14 --> Utf8 Class Initialized
INFO - 2019-05-28 11:45:14 --> URI Class Initialized
INFO - 2019-05-28 11:45:14 --> Router Class Initialized
INFO - 2019-05-28 11:45:14 --> Output Class Initialized
INFO - 2019-05-28 11:45:14 --> Security Class Initialized
DEBUG - 2019-05-28 11:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:45:14 --> Input Class Initialized
INFO - 2019-05-28 11:45:14 --> Language Class Initialized
ERROR - 2019-05-28 11:45:14 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:45:14 --> Config Class Initialized
INFO - 2019-05-28 11:45:14 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:45:14 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:45:14 --> Utf8 Class Initialized
INFO - 2019-05-28 11:45:14 --> URI Class Initialized
INFO - 2019-05-28 11:45:14 --> Router Class Initialized
INFO - 2019-05-28 11:45:14 --> Output Class Initialized
INFO - 2019-05-28 11:45:14 --> Security Class Initialized
DEBUG - 2019-05-28 11:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:45:14 --> Input Class Initialized
INFO - 2019-05-28 11:45:14 --> Language Class Initialized
ERROR - 2019-05-28 11:45:14 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:45:14 --> Config Class Initialized
INFO - 2019-05-28 11:45:14 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:45:14 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:45:14 --> Utf8 Class Initialized
INFO - 2019-05-28 11:45:14 --> URI Class Initialized
INFO - 2019-05-28 11:45:14 --> Router Class Initialized
INFO - 2019-05-28 11:45:14 --> Output Class Initialized
INFO - 2019-05-28 11:45:14 --> Security Class Initialized
DEBUG - 2019-05-28 11:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:45:14 --> Input Class Initialized
INFO - 2019-05-28 11:45:14 --> Language Class Initialized
ERROR - 2019-05-28 11:45:14 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:45:15 --> Config Class Initialized
INFO - 2019-05-28 11:45:15 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:45:15 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:45:15 --> Utf8 Class Initialized
INFO - 2019-05-28 11:45:15 --> URI Class Initialized
INFO - 2019-05-28 11:45:15 --> Router Class Initialized
INFO - 2019-05-28 11:45:15 --> Output Class Initialized
INFO - 2019-05-28 11:45:15 --> Security Class Initialized
DEBUG - 2019-05-28 11:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:45:15 --> Input Class Initialized
INFO - 2019-05-28 11:45:15 --> Language Class Initialized
ERROR - 2019-05-28 11:45:15 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:45:17 --> Config Class Initialized
INFO - 2019-05-28 11:45:17 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:45:17 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:45:17 --> Utf8 Class Initialized
INFO - 2019-05-28 11:45:17 --> URI Class Initialized
INFO - 2019-05-28 11:45:17 --> Router Class Initialized
INFO - 2019-05-28 11:45:17 --> Output Class Initialized
INFO - 2019-05-28 11:45:17 --> Security Class Initialized
DEBUG - 2019-05-28 11:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:45:17 --> Input Class Initialized
INFO - 2019-05-28 11:45:17 --> Language Class Initialized
INFO - 2019-05-28 11:45:17 --> Language Class Initialized
INFO - 2019-05-28 11:45:17 --> Config Class Initialized
INFO - 2019-05-28 11:45:17 --> Loader Class Initialized
INFO - 2019-05-28 11:45:17 --> Helper loaded: form_helper
INFO - 2019-05-28 11:45:17 --> Helper loaded: url_helper
INFO - 2019-05-28 11:45:17 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:45:17 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:45:17 --> Template library initialized
INFO - 2019-05-28 11:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:45:17 --> Controller Class Initialized
DEBUG - 2019-05-28 11:45:17 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 11:45:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 11:45:17 --> Config Class Initialized
INFO - 2019-05-28 11:45:17 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:45:17 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:45:17 --> Utf8 Class Initialized
INFO - 2019-05-28 11:45:17 --> URI Class Initialized
DEBUG - 2019-05-28 11:45:17 --> No URI present. Default controller set.
INFO - 2019-05-28 11:45:17 --> Router Class Initialized
INFO - 2019-05-28 11:45:17 --> Output Class Initialized
INFO - 2019-05-28 11:45:17 --> Security Class Initialized
DEBUG - 2019-05-28 11:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:45:17 --> Input Class Initialized
INFO - 2019-05-28 11:45:17 --> Language Class Initialized
INFO - 2019-05-28 11:45:17 --> Language Class Initialized
INFO - 2019-05-28 11:45:17 --> Config Class Initialized
INFO - 2019-05-28 11:45:17 --> Loader Class Initialized
INFO - 2019-05-28 11:45:17 --> Helper loaded: form_helper
INFO - 2019-05-28 11:45:17 --> Helper loaded: url_helper
INFO - 2019-05-28 11:45:17 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:45:17 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:45:17 --> Template library initialized
INFO - 2019-05-28 11:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:45:17 --> Controller Class Initialized
DEBUG - 2019-05-28 11:45:17 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:45:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:45:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:45:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:45:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:45:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:45:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:45:17 --> Final output sent to browser
DEBUG - 2019-05-28 11:45:17 --> Total execution time: 0.0494
INFO - 2019-05-28 11:45:18 --> Config Class Initialized
INFO - 2019-05-28 11:45:18 --> Hooks Class Initialized
INFO - 2019-05-28 11:45:18 --> Config Class Initialized
INFO - 2019-05-28 11:45:18 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:45:18 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:45:18 --> Utf8 Class Initialized
INFO - 2019-05-28 11:45:18 --> URI Class Initialized
INFO - 2019-05-28 11:45:18 --> Config Class Initialized
INFO - 2019-05-28 11:45:18 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:45:18 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:45:18 --> Utf8 Class Initialized
INFO - 2019-05-28 11:45:18 --> URI Class Initialized
INFO - 2019-05-28 11:45:18 --> Router Class Initialized
INFO - 2019-05-28 11:45:18 --> Output Class Initialized
INFO - 2019-05-28 11:45:18 --> Security Class Initialized
DEBUG - 2019-05-28 11:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:45:18 --> Input Class Initialized
INFO - 2019-05-28 11:45:18 --> Language Class Initialized
ERROR - 2019-05-28 11:45:18 --> 404 Page Not Found: /index
DEBUG - 2019-05-28 11:45:18 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:45:18 --> Utf8 Class Initialized
INFO - 2019-05-28 11:45:18 --> URI Class Initialized
INFO - 2019-05-28 11:45:18 --> Router Class Initialized
INFO - 2019-05-28 11:45:18 --> Output Class Initialized
INFO - 2019-05-28 11:45:18 --> Security Class Initialized
DEBUG - 2019-05-28 11:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:45:18 --> Input Class Initialized
INFO - 2019-05-28 11:45:18 --> Language Class Initialized
INFO - 2019-05-28 11:45:18 --> Router Class Initialized
INFO - 2019-05-28 11:45:18 --> Output Class Initialized
INFO - 2019-05-28 11:45:18 --> Security Class Initialized
DEBUG - 2019-05-28 11:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:45:18 --> Input Class Initialized
INFO - 2019-05-28 11:45:18 --> Language Class Initialized
ERROR - 2019-05-28 11:45:18 --> 404 Page Not Found: /index
ERROR - 2019-05-28 11:45:18 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:46:21 --> Config Class Initialized
INFO - 2019-05-28 11:46:21 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:46:21 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:46:21 --> Utf8 Class Initialized
INFO - 2019-05-28 11:46:21 --> URI Class Initialized
DEBUG - 2019-05-28 11:46:21 --> No URI present. Default controller set.
INFO - 2019-05-28 11:46:21 --> Router Class Initialized
INFO - 2019-05-28 11:46:21 --> Output Class Initialized
INFO - 2019-05-28 11:46:21 --> Security Class Initialized
DEBUG - 2019-05-28 11:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:46:21 --> Input Class Initialized
INFO - 2019-05-28 11:46:21 --> Language Class Initialized
INFO - 2019-05-28 11:46:21 --> Language Class Initialized
INFO - 2019-05-28 11:46:21 --> Config Class Initialized
INFO - 2019-05-28 11:46:21 --> Loader Class Initialized
INFO - 2019-05-28 11:46:21 --> Helper loaded: form_helper
INFO - 2019-05-28 11:46:21 --> Helper loaded: url_helper
INFO - 2019-05-28 11:46:21 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:46:21 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:46:21 --> Template library initialized
INFO - 2019-05-28 11:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:46:21 --> Controller Class Initialized
DEBUG - 2019-05-28 11:46:21 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:46:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:46:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:46:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:46:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:46:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:46:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:46:21 --> Config Class Initialized
INFO - 2019-05-28 11:46:21 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:46:21 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:46:21 --> Utf8 Class Initialized
INFO - 2019-05-28 11:46:21 --> URI Class Initialized
DEBUG - 2019-05-28 11:46:21 --> No URI present. Default controller set.
INFO - 2019-05-28 11:46:21 --> Router Class Initialized
INFO - 2019-05-28 11:46:21 --> Output Class Initialized
INFO - 2019-05-28 11:46:21 --> Security Class Initialized
DEBUG - 2019-05-28 11:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:46:21 --> Input Class Initialized
INFO - 2019-05-28 11:46:21 --> Language Class Initialized
INFO - 2019-05-28 11:46:21 --> Language Class Initialized
INFO - 2019-05-28 11:46:21 --> Config Class Initialized
INFO - 2019-05-28 11:46:21 --> Loader Class Initialized
INFO - 2019-05-28 11:46:21 --> Helper loaded: form_helper
INFO - 2019-05-28 11:46:21 --> Helper loaded: url_helper
INFO - 2019-05-28 11:46:21 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:46:21 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:46:21 --> Template library initialized
INFO - 2019-05-28 11:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:46:21 --> Controller Class Initialized
DEBUG - 2019-05-28 11:46:21 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:46:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:46:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:46:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:46:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:46:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:46:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:46:21 --> Config Class Initialized
INFO - 2019-05-28 11:46:21 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:46:21 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:46:21 --> Utf8 Class Initialized
INFO - 2019-05-28 11:46:21 --> URI Class Initialized
DEBUG - 2019-05-28 11:46:21 --> No URI present. Default controller set.
INFO - 2019-05-28 11:46:21 --> Router Class Initialized
INFO - 2019-05-28 11:46:21 --> Output Class Initialized
INFO - 2019-05-28 11:46:21 --> Security Class Initialized
DEBUG - 2019-05-28 11:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:46:21 --> Input Class Initialized
INFO - 2019-05-28 11:46:21 --> Language Class Initialized
INFO - 2019-05-28 11:46:21 --> Language Class Initialized
INFO - 2019-05-28 11:46:21 --> Config Class Initialized
INFO - 2019-05-28 11:46:21 --> Loader Class Initialized
INFO - 2019-05-28 11:46:21 --> Helper loaded: form_helper
INFO - 2019-05-28 11:46:21 --> Helper loaded: url_helper
INFO - 2019-05-28 11:46:21 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:46:21 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:46:21 --> Template library initialized
INFO - 2019-05-28 11:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:46:22 --> Controller Class Initialized
DEBUG - 2019-05-28 11:46:22 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:46:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:46:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:46:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:46:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:46:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:46:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:46:22 --> Final output sent to browser
DEBUG - 2019-05-28 11:46:22 --> Total execution time: 0.1925
INFO - 2019-05-28 11:46:23 --> Config Class Initialized
INFO - 2019-05-28 11:46:23 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:46:23 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:46:23 --> Utf8 Class Initialized
INFO - 2019-05-28 11:46:23 --> URI Class Initialized
INFO - 2019-05-28 11:46:23 --> Config Class Initialized
INFO - 2019-05-28 11:46:23 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:46:23 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:46:23 --> Utf8 Class Initialized
INFO - 2019-05-28 11:46:23 --> URI Class Initialized
INFO - 2019-05-28 11:46:23 --> Router Class Initialized
INFO - 2019-05-28 11:46:23 --> Output Class Initialized
INFO - 2019-05-28 11:46:23 --> Security Class Initialized
DEBUG - 2019-05-28 11:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:46:23 --> Input Class Initialized
INFO - 2019-05-28 11:46:23 --> Language Class Initialized
ERROR - 2019-05-28 11:46:23 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:46:23 --> Router Class Initialized
INFO - 2019-05-28 11:46:23 --> Output Class Initialized
INFO - 2019-05-28 11:46:23 --> Security Class Initialized
DEBUG - 2019-05-28 11:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:46:23 --> Input Class Initialized
INFO - 2019-05-28 11:46:23 --> Language Class Initialized
ERROR - 2019-05-28 11:46:23 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:46:24 --> Config Class Initialized
INFO - 2019-05-28 11:46:24 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:46:24 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:46:24 --> Utf8 Class Initialized
INFO - 2019-05-28 11:46:24 --> URI Class Initialized
INFO - 2019-05-28 11:46:24 --> Router Class Initialized
INFO - 2019-05-28 11:46:24 --> Output Class Initialized
INFO - 2019-05-28 11:46:24 --> Security Class Initialized
DEBUG - 2019-05-28 11:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:46:24 --> Input Class Initialized
INFO - 2019-05-28 11:46:24 --> Language Class Initialized
ERROR - 2019-05-28 11:46:24 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:46:26 --> Config Class Initialized
INFO - 2019-05-28 11:46:26 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:46:26 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:46:26 --> Utf8 Class Initialized
INFO - 2019-05-28 11:46:26 --> URI Class Initialized
INFO - 2019-05-28 11:46:26 --> Router Class Initialized
INFO - 2019-05-28 11:46:26 --> Output Class Initialized
INFO - 2019-05-28 11:46:26 --> Security Class Initialized
DEBUG - 2019-05-28 11:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:46:26 --> Input Class Initialized
INFO - 2019-05-28 11:46:26 --> Language Class Initialized
ERROR - 2019-05-28 11:46:26 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:46:55 --> Config Class Initialized
INFO - 2019-05-28 11:46:55 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:46:55 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:46:55 --> Utf8 Class Initialized
INFO - 2019-05-28 11:46:55 --> URI Class Initialized
DEBUG - 2019-05-28 11:46:55 --> No URI present. Default controller set.
INFO - 2019-05-28 11:46:55 --> Router Class Initialized
INFO - 2019-05-28 11:46:55 --> Output Class Initialized
INFO - 2019-05-28 11:46:55 --> Security Class Initialized
DEBUG - 2019-05-28 11:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:46:55 --> Input Class Initialized
INFO - 2019-05-28 11:46:55 --> Language Class Initialized
INFO - 2019-05-28 11:46:55 --> Language Class Initialized
INFO - 2019-05-28 11:46:55 --> Config Class Initialized
INFO - 2019-05-28 11:46:55 --> Loader Class Initialized
INFO - 2019-05-28 11:46:55 --> Helper loaded: form_helper
INFO - 2019-05-28 11:46:55 --> Helper loaded: url_helper
INFO - 2019-05-28 11:46:55 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:46:55 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:46:55 --> Template library initialized
INFO - 2019-05-28 11:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:46:55 --> Controller Class Initialized
DEBUG - 2019-05-28 11:46:55 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:46:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:46:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:46:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:46:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:46:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:46:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:46:56 --> Final output sent to browser
DEBUG - 2019-05-28 11:46:56 --> Total execution time: 0.0487
INFO - 2019-05-28 11:47:17 --> Config Class Initialized
INFO - 2019-05-28 11:47:17 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:47:17 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:47:17 --> Utf8 Class Initialized
INFO - 2019-05-28 11:47:17 --> URI Class Initialized
DEBUG - 2019-05-28 11:47:17 --> No URI present. Default controller set.
INFO - 2019-05-28 11:47:17 --> Router Class Initialized
INFO - 2019-05-28 11:47:17 --> Output Class Initialized
INFO - 2019-05-28 11:47:17 --> Security Class Initialized
DEBUG - 2019-05-28 11:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:47:17 --> Input Class Initialized
INFO - 2019-05-28 11:47:17 --> Language Class Initialized
INFO - 2019-05-28 11:47:17 --> Language Class Initialized
INFO - 2019-05-28 11:47:17 --> Config Class Initialized
INFO - 2019-05-28 11:47:17 --> Loader Class Initialized
INFO - 2019-05-28 11:47:17 --> Helper loaded: form_helper
INFO - 2019-05-28 11:47:18 --> Helper loaded: url_helper
INFO - 2019-05-28 11:47:18 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:47:18 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:47:18 --> Template library initialized
INFO - 2019-05-28 11:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:47:18 --> Controller Class Initialized
DEBUG - 2019-05-28 11:47:18 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:47:18 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:47:18 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:47:18 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:47:18 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:47:18 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:47:18 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:47:18 --> Final output sent to browser
DEBUG - 2019-05-28 11:47:18 --> Total execution time: 0.0542
INFO - 2019-05-28 11:47:18 --> Config Class Initialized
INFO - 2019-05-28 11:47:18 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:47:18 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:47:18 --> Utf8 Class Initialized
INFO - 2019-05-28 11:47:18 --> URI Class Initialized
INFO - 2019-05-28 11:47:18 --> Router Class Initialized
INFO - 2019-05-28 11:47:18 --> Output Class Initialized
INFO - 2019-05-28 11:47:18 --> Security Class Initialized
DEBUG - 2019-05-28 11:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:47:18 --> Input Class Initialized
INFO - 2019-05-28 11:47:18 --> Language Class Initialized
ERROR - 2019-05-28 11:47:18 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:47:18 --> Config Class Initialized
INFO - 2019-05-28 11:47:18 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:47:18 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:47:18 --> Utf8 Class Initialized
INFO - 2019-05-28 11:47:18 --> URI Class Initialized
INFO - 2019-05-28 11:47:18 --> Router Class Initialized
INFO - 2019-05-28 11:47:18 --> Output Class Initialized
INFO - 2019-05-28 11:47:18 --> Security Class Initialized
DEBUG - 2019-05-28 11:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:47:18 --> Input Class Initialized
INFO - 2019-05-28 11:47:18 --> Language Class Initialized
ERROR - 2019-05-28 11:47:18 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:47:19 --> Config Class Initialized
INFO - 2019-05-28 11:47:19 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:47:19 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:47:19 --> Utf8 Class Initialized
INFO - 2019-05-28 11:47:19 --> URI Class Initialized
INFO - 2019-05-28 11:47:19 --> Router Class Initialized
INFO - 2019-05-28 11:47:19 --> Output Class Initialized
INFO - 2019-05-28 11:47:19 --> Security Class Initialized
DEBUG - 2019-05-28 11:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:47:19 --> Input Class Initialized
INFO - 2019-05-28 11:47:19 --> Language Class Initialized
ERROR - 2019-05-28 11:47:19 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:47:41 --> Config Class Initialized
INFO - 2019-05-28 11:47:41 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:47:41 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:47:41 --> Utf8 Class Initialized
INFO - 2019-05-28 11:47:41 --> URI Class Initialized
DEBUG - 2019-05-28 11:47:41 --> No URI present. Default controller set.
INFO - 2019-05-28 11:47:41 --> Router Class Initialized
INFO - 2019-05-28 11:47:41 --> Output Class Initialized
INFO - 2019-05-28 11:47:41 --> Security Class Initialized
DEBUG - 2019-05-28 11:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:47:41 --> Input Class Initialized
INFO - 2019-05-28 11:47:41 --> Language Class Initialized
INFO - 2019-05-28 11:47:41 --> Language Class Initialized
INFO - 2019-05-28 11:47:41 --> Config Class Initialized
INFO - 2019-05-28 11:47:41 --> Loader Class Initialized
INFO - 2019-05-28 11:47:41 --> Helper loaded: form_helper
INFO - 2019-05-28 11:47:41 --> Helper loaded: url_helper
INFO - 2019-05-28 11:47:41 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:47:41 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:47:41 --> Template library initialized
INFO - 2019-05-28 11:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:47:41 --> Controller Class Initialized
DEBUG - 2019-05-28 11:47:41 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:47:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:47:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:47:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:47:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:47:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:47:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:47:41 --> Final output sent to browser
DEBUG - 2019-05-28 11:47:41 --> Total execution time: 0.0453
INFO - 2019-05-28 11:47:41 --> Config Class Initialized
INFO - 2019-05-28 11:47:41 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:47:41 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:47:41 --> Utf8 Class Initialized
INFO - 2019-05-28 11:47:41 --> URI Class Initialized
INFO - 2019-05-28 11:47:41 --> Config Class Initialized
INFO - 2019-05-28 11:47:41 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:47:41 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:47:41 --> Utf8 Class Initialized
INFO - 2019-05-28 11:47:41 --> URI Class Initialized
INFO - 2019-05-28 11:47:42 --> Router Class Initialized
INFO - 2019-05-28 11:47:42 --> Config Class Initialized
INFO - 2019-05-28 11:47:42 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:47:42 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:47:42 --> Utf8 Class Initialized
INFO - 2019-05-28 11:47:42 --> URI Class Initialized
INFO - 2019-05-28 11:47:42 --> Router Class Initialized
INFO - 2019-05-28 11:47:42 --> Router Class Initialized
INFO - 2019-05-28 11:47:42 --> Output Class Initialized
INFO - 2019-05-28 11:47:42 --> Security Class Initialized
DEBUG - 2019-05-28 11:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:47:42 --> Input Class Initialized
INFO - 2019-05-28 11:47:42 --> Language Class Initialized
ERROR - 2019-05-28 11:47:42 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:47:42 --> Output Class Initialized
INFO - 2019-05-28 11:47:42 --> Security Class Initialized
DEBUG - 2019-05-28 11:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:47:42 --> Input Class Initialized
INFO - 2019-05-28 11:47:42 --> Language Class Initialized
ERROR - 2019-05-28 11:47:42 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:47:42 --> Output Class Initialized
INFO - 2019-05-28 11:47:42 --> Security Class Initialized
DEBUG - 2019-05-28 11:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:47:42 --> Input Class Initialized
INFO - 2019-05-28 11:47:42 --> Language Class Initialized
ERROR - 2019-05-28 11:47:42 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:48:01 --> Config Class Initialized
INFO - 2019-05-28 11:48:01 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:48:01 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:48:01 --> Utf8 Class Initialized
INFO - 2019-05-28 11:48:01 --> URI Class Initialized
INFO - 2019-05-28 11:48:01 --> Router Class Initialized
INFO - 2019-05-28 11:48:01 --> Output Class Initialized
INFO - 2019-05-28 11:48:01 --> Security Class Initialized
DEBUG - 2019-05-28 11:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:48:01 --> Input Class Initialized
INFO - 2019-05-28 11:48:01 --> Language Class Initialized
ERROR - 2019-05-28 11:48:01 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:48:01 --> Config Class Initialized
INFO - 2019-05-28 11:48:01 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:48:01 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:48:01 --> Utf8 Class Initialized
INFO - 2019-05-28 11:48:01 --> URI Class Initialized
INFO - 2019-05-28 11:48:01 --> Router Class Initialized
INFO - 2019-05-28 11:48:01 --> Output Class Initialized
INFO - 2019-05-28 11:48:01 --> Security Class Initialized
DEBUG - 2019-05-28 11:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:48:01 --> Input Class Initialized
INFO - 2019-05-28 11:48:01 --> Language Class Initialized
ERROR - 2019-05-28 11:48:01 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:48:03 --> Config Class Initialized
INFO - 2019-05-28 11:48:03 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:48:03 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:48:03 --> Utf8 Class Initialized
INFO - 2019-05-28 11:48:03 --> URI Class Initialized
DEBUG - 2019-05-28 11:48:03 --> No URI present. Default controller set.
INFO - 2019-05-28 11:48:03 --> Router Class Initialized
INFO - 2019-05-28 11:48:03 --> Output Class Initialized
INFO - 2019-05-28 11:48:03 --> Security Class Initialized
DEBUG - 2019-05-28 11:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:48:03 --> Input Class Initialized
INFO - 2019-05-28 11:48:03 --> Language Class Initialized
INFO - 2019-05-28 11:48:03 --> Language Class Initialized
INFO - 2019-05-28 11:48:03 --> Config Class Initialized
INFO - 2019-05-28 11:48:03 --> Loader Class Initialized
INFO - 2019-05-28 11:48:03 --> Helper loaded: form_helper
INFO - 2019-05-28 11:48:03 --> Helper loaded: url_helper
INFO - 2019-05-28 11:48:03 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:48:03 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:48:03 --> Template library initialized
INFO - 2019-05-28 11:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:48:03 --> Controller Class Initialized
DEBUG - 2019-05-28 11:48:03 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:48:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:48:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:48:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:48:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:48:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:48:03 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:48:04 --> Final output sent to browser
DEBUG - 2019-05-28 11:48:04 --> Total execution time: 0.0454
INFO - 2019-05-28 11:54:06 --> Config Class Initialized
INFO - 2019-05-28 11:54:06 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:54:06 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:54:06 --> Utf8 Class Initialized
INFO - 2019-05-28 11:54:06 --> URI Class Initialized
DEBUG - 2019-05-28 11:54:06 --> No URI present. Default controller set.
INFO - 2019-05-28 11:54:06 --> Router Class Initialized
INFO - 2019-05-28 11:54:06 --> Output Class Initialized
INFO - 2019-05-28 11:54:06 --> Security Class Initialized
DEBUG - 2019-05-28 11:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:54:06 --> Input Class Initialized
INFO - 2019-05-28 11:54:06 --> Language Class Initialized
INFO - 2019-05-28 11:54:06 --> Language Class Initialized
INFO - 2019-05-28 11:54:06 --> Config Class Initialized
INFO - 2019-05-28 11:54:06 --> Loader Class Initialized
INFO - 2019-05-28 11:54:06 --> Helper loaded: form_helper
INFO - 2019-05-28 11:54:06 --> Helper loaded: url_helper
INFO - 2019-05-28 11:54:06 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:54:06 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:54:06 --> Template library initialized
INFO - 2019-05-28 11:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:54:06 --> Controller Class Initialized
DEBUG - 2019-05-28 11:54:06 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:54:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:54:06 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
ERROR - 2019-05-28 11:54:06 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php 37
INFO - 2019-05-28 11:54:08 --> Config Class Initialized
INFO - 2019-05-28 11:54:08 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:54:08 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:54:08 --> Utf8 Class Initialized
INFO - 2019-05-28 11:54:08 --> URI Class Initialized
DEBUG - 2019-05-28 11:54:08 --> No URI present. Default controller set.
INFO - 2019-05-28 11:54:08 --> Router Class Initialized
INFO - 2019-05-28 11:54:08 --> Output Class Initialized
INFO - 2019-05-28 11:54:08 --> Security Class Initialized
DEBUG - 2019-05-28 11:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:54:08 --> Input Class Initialized
INFO - 2019-05-28 11:54:08 --> Language Class Initialized
INFO - 2019-05-28 11:54:08 --> Language Class Initialized
INFO - 2019-05-28 11:54:08 --> Config Class Initialized
INFO - 2019-05-28 11:54:08 --> Loader Class Initialized
INFO - 2019-05-28 11:54:08 --> Helper loaded: form_helper
INFO - 2019-05-28 11:54:08 --> Helper loaded: url_helper
INFO - 2019-05-28 11:54:08 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:54:08 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:54:08 --> Template library initialized
INFO - 2019-05-28 11:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:54:08 --> Controller Class Initialized
DEBUG - 2019-05-28 11:54:08 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:54:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:54:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
ERROR - 2019-05-28 11:54:08 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php 37
INFO - 2019-05-28 11:54:09 --> Config Class Initialized
INFO - 2019-05-28 11:54:09 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:54:09 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:54:09 --> Utf8 Class Initialized
INFO - 2019-05-28 11:54:09 --> URI Class Initialized
DEBUG - 2019-05-28 11:54:09 --> No URI present. Default controller set.
INFO - 2019-05-28 11:54:09 --> Router Class Initialized
INFO - 2019-05-28 11:54:09 --> Output Class Initialized
INFO - 2019-05-28 11:54:09 --> Security Class Initialized
DEBUG - 2019-05-28 11:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:54:09 --> Input Class Initialized
INFO - 2019-05-28 11:54:09 --> Language Class Initialized
INFO - 2019-05-28 11:54:09 --> Language Class Initialized
INFO - 2019-05-28 11:54:09 --> Config Class Initialized
INFO - 2019-05-28 11:54:09 --> Loader Class Initialized
INFO - 2019-05-28 11:54:09 --> Helper loaded: form_helper
INFO - 2019-05-28 11:54:09 --> Helper loaded: url_helper
INFO - 2019-05-28 11:54:09 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:54:09 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:54:09 --> Template library initialized
INFO - 2019-05-28 11:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:54:09 --> Controller Class Initialized
DEBUG - 2019-05-28 11:54:09 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:54:09 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:54:09 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
ERROR - 2019-05-28 11:54:09 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php 37
INFO - 2019-05-28 11:54:10 --> Config Class Initialized
INFO - 2019-05-28 11:54:10 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:54:10 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:54:10 --> Utf8 Class Initialized
INFO - 2019-05-28 11:54:10 --> URI Class Initialized
DEBUG - 2019-05-28 11:54:10 --> No URI present. Default controller set.
INFO - 2019-05-28 11:54:10 --> Router Class Initialized
INFO - 2019-05-28 11:54:10 --> Output Class Initialized
INFO - 2019-05-28 11:54:10 --> Security Class Initialized
DEBUG - 2019-05-28 11:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:54:10 --> Input Class Initialized
INFO - 2019-05-28 11:54:10 --> Language Class Initialized
INFO - 2019-05-28 11:54:10 --> Language Class Initialized
INFO - 2019-05-28 11:54:10 --> Config Class Initialized
INFO - 2019-05-28 11:54:10 --> Loader Class Initialized
INFO - 2019-05-28 11:54:10 --> Helper loaded: form_helper
INFO - 2019-05-28 11:54:10 --> Helper loaded: url_helper
INFO - 2019-05-28 11:54:10 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:54:10 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:54:10 --> Template library initialized
INFO - 2019-05-28 11:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:54:10 --> Controller Class Initialized
DEBUG - 2019-05-28 11:54:10 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:54:10 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:54:10 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
ERROR - 2019-05-28 11:54:10 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php 37
INFO - 2019-05-28 11:54:11 --> Config Class Initialized
INFO - 2019-05-28 11:54:11 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:54:11 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:54:11 --> Utf8 Class Initialized
INFO - 2019-05-28 11:54:11 --> URI Class Initialized
DEBUG - 2019-05-28 11:54:11 --> No URI present. Default controller set.
INFO - 2019-05-28 11:54:11 --> Router Class Initialized
INFO - 2019-05-28 11:54:11 --> Output Class Initialized
INFO - 2019-05-28 11:54:11 --> Security Class Initialized
DEBUG - 2019-05-28 11:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:54:11 --> Input Class Initialized
INFO - 2019-05-28 11:54:11 --> Language Class Initialized
INFO - 2019-05-28 11:54:11 --> Language Class Initialized
INFO - 2019-05-28 11:54:11 --> Config Class Initialized
INFO - 2019-05-28 11:54:11 --> Loader Class Initialized
INFO - 2019-05-28 11:54:11 --> Helper loaded: form_helper
INFO - 2019-05-28 11:54:11 --> Helper loaded: url_helper
INFO - 2019-05-28 11:54:11 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:54:11 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:54:11 --> Template library initialized
INFO - 2019-05-28 11:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:54:11 --> Controller Class Initialized
DEBUG - 2019-05-28 11:54:11 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:54:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:54:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
ERROR - 2019-05-28 11:54:11 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php 37
INFO - 2019-05-28 11:54:12 --> Config Class Initialized
INFO - 2019-05-28 11:54:12 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:54:12 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:54:12 --> Utf8 Class Initialized
INFO - 2019-05-28 11:54:12 --> URI Class Initialized
DEBUG - 2019-05-28 11:54:12 --> No URI present. Default controller set.
INFO - 2019-05-28 11:54:12 --> Router Class Initialized
INFO - 2019-05-28 11:54:12 --> Output Class Initialized
INFO - 2019-05-28 11:54:12 --> Security Class Initialized
DEBUG - 2019-05-28 11:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:54:12 --> Input Class Initialized
INFO - 2019-05-28 11:54:12 --> Language Class Initialized
INFO - 2019-05-28 11:54:12 --> Language Class Initialized
INFO - 2019-05-28 11:54:12 --> Config Class Initialized
INFO - 2019-05-28 11:54:12 --> Loader Class Initialized
INFO - 2019-05-28 11:54:12 --> Helper loaded: form_helper
INFO - 2019-05-28 11:54:12 --> Helper loaded: url_helper
INFO - 2019-05-28 11:54:12 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:54:12 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:54:12 --> Template library initialized
INFO - 2019-05-28 11:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:54:12 --> Controller Class Initialized
DEBUG - 2019-05-28 11:54:12 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:54:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:54:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
ERROR - 2019-05-28 11:54:12 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php 37
INFO - 2019-05-28 11:54:13 --> Config Class Initialized
INFO - 2019-05-28 11:54:13 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:54:13 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:54:13 --> Utf8 Class Initialized
INFO - 2019-05-28 11:54:13 --> URI Class Initialized
DEBUG - 2019-05-28 11:54:13 --> No URI present. Default controller set.
INFO - 2019-05-28 11:54:13 --> Router Class Initialized
INFO - 2019-05-28 11:54:13 --> Output Class Initialized
INFO - 2019-05-28 11:54:13 --> Security Class Initialized
DEBUG - 2019-05-28 11:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:54:13 --> Input Class Initialized
INFO - 2019-05-28 11:54:13 --> Language Class Initialized
INFO - 2019-05-28 11:54:13 --> Language Class Initialized
INFO - 2019-05-28 11:54:13 --> Config Class Initialized
INFO - 2019-05-28 11:54:13 --> Loader Class Initialized
INFO - 2019-05-28 11:54:13 --> Helper loaded: form_helper
INFO - 2019-05-28 11:54:13 --> Helper loaded: url_helper
INFO - 2019-05-28 11:54:13 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:54:13 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:54:13 --> Template library initialized
INFO - 2019-05-28 11:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:54:13 --> Controller Class Initialized
DEBUG - 2019-05-28 11:54:13 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:54:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:54:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
ERROR - 2019-05-28 11:54:13 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php 37
INFO - 2019-05-28 11:54:14 --> Config Class Initialized
INFO - 2019-05-28 11:54:14 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:54:14 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:54:14 --> Utf8 Class Initialized
INFO - 2019-05-28 11:54:14 --> URI Class Initialized
DEBUG - 2019-05-28 11:54:14 --> No URI present. Default controller set.
INFO - 2019-05-28 11:54:14 --> Router Class Initialized
INFO - 2019-05-28 11:54:14 --> Output Class Initialized
INFO - 2019-05-28 11:54:14 --> Security Class Initialized
DEBUG - 2019-05-28 11:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:54:14 --> Input Class Initialized
INFO - 2019-05-28 11:54:14 --> Language Class Initialized
INFO - 2019-05-28 11:54:14 --> Language Class Initialized
INFO - 2019-05-28 11:54:14 --> Config Class Initialized
INFO - 2019-05-28 11:54:14 --> Loader Class Initialized
INFO - 2019-05-28 11:54:14 --> Helper loaded: form_helper
INFO - 2019-05-28 11:54:14 --> Helper loaded: url_helper
INFO - 2019-05-28 11:54:14 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:54:14 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:54:14 --> Template library initialized
INFO - 2019-05-28 11:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:54:14 --> Controller Class Initialized
DEBUG - 2019-05-28 11:54:14 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:54:14 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:54:14 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
ERROR - 2019-05-28 11:54:14 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php 37
INFO - 2019-05-28 11:54:17 --> Config Class Initialized
INFO - 2019-05-28 11:54:17 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:54:17 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:54:17 --> Utf8 Class Initialized
INFO - 2019-05-28 11:54:17 --> URI Class Initialized
DEBUG - 2019-05-28 11:54:17 --> No URI present. Default controller set.
INFO - 2019-05-28 11:54:17 --> Router Class Initialized
INFO - 2019-05-28 11:54:17 --> Output Class Initialized
INFO - 2019-05-28 11:54:17 --> Security Class Initialized
DEBUG - 2019-05-28 11:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:54:17 --> Input Class Initialized
INFO - 2019-05-28 11:54:17 --> Language Class Initialized
INFO - 2019-05-28 11:54:17 --> Language Class Initialized
INFO - 2019-05-28 11:54:17 --> Config Class Initialized
INFO - 2019-05-28 11:54:17 --> Loader Class Initialized
INFO - 2019-05-28 11:54:17 --> Helper loaded: form_helper
INFO - 2019-05-28 11:54:17 --> Helper loaded: url_helper
INFO - 2019-05-28 11:54:17 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:54:17 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:54:17 --> Template library initialized
INFO - 2019-05-28 11:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:54:17 --> Controller Class Initialized
DEBUG - 2019-05-28 11:54:17 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:54:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:54:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
ERROR - 2019-05-28 11:54:17 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php 37
INFO - 2019-05-28 11:54:17 --> Config Class Initialized
INFO - 2019-05-28 11:54:17 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:54:17 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:54:17 --> Utf8 Class Initialized
INFO - 2019-05-28 11:54:17 --> URI Class Initialized
DEBUG - 2019-05-28 11:54:17 --> No URI present. Default controller set.
INFO - 2019-05-28 11:54:17 --> Router Class Initialized
INFO - 2019-05-28 11:54:17 --> Output Class Initialized
INFO - 2019-05-28 11:54:17 --> Security Class Initialized
DEBUG - 2019-05-28 11:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:54:17 --> Input Class Initialized
INFO - 2019-05-28 11:54:17 --> Language Class Initialized
INFO - 2019-05-28 11:54:17 --> Language Class Initialized
INFO - 2019-05-28 11:54:17 --> Config Class Initialized
INFO - 2019-05-28 11:54:17 --> Loader Class Initialized
INFO - 2019-05-28 11:54:17 --> Helper loaded: form_helper
INFO - 2019-05-28 11:54:17 --> Helper loaded: url_helper
INFO - 2019-05-28 11:54:17 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:54:17 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:54:17 --> Template library initialized
INFO - 2019-05-28 11:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:54:17 --> Controller Class Initialized
DEBUG - 2019-05-28 11:54:17 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:54:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:54:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
ERROR - 2019-05-28 11:54:17 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php 37
INFO - 2019-05-28 11:54:18 --> Config Class Initialized
INFO - 2019-05-28 11:54:18 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:54:18 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:54:18 --> Utf8 Class Initialized
INFO - 2019-05-28 11:54:18 --> URI Class Initialized
DEBUG - 2019-05-28 11:54:18 --> No URI present. Default controller set.
INFO - 2019-05-28 11:54:18 --> Router Class Initialized
INFO - 2019-05-28 11:54:18 --> Output Class Initialized
INFO - 2019-05-28 11:54:18 --> Security Class Initialized
DEBUG - 2019-05-28 11:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:54:18 --> Input Class Initialized
INFO - 2019-05-28 11:54:18 --> Language Class Initialized
INFO - 2019-05-28 11:54:18 --> Language Class Initialized
INFO - 2019-05-28 11:54:18 --> Config Class Initialized
INFO - 2019-05-28 11:54:18 --> Loader Class Initialized
INFO - 2019-05-28 11:54:18 --> Helper loaded: form_helper
INFO - 2019-05-28 11:54:18 --> Helper loaded: url_helper
INFO - 2019-05-28 11:54:18 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:54:18 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:54:18 --> Template library initialized
INFO - 2019-05-28 11:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:54:18 --> Controller Class Initialized
DEBUG - 2019-05-28 11:54:18 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:54:18 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:54:18 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
ERROR - 2019-05-28 11:54:18 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php 37
INFO - 2019-05-28 11:54:57 --> Config Class Initialized
INFO - 2019-05-28 11:54:57 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:54:57 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:54:57 --> Utf8 Class Initialized
INFO - 2019-05-28 11:54:57 --> URI Class Initialized
DEBUG - 2019-05-28 11:54:57 --> No URI present. Default controller set.
INFO - 2019-05-28 11:54:57 --> Router Class Initialized
INFO - 2019-05-28 11:54:57 --> Output Class Initialized
INFO - 2019-05-28 11:54:57 --> Security Class Initialized
DEBUG - 2019-05-28 11:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:54:57 --> Input Class Initialized
INFO - 2019-05-28 11:54:57 --> Language Class Initialized
INFO - 2019-05-28 11:54:57 --> Language Class Initialized
INFO - 2019-05-28 11:54:57 --> Config Class Initialized
INFO - 2019-05-28 11:54:57 --> Loader Class Initialized
INFO - 2019-05-28 11:54:57 --> Helper loaded: form_helper
INFO - 2019-05-28 11:54:57 --> Helper loaded: url_helper
INFO - 2019-05-28 11:54:57 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:54:57 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:54:57 --> Template library initialized
INFO - 2019-05-28 11:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:54:57 --> Controller Class Initialized
DEBUG - 2019-05-28 11:54:57 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:54:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:54:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:54:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:54:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:54:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:54:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:54:58 --> Config Class Initialized
INFO - 2019-05-28 11:54:58 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:54:58 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:54:58 --> Utf8 Class Initialized
INFO - 2019-05-28 11:54:58 --> URI Class Initialized
DEBUG - 2019-05-28 11:54:58 --> No URI present. Default controller set.
INFO - 2019-05-28 11:54:58 --> Router Class Initialized
INFO - 2019-05-28 11:54:58 --> Output Class Initialized
INFO - 2019-05-28 11:54:58 --> Security Class Initialized
DEBUG - 2019-05-28 11:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:54:58 --> Input Class Initialized
INFO - 2019-05-28 11:54:58 --> Language Class Initialized
INFO - 2019-05-28 11:54:58 --> Language Class Initialized
INFO - 2019-05-28 11:54:58 --> Config Class Initialized
INFO - 2019-05-28 11:54:58 --> Loader Class Initialized
INFO - 2019-05-28 11:54:58 --> Helper loaded: form_helper
INFO - 2019-05-28 11:54:58 --> Helper loaded: url_helper
INFO - 2019-05-28 11:54:58 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:54:58 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:54:58 --> Template library initialized
INFO - 2019-05-28 11:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:54:58 --> Controller Class Initialized
DEBUG - 2019-05-28 11:54:58 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:54:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:54:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:54:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:54:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:54:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:54:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:54:58 --> Final output sent to browser
DEBUG - 2019-05-28 11:54:58 --> Total execution time: 0.0580
INFO - 2019-05-28 11:55:01 --> Config Class Initialized
INFO - 2019-05-28 11:55:01 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:55:01 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:55:01 --> Utf8 Class Initialized
INFO - 2019-05-28 11:55:01 --> URI Class Initialized
INFO - 2019-05-28 11:55:01 --> Router Class Initialized
INFO - 2019-05-28 11:55:01 --> Output Class Initialized
INFO - 2019-05-28 11:55:01 --> Security Class Initialized
DEBUG - 2019-05-28 11:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:55:01 --> Input Class Initialized
INFO - 2019-05-28 11:55:01 --> Language Class Initialized
ERROR - 2019-05-28 11:55:01 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:55:02 --> Config Class Initialized
INFO - 2019-05-28 11:55:02 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:55:02 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:55:02 --> Utf8 Class Initialized
INFO - 2019-05-28 11:55:02 --> URI Class Initialized
INFO - 2019-05-28 11:55:02 --> Router Class Initialized
INFO - 2019-05-28 11:55:02 --> Output Class Initialized
INFO - 2019-05-28 11:55:02 --> Security Class Initialized
DEBUG - 2019-05-28 11:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:55:02 --> Input Class Initialized
INFO - 2019-05-28 11:55:02 --> Language Class Initialized
ERROR - 2019-05-28 11:55:02 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:55:02 --> Config Class Initialized
INFO - 2019-05-28 11:55:02 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:55:02 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:55:02 --> Utf8 Class Initialized
INFO - 2019-05-28 11:55:02 --> URI Class Initialized
INFO - 2019-05-28 11:55:02 --> Router Class Initialized
INFO - 2019-05-28 11:55:02 --> Output Class Initialized
INFO - 2019-05-28 11:55:02 --> Security Class Initialized
DEBUG - 2019-05-28 11:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:55:02 --> Input Class Initialized
INFO - 2019-05-28 11:55:02 --> Language Class Initialized
ERROR - 2019-05-28 11:55:02 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:55:02 --> Config Class Initialized
INFO - 2019-05-28 11:55:02 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:55:02 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:55:02 --> Utf8 Class Initialized
INFO - 2019-05-28 11:55:02 --> URI Class Initialized
INFO - 2019-05-28 11:55:02 --> Router Class Initialized
INFO - 2019-05-28 11:55:02 --> Output Class Initialized
INFO - 2019-05-28 11:55:02 --> Security Class Initialized
DEBUG - 2019-05-28 11:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:55:02 --> Input Class Initialized
INFO - 2019-05-28 11:55:02 --> Language Class Initialized
ERROR - 2019-05-28 11:55:02 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:55:26 --> Config Class Initialized
INFO - 2019-05-28 11:55:26 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:55:26 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:55:26 --> Utf8 Class Initialized
INFO - 2019-05-28 11:55:26 --> URI Class Initialized
INFO - 2019-05-28 11:55:26 --> Router Class Initialized
INFO - 2019-05-28 11:55:26 --> Output Class Initialized
INFO - 2019-05-28 11:55:26 --> Security Class Initialized
DEBUG - 2019-05-28 11:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:55:26 --> Input Class Initialized
INFO - 2019-05-28 11:55:26 --> Language Class Initialized
INFO - 2019-05-28 11:55:26 --> Language Class Initialized
INFO - 2019-05-28 11:55:26 --> Config Class Initialized
INFO - 2019-05-28 11:55:26 --> Loader Class Initialized
INFO - 2019-05-28 11:55:26 --> Helper loaded: form_helper
INFO - 2019-05-28 11:55:26 --> Helper loaded: url_helper
INFO - 2019-05-28 11:55:26 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:55:26 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:55:26 --> Template library initialized
INFO - 2019-05-28 11:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:55:26 --> Controller Class Initialized
DEBUG - 2019-05-28 11:55:26 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 11:55:26 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 11:55:26 --> Final output sent to browser
DEBUG - 2019-05-28 11:55:26 --> Total execution time: 0.0451
INFO - 2019-05-28 11:56:04 --> Config Class Initialized
INFO - 2019-05-28 11:56:04 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:56:04 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:56:04 --> Utf8 Class Initialized
INFO - 2019-05-28 11:56:04 --> URI Class Initialized
INFO - 2019-05-28 11:56:04 --> Router Class Initialized
INFO - 2019-05-28 11:56:04 --> Output Class Initialized
INFO - 2019-05-28 11:56:04 --> Security Class Initialized
DEBUG - 2019-05-28 11:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:56:04 --> Input Class Initialized
INFO - 2019-05-28 11:56:04 --> Language Class Initialized
INFO - 2019-05-28 11:56:04 --> Language Class Initialized
INFO - 2019-05-28 11:56:04 --> Config Class Initialized
INFO - 2019-05-28 11:56:04 --> Loader Class Initialized
INFO - 2019-05-28 11:56:04 --> Helper loaded: form_helper
INFO - 2019-05-28 11:56:04 --> Helper loaded: url_helper
INFO - 2019-05-28 11:56:04 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:56:04 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:56:04 --> Template library initialized
INFO - 2019-05-28 11:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:56:04 --> Controller Class Initialized
DEBUG - 2019-05-28 11:56:04 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 11:56:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 11:56:04 --> Final output sent to browser
DEBUG - 2019-05-28 11:56:04 --> Total execution time: 0.0386
INFO - 2019-05-28 11:56:04 --> Config Class Initialized
INFO - 2019-05-28 11:56:04 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:56:04 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:56:04 --> Utf8 Class Initialized
INFO - 2019-05-28 11:56:04 --> URI Class Initialized
DEBUG - 2019-05-28 11:56:04 --> No URI present. Default controller set.
INFO - 2019-05-28 11:56:04 --> Router Class Initialized
INFO - 2019-05-28 11:56:04 --> Output Class Initialized
INFO - 2019-05-28 11:56:04 --> Security Class Initialized
DEBUG - 2019-05-28 11:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:56:04 --> Input Class Initialized
INFO - 2019-05-28 11:56:04 --> Language Class Initialized
INFO - 2019-05-28 11:56:04 --> Language Class Initialized
INFO - 2019-05-28 11:56:04 --> Config Class Initialized
INFO - 2019-05-28 11:56:04 --> Loader Class Initialized
INFO - 2019-05-28 11:56:04 --> Helper loaded: form_helper
INFO - 2019-05-28 11:56:04 --> Helper loaded: url_helper
INFO - 2019-05-28 11:56:04 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:56:04 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:56:04 --> Template library initialized
INFO - 2019-05-28 11:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:56:04 --> Controller Class Initialized
DEBUG - 2019-05-28 11:56:04 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:56:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:56:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:56:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:56:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:56:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:56:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:56:04 --> Final output sent to browser
DEBUG - 2019-05-28 11:56:04 --> Total execution time: 0.0524
INFO - 2019-05-28 11:56:05 --> Config Class Initialized
INFO - 2019-05-28 11:56:05 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:56:05 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:56:05 --> Utf8 Class Initialized
INFO - 2019-05-28 11:56:05 --> Config Class Initialized
INFO - 2019-05-28 11:56:05 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:56:05 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:56:05 --> Utf8 Class Initialized
INFO - 2019-05-28 11:56:05 --> URI Class Initialized
INFO - 2019-05-28 11:56:05 --> Config Class Initialized
INFO - 2019-05-28 11:56:05 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:56:05 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:56:05 --> Utf8 Class Initialized
INFO - 2019-05-28 11:56:05 --> URI Class Initialized
INFO - 2019-05-28 11:56:05 --> Router Class Initialized
INFO - 2019-05-28 11:56:05 --> Output Class Initialized
INFO - 2019-05-28 11:56:05 --> Security Class Initialized
DEBUG - 2019-05-28 11:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:56:05 --> Input Class Initialized
INFO - 2019-05-28 11:56:05 --> Language Class Initialized
ERROR - 2019-05-28 11:56:05 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:56:05 --> URI Class Initialized
INFO - 2019-05-28 11:56:05 --> Router Class Initialized
INFO - 2019-05-28 11:56:05 --> Output Class Initialized
INFO - 2019-05-28 11:56:05 --> Security Class Initialized
DEBUG - 2019-05-28 11:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:56:05 --> Input Class Initialized
INFO - 2019-05-28 11:56:05 --> Language Class Initialized
ERROR - 2019-05-28 11:56:05 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:56:05 --> Router Class Initialized
INFO - 2019-05-28 11:56:05 --> Output Class Initialized
INFO - 2019-05-28 11:56:05 --> Security Class Initialized
DEBUG - 2019-05-28 11:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:56:05 --> Input Class Initialized
INFO - 2019-05-28 11:56:05 --> Language Class Initialized
ERROR - 2019-05-28 11:56:05 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:56:43 --> Config Class Initialized
INFO - 2019-05-28 11:56:43 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:56:43 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:56:43 --> Utf8 Class Initialized
INFO - 2019-05-28 11:56:43 --> URI Class Initialized
DEBUG - 2019-05-28 11:56:43 --> No URI present. Default controller set.
INFO - 2019-05-28 11:56:43 --> Router Class Initialized
INFO - 2019-05-28 11:56:43 --> Output Class Initialized
INFO - 2019-05-28 11:56:43 --> Security Class Initialized
DEBUG - 2019-05-28 11:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:56:43 --> Input Class Initialized
INFO - 2019-05-28 11:56:43 --> Language Class Initialized
INFO - 2019-05-28 11:56:43 --> Language Class Initialized
INFO - 2019-05-28 11:56:43 --> Config Class Initialized
INFO - 2019-05-28 11:56:43 --> Loader Class Initialized
INFO - 2019-05-28 11:56:43 --> Helper loaded: form_helper
INFO - 2019-05-28 11:56:43 --> Helper loaded: url_helper
INFO - 2019-05-28 11:56:43 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:56:43 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:56:43 --> Template library initialized
INFO - 2019-05-28 11:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:56:43 --> Controller Class Initialized
DEBUG - 2019-05-28 11:56:43 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:56:43 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:56:43 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:56:43 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:56:43 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:56:43 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:56:43 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:56:43 --> Final output sent to browser
DEBUG - 2019-05-28 11:56:43 --> Total execution time: 0.0461
INFO - 2019-05-28 11:56:43 --> Config Class Initialized
INFO - 2019-05-28 11:56:43 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:56:43 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:56:43 --> Utf8 Class Initialized
INFO - 2019-05-28 11:56:43 --> URI Class Initialized
INFO - 2019-05-28 11:56:43 --> Router Class Initialized
INFO - 2019-05-28 11:56:43 --> Output Class Initialized
INFO - 2019-05-28 11:56:43 --> Security Class Initialized
DEBUG - 2019-05-28 11:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:56:43 --> Input Class Initialized
INFO - 2019-05-28 11:56:43 --> Language Class Initialized
ERROR - 2019-05-28 11:56:43 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:56:44 --> Config Class Initialized
INFO - 2019-05-28 11:56:44 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:56:44 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:56:44 --> Utf8 Class Initialized
INFO - 2019-05-28 11:56:44 --> URI Class Initialized
INFO - 2019-05-28 11:56:44 --> Router Class Initialized
INFO - 2019-05-28 11:56:44 --> Output Class Initialized
INFO - 2019-05-28 11:56:44 --> Security Class Initialized
DEBUG - 2019-05-28 11:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:56:44 --> Input Class Initialized
INFO - 2019-05-28 11:56:44 --> Language Class Initialized
INFO - 2019-05-28 11:56:44 --> Config Class Initialized
INFO - 2019-05-28 11:56:44 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:56:44 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:56:44 --> Utf8 Class Initialized
INFO - 2019-05-28 11:56:44 --> URI Class Initialized
INFO - 2019-05-28 11:56:44 --> Router Class Initialized
INFO - 2019-05-28 11:56:44 --> Output Class Initialized
ERROR - 2019-05-28 11:56:44 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:56:44 --> Security Class Initialized
DEBUG - 2019-05-28 11:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:56:44 --> Input Class Initialized
INFO - 2019-05-28 11:56:44 --> Language Class Initialized
ERROR - 2019-05-28 11:56:44 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:57:47 --> Config Class Initialized
INFO - 2019-05-28 11:57:47 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:57:47 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:57:47 --> Utf8 Class Initialized
INFO - 2019-05-28 11:57:47 --> URI Class Initialized
DEBUG - 2019-05-28 11:57:47 --> No URI present. Default controller set.
INFO - 2019-05-28 11:57:47 --> Router Class Initialized
INFO - 2019-05-28 11:57:47 --> Output Class Initialized
INFO - 2019-05-28 11:57:47 --> Security Class Initialized
DEBUG - 2019-05-28 11:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:57:47 --> Input Class Initialized
INFO - 2019-05-28 11:57:47 --> Language Class Initialized
INFO - 2019-05-28 11:57:47 --> Language Class Initialized
INFO - 2019-05-28 11:57:47 --> Config Class Initialized
INFO - 2019-05-28 11:57:47 --> Loader Class Initialized
INFO - 2019-05-28 11:57:47 --> Helper loaded: form_helper
INFO - 2019-05-28 11:57:47 --> Helper loaded: url_helper
INFO - 2019-05-28 11:57:47 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:57:47 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:57:47 --> Template library initialized
INFO - 2019-05-28 11:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:57:47 --> Controller Class Initialized
DEBUG - 2019-05-28 11:57:47 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:57:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:57:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:57:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:57:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:57:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:57:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:57:47 --> Config Class Initialized
INFO - 2019-05-28 11:57:47 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:57:47 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:57:47 --> Utf8 Class Initialized
INFO - 2019-05-28 11:57:47 --> URI Class Initialized
DEBUG - 2019-05-28 11:57:47 --> No URI present. Default controller set.
INFO - 2019-05-28 11:57:47 --> Router Class Initialized
INFO - 2019-05-28 11:57:47 --> Output Class Initialized
INFO - 2019-05-28 11:57:47 --> Security Class Initialized
DEBUG - 2019-05-28 11:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:57:47 --> Input Class Initialized
INFO - 2019-05-28 11:57:47 --> Language Class Initialized
INFO - 2019-05-28 11:57:47 --> Language Class Initialized
INFO - 2019-05-28 11:57:47 --> Config Class Initialized
INFO - 2019-05-28 11:57:47 --> Loader Class Initialized
INFO - 2019-05-28 11:57:47 --> Helper loaded: form_helper
INFO - 2019-05-28 11:57:47 --> Helper loaded: url_helper
INFO - 2019-05-28 11:57:47 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:57:47 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:57:47 --> Template library initialized
INFO - 2019-05-28 11:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:57:47 --> Controller Class Initialized
DEBUG - 2019-05-28 11:57:47 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:57:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:57:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
ERROR - 2019-05-28 11:57:47 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php 43
INFO - 2019-05-28 11:57:50 --> Config Class Initialized
INFO - 2019-05-28 11:57:50 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:57:50 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:57:50 --> Utf8 Class Initialized
INFO - 2019-05-28 11:57:50 --> URI Class Initialized
DEBUG - 2019-05-28 11:57:50 --> No URI present. Default controller set.
INFO - 2019-05-28 11:57:50 --> Router Class Initialized
INFO - 2019-05-28 11:57:50 --> Output Class Initialized
INFO - 2019-05-28 11:57:50 --> Security Class Initialized
DEBUG - 2019-05-28 11:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:57:50 --> Input Class Initialized
INFO - 2019-05-28 11:57:50 --> Language Class Initialized
INFO - 2019-05-28 11:57:50 --> Language Class Initialized
INFO - 2019-05-28 11:57:50 --> Config Class Initialized
INFO - 2019-05-28 11:57:50 --> Loader Class Initialized
INFO - 2019-05-28 11:57:50 --> Helper loaded: form_helper
INFO - 2019-05-28 11:57:50 --> Helper loaded: url_helper
INFO - 2019-05-28 11:57:50 --> Helper loaded: cookie_helper
INFO - 2019-05-28 11:57:50 --> Database Driver Class Initialized
DEBUG - 2019-05-28 11:57:50 --> Template library initialized
INFO - 2019-05-28 11:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 11:57:50 --> Controller Class Initialized
DEBUG - 2019-05-28 11:57:50 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 11:57:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 11:57:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 11:57:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 11:57:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 11:57:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 11:57:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 11:57:50 --> Final output sent to browser
DEBUG - 2019-05-28 11:57:50 --> Total execution time: 0.0479
INFO - 2019-05-28 11:57:50 --> Config Class Initialized
INFO - 2019-05-28 11:57:50 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:57:50 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:57:50 --> Utf8 Class Initialized
INFO - 2019-05-28 11:57:50 --> URI Class Initialized
INFO - 2019-05-28 11:57:50 --> Config Class Initialized
INFO - 2019-05-28 11:57:50 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:57:50 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:57:50 --> Utf8 Class Initialized
INFO - 2019-05-28 11:57:50 --> URI Class Initialized
INFO - 2019-05-28 11:57:50 --> Config Class Initialized
INFO - 2019-05-28 11:57:50 --> Hooks Class Initialized
DEBUG - 2019-05-28 11:57:50 --> UTF-8 Support Enabled
INFO - 2019-05-28 11:57:50 --> Utf8 Class Initialized
INFO - 2019-05-28 11:57:50 --> URI Class Initialized
INFO - 2019-05-28 11:57:50 --> Router Class Initialized
INFO - 2019-05-28 11:57:50 --> Output Class Initialized
INFO - 2019-05-28 11:57:50 --> Security Class Initialized
DEBUG - 2019-05-28 11:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:57:50 --> Input Class Initialized
INFO - 2019-05-28 11:57:50 --> Language Class Initialized
ERROR - 2019-05-28 11:57:50 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:57:50 --> Router Class Initialized
INFO - 2019-05-28 11:57:50 --> Output Class Initialized
INFO - 2019-05-28 11:57:50 --> Security Class Initialized
DEBUG - 2019-05-28 11:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:57:50 --> Input Class Initialized
INFO - 2019-05-28 11:57:50 --> Language Class Initialized
ERROR - 2019-05-28 11:57:50 --> 404 Page Not Found: /index
INFO - 2019-05-28 11:57:50 --> Router Class Initialized
INFO - 2019-05-28 11:57:50 --> Output Class Initialized
INFO - 2019-05-28 11:57:50 --> Security Class Initialized
DEBUG - 2019-05-28 11:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 11:57:50 --> Input Class Initialized
INFO - 2019-05-28 11:57:50 --> Language Class Initialized
ERROR - 2019-05-28 11:57:50 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:40:36 --> Config Class Initialized
INFO - 2019-05-28 12:40:36 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:40:36 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:40:36 --> Utf8 Class Initialized
INFO - 2019-05-28 12:40:36 --> URI Class Initialized
DEBUG - 2019-05-28 12:40:36 --> No URI present. Default controller set.
INFO - 2019-05-28 12:40:36 --> Router Class Initialized
INFO - 2019-05-28 12:40:36 --> Output Class Initialized
INFO - 2019-05-28 12:40:36 --> Security Class Initialized
DEBUG - 2019-05-28 12:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:40:36 --> Input Class Initialized
INFO - 2019-05-28 12:40:36 --> Language Class Initialized
INFO - 2019-05-28 12:40:36 --> Language Class Initialized
INFO - 2019-05-28 12:40:36 --> Config Class Initialized
INFO - 2019-05-28 12:40:36 --> Loader Class Initialized
INFO - 2019-05-28 12:40:36 --> Helper loaded: form_helper
INFO - 2019-05-28 12:40:36 --> Helper loaded: url_helper
INFO - 2019-05-28 12:40:36 --> Helper loaded: cookie_helper
INFO - 2019-05-28 12:40:36 --> Database Driver Class Initialized
DEBUG - 2019-05-28 12:40:36 --> Template library initialized
INFO - 2019-05-28 12:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 12:40:36 --> Controller Class Initialized
DEBUG - 2019-05-28 12:40:36 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 12:40:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 12:40:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 12:40:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 12:40:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 12:40:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 12:40:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 12:40:37 --> Final output sent to browser
DEBUG - 2019-05-28 12:40:37 --> Total execution time: 0.0459
INFO - 2019-05-28 12:40:37 --> Config Class Initialized
INFO - 2019-05-28 12:40:37 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:40:37 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:40:37 --> Utf8 Class Initialized
INFO - 2019-05-28 12:40:37 --> URI Class Initialized
INFO - 2019-05-28 12:40:37 --> Router Class Initialized
INFO - 2019-05-28 12:40:37 --> Output Class Initialized
INFO - 2019-05-28 12:40:37 --> Security Class Initialized
DEBUG - 2019-05-28 12:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:40:37 --> Input Class Initialized
INFO - 2019-05-28 12:40:37 --> Language Class Initialized
ERROR - 2019-05-28 12:40:37 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:40:37 --> Config Class Initialized
INFO - 2019-05-28 12:40:37 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:40:37 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:40:37 --> Utf8 Class Initialized
INFO - 2019-05-28 12:40:37 --> URI Class Initialized
INFO - 2019-05-28 12:40:37 --> Config Class Initialized
INFO - 2019-05-28 12:40:37 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:40:37 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:40:37 --> Utf8 Class Initialized
INFO - 2019-05-28 12:40:38 --> URI Class Initialized
INFO - 2019-05-28 12:40:38 --> Router Class Initialized
INFO - 2019-05-28 12:40:38 --> Output Class Initialized
INFO - 2019-05-28 12:40:38 --> Security Class Initialized
DEBUG - 2019-05-28 12:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:40:38 --> Input Class Initialized
INFO - 2019-05-28 12:40:38 --> Language Class Initialized
ERROR - 2019-05-28 12:40:38 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:40:38 --> Router Class Initialized
INFO - 2019-05-28 12:40:38 --> Output Class Initialized
INFO - 2019-05-28 12:40:38 --> Security Class Initialized
DEBUG - 2019-05-28 12:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:40:38 --> Input Class Initialized
INFO - 2019-05-28 12:40:38 --> Language Class Initialized
ERROR - 2019-05-28 12:40:38 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:40:40 --> Config Class Initialized
INFO - 2019-05-28 12:40:40 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:40:40 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:40:40 --> Utf8 Class Initialized
INFO - 2019-05-28 12:40:40 --> URI Class Initialized
INFO - 2019-05-28 12:40:40 --> Router Class Initialized
INFO - 2019-05-28 12:40:40 --> Output Class Initialized
INFO - 2019-05-28 12:40:40 --> Security Class Initialized
DEBUG - 2019-05-28 12:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:40:40 --> Input Class Initialized
INFO - 2019-05-28 12:40:40 --> Language Class Initialized
ERROR - 2019-05-28 12:40:40 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:40:49 --> Config Class Initialized
INFO - 2019-05-28 12:40:49 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:40:49 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:40:49 --> Utf8 Class Initialized
INFO - 2019-05-28 12:40:49 --> URI Class Initialized
INFO - 2019-05-28 12:40:49 --> Router Class Initialized
INFO - 2019-05-28 12:40:49 --> Output Class Initialized
INFO - 2019-05-28 12:40:49 --> Security Class Initialized
DEBUG - 2019-05-28 12:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:40:49 --> Input Class Initialized
INFO - 2019-05-28 12:40:49 --> Language Class Initialized
INFO - 2019-05-28 12:40:49 --> Language Class Initialized
INFO - 2019-05-28 12:40:49 --> Config Class Initialized
INFO - 2019-05-28 12:40:49 --> Loader Class Initialized
INFO - 2019-05-28 12:40:49 --> Helper loaded: form_helper
INFO - 2019-05-28 12:40:49 --> Helper loaded: url_helper
INFO - 2019-05-28 12:40:49 --> Helper loaded: cookie_helper
INFO - 2019-05-28 12:40:49 --> Database Driver Class Initialized
DEBUG - 2019-05-28 12:40:49 --> Template library initialized
INFO - 2019-05-28 12:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 12:40:49 --> Controller Class Initialized
DEBUG - 2019-05-28 12:40:49 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 12:40:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 12:40:49 --> Config Class Initialized
INFO - 2019-05-28 12:40:49 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:40:49 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:40:49 --> Utf8 Class Initialized
INFO - 2019-05-28 12:40:49 --> URI Class Initialized
DEBUG - 2019-05-28 12:40:49 --> No URI present. Default controller set.
INFO - 2019-05-28 12:40:49 --> Router Class Initialized
INFO - 2019-05-28 12:40:49 --> Output Class Initialized
INFO - 2019-05-28 12:40:49 --> Security Class Initialized
DEBUG - 2019-05-28 12:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:40:49 --> Input Class Initialized
INFO - 2019-05-28 12:40:49 --> Language Class Initialized
INFO - 2019-05-28 12:40:49 --> Language Class Initialized
INFO - 2019-05-28 12:40:49 --> Config Class Initialized
INFO - 2019-05-28 12:40:49 --> Loader Class Initialized
INFO - 2019-05-28 12:40:49 --> Helper loaded: form_helper
INFO - 2019-05-28 12:40:49 --> Helper loaded: url_helper
INFO - 2019-05-28 12:40:49 --> Helper loaded: cookie_helper
INFO - 2019-05-28 12:40:49 --> Database Driver Class Initialized
DEBUG - 2019-05-28 12:40:49 --> Template library initialized
INFO - 2019-05-28 12:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 12:40:49 --> Controller Class Initialized
DEBUG - 2019-05-28 12:40:49 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 12:40:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 12:40:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 12:40:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 12:40:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 12:40:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 12:40:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 12:40:49 --> Final output sent to browser
DEBUG - 2019-05-28 12:40:49 --> Total execution time: 0.0454
INFO - 2019-05-28 12:40:50 --> Config Class Initialized
INFO - 2019-05-28 12:40:50 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:40:50 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:40:50 --> Utf8 Class Initialized
INFO - 2019-05-28 12:40:50 --> URI Class Initialized
INFO - 2019-05-28 12:40:50 --> Config Class Initialized
INFO - 2019-05-28 12:40:50 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:40:50 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:40:50 --> Utf8 Class Initialized
INFO - 2019-05-28 12:40:50 --> URI Class Initialized
INFO - 2019-05-28 12:40:50 --> Router Class Initialized
INFO - 2019-05-28 12:40:50 --> Output Class Initialized
INFO - 2019-05-28 12:40:50 --> Security Class Initialized
DEBUG - 2019-05-28 12:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:40:50 --> Input Class Initialized
INFO - 2019-05-28 12:40:50 --> Language Class Initialized
ERROR - 2019-05-28 12:40:50 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:40:50 --> Router Class Initialized
INFO - 2019-05-28 12:40:50 --> Output Class Initialized
INFO - 2019-05-28 12:40:50 --> Security Class Initialized
DEBUG - 2019-05-28 12:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:40:50 --> Input Class Initialized
INFO - 2019-05-28 12:40:50 --> Language Class Initialized
ERROR - 2019-05-28 12:40:50 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:40:50 --> Config Class Initialized
INFO - 2019-05-28 12:40:50 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:40:50 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:40:50 --> Utf8 Class Initialized
INFO - 2019-05-28 12:40:50 --> URI Class Initialized
INFO - 2019-05-28 12:40:50 --> Router Class Initialized
INFO - 2019-05-28 12:40:50 --> Output Class Initialized
INFO - 2019-05-28 12:40:50 --> Security Class Initialized
DEBUG - 2019-05-28 12:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:40:50 --> Input Class Initialized
INFO - 2019-05-28 12:40:50 --> Language Class Initialized
ERROR - 2019-05-28 12:40:50 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:41:26 --> Config Class Initialized
INFO - 2019-05-28 12:41:26 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:41:26 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:41:26 --> Utf8 Class Initialized
INFO - 2019-05-28 12:41:26 --> URI Class Initialized
INFO - 2019-05-28 12:41:26 --> Router Class Initialized
INFO - 2019-05-28 12:41:26 --> Output Class Initialized
INFO - 2019-05-28 12:41:26 --> Security Class Initialized
DEBUG - 2019-05-28 12:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:41:26 --> Input Class Initialized
INFO - 2019-05-28 12:41:26 --> Language Class Initialized
INFO - 2019-05-28 12:41:26 --> Language Class Initialized
INFO - 2019-05-28 12:41:26 --> Config Class Initialized
INFO - 2019-05-28 12:41:26 --> Loader Class Initialized
INFO - 2019-05-28 12:41:26 --> Helper loaded: form_helper
INFO - 2019-05-28 12:41:26 --> Helper loaded: url_helper
INFO - 2019-05-28 12:41:26 --> Helper loaded: cookie_helper
INFO - 2019-05-28 12:41:26 --> Database Driver Class Initialized
DEBUG - 2019-05-28 12:41:26 --> Template library initialized
INFO - 2019-05-28 12:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 12:41:26 --> Controller Class Initialized
DEBUG - 2019-05-28 12:41:26 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 12:41:26 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 12:41:26 --> Final output sent to browser
DEBUG - 2019-05-28 12:41:26 --> Total execution time: 0.0384
INFO - 2019-05-28 12:42:08 --> Config Class Initialized
INFO - 2019-05-28 12:42:08 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:42:08 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:42:08 --> Utf8 Class Initialized
INFO - 2019-05-28 12:42:08 --> URI Class Initialized
INFO - 2019-05-28 12:42:08 --> Router Class Initialized
INFO - 2019-05-28 12:42:08 --> Output Class Initialized
INFO - 2019-05-28 12:42:08 --> Security Class Initialized
DEBUG - 2019-05-28 12:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:42:08 --> Input Class Initialized
INFO - 2019-05-28 12:42:08 --> Language Class Initialized
INFO - 2019-05-28 12:42:08 --> Language Class Initialized
INFO - 2019-05-28 12:42:08 --> Config Class Initialized
INFO - 2019-05-28 12:42:08 --> Loader Class Initialized
INFO - 2019-05-28 12:42:08 --> Helper loaded: form_helper
INFO - 2019-05-28 12:42:08 --> Helper loaded: url_helper
INFO - 2019-05-28 12:42:08 --> Helper loaded: cookie_helper
INFO - 2019-05-28 12:42:08 --> Database Driver Class Initialized
DEBUG - 2019-05-28 12:42:08 --> Template library initialized
INFO - 2019-05-28 12:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 12:42:08 --> Controller Class Initialized
DEBUG - 2019-05-28 12:42:08 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 12:42:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 12:42:08 --> Final output sent to browser
DEBUG - 2019-05-28 12:42:08 --> Total execution time: 0.0368
INFO - 2019-05-28 12:42:12 --> Config Class Initialized
INFO - 2019-05-28 12:42:12 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:42:12 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:42:12 --> Utf8 Class Initialized
INFO - 2019-05-28 12:42:12 --> URI Class Initialized
INFO - 2019-05-28 12:42:12 --> Router Class Initialized
INFO - 2019-05-28 12:42:12 --> Output Class Initialized
INFO - 2019-05-28 12:42:12 --> Security Class Initialized
DEBUG - 2019-05-28 12:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:42:12 --> Input Class Initialized
INFO - 2019-05-28 12:42:12 --> Language Class Initialized
INFO - 2019-05-28 12:42:12 --> Language Class Initialized
INFO - 2019-05-28 12:42:12 --> Config Class Initialized
INFO - 2019-05-28 12:42:12 --> Loader Class Initialized
INFO - 2019-05-28 12:42:12 --> Helper loaded: form_helper
INFO - 2019-05-28 12:42:12 --> Helper loaded: url_helper
INFO - 2019-05-28 12:42:12 --> Helper loaded: cookie_helper
INFO - 2019-05-28 12:42:12 --> Database Driver Class Initialized
DEBUG - 2019-05-28 12:42:12 --> Template library initialized
INFO - 2019-05-28 12:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 12:42:12 --> Controller Class Initialized
DEBUG - 2019-05-28 12:42:12 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 12:42:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 12:42:12 --> Final output sent to browser
DEBUG - 2019-05-28 12:42:12 --> Total execution time: 0.0358
INFO - 2019-05-28 12:42:52 --> Config Class Initialized
INFO - 2019-05-28 12:42:52 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:42:52 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:42:52 --> Utf8 Class Initialized
INFO - 2019-05-28 12:42:52 --> URI Class Initialized
INFO - 2019-05-28 12:42:52 --> Router Class Initialized
INFO - 2019-05-28 12:42:52 --> Output Class Initialized
INFO - 2019-05-28 12:42:52 --> Security Class Initialized
DEBUG - 2019-05-28 12:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:42:52 --> Input Class Initialized
INFO - 2019-05-28 12:42:52 --> Language Class Initialized
INFO - 2019-05-28 12:42:52 --> Language Class Initialized
INFO - 2019-05-28 12:42:52 --> Config Class Initialized
INFO - 2019-05-28 12:42:52 --> Loader Class Initialized
INFO - 2019-05-28 12:42:52 --> Helper loaded: form_helper
INFO - 2019-05-28 12:42:52 --> Helper loaded: url_helper
INFO - 2019-05-28 12:42:52 --> Helper loaded: cookie_helper
INFO - 2019-05-28 12:42:52 --> Database Driver Class Initialized
DEBUG - 2019-05-28 12:42:52 --> Template library initialized
INFO - 2019-05-28 12:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 12:42:52 --> Controller Class Initialized
DEBUG - 2019-05-28 12:42:52 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 12:42:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 12:42:52 --> Final output sent to browser
DEBUG - 2019-05-28 12:42:52 --> Total execution time: 0.0399
INFO - 2019-05-28 12:42:58 --> Config Class Initialized
INFO - 2019-05-28 12:42:58 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:42:58 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:42:58 --> Utf8 Class Initialized
INFO - 2019-05-28 12:42:58 --> URI Class Initialized
INFO - 2019-05-28 12:42:58 --> Router Class Initialized
INFO - 2019-05-28 12:42:58 --> Output Class Initialized
INFO - 2019-05-28 12:42:58 --> Security Class Initialized
DEBUG - 2019-05-28 12:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:42:58 --> Input Class Initialized
INFO - 2019-05-28 12:42:58 --> Language Class Initialized
INFO - 2019-05-28 12:42:58 --> Language Class Initialized
INFO - 2019-05-28 12:42:58 --> Config Class Initialized
INFO - 2019-05-28 12:42:58 --> Loader Class Initialized
INFO - 2019-05-28 12:42:58 --> Helper loaded: form_helper
INFO - 2019-05-28 12:42:58 --> Helper loaded: url_helper
INFO - 2019-05-28 12:42:58 --> Helper loaded: cookie_helper
INFO - 2019-05-28 12:42:58 --> Database Driver Class Initialized
DEBUG - 2019-05-28 12:42:58 --> Template library initialized
INFO - 2019-05-28 12:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 12:42:58 --> Controller Class Initialized
DEBUG - 2019-05-28 12:42:58 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 12:42:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 12:42:58 --> Final output sent to browser
DEBUG - 2019-05-28 12:42:58 --> Total execution time: 0.0387
INFO - 2019-05-28 12:42:58 --> Config Class Initialized
INFO - 2019-05-28 12:42:58 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:42:58 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:42:58 --> Utf8 Class Initialized
INFO - 2019-05-28 12:42:58 --> URI Class Initialized
INFO - 2019-05-28 12:42:58 --> Router Class Initialized
INFO - 2019-05-28 12:42:58 --> Output Class Initialized
INFO - 2019-05-28 12:42:58 --> Security Class Initialized
DEBUG - 2019-05-28 12:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:42:58 --> Input Class Initialized
INFO - 2019-05-28 12:42:58 --> Language Class Initialized
INFO - 2019-05-28 12:42:59 --> Language Class Initialized
INFO - 2019-05-28 12:42:59 --> Config Class Initialized
INFO - 2019-05-28 12:42:59 --> Loader Class Initialized
INFO - 2019-05-28 12:42:59 --> Helper loaded: form_helper
INFO - 2019-05-28 12:42:59 --> Helper loaded: url_helper
INFO - 2019-05-28 12:42:59 --> Helper loaded: cookie_helper
INFO - 2019-05-28 12:42:59 --> Database Driver Class Initialized
DEBUG - 2019-05-28 12:42:59 --> Template library initialized
INFO - 2019-05-28 12:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 12:42:59 --> Controller Class Initialized
DEBUG - 2019-05-28 12:42:59 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 12:42:59 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 12:42:59 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 12:42:59 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 12:42:59 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 12:42:59 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 12:42:59 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 12:42:59 --> Final output sent to browser
DEBUG - 2019-05-28 12:42:59 --> Total execution time: 0.0448
INFO - 2019-05-28 12:42:59 --> Config Class Initialized
INFO - 2019-05-28 12:42:59 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:42:59 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:42:59 --> Utf8 Class Initialized
INFO - 2019-05-28 12:42:59 --> URI Class Initialized
INFO - 2019-05-28 12:42:59 --> Config Class Initialized
INFO - 2019-05-28 12:42:59 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:42:59 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:42:59 --> Utf8 Class Initialized
INFO - 2019-05-28 12:42:59 --> URI Class Initialized
INFO - 2019-05-28 12:42:59 --> Router Class Initialized
INFO - 2019-05-28 12:42:59 --> Router Class Initialized
INFO - 2019-05-28 12:42:59 --> Output Class Initialized
INFO - 2019-05-28 12:42:59 --> Security Class Initialized
DEBUG - 2019-05-28 12:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:42:59 --> Input Class Initialized
INFO - 2019-05-28 12:42:59 --> Language Class Initialized
ERROR - 2019-05-28 12:42:59 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:42:59 --> Output Class Initialized
INFO - 2019-05-28 12:42:59 --> Security Class Initialized
DEBUG - 2019-05-28 12:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:42:59 --> Input Class Initialized
INFO - 2019-05-28 12:42:59 --> Language Class Initialized
ERROR - 2019-05-28 12:42:59 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:42:59 --> Config Class Initialized
INFO - 2019-05-28 12:42:59 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:42:59 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:42:59 --> Utf8 Class Initialized
INFO - 2019-05-28 12:42:59 --> URI Class Initialized
INFO - 2019-05-28 12:42:59 --> Router Class Initialized
INFO - 2019-05-28 12:42:59 --> Output Class Initialized
INFO - 2019-05-28 12:42:59 --> Security Class Initialized
DEBUG - 2019-05-28 12:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:42:59 --> Input Class Initialized
INFO - 2019-05-28 12:42:59 --> Language Class Initialized
ERROR - 2019-05-28 12:42:59 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:43:46 --> Config Class Initialized
INFO - 2019-05-28 12:43:46 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:43:46 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:43:46 --> Utf8 Class Initialized
INFO - 2019-05-28 12:43:46 --> URI Class Initialized
INFO - 2019-05-28 12:43:46 --> Router Class Initialized
INFO - 2019-05-28 12:43:46 --> Output Class Initialized
INFO - 2019-05-28 12:43:46 --> Security Class Initialized
DEBUG - 2019-05-28 12:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:43:46 --> Input Class Initialized
INFO - 2019-05-28 12:43:46 --> Language Class Initialized
INFO - 2019-05-28 12:43:46 --> Language Class Initialized
INFO - 2019-05-28 12:43:46 --> Config Class Initialized
INFO - 2019-05-28 12:43:46 --> Loader Class Initialized
INFO - 2019-05-28 12:43:46 --> Helper loaded: form_helper
INFO - 2019-05-28 12:43:46 --> Helper loaded: url_helper
INFO - 2019-05-28 12:43:46 --> Helper loaded: cookie_helper
INFO - 2019-05-28 12:43:46 --> Database Driver Class Initialized
DEBUG - 2019-05-28 12:43:46 --> Template library initialized
INFO - 2019-05-28 12:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 12:43:46 --> Controller Class Initialized
DEBUG - 2019-05-28 12:43:46 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 12:43:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 12:43:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 12:43:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 12:43:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 12:43:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 12:43:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 12:43:46 --> Config Class Initialized
INFO - 2019-05-28 12:43:46 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:43:46 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:43:46 --> Utf8 Class Initialized
INFO - 2019-05-28 12:43:46 --> URI Class Initialized
INFO - 2019-05-28 12:43:46 --> Router Class Initialized
INFO - 2019-05-28 12:43:46 --> Output Class Initialized
INFO - 2019-05-28 12:43:46 --> Security Class Initialized
DEBUG - 2019-05-28 12:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:43:46 --> Input Class Initialized
INFO - 2019-05-28 12:43:46 --> Language Class Initialized
INFO - 2019-05-28 12:43:46 --> Language Class Initialized
INFO - 2019-05-28 12:43:46 --> Config Class Initialized
INFO - 2019-05-28 12:43:46 --> Loader Class Initialized
INFO - 2019-05-28 12:43:46 --> Helper loaded: form_helper
INFO - 2019-05-28 12:43:46 --> Helper loaded: url_helper
INFO - 2019-05-28 12:43:46 --> Helper loaded: cookie_helper
INFO - 2019-05-28 12:43:46 --> Database Driver Class Initialized
DEBUG - 2019-05-28 12:43:46 --> Template library initialized
INFO - 2019-05-28 12:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 12:43:46 --> Controller Class Initialized
DEBUG - 2019-05-28 12:43:46 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 12:43:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 12:43:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 12:43:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 12:43:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 12:43:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 12:43:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 12:43:47 --> Final output sent to browser
DEBUG - 2019-05-28 12:43:47 --> Total execution time: 0.0469
INFO - 2019-05-28 12:43:47 --> Config Class Initialized
INFO - 2019-05-28 12:43:47 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:43:47 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:43:47 --> Utf8 Class Initialized
INFO - 2019-05-28 12:43:47 --> URI Class Initialized
INFO - 2019-05-28 12:43:47 --> Config Class Initialized
INFO - 2019-05-28 12:43:47 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:43:47 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:43:47 --> Utf8 Class Initialized
INFO - 2019-05-28 12:43:47 --> URI Class Initialized
INFO - 2019-05-28 12:43:47 --> Router Class Initialized
INFO - 2019-05-28 12:43:47 --> Router Class Initialized
INFO - 2019-05-28 12:43:47 --> Output Class Initialized
INFO - 2019-05-28 12:43:47 --> Security Class Initialized
DEBUG - 2019-05-28 12:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:43:47 --> Input Class Initialized
INFO - 2019-05-28 12:43:47 --> Language Class Initialized
ERROR - 2019-05-28 12:43:47 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:43:47 --> Output Class Initialized
INFO - 2019-05-28 12:43:47 --> Security Class Initialized
DEBUG - 2019-05-28 12:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:43:47 --> Input Class Initialized
INFO - 2019-05-28 12:43:47 --> Language Class Initialized
ERROR - 2019-05-28 12:43:47 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:43:48 --> Config Class Initialized
INFO - 2019-05-28 12:43:48 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:43:48 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:43:48 --> Utf8 Class Initialized
INFO - 2019-05-28 12:43:48 --> URI Class Initialized
INFO - 2019-05-28 12:43:48 --> Router Class Initialized
INFO - 2019-05-28 12:43:48 --> Output Class Initialized
INFO - 2019-05-28 12:43:48 --> Security Class Initialized
DEBUG - 2019-05-28 12:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:43:48 --> Input Class Initialized
INFO - 2019-05-28 12:43:48 --> Language Class Initialized
INFO - 2019-05-28 12:43:48 --> Language Class Initialized
INFO - 2019-05-28 12:43:48 --> Config Class Initialized
INFO - 2019-05-28 12:43:48 --> Loader Class Initialized
INFO - 2019-05-28 12:43:48 --> Helper loaded: form_helper
INFO - 2019-05-28 12:43:48 --> Helper loaded: url_helper
INFO - 2019-05-28 12:43:48 --> Helper loaded: cookie_helper
INFO - 2019-05-28 12:43:48 --> Database Driver Class Initialized
DEBUG - 2019-05-28 12:43:48 --> Template library initialized
INFO - 2019-05-28 12:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 12:43:48 --> Controller Class Initialized
DEBUG - 2019-05-28 12:43:48 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 12:43:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 12:43:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 12:43:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 12:43:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 12:43:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 12:43:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 12:43:48 --> Final output sent to browser
DEBUG - 2019-05-28 12:43:48 --> Total execution time: 0.0598
INFO - 2019-05-28 12:43:51 --> Config Class Initialized
INFO - 2019-05-28 12:43:51 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:43:51 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:43:51 --> Utf8 Class Initialized
INFO - 2019-05-28 12:43:51 --> URI Class Initialized
INFO - 2019-05-28 12:43:51 --> Router Class Initialized
INFO - 2019-05-28 12:43:51 --> Output Class Initialized
INFO - 2019-05-28 12:43:51 --> Security Class Initialized
DEBUG - 2019-05-28 12:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:43:51 --> Input Class Initialized
INFO - 2019-05-28 12:43:51 --> Language Class Initialized
ERROR - 2019-05-28 12:43:51 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:43:51 --> Config Class Initialized
INFO - 2019-05-28 12:43:51 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:43:51 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:43:51 --> Utf8 Class Initialized
INFO - 2019-05-28 12:43:51 --> URI Class Initialized
INFO - 2019-05-28 12:43:51 --> Router Class Initialized
INFO - 2019-05-28 12:43:51 --> Output Class Initialized
INFO - 2019-05-28 12:43:51 --> Security Class Initialized
DEBUG - 2019-05-28 12:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:43:51 --> Input Class Initialized
INFO - 2019-05-28 12:43:51 --> Language Class Initialized
ERROR - 2019-05-28 12:43:51 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:43:51 --> Config Class Initialized
INFO - 2019-05-28 12:43:51 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:43:51 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:43:51 --> Utf8 Class Initialized
INFO - 2019-05-28 12:43:51 --> URI Class Initialized
INFO - 2019-05-28 12:43:51 --> Router Class Initialized
INFO - 2019-05-28 12:43:51 --> Output Class Initialized
INFO - 2019-05-28 12:43:51 --> Security Class Initialized
DEBUG - 2019-05-28 12:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:43:51 --> Input Class Initialized
INFO - 2019-05-28 12:43:51 --> Language Class Initialized
ERROR - 2019-05-28 12:43:51 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:44:34 --> Config Class Initialized
INFO - 2019-05-28 12:44:34 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:44:34 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:44:34 --> Utf8 Class Initialized
INFO - 2019-05-28 12:44:34 --> URI Class Initialized
INFO - 2019-05-28 12:44:34 --> Router Class Initialized
INFO - 2019-05-28 12:44:34 --> Output Class Initialized
INFO - 2019-05-28 12:44:34 --> Security Class Initialized
DEBUG - 2019-05-28 12:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:44:34 --> Input Class Initialized
INFO - 2019-05-28 12:44:34 --> Language Class Initialized
INFO - 2019-05-28 12:44:34 --> Language Class Initialized
INFO - 2019-05-28 12:44:34 --> Config Class Initialized
INFO - 2019-05-28 12:44:34 --> Loader Class Initialized
INFO - 2019-05-28 12:44:34 --> Helper loaded: form_helper
INFO - 2019-05-28 12:44:34 --> Helper loaded: url_helper
INFO - 2019-05-28 12:44:34 --> Helper loaded: cookie_helper
INFO - 2019-05-28 12:44:34 --> Database Driver Class Initialized
DEBUG - 2019-05-28 12:44:34 --> Template library initialized
INFO - 2019-05-28 12:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 12:44:34 --> Controller Class Initialized
DEBUG - 2019-05-28 12:44:34 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 12:44:34 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 12:44:34 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 12:44:34 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 12:44:34 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 12:44:34 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 12:44:34 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 12:44:35 --> Config Class Initialized
INFO - 2019-05-28 12:44:35 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:44:35 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:44:35 --> Utf8 Class Initialized
INFO - 2019-05-28 12:44:35 --> URI Class Initialized
INFO - 2019-05-28 12:44:35 --> Router Class Initialized
INFO - 2019-05-28 12:44:35 --> Output Class Initialized
INFO - 2019-05-28 12:44:35 --> Security Class Initialized
DEBUG - 2019-05-28 12:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:44:35 --> Input Class Initialized
INFO - 2019-05-28 12:44:35 --> Language Class Initialized
INFO - 2019-05-28 12:44:35 --> Language Class Initialized
INFO - 2019-05-28 12:44:35 --> Config Class Initialized
INFO - 2019-05-28 12:44:35 --> Loader Class Initialized
INFO - 2019-05-28 12:44:35 --> Helper loaded: form_helper
INFO - 2019-05-28 12:44:35 --> Helper loaded: url_helper
INFO - 2019-05-28 12:44:35 --> Helper loaded: cookie_helper
INFO - 2019-05-28 12:44:35 --> Database Driver Class Initialized
DEBUG - 2019-05-28 12:44:35 --> Template library initialized
INFO - 2019-05-28 12:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 12:44:35 --> Controller Class Initialized
DEBUG - 2019-05-28 12:44:35 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 12:44:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 12:44:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 12:44:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 12:44:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 12:44:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 12:44:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 12:44:35 --> Final output sent to browser
DEBUG - 2019-05-28 12:44:35 --> Total execution time: 0.0482
INFO - 2019-05-28 12:44:36 --> Config Class Initialized
INFO - 2019-05-28 12:44:36 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:44:36 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:44:36 --> Utf8 Class Initialized
INFO - 2019-05-28 12:44:36 --> URI Class Initialized
INFO - 2019-05-28 12:44:36 --> Router Class Initialized
INFO - 2019-05-28 12:44:36 --> Output Class Initialized
INFO - 2019-05-28 12:44:36 --> Security Class Initialized
DEBUG - 2019-05-28 12:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:44:36 --> Input Class Initialized
INFO - 2019-05-28 12:44:36 --> Language Class Initialized
ERROR - 2019-05-28 12:44:36 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:44:37 --> Config Class Initialized
INFO - 2019-05-28 12:44:37 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:44:37 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:44:37 --> Utf8 Class Initialized
INFO - 2019-05-28 12:44:37 --> URI Class Initialized
INFO - 2019-05-28 12:44:37 --> Router Class Initialized
INFO - 2019-05-28 12:44:37 --> Output Class Initialized
INFO - 2019-05-28 12:44:37 --> Security Class Initialized
DEBUG - 2019-05-28 12:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:44:37 --> Input Class Initialized
INFO - 2019-05-28 12:44:37 --> Language Class Initialized
ERROR - 2019-05-28 12:44:37 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:44:37 --> Config Class Initialized
INFO - 2019-05-28 12:44:37 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:44:37 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:44:37 --> Utf8 Class Initialized
INFO - 2019-05-28 12:44:37 --> URI Class Initialized
INFO - 2019-05-28 12:44:37 --> Router Class Initialized
INFO - 2019-05-28 12:44:37 --> Output Class Initialized
INFO - 2019-05-28 12:44:37 --> Security Class Initialized
DEBUG - 2019-05-28 12:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:44:37 --> Input Class Initialized
INFO - 2019-05-28 12:44:37 --> Language Class Initialized
ERROR - 2019-05-28 12:44:37 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:44:37 --> Config Class Initialized
INFO - 2019-05-28 12:44:37 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:44:37 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:44:37 --> Utf8 Class Initialized
INFO - 2019-05-28 12:44:37 --> URI Class Initialized
INFO - 2019-05-28 12:44:37 --> Router Class Initialized
INFO - 2019-05-28 12:44:37 --> Output Class Initialized
INFO - 2019-05-28 12:44:37 --> Security Class Initialized
DEBUG - 2019-05-28 12:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:44:37 --> Input Class Initialized
INFO - 2019-05-28 12:44:37 --> Language Class Initialized
INFO - 2019-05-28 12:44:37 --> Language Class Initialized
INFO - 2019-05-28 12:44:37 --> Config Class Initialized
INFO - 2019-05-28 12:44:37 --> Loader Class Initialized
INFO - 2019-05-28 12:44:37 --> Helper loaded: form_helper
INFO - 2019-05-28 12:44:37 --> Helper loaded: url_helper
INFO - 2019-05-28 12:44:37 --> Helper loaded: cookie_helper
INFO - 2019-05-28 12:44:37 --> Database Driver Class Initialized
DEBUG - 2019-05-28 12:44:37 --> Template library initialized
INFO - 2019-05-28 12:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 12:44:37 --> Controller Class Initialized
DEBUG - 2019-05-28 12:44:37 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 12:44:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 12:44:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 12:44:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 12:44:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 12:44:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 12:44:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 12:44:38 --> Final output sent to browser
DEBUG - 2019-05-28 12:44:38 --> Total execution time: 0.0456
INFO - 2019-05-28 12:44:41 --> Config Class Initialized
INFO - 2019-05-28 12:44:41 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:44:41 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:44:41 --> Utf8 Class Initialized
INFO - 2019-05-28 12:44:41 --> URI Class Initialized
INFO - 2019-05-28 12:44:41 --> Router Class Initialized
INFO - 2019-05-28 12:44:41 --> Output Class Initialized
INFO - 2019-05-28 12:44:41 --> Security Class Initialized
DEBUG - 2019-05-28 12:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:44:41 --> Input Class Initialized
INFO - 2019-05-28 12:44:41 --> Language Class Initialized
ERROR - 2019-05-28 12:44:41 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:44:41 --> Config Class Initialized
INFO - 2019-05-28 12:44:41 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:44:41 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:44:41 --> Utf8 Class Initialized
INFO - 2019-05-28 12:44:41 --> URI Class Initialized
INFO - 2019-05-28 12:44:41 --> Router Class Initialized
INFO - 2019-05-28 12:44:41 --> Output Class Initialized
INFO - 2019-05-28 12:44:41 --> Security Class Initialized
DEBUG - 2019-05-28 12:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:44:41 --> Input Class Initialized
INFO - 2019-05-28 12:44:41 --> Language Class Initialized
ERROR - 2019-05-28 12:44:41 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:44:41 --> Config Class Initialized
INFO - 2019-05-28 12:44:41 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:44:41 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:44:41 --> Utf8 Class Initialized
INFO - 2019-05-28 12:44:41 --> URI Class Initialized
INFO - 2019-05-28 12:44:41 --> Router Class Initialized
INFO - 2019-05-28 12:44:41 --> Output Class Initialized
INFO - 2019-05-28 12:44:41 --> Security Class Initialized
DEBUG - 2019-05-28 12:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:44:41 --> Input Class Initialized
INFO - 2019-05-28 12:44:41 --> Language Class Initialized
ERROR - 2019-05-28 12:44:41 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:44:42 --> Config Class Initialized
INFO - 2019-05-28 12:44:42 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:44:42 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:44:42 --> Utf8 Class Initialized
INFO - 2019-05-28 12:44:42 --> URI Class Initialized
INFO - 2019-05-28 12:44:42 --> Router Class Initialized
INFO - 2019-05-28 12:44:42 --> Output Class Initialized
INFO - 2019-05-28 12:44:42 --> Security Class Initialized
DEBUG - 2019-05-28 12:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:44:42 --> Input Class Initialized
INFO - 2019-05-28 12:44:42 --> Language Class Initialized
ERROR - 2019-05-28 12:44:42 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:44:56 --> Config Class Initialized
INFO - 2019-05-28 12:44:56 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:44:56 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:44:56 --> Utf8 Class Initialized
INFO - 2019-05-28 12:44:56 --> URI Class Initialized
DEBUG - 2019-05-28 12:44:56 --> No URI present. Default controller set.
INFO - 2019-05-28 12:44:56 --> Router Class Initialized
INFO - 2019-05-28 12:44:56 --> Output Class Initialized
INFO - 2019-05-28 12:44:56 --> Security Class Initialized
DEBUG - 2019-05-28 12:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:44:56 --> Input Class Initialized
INFO - 2019-05-28 12:44:56 --> Language Class Initialized
INFO - 2019-05-28 12:44:56 --> Language Class Initialized
INFO - 2019-05-28 12:44:56 --> Config Class Initialized
INFO - 2019-05-28 12:44:56 --> Loader Class Initialized
INFO - 2019-05-28 12:44:56 --> Helper loaded: form_helper
INFO - 2019-05-28 12:44:56 --> Helper loaded: url_helper
INFO - 2019-05-28 12:44:56 --> Helper loaded: cookie_helper
INFO - 2019-05-28 12:44:56 --> Database Driver Class Initialized
DEBUG - 2019-05-28 12:44:56 --> Template library initialized
INFO - 2019-05-28 12:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 12:44:56 --> Controller Class Initialized
DEBUG - 2019-05-28 12:44:56 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 12:44:56 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 12:44:56 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 12:44:56 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 12:44:56 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 12:44:56 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 12:44:56 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 12:44:56 --> Final output sent to browser
DEBUG - 2019-05-28 12:44:56 --> Total execution time: 0.0471
INFO - 2019-05-28 12:44:56 --> Config Class Initialized
INFO - 2019-05-28 12:44:56 --> Hooks Class Initialized
INFO - 2019-05-28 12:44:56 --> Config Class Initialized
INFO - 2019-05-28 12:44:56 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:44:56 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:44:56 --> Utf8 Class Initialized
INFO - 2019-05-28 12:44:56 --> URI Class Initialized
INFO - 2019-05-28 12:44:56 --> Config Class Initialized
INFO - 2019-05-28 12:44:56 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:44:56 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:44:56 --> Utf8 Class Initialized
INFO - 2019-05-28 12:44:56 --> URI Class Initialized
INFO - 2019-05-28 12:44:56 --> Router Class Initialized
DEBUG - 2019-05-28 12:44:56 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:44:56 --> Utf8 Class Initialized
INFO - 2019-05-28 12:44:56 --> URI Class Initialized
INFO - 2019-05-28 12:44:56 --> Router Class Initialized
INFO - 2019-05-28 12:44:56 --> Output Class Initialized
INFO - 2019-05-28 12:44:56 --> Security Class Initialized
DEBUG - 2019-05-28 12:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:44:56 --> Input Class Initialized
INFO - 2019-05-28 12:44:56 --> Router Class Initialized
INFO - 2019-05-28 12:44:56 --> Output Class Initialized
INFO - 2019-05-28 12:44:56 --> Security Class Initialized
DEBUG - 2019-05-28 12:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:44:56 --> Input Class Initialized
INFO - 2019-05-28 12:44:56 --> Language Class Initialized
ERROR - 2019-05-28 12:44:56 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:44:56 --> Output Class Initialized
INFO - 2019-05-28 12:44:56 --> Security Class Initialized
DEBUG - 2019-05-28 12:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:44:56 --> Input Class Initialized
INFO - 2019-05-28 12:44:56 --> Language Class Initialized
ERROR - 2019-05-28 12:44:56 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:44:56 --> Language Class Initialized
ERROR - 2019-05-28 12:44:57 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:44:57 --> Config Class Initialized
INFO - 2019-05-28 12:44:57 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:44:57 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:44:57 --> Utf8 Class Initialized
INFO - 2019-05-28 12:44:57 --> URI Class Initialized
DEBUG - 2019-05-28 12:44:57 --> No URI present. Default controller set.
INFO - 2019-05-28 12:44:57 --> Router Class Initialized
INFO - 2019-05-28 12:44:57 --> Output Class Initialized
INFO - 2019-05-28 12:44:57 --> Security Class Initialized
DEBUG - 2019-05-28 12:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:44:57 --> Input Class Initialized
INFO - 2019-05-28 12:44:57 --> Language Class Initialized
INFO - 2019-05-28 12:44:57 --> Language Class Initialized
INFO - 2019-05-28 12:44:57 --> Config Class Initialized
INFO - 2019-05-28 12:44:57 --> Loader Class Initialized
INFO - 2019-05-28 12:44:57 --> Helper loaded: form_helper
INFO - 2019-05-28 12:44:57 --> Helper loaded: url_helper
INFO - 2019-05-28 12:44:57 --> Helper loaded: cookie_helper
INFO - 2019-05-28 12:44:58 --> Database Driver Class Initialized
DEBUG - 2019-05-28 12:44:58 --> Template library initialized
INFO - 2019-05-28 12:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 12:44:58 --> Controller Class Initialized
DEBUG - 2019-05-28 12:44:58 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 12:44:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 12:44:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 12:44:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 12:44:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 12:44:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 12:44:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 12:44:58 --> Final output sent to browser
DEBUG - 2019-05-28 12:44:58 --> Total execution time: 0.0461
INFO - 2019-05-28 12:44:58 --> Config Class Initialized
INFO - 2019-05-28 12:44:58 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:44:58 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:44:58 --> Utf8 Class Initialized
INFO - 2019-05-28 12:44:58 --> URI Class Initialized
INFO - 2019-05-28 12:44:58 --> Config Class Initialized
INFO - 2019-05-28 12:44:58 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:44:58 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:44:58 --> Utf8 Class Initialized
INFO - 2019-05-28 12:44:58 --> URI Class Initialized
INFO - 2019-05-28 12:44:58 --> Router Class Initialized
INFO - 2019-05-28 12:44:58 --> Config Class Initialized
INFO - 2019-05-28 12:44:58 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:44:58 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:44:58 --> Utf8 Class Initialized
INFO - 2019-05-28 12:44:58 --> URI Class Initialized
INFO - 2019-05-28 12:44:58 --> Router Class Initialized
INFO - 2019-05-28 12:44:58 --> Router Class Initialized
INFO - 2019-05-28 12:44:58 --> Output Class Initialized
INFO - 2019-05-28 12:44:58 --> Security Class Initialized
DEBUG - 2019-05-28 12:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:44:58 --> Input Class Initialized
INFO - 2019-05-28 12:44:58 --> Language Class Initialized
ERROR - 2019-05-28 12:44:58 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:44:58 --> Output Class Initialized
INFO - 2019-05-28 12:44:58 --> Security Class Initialized
DEBUG - 2019-05-28 12:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:44:58 --> Input Class Initialized
INFO - 2019-05-28 12:44:58 --> Language Class Initialized
ERROR - 2019-05-28 12:44:58 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:44:58 --> Output Class Initialized
INFO - 2019-05-28 12:44:58 --> Security Class Initialized
DEBUG - 2019-05-28 12:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:44:58 --> Input Class Initialized
INFO - 2019-05-28 12:44:58 --> Language Class Initialized
ERROR - 2019-05-28 12:44:58 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:45:33 --> Config Class Initialized
INFO - 2019-05-28 12:45:33 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:45:33 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:45:33 --> Utf8 Class Initialized
INFO - 2019-05-28 12:45:33 --> URI Class Initialized
INFO - 2019-05-28 12:45:33 --> Router Class Initialized
INFO - 2019-05-28 12:45:33 --> Output Class Initialized
INFO - 2019-05-28 12:45:33 --> Security Class Initialized
DEBUG - 2019-05-28 12:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:45:33 --> Input Class Initialized
INFO - 2019-05-28 12:45:33 --> Language Class Initialized
INFO - 2019-05-28 12:45:33 --> Language Class Initialized
INFO - 2019-05-28 12:45:33 --> Config Class Initialized
INFO - 2019-05-28 12:45:33 --> Loader Class Initialized
INFO - 2019-05-28 12:45:33 --> Helper loaded: form_helper
INFO - 2019-05-28 12:45:33 --> Helper loaded: url_helper
INFO - 2019-05-28 12:45:33 --> Helper loaded: cookie_helper
INFO - 2019-05-28 12:45:33 --> Database Driver Class Initialized
DEBUG - 2019-05-28 12:45:33 --> Template library initialized
INFO - 2019-05-28 12:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 12:45:33 --> Controller Class Initialized
DEBUG - 2019-05-28 12:45:33 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 12:45:33 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 12:45:33 --> Final output sent to browser
DEBUG - 2019-05-28 12:45:33 --> Total execution time: 0.0382
INFO - 2019-05-28 12:45:34 --> Config Class Initialized
INFO - 2019-05-28 12:45:34 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:45:34 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:45:34 --> Utf8 Class Initialized
INFO - 2019-05-28 12:45:34 --> URI Class Initialized
INFO - 2019-05-28 12:45:34 --> Router Class Initialized
INFO - 2019-05-28 12:45:35 --> Output Class Initialized
INFO - 2019-05-28 12:45:35 --> Security Class Initialized
DEBUG - 2019-05-28 12:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:45:35 --> Input Class Initialized
INFO - 2019-05-28 12:45:35 --> Language Class Initialized
ERROR - 2019-05-28 12:45:35 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:52:23 --> Config Class Initialized
INFO - 2019-05-28 12:52:23 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:52:23 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:52:23 --> Utf8 Class Initialized
INFO - 2019-05-28 12:52:23 --> URI Class Initialized
DEBUG - 2019-05-28 12:52:23 --> No URI present. Default controller set.
INFO - 2019-05-28 12:52:23 --> Router Class Initialized
INFO - 2019-05-28 12:52:23 --> Output Class Initialized
INFO - 2019-05-28 12:52:23 --> Security Class Initialized
DEBUG - 2019-05-28 12:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:52:23 --> Input Class Initialized
INFO - 2019-05-28 12:52:23 --> Language Class Initialized
INFO - 2019-05-28 12:52:23 --> Language Class Initialized
INFO - 2019-05-28 12:52:23 --> Config Class Initialized
INFO - 2019-05-28 12:52:23 --> Loader Class Initialized
INFO - 2019-05-28 12:52:23 --> Helper loaded: form_helper
INFO - 2019-05-28 12:52:23 --> Helper loaded: url_helper
INFO - 2019-05-28 12:52:23 --> Helper loaded: cookie_helper
INFO - 2019-05-28 12:52:23 --> Database Driver Class Initialized
DEBUG - 2019-05-28 12:52:23 --> Template library initialized
INFO - 2019-05-28 12:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 12:52:23 --> Controller Class Initialized
DEBUG - 2019-05-28 12:52:23 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 12:52:23 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 12:52:23 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 12:52:23 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 12:52:23 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 12:52:23 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 12:52:23 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 12:52:24 --> Final output sent to browser
DEBUG - 2019-05-28 12:52:24 --> Total execution time: 0.0478
INFO - 2019-05-28 12:52:24 --> Config Class Initialized
INFO - 2019-05-28 12:52:24 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:52:24 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:52:24 --> Utf8 Class Initialized
INFO - 2019-05-28 12:52:24 --> URI Class Initialized
INFO - 2019-05-28 12:52:24 --> Router Class Initialized
INFO - 2019-05-28 12:52:24 --> Output Class Initialized
INFO - 2019-05-28 12:52:24 --> Security Class Initialized
DEBUG - 2019-05-28 12:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:52:24 --> Input Class Initialized
INFO - 2019-05-28 12:52:24 --> Language Class Initialized
ERROR - 2019-05-28 12:52:24 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:52:24 --> Config Class Initialized
INFO - 2019-05-28 12:52:24 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:52:24 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:52:24 --> Utf8 Class Initialized
INFO - 2019-05-28 12:52:24 --> URI Class Initialized
INFO - 2019-05-28 12:52:24 --> Config Class Initialized
INFO - 2019-05-28 12:52:24 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:52:24 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:52:24 --> Utf8 Class Initialized
INFO - 2019-05-28 12:52:24 --> URI Class Initialized
INFO - 2019-05-28 12:52:24 --> Router Class Initialized
INFO - 2019-05-28 12:52:24 --> Router Class Initialized
INFO - 2019-05-28 12:52:24 --> Output Class Initialized
INFO - 2019-05-28 12:52:24 --> Security Class Initialized
DEBUG - 2019-05-28 12:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:52:24 --> Input Class Initialized
INFO - 2019-05-28 12:52:24 --> Language Class Initialized
ERROR - 2019-05-28 12:52:24 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:52:24 --> Output Class Initialized
INFO - 2019-05-28 12:52:24 --> Security Class Initialized
DEBUG - 2019-05-28 12:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:52:24 --> Input Class Initialized
INFO - 2019-05-28 12:52:24 --> Language Class Initialized
ERROR - 2019-05-28 12:52:24 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:52:25 --> Config Class Initialized
INFO - 2019-05-28 12:52:25 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:52:25 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:52:25 --> Utf8 Class Initialized
INFO - 2019-05-28 12:52:25 --> URI Class Initialized
INFO - 2019-05-28 12:52:25 --> Router Class Initialized
INFO - 2019-05-28 12:52:25 --> Output Class Initialized
INFO - 2019-05-28 12:52:25 --> Security Class Initialized
DEBUG - 2019-05-28 12:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:52:25 --> Input Class Initialized
INFO - 2019-05-28 12:52:25 --> Language Class Initialized
ERROR - 2019-05-28 12:52:25 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:52:29 --> Config Class Initialized
INFO - 2019-05-28 12:52:29 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:52:29 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:52:29 --> Utf8 Class Initialized
INFO - 2019-05-28 12:52:29 --> URI Class Initialized
INFO - 2019-05-28 12:52:29 --> Router Class Initialized
INFO - 2019-05-28 12:52:29 --> Output Class Initialized
INFO - 2019-05-28 12:52:29 --> Security Class Initialized
DEBUG - 2019-05-28 12:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:52:29 --> Input Class Initialized
INFO - 2019-05-28 12:52:29 --> Language Class Initialized
INFO - 2019-05-28 12:52:29 --> Language Class Initialized
INFO - 2019-05-28 12:52:29 --> Config Class Initialized
INFO - 2019-05-28 12:52:29 --> Loader Class Initialized
INFO - 2019-05-28 12:52:29 --> Helper loaded: form_helper
INFO - 2019-05-28 12:52:29 --> Helper loaded: url_helper
INFO - 2019-05-28 12:52:29 --> Helper loaded: cookie_helper
INFO - 2019-05-28 12:52:29 --> Database Driver Class Initialized
DEBUG - 2019-05-28 12:52:29 --> Template library initialized
INFO - 2019-05-28 12:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 12:52:29 --> Controller Class Initialized
DEBUG - 2019-05-28 12:52:29 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 12:52:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 12:52:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/dth.php
DEBUG - 2019-05-28 12:52:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 12:52:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 12:52:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 12:52:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 12:52:29 --> Final output sent to browser
DEBUG - 2019-05-28 12:52:29 --> Total execution time: 0.0501
INFO - 2019-05-28 12:52:29 --> Config Class Initialized
INFO - 2019-05-28 12:52:29 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:52:29 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:52:29 --> Utf8 Class Initialized
INFO - 2019-05-28 12:52:29 --> URI Class Initialized
INFO - 2019-05-28 12:52:29 --> Router Class Initialized
INFO - 2019-05-28 12:52:29 --> Output Class Initialized
INFO - 2019-05-28 12:52:29 --> Security Class Initialized
DEBUG - 2019-05-28 12:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:52:29 --> Input Class Initialized
INFO - 2019-05-28 12:52:29 --> Language Class Initialized
ERROR - 2019-05-28 12:52:29 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:52:29 --> Config Class Initialized
INFO - 2019-05-28 12:52:29 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:52:29 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:52:29 --> Utf8 Class Initialized
INFO - 2019-05-28 12:52:29 --> URI Class Initialized
INFO - 2019-05-28 12:52:29 --> Router Class Initialized
INFO - 2019-05-28 12:52:29 --> Output Class Initialized
INFO - 2019-05-28 12:52:29 --> Security Class Initialized
DEBUG - 2019-05-28 12:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:52:29 --> Input Class Initialized
INFO - 2019-05-28 12:52:29 --> Language Class Initialized
ERROR - 2019-05-28 12:52:29 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:52:29 --> Config Class Initialized
INFO - 2019-05-28 12:52:29 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:52:29 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:52:29 --> Utf8 Class Initialized
INFO - 2019-05-28 12:52:29 --> URI Class Initialized
INFO - 2019-05-28 12:52:29 --> Router Class Initialized
INFO - 2019-05-28 12:52:29 --> Output Class Initialized
INFO - 2019-05-28 12:52:29 --> Security Class Initialized
DEBUG - 2019-05-28 12:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:52:29 --> Input Class Initialized
INFO - 2019-05-28 12:52:29 --> Language Class Initialized
ERROR - 2019-05-28 12:52:29 --> 404 Page Not Found: /index
INFO - 2019-05-28 12:52:41 --> Config Class Initialized
INFO - 2019-05-28 12:52:41 --> Hooks Class Initialized
DEBUG - 2019-05-28 12:52:41 --> UTF-8 Support Enabled
INFO - 2019-05-28 12:52:41 --> Utf8 Class Initialized
INFO - 2019-05-28 12:52:41 --> URI Class Initialized
INFO - 2019-05-28 12:52:41 --> Router Class Initialized
INFO - 2019-05-28 12:52:41 --> Output Class Initialized
INFO - 2019-05-28 12:52:41 --> Security Class Initialized
DEBUG - 2019-05-28 12:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 12:52:41 --> Input Class Initialized
INFO - 2019-05-28 12:52:41 --> Language Class Initialized
INFO - 2019-05-28 12:52:41 --> Language Class Initialized
INFO - 2019-05-28 12:52:41 --> Config Class Initialized
INFO - 2019-05-28 12:52:41 --> Loader Class Initialized
INFO - 2019-05-28 12:52:41 --> Helper loaded: form_helper
INFO - 2019-05-28 12:52:41 --> Helper loaded: url_helper
INFO - 2019-05-28 12:52:41 --> Helper loaded: cookie_helper
INFO - 2019-05-28 12:52:41 --> Database Driver Class Initialized
DEBUG - 2019-05-28 12:52:41 --> Template library initialized
INFO - 2019-05-28 12:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 12:52:41 --> Controller Class Initialized
DEBUG - 2019-05-28 12:52:41 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 12:52:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 12:52:41 --> Final output sent to browser
DEBUG - 2019-05-28 12:52:41 --> Total execution time: 0.0408
INFO - 2019-05-28 13:15:00 --> Config Class Initialized
INFO - 2019-05-28 13:15:00 --> Hooks Class Initialized
DEBUG - 2019-05-28 13:15:00 --> UTF-8 Support Enabled
INFO - 2019-05-28 13:15:00 --> Utf8 Class Initialized
INFO - 2019-05-28 13:15:00 --> URI Class Initialized
DEBUG - 2019-05-28 13:15:00 --> No URI present. Default controller set.
INFO - 2019-05-28 13:15:00 --> Router Class Initialized
INFO - 2019-05-28 13:15:00 --> Output Class Initialized
INFO - 2019-05-28 13:15:00 --> Security Class Initialized
DEBUG - 2019-05-28 13:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 13:15:00 --> Input Class Initialized
INFO - 2019-05-28 13:15:00 --> Language Class Initialized
INFO - 2019-05-28 13:15:00 --> Language Class Initialized
INFO - 2019-05-28 13:15:00 --> Config Class Initialized
INFO - 2019-05-28 13:15:00 --> Loader Class Initialized
INFO - 2019-05-28 13:15:00 --> Config Class Initialized
INFO - 2019-05-28 13:15:00 --> Hooks Class Initialized
DEBUG - 2019-05-28 13:15:00 --> UTF-8 Support Enabled
INFO - 2019-05-28 13:15:00 --> Utf8 Class Initialized
INFO - 2019-05-28 13:15:00 --> URI Class Initialized
DEBUG - 2019-05-28 13:15:00 --> No URI present. Default controller set.
INFO - 2019-05-28 13:15:00 --> Router Class Initialized
INFO - 2019-05-28 13:15:00 --> Output Class Initialized
INFO - 2019-05-28 13:15:00 --> Security Class Initialized
DEBUG - 2019-05-28 13:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 13:15:00 --> Input Class Initialized
INFO - 2019-05-28 13:15:00 --> Language Class Initialized
INFO - 2019-05-28 13:15:00 --> Language Class Initialized
INFO - 2019-05-28 13:15:00 --> Config Class Initialized
INFO - 2019-05-28 13:15:00 --> Loader Class Initialized
INFO - 2019-05-28 13:15:00 --> Helper loaded: form_helper
INFO - 2019-05-28 13:15:00 --> Helper loaded: form_helper
INFO - 2019-05-28 13:15:00 --> Helper loaded: url_helper
INFO - 2019-05-28 13:15:00 --> Helper loaded: cookie_helper
INFO - 2019-05-28 13:15:00 --> Database Driver Class Initialized
INFO - 2019-05-28 13:15:00 --> Helper loaded: url_helper
INFO - 2019-05-28 13:15:00 --> Helper loaded: cookie_helper
INFO - 2019-05-28 13:15:00 --> Database Driver Class Initialized
DEBUG - 2019-05-28 13:15:00 --> Template library initialized
INFO - 2019-05-28 13:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 13:15:00 --> Controller Class Initialized
DEBUG - 2019-05-28 13:15:00 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 13:15:00 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 13:15:00 --> Template library initialized
INFO - 2019-05-28 13:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 13:15:00 --> Controller Class Initialized
DEBUG - 2019-05-28 13:15:00 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 13:15:00 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 13:15:00 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 13:15:00 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 13:15:00 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 13:15:00 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 13:15:00 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
DEBUG - 2019-05-28 13:15:00 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 13:15:00 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 13:15:00 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 13:15:00 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 13:15:00 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 13:15:00 --> Final output sent to browser
DEBUG - 2019-05-28 13:15:00 --> Total execution time: 0.0831
INFO - 2019-05-28 13:15:00 --> Final output sent to browser
DEBUG - 2019-05-28 13:15:00 --> Total execution time: 0.0740
INFO - 2019-05-28 13:15:01 --> Config Class Initialized
INFO - 2019-05-28 13:15:01 --> Hooks Class Initialized
DEBUG - 2019-05-28 13:15:01 --> UTF-8 Support Enabled
INFO - 2019-05-28 13:15:01 --> Utf8 Class Initialized
INFO - 2019-05-28 13:15:01 --> URI Class Initialized
INFO - 2019-05-28 13:15:01 --> Router Class Initialized
INFO - 2019-05-28 13:15:01 --> Output Class Initialized
INFO - 2019-05-28 13:15:01 --> Security Class Initialized
DEBUG - 2019-05-28 13:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 13:15:01 --> Input Class Initialized
INFO - 2019-05-28 13:15:01 --> Language Class Initialized
ERROR - 2019-05-28 13:15:01 --> 404 Page Not Found: /index
INFO - 2019-05-28 13:15:01 --> Config Class Initialized
INFO - 2019-05-28 13:15:01 --> Hooks Class Initialized
DEBUG - 2019-05-28 13:15:01 --> UTF-8 Support Enabled
INFO - 2019-05-28 13:15:01 --> Utf8 Class Initialized
INFO - 2019-05-28 13:15:01 --> URI Class Initialized
INFO - 2019-05-28 13:15:01 --> Router Class Initialized
INFO - 2019-05-28 13:15:01 --> Output Class Initialized
INFO - 2019-05-28 13:15:01 --> Security Class Initialized
DEBUG - 2019-05-28 13:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 13:15:01 --> Input Class Initialized
INFO - 2019-05-28 13:15:01 --> Language Class Initialized
ERROR - 2019-05-28 13:15:01 --> 404 Page Not Found: /index
INFO - 2019-05-28 13:15:01 --> Config Class Initialized
INFO - 2019-05-28 13:15:01 --> Hooks Class Initialized
DEBUG - 2019-05-28 13:15:01 --> UTF-8 Support Enabled
INFO - 2019-05-28 13:15:01 --> Utf8 Class Initialized
INFO - 2019-05-28 13:15:01 --> URI Class Initialized
INFO - 2019-05-28 13:15:01 --> Router Class Initialized
INFO - 2019-05-28 13:15:01 --> Output Class Initialized
INFO - 2019-05-28 13:15:01 --> Security Class Initialized
DEBUG - 2019-05-28 13:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 13:15:01 --> Input Class Initialized
INFO - 2019-05-28 13:15:01 --> Language Class Initialized
ERROR - 2019-05-28 13:15:01 --> 404 Page Not Found: /index
INFO - 2019-05-28 13:15:02 --> Config Class Initialized
INFO - 2019-05-28 13:15:02 --> Hooks Class Initialized
DEBUG - 2019-05-28 13:15:02 --> UTF-8 Support Enabled
INFO - 2019-05-28 13:15:02 --> Utf8 Class Initialized
INFO - 2019-05-28 13:15:02 --> URI Class Initialized
INFO - 2019-05-28 13:15:02 --> Router Class Initialized
INFO - 2019-05-28 13:15:02 --> Output Class Initialized
INFO - 2019-05-28 13:15:02 --> Security Class Initialized
DEBUG - 2019-05-28 13:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 13:15:02 --> Input Class Initialized
INFO - 2019-05-28 13:15:02 --> Language Class Initialized
ERROR - 2019-05-28 13:15:02 --> 404 Page Not Found: /index
INFO - 2019-05-28 13:15:02 --> Config Class Initialized
INFO - 2019-05-28 13:15:02 --> Hooks Class Initialized
DEBUG - 2019-05-28 13:15:02 --> UTF-8 Support Enabled
INFO - 2019-05-28 13:15:02 --> Utf8 Class Initialized
INFO - 2019-05-28 13:15:02 --> URI Class Initialized
INFO - 2019-05-28 13:15:02 --> Router Class Initialized
INFO - 2019-05-28 13:15:02 --> Output Class Initialized
INFO - 2019-05-28 13:15:02 --> Security Class Initialized
DEBUG - 2019-05-28 13:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 13:15:02 --> Input Class Initialized
INFO - 2019-05-28 13:15:02 --> Language Class Initialized
ERROR - 2019-05-28 13:15:02 --> 404 Page Not Found: /index
INFO - 2019-05-28 13:15:02 --> Config Class Initialized
INFO - 2019-05-28 13:15:02 --> Hooks Class Initialized
DEBUG - 2019-05-28 13:15:02 --> UTF-8 Support Enabled
INFO - 2019-05-28 13:15:02 --> Utf8 Class Initialized
INFO - 2019-05-28 13:15:02 --> URI Class Initialized
INFO - 2019-05-28 13:15:02 --> Router Class Initialized
INFO - 2019-05-28 13:15:02 --> Output Class Initialized
INFO - 2019-05-28 13:15:02 --> Security Class Initialized
DEBUG - 2019-05-28 13:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 13:15:02 --> Input Class Initialized
INFO - 2019-05-28 13:15:02 --> Language Class Initialized
ERROR - 2019-05-28 13:15:02 --> 404 Page Not Found: /index
INFO - 2019-05-28 13:15:02 --> Config Class Initialized
INFO - 2019-05-28 13:15:02 --> Hooks Class Initialized
DEBUG - 2019-05-28 13:15:02 --> UTF-8 Support Enabled
INFO - 2019-05-28 13:15:02 --> Utf8 Class Initialized
INFO - 2019-05-28 13:15:02 --> URI Class Initialized
INFO - 2019-05-28 13:15:02 --> Router Class Initialized
INFO - 2019-05-28 13:15:02 --> Output Class Initialized
INFO - 2019-05-28 13:15:02 --> Security Class Initialized
DEBUG - 2019-05-28 13:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 13:15:02 --> Input Class Initialized
INFO - 2019-05-28 13:15:02 --> Language Class Initialized
ERROR - 2019-05-28 13:15:02 --> 404 Page Not Found: /index
INFO - 2019-05-28 13:15:02 --> Config Class Initialized
INFO - 2019-05-28 13:15:02 --> Hooks Class Initialized
DEBUG - 2019-05-28 13:15:02 --> UTF-8 Support Enabled
INFO - 2019-05-28 13:15:02 --> Utf8 Class Initialized
INFO - 2019-05-28 13:15:02 --> URI Class Initialized
INFO - 2019-05-28 13:15:02 --> Router Class Initialized
INFO - 2019-05-28 13:15:02 --> Output Class Initialized
INFO - 2019-05-28 13:15:02 --> Security Class Initialized
DEBUG - 2019-05-28 13:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 13:15:03 --> Input Class Initialized
INFO - 2019-05-28 13:15:03 --> Language Class Initialized
ERROR - 2019-05-28 13:15:03 --> 404 Page Not Found: /index
INFO - 2019-05-28 13:15:03 --> Config Class Initialized
INFO - 2019-05-28 13:15:03 --> Hooks Class Initialized
DEBUG - 2019-05-28 13:15:03 --> UTF-8 Support Enabled
INFO - 2019-05-28 13:15:03 --> Utf8 Class Initialized
INFO - 2019-05-28 13:15:03 --> URI Class Initialized
INFO - 2019-05-28 13:15:03 --> Router Class Initialized
INFO - 2019-05-28 13:15:03 --> Output Class Initialized
INFO - 2019-05-28 13:15:03 --> Security Class Initialized
DEBUG - 2019-05-28 13:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 13:15:03 --> Input Class Initialized
INFO - 2019-05-28 13:15:03 --> Language Class Initialized
ERROR - 2019-05-28 13:15:03 --> 404 Page Not Found: /index
INFO - 2019-05-28 13:15:03 --> Config Class Initialized
INFO - 2019-05-28 13:15:03 --> Hooks Class Initialized
DEBUG - 2019-05-28 13:15:03 --> UTF-8 Support Enabled
INFO - 2019-05-28 13:15:03 --> Utf8 Class Initialized
INFO - 2019-05-28 13:15:03 --> URI Class Initialized
INFO - 2019-05-28 13:15:03 --> Router Class Initialized
INFO - 2019-05-28 13:15:03 --> Output Class Initialized
INFO - 2019-05-28 13:15:03 --> Security Class Initialized
DEBUG - 2019-05-28 13:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 13:15:03 --> Input Class Initialized
INFO - 2019-05-28 13:15:03 --> Language Class Initialized
ERROR - 2019-05-28 13:15:03 --> 404 Page Not Found: /index
INFO - 2019-05-28 13:15:03 --> Config Class Initialized
INFO - 2019-05-28 13:15:03 --> Hooks Class Initialized
DEBUG - 2019-05-28 13:15:03 --> UTF-8 Support Enabled
INFO - 2019-05-28 13:15:03 --> Utf8 Class Initialized
INFO - 2019-05-28 13:15:03 --> URI Class Initialized
INFO - 2019-05-28 13:15:03 --> Router Class Initialized
INFO - 2019-05-28 13:15:03 --> Output Class Initialized
INFO - 2019-05-28 13:15:03 --> Security Class Initialized
DEBUG - 2019-05-28 13:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 13:15:03 --> Input Class Initialized
INFO - 2019-05-28 13:15:03 --> Language Class Initialized
ERROR - 2019-05-28 13:15:03 --> 404 Page Not Found: /index
INFO - 2019-05-28 13:15:04 --> Config Class Initialized
INFO - 2019-05-28 13:15:04 --> Hooks Class Initialized
DEBUG - 2019-05-28 13:15:04 --> UTF-8 Support Enabled
INFO - 2019-05-28 13:15:04 --> Utf8 Class Initialized
INFO - 2019-05-28 13:15:04 --> URI Class Initialized
INFO - 2019-05-28 13:15:04 --> Router Class Initialized
INFO - 2019-05-28 13:15:04 --> Output Class Initialized
INFO - 2019-05-28 13:15:04 --> Security Class Initialized
DEBUG - 2019-05-28 13:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 13:15:04 --> Input Class Initialized
INFO - 2019-05-28 13:15:04 --> Language Class Initialized
ERROR - 2019-05-28 13:15:04 --> 404 Page Not Found: /index
INFO - 2019-05-28 13:15:04 --> Config Class Initialized
INFO - 2019-05-28 13:15:04 --> Hooks Class Initialized
DEBUG - 2019-05-28 13:15:04 --> UTF-8 Support Enabled
INFO - 2019-05-28 13:15:04 --> Utf8 Class Initialized
INFO - 2019-05-28 13:15:04 --> URI Class Initialized
INFO - 2019-05-28 13:15:04 --> Router Class Initialized
INFO - 2019-05-28 13:15:04 --> Output Class Initialized
INFO - 2019-05-28 13:15:04 --> Security Class Initialized
DEBUG - 2019-05-28 13:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 13:15:04 --> Input Class Initialized
INFO - 2019-05-28 13:15:04 --> Language Class Initialized
ERROR - 2019-05-28 13:15:04 --> 404 Page Not Found: /index
INFO - 2019-05-28 13:15:04 --> Config Class Initialized
INFO - 2019-05-28 13:15:04 --> Hooks Class Initialized
DEBUG - 2019-05-28 13:15:04 --> UTF-8 Support Enabled
INFO - 2019-05-28 13:15:04 --> Utf8 Class Initialized
INFO - 2019-05-28 13:15:04 --> URI Class Initialized
INFO - 2019-05-28 13:15:04 --> Router Class Initialized
INFO - 2019-05-28 13:15:04 --> Output Class Initialized
INFO - 2019-05-28 13:15:04 --> Security Class Initialized
DEBUG - 2019-05-28 13:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 13:15:04 --> Input Class Initialized
INFO - 2019-05-28 13:15:04 --> Language Class Initialized
ERROR - 2019-05-28 13:15:04 --> 404 Page Not Found: /index
INFO - 2019-05-28 13:15:05 --> Config Class Initialized
INFO - 2019-05-28 13:15:05 --> Hooks Class Initialized
DEBUG - 2019-05-28 13:15:05 --> UTF-8 Support Enabled
INFO - 2019-05-28 13:15:05 --> Utf8 Class Initialized
INFO - 2019-05-28 13:15:05 --> URI Class Initialized
INFO - 2019-05-28 13:15:05 --> Router Class Initialized
INFO - 2019-05-28 13:15:05 --> Output Class Initialized
INFO - 2019-05-28 13:15:05 --> Security Class Initialized
DEBUG - 2019-05-28 13:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 13:15:05 --> Input Class Initialized
INFO - 2019-05-28 13:15:05 --> Language Class Initialized
ERROR - 2019-05-28 13:15:05 --> 404 Page Not Found: /index
INFO - 2019-05-28 13:15:05 --> Config Class Initialized
INFO - 2019-05-28 13:15:05 --> Hooks Class Initialized
DEBUG - 2019-05-28 13:15:05 --> UTF-8 Support Enabled
INFO - 2019-05-28 13:15:05 --> Utf8 Class Initialized
INFO - 2019-05-28 13:15:05 --> URI Class Initialized
INFO - 2019-05-28 13:15:05 --> Router Class Initialized
INFO - 2019-05-28 13:15:05 --> Output Class Initialized
INFO - 2019-05-28 13:15:05 --> Security Class Initialized
DEBUG - 2019-05-28 13:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 13:15:05 --> Input Class Initialized
INFO - 2019-05-28 13:15:05 --> Language Class Initialized
ERROR - 2019-05-28 13:15:05 --> 404 Page Not Found: /index
INFO - 2019-05-28 14:21:31 --> Config Class Initialized
INFO - 2019-05-28 14:21:31 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:21:31 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:21:31 --> Utf8 Class Initialized
INFO - 2019-05-28 14:21:31 --> URI Class Initialized
INFO - 2019-05-28 14:21:31 --> Router Class Initialized
INFO - 2019-05-28 14:21:31 --> Output Class Initialized
INFO - 2019-05-28 14:21:31 --> Security Class Initialized
DEBUG - 2019-05-28 14:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:21:31 --> Input Class Initialized
INFO - 2019-05-28 14:21:31 --> Language Class Initialized
INFO - 2019-05-28 14:21:31 --> Language Class Initialized
INFO - 2019-05-28 14:21:31 --> Config Class Initialized
INFO - 2019-05-28 14:21:31 --> Loader Class Initialized
INFO - 2019-05-28 14:21:31 --> Helper loaded: form_helper
INFO - 2019-05-28 14:21:31 --> Helper loaded: url_helper
INFO - 2019-05-28 14:21:31 --> Helper loaded: cookie_helper
INFO - 2019-05-28 14:21:31 --> Database Driver Class Initialized
DEBUG - 2019-05-28 14:21:31 --> Template library initialized
INFO - 2019-05-28 14:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 14:21:31 --> Controller Class Initialized
DEBUG - 2019-05-28 14:21:31 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 14:21:31 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 14:21:31 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/dth.php
DEBUG - 2019-05-28 14:21:31 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 14:21:31 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 14:21:31 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 14:21:31 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 14:21:32 --> Final output sent to browser
DEBUG - 2019-05-28 14:21:32 --> Total execution time: 0.0535
INFO - 2019-05-28 14:21:32 --> Config Class Initialized
INFO - 2019-05-28 14:21:32 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:21:32 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:21:32 --> Utf8 Class Initialized
INFO - 2019-05-28 14:21:32 --> URI Class Initialized
INFO - 2019-05-28 14:21:32 --> Config Class Initialized
INFO - 2019-05-28 14:21:32 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:21:32 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:21:32 --> Utf8 Class Initialized
INFO - 2019-05-28 14:21:32 --> URI Class Initialized
INFO - 2019-05-28 14:21:32 --> Config Class Initialized
INFO - 2019-05-28 14:21:32 --> Hooks Class Initialized
INFO - 2019-05-28 14:21:32 --> Router Class Initialized
INFO - 2019-05-28 14:21:32 --> Output Class Initialized
INFO - 2019-05-28 14:21:32 --> Security Class Initialized
DEBUG - 2019-05-28 14:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:21:32 --> Input Class Initialized
INFO - 2019-05-28 14:21:32 --> Language Class Initialized
ERROR - 2019-05-28 14:21:32 --> 404 Page Not Found: /index
DEBUG - 2019-05-28 14:21:32 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:21:32 --> Utf8 Class Initialized
INFO - 2019-05-28 14:21:32 --> URI Class Initialized
INFO - 2019-05-28 14:21:32 --> Router Class Initialized
INFO - 2019-05-28 14:21:32 --> Output Class Initialized
INFO - 2019-05-28 14:21:32 --> Security Class Initialized
DEBUG - 2019-05-28 14:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:21:32 --> Input Class Initialized
INFO - 2019-05-28 14:21:32 --> Language Class Initialized
ERROR - 2019-05-28 14:21:32 --> 404 Page Not Found: /index
INFO - 2019-05-28 14:21:32 --> Router Class Initialized
INFO - 2019-05-28 14:21:32 --> Output Class Initialized
INFO - 2019-05-28 14:21:32 --> Security Class Initialized
DEBUG - 2019-05-28 14:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:21:32 --> Input Class Initialized
INFO - 2019-05-28 14:21:32 --> Language Class Initialized
ERROR - 2019-05-28 14:21:32 --> 404 Page Not Found: /index
INFO - 2019-05-28 14:21:48 --> Config Class Initialized
INFO - 2019-05-28 14:21:48 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:21:48 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:21:48 --> Utf8 Class Initialized
INFO - 2019-05-28 14:21:48 --> URI Class Initialized
DEBUG - 2019-05-28 14:21:48 --> No URI present. Default controller set.
INFO - 2019-05-28 14:21:48 --> Router Class Initialized
INFO - 2019-05-28 14:21:48 --> Output Class Initialized
INFO - 2019-05-28 14:21:48 --> Security Class Initialized
DEBUG - 2019-05-28 14:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:21:48 --> Input Class Initialized
INFO - 2019-05-28 14:21:48 --> Language Class Initialized
INFO - 2019-05-28 14:21:48 --> Language Class Initialized
INFO - 2019-05-28 14:21:48 --> Config Class Initialized
INFO - 2019-05-28 14:21:48 --> Loader Class Initialized
INFO - 2019-05-28 14:21:48 --> Helper loaded: form_helper
INFO - 2019-05-28 14:21:48 --> Helper loaded: url_helper
INFO - 2019-05-28 14:21:48 --> Helper loaded: cookie_helper
INFO - 2019-05-28 14:21:48 --> Database Driver Class Initialized
DEBUG - 2019-05-28 14:21:48 --> Template library initialized
INFO - 2019-05-28 14:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 14:21:48 --> Controller Class Initialized
DEBUG - 2019-05-28 14:21:48 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 14:21:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 14:21:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 14:21:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 14:21:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 14:21:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 14:21:48 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 14:21:49 --> Final output sent to browser
DEBUG - 2019-05-28 14:21:49 --> Total execution time: 0.0467
INFO - 2019-05-28 14:21:49 --> Config Class Initialized
INFO - 2019-05-28 14:21:49 --> Hooks Class Initialized
INFO - 2019-05-28 14:21:49 --> Config Class Initialized
INFO - 2019-05-28 14:21:49 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:21:49 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:21:49 --> Utf8 Class Initialized
INFO - 2019-05-28 14:21:49 --> URI Class Initialized
INFO - 2019-05-28 14:21:49 --> Router Class Initialized
INFO - 2019-05-28 14:21:49 --> Config Class Initialized
INFO - 2019-05-28 14:21:49 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:21:49 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:21:49 --> Utf8 Class Initialized
INFO - 2019-05-28 14:21:49 --> URI Class Initialized
INFO - 2019-05-28 14:21:49 --> Router Class Initialized
INFO - 2019-05-28 14:21:49 --> Output Class Initialized
INFO - 2019-05-28 14:21:49 --> Security Class Initialized
DEBUG - 2019-05-28 14:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:21:49 --> Input Class Initialized
INFO - 2019-05-28 14:21:49 --> Language Class Initialized
ERROR - 2019-05-28 14:21:49 --> 404 Page Not Found: /index
DEBUG - 2019-05-28 14:21:49 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:21:49 --> Utf8 Class Initialized
INFO - 2019-05-28 14:21:49 --> URI Class Initialized
INFO - 2019-05-28 14:21:49 --> Router Class Initialized
INFO - 2019-05-28 14:21:49 --> Output Class Initialized
INFO - 2019-05-28 14:21:49 --> Security Class Initialized
INFO - 2019-05-28 14:21:49 --> Output Class Initialized
INFO - 2019-05-28 14:21:49 --> Security Class Initialized
DEBUG - 2019-05-28 14:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:21:49 --> Input Class Initialized
INFO - 2019-05-28 14:21:49 --> Language Class Initialized
ERROR - 2019-05-28 14:21:49 --> 404 Page Not Found: /index
DEBUG - 2019-05-28 14:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:21:49 --> Input Class Initialized
INFO - 2019-05-28 14:21:49 --> Language Class Initialized
ERROR - 2019-05-28 14:21:49 --> 404 Page Not Found: /index
INFO - 2019-05-28 14:21:52 --> Config Class Initialized
INFO - 2019-05-28 14:21:52 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:21:52 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:21:52 --> Utf8 Class Initialized
INFO - 2019-05-28 14:21:52 --> URI Class Initialized
INFO - 2019-05-28 14:21:52 --> Router Class Initialized
INFO - 2019-05-28 14:21:52 --> Output Class Initialized
INFO - 2019-05-28 14:21:52 --> Security Class Initialized
DEBUG - 2019-05-28 14:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:21:52 --> Input Class Initialized
INFO - 2019-05-28 14:21:52 --> Language Class Initialized
INFO - 2019-05-28 14:21:52 --> Language Class Initialized
INFO - 2019-05-28 14:21:52 --> Config Class Initialized
INFO - 2019-05-28 14:21:52 --> Loader Class Initialized
INFO - 2019-05-28 14:21:52 --> Helper loaded: form_helper
INFO - 2019-05-28 14:21:52 --> Helper loaded: url_helper
INFO - 2019-05-28 14:21:52 --> Helper loaded: cookie_helper
INFO - 2019-05-28 14:21:52 --> Database Driver Class Initialized
DEBUG - 2019-05-28 14:21:52 --> Template library initialized
INFO - 2019-05-28 14:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 14:21:52 --> Controller Class Initialized
DEBUG - 2019-05-28 14:21:52 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 14:21:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 14:21:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/insurance.php
DEBUG - 2019-05-28 14:21:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 14:21:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 14:21:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 14:21:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 14:21:52 --> Final output sent to browser
DEBUG - 2019-05-28 14:21:52 --> Total execution time: 0.0475
INFO - 2019-05-28 14:21:53 --> Config Class Initialized
INFO - 2019-05-28 14:21:53 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:21:53 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:21:53 --> Utf8 Class Initialized
INFO - 2019-05-28 14:21:53 --> URI Class Initialized
INFO - 2019-05-28 14:21:53 --> Config Class Initialized
INFO - 2019-05-28 14:21:53 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:21:53 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:21:53 --> Utf8 Class Initialized
INFO - 2019-05-28 14:21:53 --> URI Class Initialized
INFO - 2019-05-28 14:21:53 --> Config Class Initialized
INFO - 2019-05-28 14:21:53 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:21:53 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:21:53 --> Utf8 Class Initialized
INFO - 2019-05-28 14:21:53 --> URI Class Initialized
INFO - 2019-05-28 14:21:53 --> Router Class Initialized
INFO - 2019-05-28 14:21:53 --> Output Class Initialized
INFO - 2019-05-28 14:21:53 --> Security Class Initialized
DEBUG - 2019-05-28 14:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:21:53 --> Input Class Initialized
INFO - 2019-05-28 14:21:53 --> Language Class Initialized
ERROR - 2019-05-28 14:21:53 --> 404 Page Not Found: /index
INFO - 2019-05-28 14:21:53 --> Router Class Initialized
INFO - 2019-05-28 14:21:53 --> Output Class Initialized
INFO - 2019-05-28 14:21:53 --> Security Class Initialized
DEBUG - 2019-05-28 14:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:21:53 --> Input Class Initialized
INFO - 2019-05-28 14:21:53 --> Language Class Initialized
ERROR - 2019-05-28 14:21:53 --> 404 Page Not Found: /index
INFO - 2019-05-28 14:21:53 --> Router Class Initialized
INFO - 2019-05-28 14:21:53 --> Output Class Initialized
INFO - 2019-05-28 14:21:53 --> Security Class Initialized
DEBUG - 2019-05-28 14:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:21:53 --> Input Class Initialized
INFO - 2019-05-28 14:21:53 --> Language Class Initialized
ERROR - 2019-05-28 14:21:53 --> 404 Page Not Found: /index
INFO - 2019-05-28 14:21:55 --> Config Class Initialized
INFO - 2019-05-28 14:21:55 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:21:55 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:21:55 --> Utf8 Class Initialized
INFO - 2019-05-28 14:21:55 --> URI Class Initialized
DEBUG - 2019-05-28 14:21:55 --> No URI present. Default controller set.
INFO - 2019-05-28 14:21:55 --> Router Class Initialized
INFO - 2019-05-28 14:21:55 --> Output Class Initialized
INFO - 2019-05-28 14:21:55 --> Security Class Initialized
DEBUG - 2019-05-28 14:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:21:55 --> Input Class Initialized
INFO - 2019-05-28 14:21:55 --> Language Class Initialized
INFO - 2019-05-28 14:21:55 --> Language Class Initialized
INFO - 2019-05-28 14:21:55 --> Config Class Initialized
INFO - 2019-05-28 14:21:55 --> Loader Class Initialized
INFO - 2019-05-28 14:21:55 --> Helper loaded: form_helper
INFO - 2019-05-28 14:21:55 --> Helper loaded: url_helper
INFO - 2019-05-28 14:21:55 --> Helper loaded: cookie_helper
INFO - 2019-05-28 14:21:55 --> Database Driver Class Initialized
DEBUG - 2019-05-28 14:21:55 --> Template library initialized
INFO - 2019-05-28 14:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 14:21:55 --> Controller Class Initialized
DEBUG - 2019-05-28 14:21:55 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 14:21:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 14:21:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 14:21:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 14:21:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 14:21:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 14:21:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 14:21:55 --> Final output sent to browser
DEBUG - 2019-05-28 14:21:55 --> Total execution time: 0.0487
INFO - 2019-05-28 14:21:55 --> Config Class Initialized
INFO - 2019-05-28 14:21:55 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:21:55 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:21:55 --> Utf8 Class Initialized
INFO - 2019-05-28 14:21:55 --> URI Class Initialized
INFO - 2019-05-28 14:21:55 --> Config Class Initialized
INFO - 2019-05-28 14:21:55 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:21:55 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:21:55 --> Utf8 Class Initialized
INFO - 2019-05-28 14:21:55 --> URI Class Initialized
INFO - 2019-05-28 14:21:55 --> Config Class Initialized
INFO - 2019-05-28 14:21:55 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:21:55 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:21:55 --> Utf8 Class Initialized
INFO - 2019-05-28 14:21:55 --> URI Class Initialized
INFO - 2019-05-28 14:21:55 --> Router Class Initialized
INFO - 2019-05-28 14:21:55 --> Output Class Initialized
INFO - 2019-05-28 14:21:55 --> Security Class Initialized
DEBUG - 2019-05-28 14:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:21:55 --> Input Class Initialized
INFO - 2019-05-28 14:21:55 --> Language Class Initialized
ERROR - 2019-05-28 14:21:55 --> 404 Page Not Found: /index
INFO - 2019-05-28 14:21:55 --> Router Class Initialized
INFO - 2019-05-28 14:21:55 --> Output Class Initialized
INFO - 2019-05-28 14:21:55 --> Security Class Initialized
DEBUG - 2019-05-28 14:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:21:55 --> Input Class Initialized
INFO - 2019-05-28 14:21:55 --> Language Class Initialized
ERROR - 2019-05-28 14:21:55 --> 404 Page Not Found: /index
INFO - 2019-05-28 14:21:55 --> Router Class Initialized
INFO - 2019-05-28 14:21:55 --> Output Class Initialized
INFO - 2019-05-28 14:21:55 --> Security Class Initialized
DEBUG - 2019-05-28 14:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:21:55 --> Input Class Initialized
INFO - 2019-05-28 14:21:55 --> Language Class Initialized
ERROR - 2019-05-28 14:21:55 --> 404 Page Not Found: /index
INFO - 2019-05-28 14:22:02 --> Config Class Initialized
INFO - 2019-05-28 14:22:02 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:22:02 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:22:02 --> Utf8 Class Initialized
INFO - 2019-05-28 14:22:02 --> URI Class Initialized
DEBUG - 2019-05-28 14:22:02 --> No URI present. Default controller set.
INFO - 2019-05-28 14:22:02 --> Router Class Initialized
INFO - 2019-05-28 14:22:02 --> Output Class Initialized
INFO - 2019-05-28 14:22:02 --> Security Class Initialized
DEBUG - 2019-05-28 14:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:22:02 --> Input Class Initialized
INFO - 2019-05-28 14:22:02 --> Language Class Initialized
INFO - 2019-05-28 14:22:02 --> Language Class Initialized
INFO - 2019-05-28 14:22:02 --> Config Class Initialized
INFO - 2019-05-28 14:22:02 --> Loader Class Initialized
INFO - 2019-05-28 14:22:02 --> Helper loaded: form_helper
INFO - 2019-05-28 14:22:02 --> Helper loaded: url_helper
INFO - 2019-05-28 14:22:02 --> Helper loaded: cookie_helper
INFO - 2019-05-28 14:22:02 --> Database Driver Class Initialized
DEBUG - 2019-05-28 14:22:02 --> Template library initialized
INFO - 2019-05-28 14:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 14:22:02 --> Controller Class Initialized
DEBUG - 2019-05-28 14:22:02 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 14:22:02 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 14:22:02 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 14:22:02 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 14:22:02 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 14:22:02 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 14:22:02 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 14:22:03 --> Final output sent to browser
DEBUG - 2019-05-28 14:22:03 --> Total execution time: 0.0447
INFO - 2019-05-28 14:22:03 --> Config Class Initialized
INFO - 2019-05-28 14:22:03 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:22:03 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:22:03 --> Utf8 Class Initialized
INFO - 2019-05-28 14:22:03 --> URI Class Initialized
INFO - 2019-05-28 14:22:03 --> Config Class Initialized
INFO - 2019-05-28 14:22:03 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:22:03 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:22:03 --> Utf8 Class Initialized
INFO - 2019-05-28 14:22:03 --> URI Class Initialized
INFO - 2019-05-28 14:22:03 --> Router Class Initialized
INFO - 2019-05-28 14:22:03 --> Config Class Initialized
INFO - 2019-05-28 14:22:03 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:22:03 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:22:03 --> Utf8 Class Initialized
INFO - 2019-05-28 14:22:03 --> URI Class Initialized
INFO - 2019-05-28 14:22:03 --> Router Class Initialized
INFO - 2019-05-28 14:22:03 --> Router Class Initialized
INFO - 2019-05-28 14:22:03 --> Output Class Initialized
INFO - 2019-05-28 14:22:03 --> Security Class Initialized
DEBUG - 2019-05-28 14:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:22:03 --> Input Class Initialized
INFO - 2019-05-28 14:22:03 --> Language Class Initialized
ERROR - 2019-05-28 14:22:03 --> 404 Page Not Found: /index
INFO - 2019-05-28 14:22:03 --> Output Class Initialized
INFO - 2019-05-28 14:22:03 --> Security Class Initialized
DEBUG - 2019-05-28 14:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:22:03 --> Input Class Initialized
INFO - 2019-05-28 14:22:03 --> Language Class Initialized
ERROR - 2019-05-28 14:22:03 --> 404 Page Not Found: /index
INFO - 2019-05-28 14:22:03 --> Output Class Initialized
INFO - 2019-05-28 14:22:03 --> Security Class Initialized
DEBUG - 2019-05-28 14:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:22:03 --> Input Class Initialized
INFO - 2019-05-28 14:22:03 --> Language Class Initialized
ERROR - 2019-05-28 14:22:03 --> 404 Page Not Found: /index
INFO - 2019-05-28 14:22:12 --> Config Class Initialized
INFO - 2019-05-28 14:22:12 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:22:12 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:22:12 --> Utf8 Class Initialized
INFO - 2019-05-28 14:22:12 --> URI Class Initialized
DEBUG - 2019-05-28 14:22:12 --> No URI present. Default controller set.
INFO - 2019-05-28 14:22:12 --> Router Class Initialized
INFO - 2019-05-28 14:22:12 --> Output Class Initialized
INFO - 2019-05-28 14:22:12 --> Security Class Initialized
DEBUG - 2019-05-28 14:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:22:12 --> Input Class Initialized
INFO - 2019-05-28 14:22:12 --> Language Class Initialized
INFO - 2019-05-28 14:22:12 --> Language Class Initialized
INFO - 2019-05-28 14:22:12 --> Config Class Initialized
INFO - 2019-05-28 14:22:12 --> Loader Class Initialized
INFO - 2019-05-28 14:22:12 --> Helper loaded: form_helper
INFO - 2019-05-28 14:22:12 --> Helper loaded: url_helper
INFO - 2019-05-28 14:22:12 --> Helper loaded: cookie_helper
INFO - 2019-05-28 14:22:12 --> Database Driver Class Initialized
DEBUG - 2019-05-28 14:22:12 --> Template library initialized
INFO - 2019-05-28 14:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 14:22:12 --> Controller Class Initialized
DEBUG - 2019-05-28 14:22:12 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 14:22:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 14:22:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 14:22:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 14:22:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 14:22:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 14:22:12 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 14:22:12 --> Final output sent to browser
DEBUG - 2019-05-28 14:22:12 --> Total execution time: 0.0457
INFO - 2019-05-28 14:22:13 --> Config Class Initialized
INFO - 2019-05-28 14:22:13 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:22:13 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:22:13 --> Utf8 Class Initialized
INFO - 2019-05-28 14:22:13 --> URI Class Initialized
INFO - 2019-05-28 14:22:13 --> Config Class Initialized
INFO - 2019-05-28 14:22:13 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:22:13 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:22:13 --> Utf8 Class Initialized
INFO - 2019-05-28 14:22:13 --> URI Class Initialized
INFO - 2019-05-28 14:22:13 --> Router Class Initialized
INFO - 2019-05-28 14:22:13 --> Config Class Initialized
INFO - 2019-05-28 14:22:13 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:22:13 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:22:13 --> Utf8 Class Initialized
INFO - 2019-05-28 14:22:13 --> URI Class Initialized
INFO - 2019-05-28 14:22:13 --> Router Class Initialized
INFO - 2019-05-28 14:22:13 --> Router Class Initialized
INFO - 2019-05-28 14:22:13 --> Output Class Initialized
INFO - 2019-05-28 14:22:13 --> Security Class Initialized
DEBUG - 2019-05-28 14:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:22:13 --> Input Class Initialized
INFO - 2019-05-28 14:22:13 --> Language Class Initialized
ERROR - 2019-05-28 14:22:13 --> 404 Page Not Found: /index
INFO - 2019-05-28 14:22:13 --> Output Class Initialized
INFO - 2019-05-28 14:22:13 --> Security Class Initialized
DEBUG - 2019-05-28 14:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:22:13 --> Input Class Initialized
INFO - 2019-05-28 14:22:13 --> Language Class Initialized
ERROR - 2019-05-28 14:22:13 --> 404 Page Not Found: /index
INFO - 2019-05-28 14:22:13 --> Output Class Initialized
INFO - 2019-05-28 14:22:13 --> Security Class Initialized
DEBUG - 2019-05-28 14:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:22:13 --> Input Class Initialized
INFO - 2019-05-28 14:22:13 --> Language Class Initialized
ERROR - 2019-05-28 14:22:13 --> 404 Page Not Found: /index
INFO - 2019-05-28 14:23:01 --> Config Class Initialized
INFO - 2019-05-28 14:23:01 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:23:01 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:23:01 --> Utf8 Class Initialized
INFO - 2019-05-28 14:23:01 --> URI Class Initialized
DEBUG - 2019-05-28 14:23:01 --> No URI present. Default controller set.
INFO - 2019-05-28 14:23:01 --> Router Class Initialized
INFO - 2019-05-28 14:23:01 --> Output Class Initialized
INFO - 2019-05-28 14:23:01 --> Security Class Initialized
DEBUG - 2019-05-28 14:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:23:01 --> Input Class Initialized
INFO - 2019-05-28 14:23:01 --> Language Class Initialized
INFO - 2019-05-28 14:23:01 --> Language Class Initialized
INFO - 2019-05-28 14:23:01 --> Config Class Initialized
INFO - 2019-05-28 14:23:01 --> Loader Class Initialized
INFO - 2019-05-28 14:23:01 --> Helper loaded: form_helper
INFO - 2019-05-28 14:23:01 --> Helper loaded: url_helper
INFO - 2019-05-28 14:23:01 --> Helper loaded: cookie_helper
INFO - 2019-05-28 14:23:01 --> Database Driver Class Initialized
DEBUG - 2019-05-28 14:23:01 --> Template library initialized
INFO - 2019-05-28 14:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 14:23:01 --> Controller Class Initialized
DEBUG - 2019-05-28 14:23:01 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 14:23:01 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 14:23:01 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 14:23:01 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 14:23:01 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 14:23:01 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 14:23:01 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 14:23:02 --> Final output sent to browser
DEBUG - 2019-05-28 14:23:02 --> Total execution time: 0.0481
INFO - 2019-05-28 14:23:02 --> Config Class Initialized
INFO - 2019-05-28 14:23:02 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:23:02 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:23:02 --> Utf8 Class Initialized
INFO - 2019-05-28 14:23:02 --> URI Class Initialized
INFO - 2019-05-28 14:23:02 --> Config Class Initialized
INFO - 2019-05-28 14:23:02 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:23:02 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:23:02 --> Utf8 Class Initialized
INFO - 2019-05-28 14:23:02 --> URI Class Initialized
INFO - 2019-05-28 14:23:02 --> Config Class Initialized
INFO - 2019-05-28 14:23:02 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:23:02 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:23:02 --> Utf8 Class Initialized
INFO - 2019-05-28 14:23:02 --> URI Class Initialized
INFO - 2019-05-28 14:23:02 --> Router Class Initialized
INFO - 2019-05-28 14:23:02 --> Output Class Initialized
INFO - 2019-05-28 14:23:02 --> Security Class Initialized
DEBUG - 2019-05-28 14:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:23:02 --> Input Class Initialized
INFO - 2019-05-28 14:23:02 --> Language Class Initialized
ERROR - 2019-05-28 14:23:02 --> 404 Page Not Found: /index
INFO - 2019-05-28 14:23:02 --> Router Class Initialized
INFO - 2019-05-28 14:23:02 --> Output Class Initialized
INFO - 2019-05-28 14:23:02 --> Security Class Initialized
DEBUG - 2019-05-28 14:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:23:02 --> Input Class Initialized
INFO - 2019-05-28 14:23:02 --> Language Class Initialized
ERROR - 2019-05-28 14:23:02 --> 404 Page Not Found: /index
INFO - 2019-05-28 14:23:02 --> Router Class Initialized
INFO - 2019-05-28 14:23:02 --> Output Class Initialized
INFO - 2019-05-28 14:23:02 --> Security Class Initialized
DEBUG - 2019-05-28 14:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:23:02 --> Input Class Initialized
INFO - 2019-05-28 14:23:02 --> Language Class Initialized
ERROR - 2019-05-28 14:23:02 --> 404 Page Not Found: /index
INFO - 2019-05-28 14:24:42 --> Config Class Initialized
INFO - 2019-05-28 14:24:42 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:24:42 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:24:42 --> Utf8 Class Initialized
INFO - 2019-05-28 14:24:42 --> URI Class Initialized
INFO - 2019-05-28 14:24:42 --> Router Class Initialized
INFO - 2019-05-28 14:24:42 --> Output Class Initialized
INFO - 2019-05-28 14:24:42 --> Security Class Initialized
DEBUG - 2019-05-28 14:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:24:42 --> Input Class Initialized
INFO - 2019-05-28 14:24:42 --> Language Class Initialized
INFO - 2019-05-28 14:24:42 --> Language Class Initialized
INFO - 2019-05-28 14:24:42 --> Config Class Initialized
INFO - 2019-05-28 14:24:42 --> Loader Class Initialized
INFO - 2019-05-28 14:24:42 --> Helper loaded: form_helper
INFO - 2019-05-28 14:24:42 --> Helper loaded: url_helper
INFO - 2019-05-28 14:24:42 --> Helper loaded: cookie_helper
INFO - 2019-05-28 14:24:42 --> Database Driver Class Initialized
DEBUG - 2019-05-28 14:24:42 --> Template library initialized
INFO - 2019-05-28 14:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 14:24:42 --> Controller Class Initialized
DEBUG - 2019-05-28 14:24:42 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 14:24:42 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 14:24:43 --> Config Class Initialized
INFO - 2019-05-28 14:24:43 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:24:43 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:24:43 --> Utf8 Class Initialized
INFO - 2019-05-28 14:24:43 --> URI Class Initialized
DEBUG - 2019-05-28 14:24:43 --> No URI present. Default controller set.
INFO - 2019-05-28 14:24:43 --> Router Class Initialized
INFO - 2019-05-28 14:24:43 --> Output Class Initialized
INFO - 2019-05-28 14:24:43 --> Security Class Initialized
DEBUG - 2019-05-28 14:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:24:43 --> Input Class Initialized
INFO - 2019-05-28 14:24:43 --> Language Class Initialized
INFO - 2019-05-28 14:24:43 --> Language Class Initialized
INFO - 2019-05-28 14:24:43 --> Config Class Initialized
INFO - 2019-05-28 14:24:43 --> Loader Class Initialized
INFO - 2019-05-28 14:24:43 --> Helper loaded: form_helper
INFO - 2019-05-28 14:24:43 --> Helper loaded: url_helper
INFO - 2019-05-28 14:24:43 --> Helper loaded: cookie_helper
INFO - 2019-05-28 14:24:43 --> Database Driver Class Initialized
DEBUG - 2019-05-28 14:24:43 --> Template library initialized
INFO - 2019-05-28 14:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 14:24:43 --> Controller Class Initialized
DEBUG - 2019-05-28 14:24:43 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 14:24:43 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 14:24:43 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 14:24:43 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 14:24:43 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 14:24:43 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 14:24:43 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 14:24:43 --> Final output sent to browser
DEBUG - 2019-05-28 14:24:43 --> Total execution time: 0.0452
INFO - 2019-05-28 14:24:43 --> Config Class Initialized
INFO - 2019-05-28 14:24:43 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:24:43 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:24:43 --> Utf8 Class Initialized
INFO - 2019-05-28 14:24:43 --> Config Class Initialized
INFO - 2019-05-28 14:24:43 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:24:43 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:24:43 --> Utf8 Class Initialized
INFO - 2019-05-28 14:24:43 --> URI Class Initialized
INFO - 2019-05-28 14:24:43 --> Config Class Initialized
INFO - 2019-05-28 14:24:43 --> Hooks Class Initialized
DEBUG - 2019-05-28 14:24:43 --> UTF-8 Support Enabled
INFO - 2019-05-28 14:24:43 --> Utf8 Class Initialized
INFO - 2019-05-28 14:24:43 --> URI Class Initialized
INFO - 2019-05-28 14:24:43 --> URI Class Initialized
INFO - 2019-05-28 14:24:43 --> Router Class Initialized
INFO - 2019-05-28 14:24:43 --> Output Class Initialized
INFO - 2019-05-28 14:24:43 --> Security Class Initialized
INFO - 2019-05-28 14:24:43 --> Router Class Initialized
INFO - 2019-05-28 14:24:43 --> Output Class Initialized
INFO - 2019-05-28 14:24:43 --> Security Class Initialized
DEBUG - 2019-05-28 14:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:24:43 --> Input Class Initialized
INFO - 2019-05-28 14:24:43 --> Language Class Initialized
ERROR - 2019-05-28 14:24:43 --> 404 Page Not Found: /index
INFO - 2019-05-28 14:24:43 --> Router Class Initialized
INFO - 2019-05-28 14:24:43 --> Output Class Initialized
INFO - 2019-05-28 14:24:43 --> Security Class Initialized
DEBUG - 2019-05-28 14:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:24:43 --> Input Class Initialized
DEBUG - 2019-05-28 14:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 14:24:43 --> Input Class Initialized
INFO - 2019-05-28 14:24:43 --> Language Class Initialized
ERROR - 2019-05-28 14:24:43 --> 404 Page Not Found: /index
INFO - 2019-05-28 14:24:43 --> Language Class Initialized
ERROR - 2019-05-28 14:24:43 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:03:39 --> Config Class Initialized
INFO - 2019-05-28 15:03:39 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:03:39 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:03:39 --> Utf8 Class Initialized
INFO - 2019-05-28 15:03:39 --> URI Class Initialized
DEBUG - 2019-05-28 15:03:39 --> No URI present. Default controller set.
INFO - 2019-05-28 15:03:39 --> Router Class Initialized
INFO - 2019-05-28 15:03:39 --> Output Class Initialized
INFO - 2019-05-28 15:03:39 --> Security Class Initialized
DEBUG - 2019-05-28 15:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:03:39 --> Input Class Initialized
INFO - 2019-05-28 15:03:39 --> Language Class Initialized
INFO - 2019-05-28 15:03:39 --> Language Class Initialized
INFO - 2019-05-28 15:03:39 --> Config Class Initialized
INFO - 2019-05-28 15:03:39 --> Loader Class Initialized
INFO - 2019-05-28 15:03:39 --> Helper loaded: form_helper
INFO - 2019-05-28 15:03:39 --> Helper loaded: url_helper
INFO - 2019-05-28 15:03:39 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:03:39 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:03:39 --> Template library initialized
INFO - 2019-05-28 15:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:03:39 --> Controller Class Initialized
DEBUG - 2019-05-28 15:03:39 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 15:03:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 15:03:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 15:03:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 15:03:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 15:03:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 15:03:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 15:03:40 --> Final output sent to browser
DEBUG - 2019-05-28 15:03:40 --> Total execution time: 0.0481
INFO - 2019-05-28 15:03:40 --> Config Class Initialized
INFO - 2019-05-28 15:03:40 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:03:40 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:03:40 --> Utf8 Class Initialized
INFO - 2019-05-28 15:03:40 --> URI Class Initialized
DEBUG - 2019-05-28 15:03:40 --> No URI present. Default controller set.
INFO - 2019-05-28 15:03:40 --> Router Class Initialized
INFO - 2019-05-28 15:03:40 --> Output Class Initialized
INFO - 2019-05-28 15:03:40 --> Security Class Initialized
DEBUG - 2019-05-28 15:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:03:40 --> Input Class Initialized
INFO - 2019-05-28 15:03:40 --> Language Class Initialized
INFO - 2019-05-28 15:03:40 --> Language Class Initialized
INFO - 2019-05-28 15:03:40 --> Config Class Initialized
INFO - 2019-05-28 15:03:40 --> Loader Class Initialized
INFO - 2019-05-28 15:03:40 --> Helper loaded: form_helper
INFO - 2019-05-28 15:03:40 --> Helper loaded: url_helper
INFO - 2019-05-28 15:03:40 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:03:40 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:03:40 --> Template library initialized
INFO - 2019-05-28 15:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:03:40 --> Controller Class Initialized
DEBUG - 2019-05-28 15:03:40 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 15:03:40 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 15:03:40 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 15:03:40 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 15:03:40 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 15:03:40 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 15:03:40 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 15:03:41 --> Final output sent to browser
DEBUG - 2019-05-28 15:03:41 --> Total execution time: 0.0523
INFO - 2019-05-28 15:03:41 --> Config Class Initialized
INFO - 2019-05-28 15:03:41 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:03:41 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:03:41 --> Utf8 Class Initialized
INFO - 2019-05-28 15:03:41 --> URI Class Initialized
INFO - 2019-05-28 15:03:41 --> Router Class Initialized
INFO - 2019-05-28 15:03:41 --> Output Class Initialized
INFO - 2019-05-28 15:03:41 --> Security Class Initialized
DEBUG - 2019-05-28 15:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:03:41 --> Input Class Initialized
INFO - 2019-05-28 15:03:41 --> Language Class Initialized
ERROR - 2019-05-28 15:03:41 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:03:41 --> Config Class Initialized
INFO - 2019-05-28 15:03:41 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:03:41 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:03:41 --> Utf8 Class Initialized
INFO - 2019-05-28 15:03:41 --> URI Class Initialized
INFO - 2019-05-28 15:03:41 --> Router Class Initialized
INFO - 2019-05-28 15:03:41 --> Output Class Initialized
INFO - 2019-05-28 15:03:41 --> Security Class Initialized
DEBUG - 2019-05-28 15:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:03:41 --> Input Class Initialized
INFO - 2019-05-28 15:03:41 --> Language Class Initialized
ERROR - 2019-05-28 15:03:41 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:03:43 --> Config Class Initialized
INFO - 2019-05-28 15:03:43 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:03:43 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:03:43 --> Utf8 Class Initialized
INFO - 2019-05-28 15:03:43 --> URI Class Initialized
INFO - 2019-05-28 15:03:43 --> Router Class Initialized
INFO - 2019-05-28 15:03:43 --> Output Class Initialized
INFO - 2019-05-28 15:03:43 --> Security Class Initialized
DEBUG - 2019-05-28 15:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:03:43 --> Input Class Initialized
INFO - 2019-05-28 15:03:43 --> Language Class Initialized
ERROR - 2019-05-28 15:03:43 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:03:57 --> Config Class Initialized
INFO - 2019-05-28 15:03:57 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:03:57 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:03:57 --> Utf8 Class Initialized
INFO - 2019-05-28 15:03:57 --> URI Class Initialized
INFO - 2019-05-28 15:03:57 --> Router Class Initialized
INFO - 2019-05-28 15:03:57 --> Output Class Initialized
INFO - 2019-05-28 15:03:57 --> Security Class Initialized
DEBUG - 2019-05-28 15:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:03:57 --> Input Class Initialized
INFO - 2019-05-28 15:03:57 --> Language Class Initialized
INFO - 2019-05-28 15:03:57 --> Language Class Initialized
INFO - 2019-05-28 15:03:57 --> Config Class Initialized
INFO - 2019-05-28 15:03:57 --> Loader Class Initialized
INFO - 2019-05-28 15:03:57 --> Helper loaded: form_helper
INFO - 2019-05-28 15:03:57 --> Helper loaded: url_helper
INFO - 2019-05-28 15:03:57 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:03:57 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:03:57 --> Template library initialized
INFO - 2019-05-28 15:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:03:57 --> Controller Class Initialized
DEBUG - 2019-05-28 15:03:57 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 15:03:57 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
ERROR - 2019-05-28 15:03:57 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: SELECT *
FROM `tbl_registered_user`
WHERE `id` = 15
INFO - 2019-05-28 15:03:57 --> Language file loaded: language/english/db_lang.php
INFO - 2019-05-28 15:04:05 --> Config Class Initialized
INFO - 2019-05-28 15:04:05 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:04:05 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:04:05 --> Utf8 Class Initialized
INFO - 2019-05-28 15:04:05 --> URI Class Initialized
INFO - 2019-05-28 15:04:05 --> Router Class Initialized
INFO - 2019-05-28 15:04:05 --> Output Class Initialized
INFO - 2019-05-28 15:04:05 --> Security Class Initialized
DEBUG - 2019-05-28 15:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:04:05 --> Input Class Initialized
INFO - 2019-05-28 15:04:05 --> Language Class Initialized
ERROR - 2019-05-28 15:04:05 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:04:08 --> Config Class Initialized
INFO - 2019-05-28 15:04:08 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:04:08 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:04:08 --> Utf8 Class Initialized
INFO - 2019-05-28 15:04:08 --> URI Class Initialized
INFO - 2019-05-28 15:04:08 --> Router Class Initialized
INFO - 2019-05-28 15:04:08 --> Output Class Initialized
INFO - 2019-05-28 15:04:08 --> Security Class Initialized
DEBUG - 2019-05-28 15:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:04:08 --> Input Class Initialized
INFO - 2019-05-28 15:04:08 --> Language Class Initialized
INFO - 2019-05-28 15:04:08 --> Language Class Initialized
INFO - 2019-05-28 15:04:08 --> Config Class Initialized
INFO - 2019-05-28 15:04:08 --> Loader Class Initialized
INFO - 2019-05-28 15:04:08 --> Helper loaded: form_helper
INFO - 2019-05-28 15:04:08 --> Helper loaded: url_helper
INFO - 2019-05-28 15:04:08 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:04:08 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:04:08 --> Template library initialized
INFO - 2019-05-28 15:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:04:08 --> Controller Class Initialized
DEBUG - 2019-05-28 15:04:08 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 15:04:08 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 15:04:08 --> Email Class Initialized
ERROR - 2019-05-28 15:04:13 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.googlemail.com:465 (Connection timed out) /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/system/libraries/Email.php 2069
INFO - 2019-05-28 15:04:13 --> Language file loaded: language/english/email_lang.php
INFO - 2019-05-28 15:04:13 --> Final output sent to browser
DEBUG - 2019-05-28 15:04:13 --> Total execution time: 5.0519
INFO - 2019-05-28 15:04:13 --> Config Class Initialized
INFO - 2019-05-28 15:04:13 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:04:13 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:04:13 --> Utf8 Class Initialized
INFO - 2019-05-28 15:04:13 --> URI Class Initialized
INFO - 2019-05-28 15:04:13 --> Router Class Initialized
INFO - 2019-05-28 15:04:13 --> Output Class Initialized
INFO - 2019-05-28 15:04:13 --> Security Class Initialized
DEBUG - 2019-05-28 15:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:04:13 --> Input Class Initialized
INFO - 2019-05-28 15:04:13 --> Language Class Initialized
INFO - 2019-05-28 15:04:13 --> Language Class Initialized
INFO - 2019-05-28 15:04:13 --> Config Class Initialized
INFO - 2019-05-28 15:04:13 --> Loader Class Initialized
INFO - 2019-05-28 15:04:13 --> Helper loaded: form_helper
INFO - 2019-05-28 15:04:13 --> Helper loaded: url_helper
INFO - 2019-05-28 15:04:13 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:04:13 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:04:13 --> Template library initialized
INFO - 2019-05-28 15:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:04:13 --> Controller Class Initialized
DEBUG - 2019-05-28 15:04:13 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 15:04:13 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 15:04:13 --> Email Class Initialized
ERROR - 2019-05-28 15:04:18 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.googlemail.com:465 (Connection timed out) /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/system/libraries/Email.php 2069
INFO - 2019-05-28 15:04:18 --> Language file loaded: language/english/email_lang.php
INFO - 2019-05-28 15:04:18 --> Final output sent to browser
DEBUG - 2019-05-28 15:04:18 --> Total execution time: 5.0515
INFO - 2019-05-28 15:04:20 --> Config Class Initialized
INFO - 2019-05-28 15:04:20 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:04:20 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:04:20 --> Utf8 Class Initialized
INFO - 2019-05-28 15:04:20 --> URI Class Initialized
INFO - 2019-05-28 15:04:20 --> Router Class Initialized
INFO - 2019-05-28 15:04:20 --> Output Class Initialized
INFO - 2019-05-28 15:04:20 --> Security Class Initialized
DEBUG - 2019-05-28 15:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:04:20 --> Input Class Initialized
INFO - 2019-05-28 15:04:20 --> Language Class Initialized
ERROR - 2019-05-28 15:04:20 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:04:20 --> Config Class Initialized
INFO - 2019-05-28 15:04:20 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:04:20 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:04:20 --> Utf8 Class Initialized
INFO - 2019-05-28 15:04:20 --> URI Class Initialized
INFO - 2019-05-28 15:04:20 --> Router Class Initialized
INFO - 2019-05-28 15:04:20 --> Output Class Initialized
INFO - 2019-05-28 15:04:20 --> Security Class Initialized
DEBUG - 2019-05-28 15:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:04:20 --> Input Class Initialized
INFO - 2019-05-28 15:04:20 --> Language Class Initialized
ERROR - 2019-05-28 15:04:20 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:04:28 --> Config Class Initialized
INFO - 2019-05-28 15:04:28 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:04:28 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:04:28 --> Utf8 Class Initialized
INFO - 2019-05-28 15:04:28 --> URI Class Initialized
INFO - 2019-05-28 15:04:28 --> Router Class Initialized
INFO - 2019-05-28 15:04:28 --> Output Class Initialized
INFO - 2019-05-28 15:04:28 --> Security Class Initialized
DEBUG - 2019-05-28 15:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:04:28 --> Input Class Initialized
INFO - 2019-05-28 15:04:28 --> Language Class Initialized
INFO - 2019-05-28 15:04:28 --> Language Class Initialized
INFO - 2019-05-28 15:04:28 --> Config Class Initialized
INFO - 2019-05-28 15:04:28 --> Loader Class Initialized
INFO - 2019-05-28 15:04:28 --> Helper loaded: form_helper
INFO - 2019-05-28 15:04:28 --> Helper loaded: url_helper
INFO - 2019-05-28 15:04:28 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:04:28 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:04:28 --> Template library initialized
INFO - 2019-05-28 15:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:04:28 --> Controller Class Initialized
DEBUG - 2019-05-28 15:04:28 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 15:04:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 15:04:28 --> Email Class Initialized
ERROR - 2019-05-28 15:04:33 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.googlemail.com:465 (Connection timed out) /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/system/libraries/Email.php 2069
INFO - 2019-05-28 15:04:33 --> Language file loaded: language/english/email_lang.php
INFO - 2019-05-28 15:04:33 --> Final output sent to browser
DEBUG - 2019-05-28 15:04:33 --> Total execution time: 5.0797
INFO - 2019-05-28 15:04:43 --> Config Class Initialized
INFO - 2019-05-28 15:04:43 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:04:43 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:04:43 --> Utf8 Class Initialized
INFO - 2019-05-28 15:04:43 --> URI Class Initialized
INFO - 2019-05-28 15:04:43 --> Router Class Initialized
INFO - 2019-05-28 15:04:43 --> Output Class Initialized
INFO - 2019-05-28 15:04:43 --> Security Class Initialized
DEBUG - 2019-05-28 15:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:04:43 --> Input Class Initialized
INFO - 2019-05-28 15:04:43 --> Language Class Initialized
INFO - 2019-05-28 15:04:43 --> Language Class Initialized
INFO - 2019-05-28 15:04:43 --> Config Class Initialized
INFO - 2019-05-28 15:04:43 --> Loader Class Initialized
INFO - 2019-05-28 15:04:43 --> Helper loaded: form_helper
INFO - 2019-05-28 15:04:43 --> Helper loaded: url_helper
INFO - 2019-05-28 15:04:43 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:04:43 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:04:43 --> Template library initialized
INFO - 2019-05-28 15:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:04:43 --> Controller Class Initialized
DEBUG - 2019-05-28 15:04:43 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 15:04:43 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 15:04:43 --> Email Class Initialized
ERROR - 2019-05-28 15:04:48 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.googlemail.com:465 (Connection timed out) /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/system/libraries/Email.php 2069
INFO - 2019-05-28 15:04:48 --> Language file loaded: language/english/email_lang.php
INFO - 2019-05-28 15:04:48 --> Final output sent to browser
DEBUG - 2019-05-28 15:04:48 --> Total execution time: 5.0484
INFO - 2019-05-28 15:04:48 --> Config Class Initialized
INFO - 2019-05-28 15:04:48 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:04:48 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:04:48 --> Utf8 Class Initialized
INFO - 2019-05-28 15:04:48 --> URI Class Initialized
INFO - 2019-05-28 15:04:48 --> Router Class Initialized
INFO - 2019-05-28 15:04:48 --> Output Class Initialized
INFO - 2019-05-28 15:04:48 --> Security Class Initialized
DEBUG - 2019-05-28 15:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:04:48 --> Input Class Initialized
INFO - 2019-05-28 15:04:48 --> Language Class Initialized
ERROR - 2019-05-28 15:04:48 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:07:15 --> Config Class Initialized
INFO - 2019-05-28 15:07:15 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:07:15 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:07:15 --> Utf8 Class Initialized
INFO - 2019-05-28 15:07:15 --> URI Class Initialized
INFO - 2019-05-28 15:07:15 --> Router Class Initialized
INFO - 2019-05-28 15:07:15 --> Output Class Initialized
INFO - 2019-05-28 15:07:15 --> Security Class Initialized
DEBUG - 2019-05-28 15:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:07:15 --> Input Class Initialized
INFO - 2019-05-28 15:07:15 --> Language Class Initialized
INFO - 2019-05-28 15:07:15 --> Language Class Initialized
INFO - 2019-05-28 15:07:15 --> Config Class Initialized
INFO - 2019-05-28 15:07:15 --> Loader Class Initialized
INFO - 2019-05-28 15:07:15 --> Helper loaded: form_helper
INFO - 2019-05-28 15:07:15 --> Helper loaded: url_helper
INFO - 2019-05-28 15:07:15 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:07:15 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:07:15 --> Template library initialized
INFO - 2019-05-28 15:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:07:15 --> Controller Class Initialized
DEBUG - 2019-05-28 15:07:15 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 15:07:15 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 15:07:15 --> Email Class Initialized
ERROR - 2019-05-28 15:07:20 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.googlemail.com:465 (Connection timed out) /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/system/libraries/Email.php 2069
INFO - 2019-05-28 15:07:20 --> Language file loaded: language/english/email_lang.php
INFO - 2019-05-28 15:07:20 --> Final output sent to browser
DEBUG - 2019-05-28 15:07:20 --> Total execution time: 5.0550
INFO - 2019-05-28 15:10:32 --> Config Class Initialized
INFO - 2019-05-28 15:10:32 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:10:32 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:10:32 --> Utf8 Class Initialized
INFO - 2019-05-28 15:10:32 --> URI Class Initialized
INFO - 2019-05-28 15:10:32 --> Router Class Initialized
INFO - 2019-05-28 15:10:32 --> Output Class Initialized
INFO - 2019-05-28 15:10:32 --> Security Class Initialized
DEBUG - 2019-05-28 15:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:10:32 --> Input Class Initialized
INFO - 2019-05-28 15:10:32 --> Language Class Initialized
ERROR - 2019-05-28 15:10:32 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/controllers/Api.php 34
INFO - 2019-05-28 15:10:37 --> Config Class Initialized
INFO - 2019-05-28 15:10:37 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:10:37 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:10:37 --> Utf8 Class Initialized
INFO - 2019-05-28 15:10:37 --> URI Class Initialized
INFO - 2019-05-28 15:10:37 --> Router Class Initialized
INFO - 2019-05-28 15:10:37 --> Output Class Initialized
INFO - 2019-05-28 15:10:37 --> Security Class Initialized
DEBUG - 2019-05-28 15:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:10:37 --> Input Class Initialized
INFO - 2019-05-28 15:10:37 --> Language Class Initialized
ERROR - 2019-05-28 15:10:37 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/controllers/Api.php 34
INFO - 2019-05-28 15:11:15 --> Config Class Initialized
INFO - 2019-05-28 15:11:15 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:11:15 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:11:15 --> Utf8 Class Initialized
INFO - 2019-05-28 15:11:15 --> URI Class Initialized
INFO - 2019-05-28 15:11:15 --> Router Class Initialized
INFO - 2019-05-28 15:11:15 --> Output Class Initialized
INFO - 2019-05-28 15:11:15 --> Security Class Initialized
DEBUG - 2019-05-28 15:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:11:15 --> Input Class Initialized
INFO - 2019-05-28 15:11:15 --> Language Class Initialized
INFO - 2019-05-28 15:11:15 --> Language Class Initialized
INFO - 2019-05-28 15:11:15 --> Config Class Initialized
INFO - 2019-05-28 15:11:15 --> Loader Class Initialized
INFO - 2019-05-28 15:11:15 --> Helper loaded: form_helper
INFO - 2019-05-28 15:11:15 --> Helper loaded: url_helper
INFO - 2019-05-28 15:11:15 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:11:15 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:11:15 --> Template library initialized
INFO - 2019-05-28 15:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:11:15 --> Controller Class Initialized
DEBUG - 2019-05-28 15:11:15 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 15:11:15 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
ERROR - 2019-05-28 15:11:15 --> Severity: Notice --> Undefined variable: body /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/controllers/Api.php 35
INFO - 2019-05-28 15:11:15 --> Final output sent to browser
DEBUG - 2019-05-28 15:11:15 --> Total execution time: 0.0566
INFO - 2019-05-28 15:11:18 --> Config Class Initialized
INFO - 2019-05-28 15:11:18 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:11:18 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:11:18 --> Utf8 Class Initialized
INFO - 2019-05-28 15:11:18 --> URI Class Initialized
INFO - 2019-05-28 15:11:18 --> Router Class Initialized
INFO - 2019-05-28 15:11:18 --> Output Class Initialized
INFO - 2019-05-28 15:11:18 --> Security Class Initialized
DEBUG - 2019-05-28 15:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:11:18 --> Input Class Initialized
INFO - 2019-05-28 15:11:18 --> Language Class Initialized
INFO - 2019-05-28 15:11:18 --> Language Class Initialized
INFO - 2019-05-28 15:11:18 --> Config Class Initialized
INFO - 2019-05-28 15:11:18 --> Loader Class Initialized
INFO - 2019-05-28 15:11:18 --> Helper loaded: form_helper
INFO - 2019-05-28 15:11:18 --> Helper loaded: url_helper
INFO - 2019-05-28 15:11:18 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:11:18 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:11:18 --> Template library initialized
INFO - 2019-05-28 15:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:11:18 --> Controller Class Initialized
DEBUG - 2019-05-28 15:11:18 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 15:11:18 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
ERROR - 2019-05-28 15:11:18 --> Severity: Notice --> Undefined variable: body /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/controllers/Api.php 35
INFO - 2019-05-28 15:11:18 --> Final output sent to browser
DEBUG - 2019-05-28 15:11:18 --> Total execution time: 0.0565
INFO - 2019-05-28 15:12:09 --> Config Class Initialized
INFO - 2019-05-28 15:12:09 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:12:09 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:12:09 --> Utf8 Class Initialized
INFO - 2019-05-28 15:12:09 --> URI Class Initialized
INFO - 2019-05-28 15:12:09 --> Router Class Initialized
INFO - 2019-05-28 15:12:09 --> Output Class Initialized
INFO - 2019-05-28 15:12:09 --> Security Class Initialized
DEBUG - 2019-05-28 15:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:12:09 --> Input Class Initialized
INFO - 2019-05-28 15:12:09 --> Language Class Initialized
INFO - 2019-05-28 15:12:09 --> Language Class Initialized
INFO - 2019-05-28 15:12:09 --> Config Class Initialized
INFO - 2019-05-28 15:12:09 --> Loader Class Initialized
INFO - 2019-05-28 15:12:09 --> Helper loaded: form_helper
INFO - 2019-05-28 15:12:09 --> Helper loaded: url_helper
INFO - 2019-05-28 15:12:09 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:12:09 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:12:09 --> Template library initialized
INFO - 2019-05-28 15:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:12:09 --> Controller Class Initialized
DEBUG - 2019-05-28 15:12:09 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 15:12:09 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 15:12:09 --> Final output sent to browser
DEBUG - 2019-05-28 15:12:09 --> Total execution time: 0.0538
INFO - 2019-05-28 15:12:14 --> Config Class Initialized
INFO - 2019-05-28 15:12:14 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:12:14 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:12:14 --> Utf8 Class Initialized
INFO - 2019-05-28 15:12:14 --> URI Class Initialized
INFO - 2019-05-28 15:12:14 --> Router Class Initialized
INFO - 2019-05-28 15:12:14 --> Output Class Initialized
INFO - 2019-05-28 15:12:14 --> Security Class Initialized
DEBUG - 2019-05-28 15:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:12:14 --> Input Class Initialized
INFO - 2019-05-28 15:12:14 --> Language Class Initialized
INFO - 2019-05-28 15:12:14 --> Language Class Initialized
INFO - 2019-05-28 15:12:14 --> Config Class Initialized
INFO - 2019-05-28 15:12:14 --> Loader Class Initialized
INFO - 2019-05-28 15:12:14 --> Helper loaded: form_helper
INFO - 2019-05-28 15:12:14 --> Helper loaded: url_helper
INFO - 2019-05-28 15:12:14 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:12:14 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:12:14 --> Template library initialized
INFO - 2019-05-28 15:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:12:14 --> Controller Class Initialized
DEBUG - 2019-05-28 15:12:14 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 15:12:14 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 15:12:14 --> Final output sent to browser
DEBUG - 2019-05-28 15:12:14 --> Total execution time: 0.0571
INFO - 2019-05-28 15:15:01 --> Config Class Initialized
INFO - 2019-05-28 15:15:01 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:15:01 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:15:01 --> Utf8 Class Initialized
INFO - 2019-05-28 15:15:01 --> URI Class Initialized
INFO - 2019-05-28 15:15:01 --> Router Class Initialized
INFO - 2019-05-28 15:15:01 --> Output Class Initialized
INFO - 2019-05-28 15:15:01 --> Security Class Initialized
DEBUG - 2019-05-28 15:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:15:01 --> Input Class Initialized
INFO - 2019-05-28 15:15:01 --> Language Class Initialized
INFO - 2019-05-28 15:15:01 --> Language Class Initialized
INFO - 2019-05-28 15:15:01 --> Config Class Initialized
INFO - 2019-05-28 15:15:01 --> Loader Class Initialized
INFO - 2019-05-28 15:15:01 --> Helper loaded: form_helper
INFO - 2019-05-28 15:15:01 --> Helper loaded: url_helper
INFO - 2019-05-28 15:15:01 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:15:01 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:15:01 --> Template library initialized
INFO - 2019-05-28 15:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:15:01 --> Controller Class Initialized
DEBUG - 2019-05-28 15:15:01 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 15:15:01 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 15:15:01 --> Final output sent to browser
DEBUG - 2019-05-28 15:15:01 --> Total execution time: 0.0577
INFO - 2019-05-28 15:15:02 --> Config Class Initialized
INFO - 2019-05-28 15:15:02 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:15:02 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:15:02 --> Utf8 Class Initialized
INFO - 2019-05-28 15:15:02 --> URI Class Initialized
INFO - 2019-05-28 15:15:02 --> Router Class Initialized
INFO - 2019-05-28 15:15:02 --> Output Class Initialized
INFO - 2019-05-28 15:15:02 --> Security Class Initialized
DEBUG - 2019-05-28 15:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:15:02 --> Input Class Initialized
INFO - 2019-05-28 15:15:02 --> Language Class Initialized
INFO - 2019-05-28 15:15:02 --> Language Class Initialized
INFO - 2019-05-28 15:15:02 --> Config Class Initialized
INFO - 2019-05-28 15:15:02 --> Loader Class Initialized
INFO - 2019-05-28 15:15:02 --> Helper loaded: form_helper
INFO - 2019-05-28 15:15:02 --> Helper loaded: url_helper
INFO - 2019-05-28 15:15:02 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:15:02 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:15:02 --> Template library initialized
INFO - 2019-05-28 15:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:15:02 --> Controller Class Initialized
DEBUG - 2019-05-28 15:15:02 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 15:15:02 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 15:15:02 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 15:15:02 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 15:15:02 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 15:15:02 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 15:15:02 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 15:15:02 --> Final output sent to browser
DEBUG - 2019-05-28 15:15:02 --> Total execution time: 0.0693
INFO - 2019-05-28 15:15:03 --> Config Class Initialized
INFO - 2019-05-28 15:15:03 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:15:03 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:15:03 --> Utf8 Class Initialized
INFO - 2019-05-28 15:15:03 --> URI Class Initialized
INFO - 2019-05-28 15:15:03 --> Router Class Initialized
INFO - 2019-05-28 15:15:03 --> Output Class Initialized
INFO - 2019-05-28 15:15:03 --> Security Class Initialized
DEBUG - 2019-05-28 15:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:15:03 --> Input Class Initialized
INFO - 2019-05-28 15:15:03 --> Language Class Initialized
ERROR - 2019-05-28 15:15:03 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:15:03 --> Config Class Initialized
INFO - 2019-05-28 15:15:03 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:15:03 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:15:03 --> Utf8 Class Initialized
INFO - 2019-05-28 15:15:03 --> Config Class Initialized
INFO - 2019-05-28 15:15:03 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:15:03 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:15:03 --> Utf8 Class Initialized
INFO - 2019-05-28 15:15:03 --> URI Class Initialized
INFO - 2019-05-28 15:15:03 --> URI Class Initialized
INFO - 2019-05-28 15:15:03 --> Router Class Initialized
INFO - 2019-05-28 15:15:03 --> Router Class Initialized
INFO - 2019-05-28 15:15:03 --> Output Class Initialized
INFO - 2019-05-28 15:15:03 --> Security Class Initialized
DEBUG - 2019-05-28 15:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:15:03 --> Input Class Initialized
INFO - 2019-05-28 15:15:03 --> Language Class Initialized
ERROR - 2019-05-28 15:15:03 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:15:03 --> Output Class Initialized
INFO - 2019-05-28 15:15:03 --> Security Class Initialized
DEBUG - 2019-05-28 15:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:15:03 --> Input Class Initialized
INFO - 2019-05-28 15:15:03 --> Language Class Initialized
ERROR - 2019-05-28 15:15:03 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:15:04 --> Config Class Initialized
INFO - 2019-05-28 15:15:04 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:15:04 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:15:04 --> Utf8 Class Initialized
INFO - 2019-05-28 15:15:04 --> URI Class Initialized
INFO - 2019-05-28 15:15:04 --> Router Class Initialized
INFO - 2019-05-28 15:15:04 --> Output Class Initialized
INFO - 2019-05-28 15:15:04 --> Security Class Initialized
DEBUG - 2019-05-28 15:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:15:04 --> Input Class Initialized
INFO - 2019-05-28 15:15:04 --> Language Class Initialized
ERROR - 2019-05-28 15:15:04 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:15:04 --> Config Class Initialized
INFO - 2019-05-28 15:15:04 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:15:04 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:15:04 --> Utf8 Class Initialized
INFO - 2019-05-28 15:15:04 --> URI Class Initialized
INFO - 2019-05-28 15:15:04 --> Router Class Initialized
INFO - 2019-05-28 15:15:04 --> Output Class Initialized
INFO - 2019-05-28 15:15:04 --> Security Class Initialized
DEBUG - 2019-05-28 15:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:15:04 --> Input Class Initialized
INFO - 2019-05-28 15:15:04 --> Language Class Initialized
ERROR - 2019-05-28 15:15:04 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:15:07 --> Config Class Initialized
INFO - 2019-05-28 15:15:07 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:15:07 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:15:07 --> Utf8 Class Initialized
INFO - 2019-05-28 15:15:07 --> URI Class Initialized
INFO - 2019-05-28 15:15:07 --> Router Class Initialized
INFO - 2019-05-28 15:15:07 --> Output Class Initialized
INFO - 2019-05-28 15:15:07 --> Security Class Initialized
DEBUG - 2019-05-28 15:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:15:07 --> Input Class Initialized
INFO - 2019-05-28 15:15:07 --> Language Class Initialized
ERROR - 2019-05-28 15:15:07 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:15:21 --> Config Class Initialized
INFO - 2019-05-28 15:15:21 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:15:21 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:15:21 --> Utf8 Class Initialized
INFO - 2019-05-28 15:15:21 --> URI Class Initialized
DEBUG - 2019-05-28 15:15:21 --> No URI present. Default controller set.
INFO - 2019-05-28 15:15:21 --> Router Class Initialized
INFO - 2019-05-28 15:15:21 --> Output Class Initialized
INFO - 2019-05-28 15:15:21 --> Security Class Initialized
DEBUG - 2019-05-28 15:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:15:21 --> Input Class Initialized
INFO - 2019-05-28 15:15:21 --> Language Class Initialized
INFO - 2019-05-28 15:15:21 --> Language Class Initialized
INFO - 2019-05-28 15:15:21 --> Config Class Initialized
INFO - 2019-05-28 15:15:21 --> Loader Class Initialized
INFO - 2019-05-28 15:15:21 --> Helper loaded: form_helper
INFO - 2019-05-28 15:15:21 --> Helper loaded: url_helper
INFO - 2019-05-28 15:15:21 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:15:21 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:15:21 --> Template library initialized
INFO - 2019-05-28 15:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:15:21 --> Controller Class Initialized
DEBUG - 2019-05-28 15:15:21 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 15:15:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 15:15:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 15:15:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 15:15:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 15:15:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 15:15:21 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 15:15:22 --> Final output sent to browser
DEBUG - 2019-05-28 15:15:22 --> Total execution time: 0.0470
INFO - 2019-05-28 15:15:22 --> Config Class Initialized
INFO - 2019-05-28 15:15:22 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:15:22 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:15:22 --> Utf8 Class Initialized
INFO - 2019-05-28 15:15:22 --> URI Class Initialized
INFO - 2019-05-28 15:15:22 --> Router Class Initialized
INFO - 2019-05-28 15:15:22 --> Output Class Initialized
INFO - 2019-05-28 15:15:22 --> Security Class Initialized
DEBUG - 2019-05-28 15:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:15:22 --> Input Class Initialized
INFO - 2019-05-28 15:15:22 --> Language Class Initialized
ERROR - 2019-05-28 15:15:22 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:15:22 --> Config Class Initialized
INFO - 2019-05-28 15:15:22 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:15:22 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:15:22 --> Utf8 Class Initialized
INFO - 2019-05-28 15:15:22 --> URI Class Initialized
INFO - 2019-05-28 15:15:22 --> Router Class Initialized
INFO - 2019-05-28 15:15:22 --> Output Class Initialized
INFO - 2019-05-28 15:15:22 --> Security Class Initialized
DEBUG - 2019-05-28 15:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:15:22 --> Input Class Initialized
INFO - 2019-05-28 15:15:22 --> Language Class Initialized
ERROR - 2019-05-28 15:15:22 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:15:22 --> Config Class Initialized
INFO - 2019-05-28 15:15:22 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:15:22 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:15:22 --> Utf8 Class Initialized
INFO - 2019-05-28 15:15:22 --> URI Class Initialized
INFO - 2019-05-28 15:15:22 --> Router Class Initialized
INFO - 2019-05-28 15:15:22 --> Output Class Initialized
INFO - 2019-05-28 15:15:22 --> Security Class Initialized
DEBUG - 2019-05-28 15:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:15:22 --> Input Class Initialized
INFO - 2019-05-28 15:15:22 --> Language Class Initialized
ERROR - 2019-05-28 15:15:22 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:15:32 --> Config Class Initialized
INFO - 2019-05-28 15:15:32 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:15:32 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:15:32 --> Utf8 Class Initialized
INFO - 2019-05-28 15:15:32 --> URI Class Initialized
INFO - 2019-05-28 15:15:32 --> Router Class Initialized
INFO - 2019-05-28 15:15:32 --> Output Class Initialized
INFO - 2019-05-28 15:15:32 --> Security Class Initialized
DEBUG - 2019-05-28 15:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:15:32 --> Input Class Initialized
INFO - 2019-05-28 15:15:32 --> Language Class Initialized
INFO - 2019-05-28 15:15:32 --> Language Class Initialized
INFO - 2019-05-28 15:15:32 --> Config Class Initialized
INFO - 2019-05-28 15:15:32 --> Loader Class Initialized
INFO - 2019-05-28 15:15:32 --> Helper loaded: form_helper
INFO - 2019-05-28 15:15:32 --> Helper loaded: url_helper
INFO - 2019-05-28 15:15:32 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:15:32 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:15:32 --> Template library initialized
INFO - 2019-05-28 15:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:15:32 --> Controller Class Initialized
DEBUG - 2019-05-28 15:15:32 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 15:15:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 15:15:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/dth.php
DEBUG - 2019-05-28 15:15:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 15:15:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 15:15:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 15:15:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 15:15:32 --> Final output sent to browser
DEBUG - 2019-05-28 15:15:32 --> Total execution time: 0.0631
INFO - 2019-05-28 15:15:32 --> Config Class Initialized
INFO - 2019-05-28 15:15:32 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:15:32 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:15:32 --> Utf8 Class Initialized
INFO - 2019-05-28 15:15:32 --> URI Class Initialized
INFO - 2019-05-28 15:15:32 --> Router Class Initialized
INFO - 2019-05-28 15:15:32 --> Output Class Initialized
INFO - 2019-05-28 15:15:32 --> Security Class Initialized
DEBUG - 2019-05-28 15:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:15:32 --> Input Class Initialized
INFO - 2019-05-28 15:15:32 --> Language Class Initialized
ERROR - 2019-05-28 15:15:32 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:15:33 --> Config Class Initialized
INFO - 2019-05-28 15:15:33 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:15:33 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:15:33 --> Utf8 Class Initialized
INFO - 2019-05-28 15:15:33 --> URI Class Initialized
INFO - 2019-05-28 15:15:33 --> Config Class Initialized
INFO - 2019-05-28 15:15:33 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:15:33 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:15:33 --> Utf8 Class Initialized
INFO - 2019-05-28 15:15:33 --> URI Class Initialized
INFO - 2019-05-28 15:15:33 --> Router Class Initialized
INFO - 2019-05-28 15:15:33 --> Output Class Initialized
INFO - 2019-05-28 15:15:33 --> Security Class Initialized
DEBUG - 2019-05-28 15:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:15:33 --> Input Class Initialized
INFO - 2019-05-28 15:15:33 --> Language Class Initialized
ERROR - 2019-05-28 15:15:33 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:15:33 --> Router Class Initialized
INFO - 2019-05-28 15:15:33 --> Output Class Initialized
INFO - 2019-05-28 15:15:33 --> Security Class Initialized
DEBUG - 2019-05-28 15:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:15:33 --> Input Class Initialized
INFO - 2019-05-28 15:15:33 --> Language Class Initialized
ERROR - 2019-05-28 15:15:33 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:15:38 --> Config Class Initialized
INFO - 2019-05-28 15:15:38 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:15:38 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:15:38 --> Utf8 Class Initialized
INFO - 2019-05-28 15:15:38 --> URI Class Initialized
DEBUG - 2019-05-28 15:15:38 --> No URI present. Default controller set.
INFO - 2019-05-28 15:15:38 --> Router Class Initialized
INFO - 2019-05-28 15:15:38 --> Output Class Initialized
INFO - 2019-05-28 15:15:38 --> Security Class Initialized
DEBUG - 2019-05-28 15:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:15:38 --> Input Class Initialized
INFO - 2019-05-28 15:15:38 --> Language Class Initialized
INFO - 2019-05-28 15:15:38 --> Language Class Initialized
INFO - 2019-05-28 15:15:38 --> Config Class Initialized
INFO - 2019-05-28 15:15:38 --> Loader Class Initialized
INFO - 2019-05-28 15:15:38 --> Helper loaded: form_helper
INFO - 2019-05-28 15:15:38 --> Helper loaded: url_helper
INFO - 2019-05-28 15:15:38 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:15:38 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:15:38 --> Template library initialized
INFO - 2019-05-28 15:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:15:38 --> Controller Class Initialized
DEBUG - 2019-05-28 15:15:38 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 15:15:38 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 15:15:38 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 15:15:38 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 15:15:38 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 15:15:38 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 15:15:38 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 15:15:38 --> Final output sent to browser
DEBUG - 2019-05-28 15:15:38 --> Total execution time: 0.0449
INFO - 2019-05-28 15:15:39 --> Config Class Initialized
INFO - 2019-05-28 15:15:39 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:15:39 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:15:39 --> Utf8 Class Initialized
INFO - 2019-05-28 15:15:39 --> URI Class Initialized
INFO - 2019-05-28 15:15:39 --> Router Class Initialized
INFO - 2019-05-28 15:15:39 --> Output Class Initialized
INFO - 2019-05-28 15:15:39 --> Security Class Initialized
DEBUG - 2019-05-28 15:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:15:39 --> Input Class Initialized
INFO - 2019-05-28 15:15:39 --> Language Class Initialized
ERROR - 2019-05-28 15:15:39 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:15:39 --> Config Class Initialized
INFO - 2019-05-28 15:15:39 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:15:39 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:15:39 --> Utf8 Class Initialized
INFO - 2019-05-28 15:15:39 --> URI Class Initialized
INFO - 2019-05-28 15:15:39 --> Config Class Initialized
INFO - 2019-05-28 15:15:39 --> Hooks Class Initialized
INFO - 2019-05-28 15:15:39 --> Router Class Initialized
INFO - 2019-05-28 15:15:39 --> Output Class Initialized
INFO - 2019-05-28 15:15:39 --> Security Class Initialized
DEBUG - 2019-05-28 15:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:15:39 --> Input Class Initialized
INFO - 2019-05-28 15:15:39 --> Language Class Initialized
ERROR - 2019-05-28 15:15:39 --> 404 Page Not Found: /index
DEBUG - 2019-05-28 15:15:39 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:15:39 --> Utf8 Class Initialized
INFO - 2019-05-28 15:15:39 --> URI Class Initialized
INFO - 2019-05-28 15:15:39 --> Router Class Initialized
INFO - 2019-05-28 15:15:39 --> Output Class Initialized
INFO - 2019-05-28 15:15:39 --> Security Class Initialized
DEBUG - 2019-05-28 15:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:15:39 --> Input Class Initialized
INFO - 2019-05-28 15:15:39 --> Language Class Initialized
ERROR - 2019-05-28 15:15:39 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:15:47 --> Config Class Initialized
INFO - 2019-05-28 15:15:47 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:15:47 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:15:47 --> Utf8 Class Initialized
INFO - 2019-05-28 15:15:47 --> URI Class Initialized
DEBUG - 2019-05-28 15:15:47 --> No URI present. Default controller set.
INFO - 2019-05-28 15:15:47 --> Router Class Initialized
INFO - 2019-05-28 15:15:47 --> Output Class Initialized
INFO - 2019-05-28 15:15:47 --> Security Class Initialized
DEBUG - 2019-05-28 15:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:15:47 --> Input Class Initialized
INFO - 2019-05-28 15:15:47 --> Language Class Initialized
INFO - 2019-05-28 15:15:47 --> Language Class Initialized
INFO - 2019-05-28 15:15:47 --> Config Class Initialized
INFO - 2019-05-28 15:15:47 --> Loader Class Initialized
INFO - 2019-05-28 15:15:47 --> Helper loaded: form_helper
INFO - 2019-05-28 15:15:47 --> Helper loaded: url_helper
INFO - 2019-05-28 15:15:47 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:15:47 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:15:47 --> Template library initialized
INFO - 2019-05-28 15:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:15:47 --> Controller Class Initialized
DEBUG - 2019-05-28 15:15:47 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 15:15:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 15:15:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 15:15:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 15:15:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 15:15:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 15:15:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 15:15:47 --> Final output sent to browser
DEBUG - 2019-05-28 15:15:47 --> Total execution time: 0.0610
INFO - 2019-05-28 15:15:48 --> Config Class Initialized
INFO - 2019-05-28 15:15:48 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:15:48 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:15:48 --> Utf8 Class Initialized
INFO - 2019-05-28 15:15:48 --> URI Class Initialized
INFO - 2019-05-28 15:15:48 --> Router Class Initialized
INFO - 2019-05-28 15:15:48 --> Output Class Initialized
INFO - 2019-05-28 15:15:48 --> Security Class Initialized
DEBUG - 2019-05-28 15:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:15:48 --> Input Class Initialized
INFO - 2019-05-28 15:15:48 --> Language Class Initialized
ERROR - 2019-05-28 15:15:48 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:15:48 --> Config Class Initialized
INFO - 2019-05-28 15:15:48 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:15:48 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:15:48 --> Utf8 Class Initialized
INFO - 2019-05-28 15:15:48 --> URI Class Initialized
INFO - 2019-05-28 15:15:48 --> Router Class Initialized
INFO - 2019-05-28 15:15:48 --> Output Class Initialized
INFO - 2019-05-28 15:15:48 --> Security Class Initialized
DEBUG - 2019-05-28 15:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:15:48 --> Input Class Initialized
INFO - 2019-05-28 15:15:48 --> Language Class Initialized
ERROR - 2019-05-28 15:15:48 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:15:48 --> Config Class Initialized
INFO - 2019-05-28 15:15:48 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:15:48 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:15:48 --> Utf8 Class Initialized
INFO - 2019-05-28 15:15:48 --> URI Class Initialized
INFO - 2019-05-28 15:15:48 --> Router Class Initialized
INFO - 2019-05-28 15:15:48 --> Output Class Initialized
INFO - 2019-05-28 15:15:48 --> Security Class Initialized
DEBUG - 2019-05-28 15:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:15:48 --> Input Class Initialized
INFO - 2019-05-28 15:15:48 --> Language Class Initialized
ERROR - 2019-05-28 15:15:48 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:20:23 --> Config Class Initialized
INFO - 2019-05-28 15:20:23 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:20:23 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:20:23 --> Utf8 Class Initialized
INFO - 2019-05-28 15:20:23 --> URI Class Initialized
DEBUG - 2019-05-28 15:20:23 --> No URI present. Default controller set.
INFO - 2019-05-28 15:20:23 --> Router Class Initialized
INFO - 2019-05-28 15:20:23 --> Output Class Initialized
INFO - 2019-05-28 15:20:23 --> Security Class Initialized
DEBUG - 2019-05-28 15:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:20:23 --> Input Class Initialized
INFO - 2019-05-28 15:20:23 --> Language Class Initialized
INFO - 2019-05-28 15:20:23 --> Language Class Initialized
INFO - 2019-05-28 15:20:23 --> Config Class Initialized
INFO - 2019-05-28 15:20:23 --> Loader Class Initialized
INFO - 2019-05-28 15:20:23 --> Helper loaded: form_helper
INFO - 2019-05-28 15:20:23 --> Helper loaded: url_helper
INFO - 2019-05-28 15:20:23 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:20:23 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:20:23 --> Template library initialized
INFO - 2019-05-28 15:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:20:23 --> Controller Class Initialized
DEBUG - 2019-05-28 15:20:23 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 15:20:23 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 15:20:23 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 15:20:23 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 15:20:23 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 15:20:23 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 15:20:23 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 15:20:23 --> Final output sent to browser
DEBUG - 2019-05-28 15:20:23 --> Total execution time: 0.0447
INFO - 2019-05-28 15:20:26 --> Config Class Initialized
INFO - 2019-05-28 15:20:26 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:20:26 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:20:26 --> Utf8 Class Initialized
INFO - 2019-05-28 15:20:26 --> URI Class Initialized
INFO - 2019-05-28 15:20:26 --> Router Class Initialized
INFO - 2019-05-28 15:20:26 --> Output Class Initialized
INFO - 2019-05-28 15:20:26 --> Security Class Initialized
DEBUG - 2019-05-28 15:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:20:26 --> Input Class Initialized
INFO - 2019-05-28 15:20:26 --> Language Class Initialized
ERROR - 2019-05-28 15:20:26 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:20:26 --> Config Class Initialized
INFO - 2019-05-28 15:20:26 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:20:26 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:20:26 --> Utf8 Class Initialized
INFO - 2019-05-28 15:20:26 --> URI Class Initialized
INFO - 2019-05-28 15:20:26 --> Router Class Initialized
INFO - 2019-05-28 15:20:26 --> Output Class Initialized
INFO - 2019-05-28 15:20:26 --> Security Class Initialized
DEBUG - 2019-05-28 15:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:20:26 --> Input Class Initialized
INFO - 2019-05-28 15:20:26 --> Language Class Initialized
ERROR - 2019-05-28 15:20:26 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:20:27 --> Config Class Initialized
INFO - 2019-05-28 15:20:27 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:20:27 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:20:27 --> Utf8 Class Initialized
INFO - 2019-05-28 15:20:27 --> URI Class Initialized
INFO - 2019-05-28 15:20:27 --> Router Class Initialized
INFO - 2019-05-28 15:20:27 --> Output Class Initialized
INFO - 2019-05-28 15:20:27 --> Security Class Initialized
DEBUG - 2019-05-28 15:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:20:27 --> Input Class Initialized
INFO - 2019-05-28 15:20:27 --> Language Class Initialized
ERROR - 2019-05-28 15:20:27 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:20:27 --> Config Class Initialized
INFO - 2019-05-28 15:20:27 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:20:27 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:20:27 --> Utf8 Class Initialized
INFO - 2019-05-28 15:20:27 --> URI Class Initialized
INFO - 2019-05-28 15:20:27 --> Router Class Initialized
INFO - 2019-05-28 15:20:27 --> Output Class Initialized
INFO - 2019-05-28 15:20:27 --> Security Class Initialized
DEBUG - 2019-05-28 15:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:20:27 --> Input Class Initialized
INFO - 2019-05-28 15:20:27 --> Language Class Initialized
ERROR - 2019-05-28 15:20:27 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:27:45 --> Config Class Initialized
INFO - 2019-05-28 15:27:45 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:27:45 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:27:45 --> Utf8 Class Initialized
INFO - 2019-05-28 15:27:45 --> URI Class Initialized
INFO - 2019-05-28 15:27:45 --> Router Class Initialized
INFO - 2019-05-28 15:27:45 --> Output Class Initialized
INFO - 2019-05-28 15:27:45 --> Security Class Initialized
DEBUG - 2019-05-28 15:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:27:45 --> Input Class Initialized
INFO - 2019-05-28 15:27:45 --> Language Class Initialized
INFO - 2019-05-28 15:27:45 --> Language Class Initialized
INFO - 2019-05-28 15:27:45 --> Config Class Initialized
INFO - 2019-05-28 15:27:45 --> Loader Class Initialized
INFO - 2019-05-28 15:27:45 --> Helper loaded: form_helper
INFO - 2019-05-28 15:27:45 --> Helper loaded: url_helper
INFO - 2019-05-28 15:27:45 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:27:45 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:27:45 --> Template library initialized
INFO - 2019-05-28 15:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:27:45 --> Controller Class Initialized
DEBUG - 2019-05-28 15:27:45 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 15:27:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 15:27:46 --> Config Class Initialized
INFO - 2019-05-28 15:27:46 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:27:46 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:27:46 --> Utf8 Class Initialized
INFO - 2019-05-28 15:27:46 --> URI Class Initialized
DEBUG - 2019-05-28 15:27:46 --> No URI present. Default controller set.
INFO - 2019-05-28 15:27:46 --> Router Class Initialized
INFO - 2019-05-28 15:27:46 --> Output Class Initialized
INFO - 2019-05-28 15:27:46 --> Security Class Initialized
DEBUG - 2019-05-28 15:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:27:46 --> Input Class Initialized
INFO - 2019-05-28 15:27:46 --> Language Class Initialized
INFO - 2019-05-28 15:27:46 --> Language Class Initialized
INFO - 2019-05-28 15:27:46 --> Config Class Initialized
INFO - 2019-05-28 15:27:46 --> Loader Class Initialized
INFO - 2019-05-28 15:27:46 --> Helper loaded: form_helper
INFO - 2019-05-28 15:27:46 --> Helper loaded: url_helper
INFO - 2019-05-28 15:27:46 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:27:46 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:27:46 --> Template library initialized
INFO - 2019-05-28 15:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:27:46 --> Controller Class Initialized
DEBUG - 2019-05-28 15:27:46 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 15:27:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 15:27:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 15:27:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 15:27:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 15:27:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 15:27:46 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 15:27:46 --> Final output sent to browser
DEBUG - 2019-05-28 15:27:46 --> Total execution time: 0.0887
INFO - 2019-05-28 15:27:46 --> Config Class Initialized
INFO - 2019-05-28 15:27:46 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:27:46 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:27:46 --> Utf8 Class Initialized
INFO - 2019-05-28 15:27:46 --> URI Class Initialized
INFO - 2019-05-28 15:27:46 --> Config Class Initialized
INFO - 2019-05-28 15:27:46 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:27:46 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:27:46 --> Utf8 Class Initialized
INFO - 2019-05-28 15:27:46 --> URI Class Initialized
INFO - 2019-05-28 15:27:46 --> Config Class Initialized
INFO - 2019-05-28 15:27:46 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:27:46 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:27:46 --> Utf8 Class Initialized
INFO - 2019-05-28 15:27:46 --> URI Class Initialized
INFO - 2019-05-28 15:27:46 --> Router Class Initialized
INFO - 2019-05-28 15:27:46 --> Output Class Initialized
INFO - 2019-05-28 15:27:46 --> Security Class Initialized
DEBUG - 2019-05-28 15:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:27:46 --> Input Class Initialized
INFO - 2019-05-28 15:27:46 --> Language Class Initialized
ERROR - 2019-05-28 15:27:46 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:27:46 --> Router Class Initialized
INFO - 2019-05-28 15:27:46 --> Output Class Initialized
INFO - 2019-05-28 15:27:46 --> Security Class Initialized
DEBUG - 2019-05-28 15:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:27:46 --> Input Class Initialized
INFO - 2019-05-28 15:27:46 --> Language Class Initialized
ERROR - 2019-05-28 15:27:46 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:27:46 --> Router Class Initialized
INFO - 2019-05-28 15:27:46 --> Output Class Initialized
INFO - 2019-05-28 15:27:46 --> Security Class Initialized
DEBUG - 2019-05-28 15:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:27:46 --> Input Class Initialized
INFO - 2019-05-28 15:27:46 --> Language Class Initialized
ERROR - 2019-05-28 15:27:46 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:27:59 --> Config Class Initialized
INFO - 2019-05-28 15:27:59 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:27:59 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:27:59 --> Utf8 Class Initialized
INFO - 2019-05-28 15:27:59 --> URI Class Initialized
INFO - 2019-05-28 15:27:59 --> Router Class Initialized
INFO - 2019-05-28 15:27:59 --> Output Class Initialized
INFO - 2019-05-28 15:27:59 --> Security Class Initialized
DEBUG - 2019-05-28 15:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:27:59 --> Input Class Initialized
INFO - 2019-05-28 15:27:59 --> Language Class Initialized
INFO - 2019-05-28 15:27:59 --> Language Class Initialized
INFO - 2019-05-28 15:27:59 --> Config Class Initialized
INFO - 2019-05-28 15:27:59 --> Loader Class Initialized
INFO - 2019-05-28 15:27:59 --> Helper loaded: form_helper
INFO - 2019-05-28 15:27:59 --> Helper loaded: url_helper
INFO - 2019-05-28 15:27:59 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:27:59 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:27:59 --> Template library initialized
INFO - 2019-05-28 15:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:27:59 --> Controller Class Initialized
DEBUG - 2019-05-28 15:27:59 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 15:27:59 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 15:27:59 --> Final output sent to browser
DEBUG - 2019-05-28 15:27:59 --> Total execution time: 0.0409
INFO - 2019-05-28 15:28:17 --> Config Class Initialized
INFO - 2019-05-28 15:28:17 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:28:17 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:28:17 --> Utf8 Class Initialized
INFO - 2019-05-28 15:28:17 --> URI Class Initialized
INFO - 2019-05-28 15:28:17 --> Router Class Initialized
INFO - 2019-05-28 15:28:17 --> Output Class Initialized
INFO - 2019-05-28 15:28:17 --> Security Class Initialized
DEBUG - 2019-05-28 15:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:28:17 --> Input Class Initialized
INFO - 2019-05-28 15:28:17 --> Language Class Initialized
INFO - 2019-05-28 15:28:17 --> Language Class Initialized
INFO - 2019-05-28 15:28:17 --> Config Class Initialized
INFO - 2019-05-28 15:28:17 --> Loader Class Initialized
INFO - 2019-05-28 15:28:17 --> Helper loaded: form_helper
INFO - 2019-05-28 15:28:17 --> Helper loaded: url_helper
INFO - 2019-05-28 15:28:17 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:28:17 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:28:17 --> Template library initialized
INFO - 2019-05-28 15:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:28:17 --> Controller Class Initialized
DEBUG - 2019-05-28 15:28:17 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 15:28:18 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 15:28:18 --> Final output sent to browser
DEBUG - 2019-05-28 15:28:18 --> Total execution time: 0.0372
INFO - 2019-05-28 15:28:23 --> Config Class Initialized
INFO - 2019-05-28 15:28:23 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:28:23 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:28:23 --> Utf8 Class Initialized
INFO - 2019-05-28 15:28:23 --> URI Class Initialized
INFO - 2019-05-28 15:28:23 --> Router Class Initialized
INFO - 2019-05-28 15:28:23 --> Output Class Initialized
INFO - 2019-05-28 15:28:23 --> Security Class Initialized
DEBUG - 2019-05-28 15:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:28:23 --> Input Class Initialized
INFO - 2019-05-28 15:28:23 --> Language Class Initialized
INFO - 2019-05-28 15:28:23 --> Language Class Initialized
INFO - 2019-05-28 15:28:23 --> Config Class Initialized
INFO - 2019-05-28 15:28:23 --> Loader Class Initialized
INFO - 2019-05-28 15:28:23 --> Helper loaded: form_helper
INFO - 2019-05-28 15:28:23 --> Helper loaded: url_helper
INFO - 2019-05-28 15:28:23 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:28:23 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:28:23 --> Template library initialized
INFO - 2019-05-28 15:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:28:23 --> Controller Class Initialized
DEBUG - 2019-05-28 15:28:23 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 15:28:23 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 15:28:23 --> Final output sent to browser
DEBUG - 2019-05-28 15:28:23 --> Total execution time: 0.0376
INFO - 2019-05-28 15:28:52 --> Config Class Initialized
INFO - 2019-05-28 15:28:52 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:28:52 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:28:52 --> Utf8 Class Initialized
INFO - 2019-05-28 15:28:52 --> URI Class Initialized
INFO - 2019-05-28 15:28:52 --> Router Class Initialized
INFO - 2019-05-28 15:28:52 --> Output Class Initialized
INFO - 2019-05-28 15:28:52 --> Security Class Initialized
DEBUG - 2019-05-28 15:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:28:52 --> Input Class Initialized
INFO - 2019-05-28 15:28:52 --> Language Class Initialized
INFO - 2019-05-28 15:28:52 --> Language Class Initialized
INFO - 2019-05-28 15:28:52 --> Config Class Initialized
INFO - 2019-05-28 15:28:52 --> Loader Class Initialized
INFO - 2019-05-28 15:28:52 --> Helper loaded: form_helper
INFO - 2019-05-28 15:28:52 --> Helper loaded: url_helper
INFO - 2019-05-28 15:28:52 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:28:52 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:28:52 --> Template library initialized
INFO - 2019-05-28 15:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:28:52 --> Controller Class Initialized
DEBUG - 2019-05-28 15:28:52 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 15:28:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 15:28:52 --> Final output sent to browser
DEBUG - 2019-05-28 15:28:52 --> Total execution time: 0.0402
INFO - 2019-05-28 15:28:52 --> Config Class Initialized
INFO - 2019-05-28 15:28:52 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:28:52 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:28:52 --> Utf8 Class Initialized
INFO - 2019-05-28 15:28:52 --> URI Class Initialized
DEBUG - 2019-05-28 15:28:52 --> No URI present. Default controller set.
INFO - 2019-05-28 15:28:52 --> Router Class Initialized
INFO - 2019-05-28 15:28:52 --> Output Class Initialized
INFO - 2019-05-28 15:28:52 --> Security Class Initialized
DEBUG - 2019-05-28 15:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:28:52 --> Input Class Initialized
INFO - 2019-05-28 15:28:52 --> Language Class Initialized
INFO - 2019-05-28 15:28:52 --> Language Class Initialized
INFO - 2019-05-28 15:28:52 --> Config Class Initialized
INFO - 2019-05-28 15:28:52 --> Loader Class Initialized
INFO - 2019-05-28 15:28:52 --> Helper loaded: form_helper
INFO - 2019-05-28 15:28:52 --> Helper loaded: url_helper
INFO - 2019-05-28 15:28:52 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:28:52 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:28:52 --> Template library initialized
INFO - 2019-05-28 15:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:28:52 --> Controller Class Initialized
DEBUG - 2019-05-28 15:28:52 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 15:28:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 15:28:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 15:28:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 15:28:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 15:28:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 15:28:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 15:28:52 --> Final output sent to browser
DEBUG - 2019-05-28 15:28:52 --> Total execution time: 0.0462
INFO - 2019-05-28 15:28:53 --> Config Class Initialized
INFO - 2019-05-28 15:28:53 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:28:53 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:28:53 --> Utf8 Class Initialized
INFO - 2019-05-28 15:28:53 --> Config Class Initialized
INFO - 2019-05-28 15:28:53 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:28:53 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:28:53 --> Utf8 Class Initialized
INFO - 2019-05-28 15:28:53 --> URI Class Initialized
INFO - 2019-05-28 15:28:53 --> Config Class Initialized
INFO - 2019-05-28 15:28:53 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:28:53 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:28:53 --> Utf8 Class Initialized
INFO - 2019-05-28 15:28:53 --> URI Class Initialized
INFO - 2019-05-28 15:28:53 --> Router Class Initialized
INFO - 2019-05-28 15:28:53 --> URI Class Initialized
INFO - 2019-05-28 15:28:53 --> Router Class Initialized
INFO - 2019-05-28 15:28:53 --> Output Class Initialized
INFO - 2019-05-28 15:28:53 --> Security Class Initialized
DEBUG - 2019-05-28 15:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:28:53 --> Input Class Initialized
INFO - 2019-05-28 15:28:53 --> Language Class Initialized
ERROR - 2019-05-28 15:28:53 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:28:53 --> Router Class Initialized
INFO - 2019-05-28 15:28:53 --> Output Class Initialized
INFO - 2019-05-28 15:28:53 --> Security Class Initialized
DEBUG - 2019-05-28 15:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:28:53 --> Input Class Initialized
INFO - 2019-05-28 15:28:53 --> Language Class Initialized
ERROR - 2019-05-28 15:28:53 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:28:53 --> Output Class Initialized
INFO - 2019-05-28 15:28:53 --> Security Class Initialized
DEBUG - 2019-05-28 15:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:28:53 --> Input Class Initialized
INFO - 2019-05-28 15:28:53 --> Language Class Initialized
ERROR - 2019-05-28 15:28:53 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:29:14 --> Config Class Initialized
INFO - 2019-05-28 15:29:14 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:29:14 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:29:14 --> Utf8 Class Initialized
INFO - 2019-05-28 15:29:14 --> URI Class Initialized
DEBUG - 2019-05-28 15:29:14 --> No URI present. Default controller set.
INFO - 2019-05-28 15:29:14 --> Router Class Initialized
INFO - 2019-05-28 15:29:14 --> Output Class Initialized
INFO - 2019-05-28 15:29:14 --> Security Class Initialized
DEBUG - 2019-05-28 15:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:29:14 --> Input Class Initialized
INFO - 2019-05-28 15:29:14 --> Language Class Initialized
INFO - 2019-05-28 15:29:14 --> Language Class Initialized
INFO - 2019-05-28 15:29:14 --> Config Class Initialized
INFO - 2019-05-28 15:29:14 --> Loader Class Initialized
INFO - 2019-05-28 15:29:14 --> Helper loaded: form_helper
INFO - 2019-05-28 15:29:14 --> Helper loaded: url_helper
INFO - 2019-05-28 15:29:14 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:29:14 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:29:14 --> Template library initialized
INFO - 2019-05-28 15:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:29:14 --> Controller Class Initialized
DEBUG - 2019-05-28 15:29:14 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 15:29:14 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 15:29:14 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 15:29:14 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 15:29:14 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 15:29:14 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 15:29:14 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 15:29:14 --> Final output sent to browser
DEBUG - 2019-05-28 15:29:14 --> Total execution time: 0.0447
INFO - 2019-05-28 15:29:14 --> Config Class Initialized
INFO - 2019-05-28 15:29:14 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:29:14 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:29:14 --> Utf8 Class Initialized
INFO - 2019-05-28 15:29:14 --> URI Class Initialized
INFO - 2019-05-28 15:29:14 --> Config Class Initialized
INFO - 2019-05-28 15:29:14 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:29:14 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:29:14 --> Utf8 Class Initialized
INFO - 2019-05-28 15:29:14 --> URI Class Initialized
INFO - 2019-05-28 15:29:14 --> Router Class Initialized
INFO - 2019-05-28 15:29:14 --> Config Class Initialized
INFO - 2019-05-28 15:29:14 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:29:14 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:29:14 --> Utf8 Class Initialized
INFO - 2019-05-28 15:29:14 --> URI Class Initialized
INFO - 2019-05-28 15:29:14 --> Router Class Initialized
INFO - 2019-05-28 15:29:14 --> Output Class Initialized
INFO - 2019-05-28 15:29:14 --> Security Class Initialized
DEBUG - 2019-05-28 15:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:29:14 --> Input Class Initialized
INFO - 2019-05-28 15:29:14 --> Language Class Initialized
ERROR - 2019-05-28 15:29:14 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:29:14 --> Router Class Initialized
INFO - 2019-05-28 15:29:14 --> Output Class Initialized
INFO - 2019-05-28 15:29:14 --> Security Class Initialized
DEBUG - 2019-05-28 15:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:29:14 --> Input Class Initialized
INFO - 2019-05-28 15:29:14 --> Language Class Initialized
ERROR - 2019-05-28 15:29:14 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:29:14 --> Output Class Initialized
INFO - 2019-05-28 15:29:14 --> Security Class Initialized
DEBUG - 2019-05-28 15:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:29:14 --> Input Class Initialized
INFO - 2019-05-28 15:29:14 --> Language Class Initialized
ERROR - 2019-05-28 15:29:14 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:29:24 --> Config Class Initialized
INFO - 2019-05-28 15:29:24 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:29:24 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:29:24 --> Utf8 Class Initialized
INFO - 2019-05-28 15:29:24 --> URI Class Initialized
INFO - 2019-05-28 15:29:24 --> Router Class Initialized
INFO - 2019-05-28 15:29:24 --> Output Class Initialized
INFO - 2019-05-28 15:29:24 --> Security Class Initialized
DEBUG - 2019-05-28 15:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:29:24 --> Input Class Initialized
INFO - 2019-05-28 15:29:24 --> Language Class Initialized
INFO - 2019-05-28 15:29:24 --> Language Class Initialized
INFO - 2019-05-28 15:29:24 --> Config Class Initialized
INFO - 2019-05-28 15:29:24 --> Loader Class Initialized
INFO - 2019-05-28 15:29:24 --> Helper loaded: form_helper
INFO - 2019-05-28 15:29:24 --> Helper loaded: url_helper
INFO - 2019-05-28 15:29:24 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:29:24 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:29:24 --> Template library initialized
INFO - 2019-05-28 15:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:29:24 --> Controller Class Initialized
DEBUG - 2019-05-28 15:29:24 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 15:29:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 15:29:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/transport.php
DEBUG - 2019-05-28 15:29:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 15:29:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 15:29:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 15:29:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 15:29:25 --> Final output sent to browser
DEBUG - 2019-05-28 15:29:25 --> Total execution time: 0.0489
INFO - 2019-05-28 15:29:25 --> Config Class Initialized
INFO - 2019-05-28 15:29:25 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:29:25 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:29:25 --> Utf8 Class Initialized
INFO - 2019-05-28 15:29:25 --> URI Class Initialized
INFO - 2019-05-28 15:29:25 --> Router Class Initialized
INFO - 2019-05-28 15:29:25 --> Output Class Initialized
INFO - 2019-05-28 15:29:25 --> Security Class Initialized
DEBUG - 2019-05-28 15:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:29:25 --> Input Class Initialized
INFO - 2019-05-28 15:29:25 --> Language Class Initialized
ERROR - 2019-05-28 15:29:25 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:29:25 --> Config Class Initialized
INFO - 2019-05-28 15:29:25 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:29:25 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:29:25 --> Utf8 Class Initialized
INFO - 2019-05-28 15:29:25 --> URI Class Initialized
INFO - 2019-05-28 15:29:25 --> Config Class Initialized
INFO - 2019-05-28 15:29:25 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:29:25 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:29:25 --> Utf8 Class Initialized
INFO - 2019-05-28 15:29:25 --> URI Class Initialized
INFO - 2019-05-28 15:29:25 --> Router Class Initialized
INFO - 2019-05-28 15:29:25 --> Output Class Initialized
INFO - 2019-05-28 15:29:25 --> Security Class Initialized
DEBUG - 2019-05-28 15:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:29:25 --> Input Class Initialized
INFO - 2019-05-28 15:29:25 --> Language Class Initialized
ERROR - 2019-05-28 15:29:25 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:29:25 --> Router Class Initialized
INFO - 2019-05-28 15:29:25 --> Output Class Initialized
INFO - 2019-05-28 15:29:25 --> Security Class Initialized
DEBUG - 2019-05-28 15:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:29:25 --> Input Class Initialized
INFO - 2019-05-28 15:29:25 --> Language Class Initialized
ERROR - 2019-05-28 15:29:25 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:29:27 --> Config Class Initialized
INFO - 2019-05-28 15:29:27 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:29:27 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:29:27 --> Utf8 Class Initialized
INFO - 2019-05-28 15:29:27 --> URI Class Initialized
INFO - 2019-05-28 15:29:27 --> Router Class Initialized
INFO - 2019-05-28 15:29:27 --> Output Class Initialized
INFO - 2019-05-28 15:29:27 --> Security Class Initialized
DEBUG - 2019-05-28 15:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:29:27 --> Input Class Initialized
INFO - 2019-05-28 15:29:27 --> Language Class Initialized
INFO - 2019-05-28 15:29:27 --> Language Class Initialized
INFO - 2019-05-28 15:29:27 --> Config Class Initialized
INFO - 2019-05-28 15:29:27 --> Loader Class Initialized
INFO - 2019-05-28 15:29:27 --> Helper loaded: form_helper
INFO - 2019-05-28 15:29:27 --> Helper loaded: url_helper
INFO - 2019-05-28 15:29:27 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:29:27 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:29:27 --> Template library initialized
INFO - 2019-05-28 15:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:29:27 --> Controller Class Initialized
DEBUG - 2019-05-28 15:29:27 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 15:29:27 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 15:29:27 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/mobile.php
DEBUG - 2019-05-28 15:29:27 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 15:29:27 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 15:29:27 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 15:29:27 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 15:29:27 --> Final output sent to browser
DEBUG - 2019-05-28 15:29:27 --> Total execution time: 0.0608
INFO - 2019-05-28 15:29:27 --> Config Class Initialized
INFO - 2019-05-28 15:29:27 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:29:27 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:29:27 --> Utf8 Class Initialized
INFO - 2019-05-28 15:29:27 --> URI Class Initialized
INFO - 2019-05-28 15:29:27 --> Config Class Initialized
INFO - 2019-05-28 15:29:27 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:29:27 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:29:27 --> Utf8 Class Initialized
INFO - 2019-05-28 15:29:27 --> URI Class Initialized
INFO - 2019-05-28 15:29:27 --> Router Class Initialized
INFO - 2019-05-28 15:29:27 --> Config Class Initialized
INFO - 2019-05-28 15:29:27 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:29:27 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:29:27 --> Utf8 Class Initialized
INFO - 2019-05-28 15:29:27 --> URI Class Initialized
INFO - 2019-05-28 15:29:27 --> Router Class Initialized
INFO - 2019-05-28 15:29:27 --> Output Class Initialized
INFO - 2019-05-28 15:29:27 --> Security Class Initialized
DEBUG - 2019-05-28 15:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:29:27 --> Input Class Initialized
INFO - 2019-05-28 15:29:27 --> Language Class Initialized
ERROR - 2019-05-28 15:29:27 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:29:27 --> Router Class Initialized
INFO - 2019-05-28 15:29:27 --> Output Class Initialized
INFO - 2019-05-28 15:29:27 --> Security Class Initialized
DEBUG - 2019-05-28 15:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:29:27 --> Input Class Initialized
INFO - 2019-05-28 15:29:27 --> Language Class Initialized
ERROR - 2019-05-28 15:29:27 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:29:27 --> Output Class Initialized
INFO - 2019-05-28 15:29:27 --> Security Class Initialized
DEBUG - 2019-05-28 15:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:29:27 --> Input Class Initialized
INFO - 2019-05-28 15:29:27 --> Language Class Initialized
ERROR - 2019-05-28 15:29:27 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:29:29 --> Config Class Initialized
INFO - 2019-05-28 15:29:29 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:29:29 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:29:29 --> Utf8 Class Initialized
INFO - 2019-05-28 15:29:29 --> URI Class Initialized
DEBUG - 2019-05-28 15:29:29 --> No URI present. Default controller set.
INFO - 2019-05-28 15:29:29 --> Router Class Initialized
INFO - 2019-05-28 15:29:29 --> Output Class Initialized
INFO - 2019-05-28 15:29:29 --> Security Class Initialized
DEBUG - 2019-05-28 15:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:29:29 --> Input Class Initialized
INFO - 2019-05-28 15:29:29 --> Language Class Initialized
INFO - 2019-05-28 15:29:29 --> Language Class Initialized
INFO - 2019-05-28 15:29:29 --> Config Class Initialized
INFO - 2019-05-28 15:29:29 --> Loader Class Initialized
INFO - 2019-05-28 15:29:29 --> Helper loaded: form_helper
INFO - 2019-05-28 15:29:29 --> Helper loaded: url_helper
INFO - 2019-05-28 15:29:29 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:29:29 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:29:29 --> Template library initialized
INFO - 2019-05-28 15:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:29:29 --> Controller Class Initialized
DEBUG - 2019-05-28 15:29:29 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 15:29:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 15:29:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 15:29:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 15:29:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 15:29:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 15:29:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 15:29:29 --> Final output sent to browser
DEBUG - 2019-05-28 15:29:29 --> Total execution time: 0.0454
INFO - 2019-05-28 15:29:29 --> Config Class Initialized
INFO - 2019-05-28 15:29:29 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:29:29 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:29:29 --> Utf8 Class Initialized
INFO - 2019-05-28 15:29:29 --> URI Class Initialized
INFO - 2019-05-28 15:29:29 --> Config Class Initialized
INFO - 2019-05-28 15:29:29 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:29:29 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:29:29 --> Utf8 Class Initialized
INFO - 2019-05-28 15:29:29 --> URI Class Initialized
INFO - 2019-05-28 15:29:29 --> Router Class Initialized
INFO - 2019-05-28 15:29:29 --> Config Class Initialized
INFO - 2019-05-28 15:29:29 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:29:29 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:29:29 --> Utf8 Class Initialized
INFO - 2019-05-28 15:29:29 --> URI Class Initialized
INFO - 2019-05-28 15:29:29 --> Router Class Initialized
INFO - 2019-05-28 15:29:29 --> Router Class Initialized
INFO - 2019-05-28 15:29:29 --> Output Class Initialized
INFO - 2019-05-28 15:29:29 --> Security Class Initialized
DEBUG - 2019-05-28 15:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:29:29 --> Input Class Initialized
INFO - 2019-05-28 15:29:29 --> Language Class Initialized
ERROR - 2019-05-28 15:29:29 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:29:29 --> Output Class Initialized
INFO - 2019-05-28 15:29:29 --> Security Class Initialized
DEBUG - 2019-05-28 15:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:29:29 --> Input Class Initialized
INFO - 2019-05-28 15:29:29 --> Language Class Initialized
ERROR - 2019-05-28 15:29:29 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:29:29 --> Output Class Initialized
INFO - 2019-05-28 15:29:29 --> Security Class Initialized
DEBUG - 2019-05-28 15:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:29:29 --> Input Class Initialized
INFO - 2019-05-28 15:29:29 --> Language Class Initialized
ERROR - 2019-05-28 15:29:29 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:29:32 --> Config Class Initialized
INFO - 2019-05-28 15:29:32 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:29:32 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:29:32 --> Utf8 Class Initialized
INFO - 2019-05-28 15:29:32 --> URI Class Initialized
INFO - 2019-05-28 15:29:32 --> Router Class Initialized
INFO - 2019-05-28 15:29:32 --> Output Class Initialized
INFO - 2019-05-28 15:29:32 --> Security Class Initialized
DEBUG - 2019-05-28 15:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:29:32 --> Input Class Initialized
INFO - 2019-05-28 15:29:32 --> Language Class Initialized
INFO - 2019-05-28 15:29:32 --> Language Class Initialized
INFO - 2019-05-28 15:29:32 --> Config Class Initialized
INFO - 2019-05-28 15:29:32 --> Loader Class Initialized
INFO - 2019-05-28 15:29:32 --> Helper loaded: form_helper
INFO - 2019-05-28 15:29:32 --> Helper loaded: url_helper
INFO - 2019-05-28 15:29:32 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:29:32 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:29:32 --> Template library initialized
INFO - 2019-05-28 15:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:29:32 --> Controller Class Initialized
DEBUG - 2019-05-28 15:29:32 --> Api MX_Controller Initialized
DEBUG - 2019-05-28 15:29:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/api/models/Api_model.php
INFO - 2019-05-28 15:29:32 --> Config Class Initialized
INFO - 2019-05-28 15:29:32 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:29:32 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:29:32 --> Utf8 Class Initialized
INFO - 2019-05-28 15:29:32 --> URI Class Initialized
DEBUG - 2019-05-28 15:29:32 --> No URI present. Default controller set.
INFO - 2019-05-28 15:29:32 --> Router Class Initialized
INFO - 2019-05-28 15:29:32 --> Output Class Initialized
INFO - 2019-05-28 15:29:32 --> Security Class Initialized
DEBUG - 2019-05-28 15:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:29:32 --> Input Class Initialized
INFO - 2019-05-28 15:29:32 --> Language Class Initialized
INFO - 2019-05-28 15:29:32 --> Language Class Initialized
INFO - 2019-05-28 15:29:32 --> Config Class Initialized
INFO - 2019-05-28 15:29:32 --> Loader Class Initialized
INFO - 2019-05-28 15:29:32 --> Helper loaded: form_helper
INFO - 2019-05-28 15:29:32 --> Helper loaded: url_helper
INFO - 2019-05-28 15:29:32 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:29:32 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:29:32 --> Template library initialized
INFO - 2019-05-28 15:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:29:32 --> Controller Class Initialized
DEBUG - 2019-05-28 15:29:32 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 15:29:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 15:29:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 15:29:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 15:29:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 15:29:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 15:29:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 15:29:33 --> Final output sent to browser
DEBUG - 2019-05-28 15:29:33 --> Total execution time: 0.0445
INFO - 2019-05-28 15:29:33 --> Config Class Initialized
INFO - 2019-05-28 15:29:33 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:29:33 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:29:33 --> Utf8 Class Initialized
INFO - 2019-05-28 15:29:33 --> URI Class Initialized
INFO - 2019-05-28 15:29:33 --> Config Class Initialized
INFO - 2019-05-28 15:29:33 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:29:33 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:29:33 --> Utf8 Class Initialized
INFO - 2019-05-28 15:29:33 --> URI Class Initialized
INFO - 2019-05-28 15:29:33 --> Config Class Initialized
INFO - 2019-05-28 15:29:33 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:29:33 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:29:33 --> Utf8 Class Initialized
INFO - 2019-05-28 15:29:33 --> URI Class Initialized
INFO - 2019-05-28 15:29:33 --> Router Class Initialized
INFO - 2019-05-28 15:29:33 --> Output Class Initialized
INFO - 2019-05-28 15:29:33 --> Security Class Initialized
DEBUG - 2019-05-28 15:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:29:33 --> Input Class Initialized
INFO - 2019-05-28 15:29:33 --> Language Class Initialized
ERROR - 2019-05-28 15:29:33 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:29:33 --> Router Class Initialized
INFO - 2019-05-28 15:29:33 --> Output Class Initialized
INFO - 2019-05-28 15:29:33 --> Security Class Initialized
DEBUG - 2019-05-28 15:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:29:33 --> Input Class Initialized
INFO - 2019-05-28 15:29:33 --> Language Class Initialized
ERROR - 2019-05-28 15:29:33 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:29:33 --> Router Class Initialized
INFO - 2019-05-28 15:29:33 --> Output Class Initialized
INFO - 2019-05-28 15:29:33 --> Security Class Initialized
DEBUG - 2019-05-28 15:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:29:33 --> Input Class Initialized
INFO - 2019-05-28 15:29:33 --> Language Class Initialized
ERROR - 2019-05-28 15:29:33 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:31:28 --> Config Class Initialized
INFO - 2019-05-28 15:31:28 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:31:28 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:31:28 --> Utf8 Class Initialized
INFO - 2019-05-28 15:31:28 --> URI Class Initialized
DEBUG - 2019-05-28 15:31:28 --> No URI present. Default controller set.
INFO - 2019-05-28 15:31:28 --> Router Class Initialized
INFO - 2019-05-28 15:31:28 --> Output Class Initialized
INFO - 2019-05-28 15:31:28 --> Security Class Initialized
DEBUG - 2019-05-28 15:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:31:28 --> Input Class Initialized
INFO - 2019-05-28 15:31:28 --> Language Class Initialized
INFO - 2019-05-28 15:31:28 --> Language Class Initialized
INFO - 2019-05-28 15:31:28 --> Config Class Initialized
INFO - 2019-05-28 15:31:28 --> Loader Class Initialized
INFO - 2019-05-28 15:31:28 --> Helper loaded: form_helper
INFO - 2019-05-28 15:31:28 --> Helper loaded: url_helper
INFO - 2019-05-28 15:31:28 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:31:28 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:31:28 --> Template library initialized
INFO - 2019-05-28 15:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:31:28 --> Controller Class Initialized
DEBUG - 2019-05-28 15:31:28 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 15:31:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 15:31:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 15:31:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 15:31:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 15:31:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 15:31:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 15:31:28 --> Final output sent to browser
DEBUG - 2019-05-28 15:31:28 --> Total execution time: 0.0445
INFO - 2019-05-28 15:31:28 --> Config Class Initialized
INFO - 2019-05-28 15:31:28 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:31:28 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:31:28 --> Utf8 Class Initialized
INFO - 2019-05-28 15:31:28 --> URI Class Initialized
INFO - 2019-05-28 15:31:28 --> Config Class Initialized
INFO - 2019-05-28 15:31:28 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:31:28 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:31:28 --> Utf8 Class Initialized
INFO - 2019-05-28 15:31:28 --> URI Class Initialized
INFO - 2019-05-28 15:31:28 --> Config Class Initialized
INFO - 2019-05-28 15:31:28 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:31:28 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:31:28 --> Utf8 Class Initialized
INFO - 2019-05-28 15:31:28 --> URI Class Initialized
INFO - 2019-05-28 15:31:28 --> Router Class Initialized
INFO - 2019-05-28 15:31:28 --> Router Class Initialized
INFO - 2019-05-28 15:31:28 --> Output Class Initialized
INFO - 2019-05-28 15:31:28 --> Security Class Initialized
DEBUG - 2019-05-28 15:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:31:28 --> Input Class Initialized
INFO - 2019-05-28 15:31:28 --> Language Class Initialized
ERROR - 2019-05-28 15:31:28 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:31:28 --> Output Class Initialized
INFO - 2019-05-28 15:31:28 --> Security Class Initialized
DEBUG - 2019-05-28 15:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:31:28 --> Input Class Initialized
INFO - 2019-05-28 15:31:28 --> Language Class Initialized
ERROR - 2019-05-28 15:31:28 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:31:28 --> Router Class Initialized
INFO - 2019-05-28 15:31:28 --> Output Class Initialized
INFO - 2019-05-28 15:31:28 --> Security Class Initialized
DEBUG - 2019-05-28 15:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:31:28 --> Input Class Initialized
INFO - 2019-05-28 15:31:28 --> Language Class Initialized
ERROR - 2019-05-28 15:31:28 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:31:41 --> Config Class Initialized
INFO - 2019-05-28 15:31:41 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:31:41 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:31:41 --> Utf8 Class Initialized
INFO - 2019-05-28 15:31:41 --> URI Class Initialized
DEBUG - 2019-05-28 15:31:41 --> No URI present. Default controller set.
INFO - 2019-05-28 15:31:41 --> Router Class Initialized
INFO - 2019-05-28 15:31:41 --> Output Class Initialized
INFO - 2019-05-28 15:31:41 --> Security Class Initialized
DEBUG - 2019-05-28 15:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:31:41 --> Input Class Initialized
INFO - 2019-05-28 15:31:41 --> Language Class Initialized
INFO - 2019-05-28 15:31:41 --> Language Class Initialized
INFO - 2019-05-28 15:31:41 --> Config Class Initialized
INFO - 2019-05-28 15:31:41 --> Loader Class Initialized
INFO - 2019-05-28 15:31:41 --> Helper loaded: form_helper
INFO - 2019-05-28 15:31:41 --> Helper loaded: url_helper
INFO - 2019-05-28 15:31:41 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:31:41 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:31:41 --> Template library initialized
INFO - 2019-05-28 15:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:31:41 --> Controller Class Initialized
DEBUG - 2019-05-28 15:31:41 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 15:31:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 15:31:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 15:31:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 15:31:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 15:31:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 15:31:41 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 15:31:42 --> Config Class Initialized
INFO - 2019-05-28 15:31:42 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:31:42 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:31:42 --> Utf8 Class Initialized
INFO - 2019-05-28 15:31:42 --> URI Class Initialized
DEBUG - 2019-05-28 15:31:42 --> No URI present. Default controller set.
INFO - 2019-05-28 15:31:42 --> Router Class Initialized
INFO - 2019-05-28 15:31:42 --> Output Class Initialized
INFO - 2019-05-28 15:31:42 --> Security Class Initialized
DEBUG - 2019-05-28 15:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:31:42 --> Input Class Initialized
INFO - 2019-05-28 15:31:42 --> Language Class Initialized
INFO - 2019-05-28 15:31:42 --> Language Class Initialized
INFO - 2019-05-28 15:31:42 --> Config Class Initialized
INFO - 2019-05-28 15:31:42 --> Loader Class Initialized
INFO - 2019-05-28 15:31:42 --> Helper loaded: form_helper
INFO - 2019-05-28 15:31:42 --> Helper loaded: url_helper
INFO - 2019-05-28 15:31:42 --> Helper loaded: cookie_helper
INFO - 2019-05-28 15:31:42 --> Database Driver Class Initialized
DEBUG - 2019-05-28 15:31:42 --> Template library initialized
INFO - 2019-05-28 15:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 15:31:42 --> Controller Class Initialized
DEBUG - 2019-05-28 15:31:42 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 15:31:42 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 15:31:42 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 15:31:42 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 15:31:42 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 15:31:42 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 15:31:42 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 15:31:42 --> Final output sent to browser
DEBUG - 2019-05-28 15:31:42 --> Total execution time: 0.0447
INFO - 2019-05-28 15:31:43 --> Config Class Initialized
INFO - 2019-05-28 15:31:43 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:31:43 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:31:43 --> Utf8 Class Initialized
INFO - 2019-05-28 15:31:43 --> URI Class Initialized
INFO - 2019-05-28 15:31:43 --> Router Class Initialized
INFO - 2019-05-28 15:31:43 --> Output Class Initialized
INFO - 2019-05-28 15:31:43 --> Security Class Initialized
DEBUG - 2019-05-28 15:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:31:43 --> Input Class Initialized
INFO - 2019-05-28 15:31:43 --> Language Class Initialized
ERROR - 2019-05-28 15:31:43 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:31:43 --> Config Class Initialized
INFO - 2019-05-28 15:31:43 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:31:43 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:31:43 --> Utf8 Class Initialized
INFO - 2019-05-28 15:31:43 --> URI Class Initialized
INFO - 2019-05-28 15:31:43 --> Router Class Initialized
INFO - 2019-05-28 15:31:43 --> Output Class Initialized
INFO - 2019-05-28 15:31:43 --> Security Class Initialized
DEBUG - 2019-05-28 15:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:31:43 --> Input Class Initialized
INFO - 2019-05-28 15:31:43 --> Language Class Initialized
ERROR - 2019-05-28 15:31:43 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:31:44 --> Config Class Initialized
INFO - 2019-05-28 15:31:44 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:31:44 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:31:44 --> Utf8 Class Initialized
INFO - 2019-05-28 15:31:44 --> URI Class Initialized
INFO - 2019-05-28 15:31:44 --> Router Class Initialized
INFO - 2019-05-28 15:31:44 --> Output Class Initialized
INFO - 2019-05-28 15:31:44 --> Security Class Initialized
DEBUG - 2019-05-28 15:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:31:44 --> Input Class Initialized
INFO - 2019-05-28 15:31:44 --> Language Class Initialized
ERROR - 2019-05-28 15:31:44 --> 404 Page Not Found: /index
INFO - 2019-05-28 15:31:46 --> Config Class Initialized
INFO - 2019-05-28 15:31:46 --> Hooks Class Initialized
DEBUG - 2019-05-28 15:31:46 --> UTF-8 Support Enabled
INFO - 2019-05-28 15:31:46 --> Utf8 Class Initialized
INFO - 2019-05-28 15:31:46 --> URI Class Initialized
INFO - 2019-05-28 15:31:46 --> Router Class Initialized
INFO - 2019-05-28 15:31:46 --> Output Class Initialized
INFO - 2019-05-28 15:31:46 --> Security Class Initialized
DEBUG - 2019-05-28 15:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 15:31:46 --> Input Class Initialized
INFO - 2019-05-28 15:31:46 --> Language Class Initialized
ERROR - 2019-05-28 15:31:46 --> 404 Page Not Found: /index
INFO - 2019-05-28 19:34:49 --> Config Class Initialized
INFO - 2019-05-28 19:34:49 --> Hooks Class Initialized
DEBUG - 2019-05-28 19:34:49 --> UTF-8 Support Enabled
INFO - 2019-05-28 19:34:49 --> Utf8 Class Initialized
INFO - 2019-05-28 19:34:49 --> URI Class Initialized
DEBUG - 2019-05-28 19:34:49 --> No URI present. Default controller set.
INFO - 2019-05-28 19:34:49 --> Router Class Initialized
INFO - 2019-05-28 19:34:49 --> Output Class Initialized
INFO - 2019-05-28 19:34:49 --> Security Class Initialized
DEBUG - 2019-05-28 19:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 19:34:49 --> Input Class Initialized
INFO - 2019-05-28 19:34:49 --> Language Class Initialized
INFO - 2019-05-28 19:34:49 --> Language Class Initialized
INFO - 2019-05-28 19:34:49 --> Config Class Initialized
INFO - 2019-05-28 19:34:49 --> Loader Class Initialized
INFO - 2019-05-28 19:34:49 --> Helper loaded: form_helper
INFO - 2019-05-28 19:34:49 --> Helper loaded: url_helper
INFO - 2019-05-28 19:34:49 --> Helper loaded: cookie_helper
INFO - 2019-05-28 19:34:49 --> Database Driver Class Initialized
DEBUG - 2019-05-28 19:34:49 --> Template library initialized
INFO - 2019-05-28 19:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-28 19:34:49 --> Controller Class Initialized
DEBUG - 2019-05-28 19:34:49 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-28 19:34:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-28 19:34:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-28 19:34:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-28 19:34:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-28 19:34:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-28 19:34:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-28 19:34:50 --> Final output sent to browser
DEBUG - 2019-05-28 19:34:50 --> Total execution time: 0.0612
INFO - 2019-05-28 19:34:50 --> Config Class Initialized
INFO - 2019-05-28 19:34:50 --> Hooks Class Initialized
DEBUG - 2019-05-28 19:34:50 --> UTF-8 Support Enabled
INFO - 2019-05-28 19:34:50 --> Utf8 Class Initialized
INFO - 2019-05-28 19:34:50 --> URI Class Initialized
INFO - 2019-05-28 19:34:50 --> Router Class Initialized
INFO - 2019-05-28 19:34:50 --> Output Class Initialized
INFO - 2019-05-28 19:34:50 --> Security Class Initialized
DEBUG - 2019-05-28 19:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 19:34:50 --> Input Class Initialized
INFO - 2019-05-28 19:34:50 --> Language Class Initialized
ERROR - 2019-05-28 19:34:50 --> 404 Page Not Found: /index
INFO - 2019-05-28 19:34:51 --> Config Class Initialized
INFO - 2019-05-28 19:34:51 --> Hooks Class Initialized
DEBUG - 2019-05-28 19:34:51 --> UTF-8 Support Enabled
INFO - 2019-05-28 19:34:51 --> Utf8 Class Initialized
INFO - 2019-05-28 19:34:51 --> URI Class Initialized
INFO - 2019-05-28 19:34:51 --> Router Class Initialized
INFO - 2019-05-28 19:34:51 --> Output Class Initialized
INFO - 2019-05-28 19:34:51 --> Security Class Initialized
DEBUG - 2019-05-28 19:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 19:34:51 --> Input Class Initialized
INFO - 2019-05-28 19:34:51 --> Language Class Initialized
ERROR - 2019-05-28 19:34:51 --> 404 Page Not Found: /index
INFO - 2019-05-28 19:34:51 --> Config Class Initialized
INFO - 2019-05-28 19:34:51 --> Hooks Class Initialized
DEBUG - 2019-05-28 19:34:51 --> UTF-8 Support Enabled
INFO - 2019-05-28 19:34:51 --> Utf8 Class Initialized
INFO - 2019-05-28 19:34:51 --> URI Class Initialized
INFO - 2019-05-28 19:34:51 --> Router Class Initialized
INFO - 2019-05-28 19:34:51 --> Output Class Initialized
INFO - 2019-05-28 19:34:51 --> Security Class Initialized
DEBUG - 2019-05-28 19:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 19:34:51 --> Input Class Initialized
INFO - 2019-05-28 19:34:51 --> Language Class Initialized
ERROR - 2019-05-28 19:34:51 --> 404 Page Not Found: /index
INFO - 2019-05-28 19:34:52 --> Config Class Initialized
INFO - 2019-05-28 19:34:52 --> Hooks Class Initialized
DEBUG - 2019-05-28 19:34:52 --> UTF-8 Support Enabled
INFO - 2019-05-28 19:34:52 --> Utf8 Class Initialized
INFO - 2019-05-28 19:34:52 --> URI Class Initialized
INFO - 2019-05-28 19:34:52 --> Router Class Initialized
INFO - 2019-05-28 19:34:52 --> Output Class Initialized
INFO - 2019-05-28 19:34:52 --> Security Class Initialized
DEBUG - 2019-05-28 19:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 19:34:52 --> Input Class Initialized
INFO - 2019-05-28 19:34:52 --> Language Class Initialized
ERROR - 2019-05-28 19:34:52 --> 404 Page Not Found: /index
INFO - 2019-05-28 19:34:52 --> Config Class Initialized
INFO - 2019-05-28 19:34:52 --> Hooks Class Initialized
DEBUG - 2019-05-28 19:34:52 --> UTF-8 Support Enabled
INFO - 2019-05-28 19:34:52 --> Utf8 Class Initialized
INFO - 2019-05-28 19:34:52 --> URI Class Initialized
INFO - 2019-05-28 19:34:52 --> Router Class Initialized
INFO - 2019-05-28 19:34:52 --> Output Class Initialized
INFO - 2019-05-28 19:34:52 --> Security Class Initialized
DEBUG - 2019-05-28 19:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 19:34:52 --> Input Class Initialized
INFO - 2019-05-28 19:34:52 --> Language Class Initialized
ERROR - 2019-05-28 19:34:52 --> 404 Page Not Found: /index
INFO - 2019-05-28 19:34:52 --> Config Class Initialized
INFO - 2019-05-28 19:34:52 --> Hooks Class Initialized
DEBUG - 2019-05-28 19:34:52 --> UTF-8 Support Enabled
INFO - 2019-05-28 19:34:52 --> Utf8 Class Initialized
INFO - 2019-05-28 19:34:52 --> URI Class Initialized
INFO - 2019-05-28 19:34:52 --> Router Class Initialized
INFO - 2019-05-28 19:34:52 --> Output Class Initialized
INFO - 2019-05-28 19:34:52 --> Security Class Initialized
DEBUG - 2019-05-28 19:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 19:34:52 --> Input Class Initialized
INFO - 2019-05-28 19:34:52 --> Language Class Initialized
ERROR - 2019-05-28 19:34:52 --> 404 Page Not Found: /index
INFO - 2019-05-28 19:34:53 --> Config Class Initialized
INFO - 2019-05-28 19:34:53 --> Hooks Class Initialized
DEBUG - 2019-05-28 19:34:53 --> UTF-8 Support Enabled
INFO - 2019-05-28 19:34:53 --> Utf8 Class Initialized
INFO - 2019-05-28 19:34:53 --> URI Class Initialized
INFO - 2019-05-28 19:34:53 --> Router Class Initialized
INFO - 2019-05-28 19:34:53 --> Output Class Initialized
INFO - 2019-05-28 19:34:53 --> Security Class Initialized
DEBUG - 2019-05-28 19:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 19:34:53 --> Input Class Initialized
INFO - 2019-05-28 19:34:53 --> Language Class Initialized
ERROR - 2019-05-28 19:34:53 --> 404 Page Not Found: /index
INFO - 2019-05-28 19:34:53 --> Config Class Initialized
INFO - 2019-05-28 19:34:53 --> Hooks Class Initialized
DEBUG - 2019-05-28 19:34:53 --> UTF-8 Support Enabled
INFO - 2019-05-28 19:34:53 --> Utf8 Class Initialized
INFO - 2019-05-28 19:34:53 --> URI Class Initialized
INFO - 2019-05-28 19:34:53 --> Router Class Initialized
INFO - 2019-05-28 19:34:53 --> Output Class Initialized
INFO - 2019-05-28 19:34:53 --> Security Class Initialized
DEBUG - 2019-05-28 19:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 19:34:53 --> Input Class Initialized
INFO - 2019-05-28 19:34:53 --> Language Class Initialized
ERROR - 2019-05-28 19:34:53 --> 404 Page Not Found: /index
INFO - 2019-05-28 19:34:53 --> Config Class Initialized
INFO - 2019-05-28 19:34:53 --> Hooks Class Initialized
DEBUG - 2019-05-28 19:34:53 --> UTF-8 Support Enabled
INFO - 2019-05-28 19:34:53 --> Utf8 Class Initialized
INFO - 2019-05-28 19:34:53 --> URI Class Initialized
INFO - 2019-05-28 19:34:53 --> Router Class Initialized
INFO - 2019-05-28 19:34:53 --> Output Class Initialized
INFO - 2019-05-28 19:34:53 --> Security Class Initialized
DEBUG - 2019-05-28 19:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 19:34:53 --> Input Class Initialized
INFO - 2019-05-28 19:34:53 --> Language Class Initialized
ERROR - 2019-05-28 19:34:53 --> 404 Page Not Found: /index
INFO - 2019-05-28 19:34:54 --> Config Class Initialized
INFO - 2019-05-28 19:34:54 --> Hooks Class Initialized
DEBUG - 2019-05-28 19:34:54 --> UTF-8 Support Enabled
INFO - 2019-05-28 19:34:54 --> Utf8 Class Initialized
INFO - 2019-05-28 19:34:54 --> URI Class Initialized
INFO - 2019-05-28 19:34:54 --> Router Class Initialized
INFO - 2019-05-28 19:34:54 --> Output Class Initialized
INFO - 2019-05-28 19:34:54 --> Security Class Initialized
DEBUG - 2019-05-28 19:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 19:34:54 --> Input Class Initialized
INFO - 2019-05-28 19:34:54 --> Language Class Initialized
ERROR - 2019-05-28 19:34:54 --> 404 Page Not Found: /index
INFO - 2019-05-28 19:34:54 --> Config Class Initialized
INFO - 2019-05-28 19:34:54 --> Hooks Class Initialized
DEBUG - 2019-05-28 19:34:54 --> UTF-8 Support Enabled
INFO - 2019-05-28 19:34:54 --> Utf8 Class Initialized
INFO - 2019-05-28 19:34:54 --> URI Class Initialized
INFO - 2019-05-28 19:34:54 --> Router Class Initialized
INFO - 2019-05-28 19:34:54 --> Output Class Initialized
INFO - 2019-05-28 19:34:54 --> Security Class Initialized
DEBUG - 2019-05-28 19:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 19:34:54 --> Input Class Initialized
INFO - 2019-05-28 19:34:54 --> Language Class Initialized
ERROR - 2019-05-28 19:34:54 --> 404 Page Not Found: /index
INFO - 2019-05-28 19:34:54 --> Config Class Initialized
INFO - 2019-05-28 19:34:54 --> Hooks Class Initialized
DEBUG - 2019-05-28 19:34:54 --> UTF-8 Support Enabled
INFO - 2019-05-28 19:34:54 --> Utf8 Class Initialized
INFO - 2019-05-28 19:34:54 --> URI Class Initialized
INFO - 2019-05-28 19:34:54 --> Router Class Initialized
INFO - 2019-05-28 19:34:54 --> Output Class Initialized
INFO - 2019-05-28 19:34:54 --> Security Class Initialized
DEBUG - 2019-05-28 19:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-28 19:34:54 --> Input Class Initialized
INFO - 2019-05-28 19:34:54 --> Language Class Initialized
ERROR - 2019-05-28 19:34:54 --> 404 Page Not Found: /index
