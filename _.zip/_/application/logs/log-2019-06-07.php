<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-06-07 07:06:35 --> Config Class Initialized
INFO - 2019-06-07 07:06:35 --> Hooks Class Initialized
DEBUG - 2019-06-07 07:06:35 --> UTF-8 Support Enabled
INFO - 2019-06-07 07:06:35 --> Utf8 Class Initialized
INFO - 2019-06-07 07:06:35 --> URI Class Initialized
DEBUG - 2019-06-07 07:06:35 --> No URI present. Default controller set.
INFO - 2019-06-07 07:06:35 --> Router Class Initialized
INFO - 2019-06-07 07:06:35 --> Output Class Initialized
INFO - 2019-06-07 07:06:35 --> Security Class Initialized
DEBUG - 2019-06-07 07:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 07:06:35 --> Input Class Initialized
INFO - 2019-06-07 07:06:35 --> Language Class Initialized
INFO - 2019-06-07 07:06:35 --> Language Class Initialized
INFO - 2019-06-07 07:06:35 --> Config Class Initialized
INFO - 2019-06-07 07:06:35 --> Loader Class Initialized
INFO - 2019-06-07 07:06:35 --> Helper loaded: form_helper
INFO - 2019-06-07 07:06:35 --> Helper loaded: url_helper
INFO - 2019-06-07 07:06:36 --> Helper loaded: cookie_helper
INFO - 2019-06-07 07:06:36 --> Database Driver Class Initialized
DEBUG - 2019-06-07 07:06:36 --> Template library initialized
INFO - 2019-06-07 07:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-07 07:06:36 --> Controller Class Initialized
DEBUG - 2019-06-07 07:06:36 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-07 07:06:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
ERROR - 2019-06-07 07:06:36 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:06:36 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:06:36 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:06:36 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:06:36 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:06:36 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:06:36 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:06:36 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:06:36 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:06:36 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:06:36 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:06:36 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:06:36 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:06:36 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:06:36 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:06:36 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:06:36 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:06:36 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:06:36 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:06:36 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:06:36 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:06:36 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
DEBUG - 2019-06-07 07:06:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-07 07:06:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-07 07:06:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-07 07:06:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-07 07:06:36 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-07 07:06:36 --> Final output sent to browser
DEBUG - 2019-06-07 07:06:36 --> Total execution time: 0.0729
INFO - 2019-06-07 07:07:31 --> Config Class Initialized
INFO - 2019-06-07 07:07:31 --> Hooks Class Initialized
DEBUG - 2019-06-07 07:07:31 --> UTF-8 Support Enabled
INFO - 2019-06-07 07:07:31 --> Utf8 Class Initialized
INFO - 2019-06-07 07:07:31 --> URI Class Initialized
INFO - 2019-06-07 07:07:31 --> Router Class Initialized
INFO - 2019-06-07 07:07:31 --> Output Class Initialized
INFO - 2019-06-07 07:07:31 --> Security Class Initialized
DEBUG - 2019-06-07 07:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 07:07:31 --> Input Class Initialized
INFO - 2019-06-07 07:07:31 --> Language Class Initialized
ERROR - 2019-06-07 07:07:31 --> 404 Page Not Found: /index
INFO - 2019-06-07 07:07:44 --> Config Class Initialized
INFO - 2019-06-07 07:07:44 --> Hooks Class Initialized
DEBUG - 2019-06-07 07:07:44 --> UTF-8 Support Enabled
INFO - 2019-06-07 07:07:44 --> Utf8 Class Initialized
INFO - 2019-06-07 07:07:44 --> URI Class Initialized
DEBUG - 2019-06-07 07:07:44 --> No URI present. Default controller set.
INFO - 2019-06-07 07:07:44 --> Router Class Initialized
INFO - 2019-06-07 07:07:44 --> Output Class Initialized
INFO - 2019-06-07 07:07:44 --> Security Class Initialized
DEBUG - 2019-06-07 07:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 07:07:44 --> Input Class Initialized
INFO - 2019-06-07 07:07:44 --> Language Class Initialized
INFO - 2019-06-07 07:07:44 --> Language Class Initialized
INFO - 2019-06-07 07:07:44 --> Config Class Initialized
INFO - 2019-06-07 07:07:44 --> Loader Class Initialized
INFO - 2019-06-07 07:07:44 --> Helper loaded: form_helper
INFO - 2019-06-07 07:07:44 --> Helper loaded: url_helper
INFO - 2019-06-07 07:07:44 --> Helper loaded: cookie_helper
INFO - 2019-06-07 07:07:44 --> Database Driver Class Initialized
DEBUG - 2019-06-07 07:07:44 --> Template library initialized
INFO - 2019-06-07 07:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-07 07:07:44 --> Controller Class Initialized
DEBUG - 2019-06-07 07:07:44 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-07 07:07:44 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
ERROR - 2019-06-07 07:07:44 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:07:44 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:07:44 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:07:44 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:07:44 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:07:44 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:07:44 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:07:44 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:07:44 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:07:44 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:07:44 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:07:44 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:07:44 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:07:44 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:07:44 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:07:44 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:07:44 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:07:44 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:07:44 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:07:45 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:07:45 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 07:07:45 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
DEBUG - 2019-06-07 07:07:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-07 07:07:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-07 07:07:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-07 07:07:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-07 07:07:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-07 07:07:45 --> Final output sent to browser
DEBUG - 2019-06-07 07:07:45 --> Total execution time: 0.0704
INFO - 2019-06-07 08:13:52 --> Config Class Initialized
INFO - 2019-06-07 08:13:52 --> Hooks Class Initialized
DEBUG - 2019-06-07 08:13:52 --> UTF-8 Support Enabled
INFO - 2019-06-07 08:13:52 --> Utf8 Class Initialized
INFO - 2019-06-07 08:13:52 --> URI Class Initialized
DEBUG - 2019-06-07 08:13:52 --> No URI present. Default controller set.
INFO - 2019-06-07 08:13:52 --> Router Class Initialized
INFO - 2019-06-07 08:13:52 --> Output Class Initialized
INFO - 2019-06-07 08:13:52 --> Security Class Initialized
DEBUG - 2019-06-07 08:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 08:13:52 --> Input Class Initialized
INFO - 2019-06-07 08:13:52 --> Language Class Initialized
INFO - 2019-06-07 08:13:52 --> Language Class Initialized
INFO - 2019-06-07 08:13:52 --> Config Class Initialized
INFO - 2019-06-07 08:13:52 --> Loader Class Initialized
INFO - 2019-06-07 08:13:52 --> Helper loaded: form_helper
INFO - 2019-06-07 08:13:52 --> Helper loaded: url_helper
INFO - 2019-06-07 08:13:52 --> Helper loaded: cookie_helper
INFO - 2019-06-07 08:13:52 --> Database Driver Class Initialized
DEBUG - 2019-06-07 08:13:52 --> Template library initialized
INFO - 2019-06-07 08:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-07 08:13:52 --> Controller Class Initialized
DEBUG - 2019-06-07 08:13:52 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-07 08:13:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
ERROR - 2019-06-07 08:13:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:13:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:13:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:13:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:13:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:13:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:13:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:13:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:13:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:13:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:13:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:13:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:13:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:13:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:13:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:13:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:13:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:13:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:13:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:13:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:13:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:13:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
DEBUG - 2019-06-07 08:13:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-07 08:13:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-07 08:13:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-07 08:13:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-07 08:13:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-07 08:13:52 --> Final output sent to browser
DEBUG - 2019-06-07 08:13:52 --> Total execution time: 0.0658
INFO - 2019-06-07 08:14:03 --> Config Class Initialized
INFO - 2019-06-07 08:14:03 --> Hooks Class Initialized
DEBUG - 2019-06-07 08:14:03 --> UTF-8 Support Enabled
INFO - 2019-06-07 08:14:03 --> Utf8 Class Initialized
INFO - 2019-06-07 08:14:03 --> URI Class Initialized
INFO - 2019-06-07 08:14:03 --> Router Class Initialized
INFO - 2019-06-07 08:14:03 --> Output Class Initialized
INFO - 2019-06-07 08:14:03 --> Security Class Initialized
DEBUG - 2019-06-07 08:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 08:14:03 --> Input Class Initialized
INFO - 2019-06-07 08:14:03 --> Language Class Initialized
ERROR - 2019-06-07 08:14:03 --> 404 Page Not Found: /index
INFO - 2019-06-07 08:21:35 --> Config Class Initialized
INFO - 2019-06-07 08:21:35 --> Hooks Class Initialized
DEBUG - 2019-06-07 08:21:35 --> UTF-8 Support Enabled
INFO - 2019-06-07 08:21:35 --> Utf8 Class Initialized
INFO - 2019-06-07 08:21:35 --> URI Class Initialized
DEBUG - 2019-06-07 08:21:35 --> No URI present. Default controller set.
INFO - 2019-06-07 08:21:35 --> Router Class Initialized
INFO - 2019-06-07 08:21:35 --> Output Class Initialized
INFO - 2019-06-07 08:21:35 --> Security Class Initialized
DEBUG - 2019-06-07 08:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 08:21:35 --> Input Class Initialized
INFO - 2019-06-07 08:21:35 --> Language Class Initialized
INFO - 2019-06-07 08:21:35 --> Language Class Initialized
INFO - 2019-06-07 08:21:35 --> Config Class Initialized
INFO - 2019-06-07 08:21:35 --> Loader Class Initialized
INFO - 2019-06-07 08:21:35 --> Helper loaded: form_helper
INFO - 2019-06-07 08:21:35 --> Helper loaded: url_helper
INFO - 2019-06-07 08:21:35 --> Helper loaded: cookie_helper
INFO - 2019-06-07 08:21:35 --> Database Driver Class Initialized
DEBUG - 2019-06-07 08:21:35 --> Template library initialized
INFO - 2019-06-07 08:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-07 08:21:35 --> Controller Class Initialized
DEBUG - 2019-06-07 08:21:35 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-07 08:21:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
ERROR - 2019-06-07 08:21:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:21:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:21:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:21:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:21:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:21:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:21:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:21:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:21:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:21:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:21:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:21:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:21:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:21:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:21:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:21:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:21:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:21:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:21:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:21:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:21:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 08:21:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
DEBUG - 2019-06-07 08:21:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-07 08:21:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-07 08:21:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-07 08:21:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-07 08:21:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-07 08:21:36 --> Final output sent to browser
DEBUG - 2019-06-07 08:21:36 --> Total execution time: 0.0641
INFO - 2019-06-07 08:21:39 --> Config Class Initialized
INFO - 2019-06-07 08:21:39 --> Hooks Class Initialized
DEBUG - 2019-06-07 08:21:39 --> UTF-8 Support Enabled
INFO - 2019-06-07 08:21:39 --> Utf8 Class Initialized
INFO - 2019-06-07 08:21:39 --> URI Class Initialized
INFO - 2019-06-07 08:21:39 --> Router Class Initialized
INFO - 2019-06-07 08:21:39 --> Output Class Initialized
INFO - 2019-06-07 08:21:39 --> Security Class Initialized
DEBUG - 2019-06-07 08:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 08:21:39 --> Input Class Initialized
INFO - 2019-06-07 08:21:39 --> Language Class Initialized
ERROR - 2019-06-07 08:21:39 --> 404 Page Not Found: /index
INFO - 2019-06-07 08:21:39 --> Config Class Initialized
INFO - 2019-06-07 08:21:39 --> Hooks Class Initialized
DEBUG - 2019-06-07 08:21:39 --> UTF-8 Support Enabled
INFO - 2019-06-07 08:21:39 --> Utf8 Class Initialized
INFO - 2019-06-07 08:21:39 --> URI Class Initialized
INFO - 2019-06-07 08:21:39 --> Router Class Initialized
INFO - 2019-06-07 08:21:39 --> Output Class Initialized
INFO - 2019-06-07 08:21:39 --> Security Class Initialized
DEBUG - 2019-06-07 08:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 08:21:39 --> Input Class Initialized
INFO - 2019-06-07 08:21:39 --> Language Class Initialized
ERROR - 2019-06-07 08:21:39 --> 404 Page Not Found: /index
INFO - 2019-06-07 08:21:40 --> Config Class Initialized
INFO - 2019-06-07 08:21:40 --> Hooks Class Initialized
DEBUG - 2019-06-07 08:21:40 --> UTF-8 Support Enabled
INFO - 2019-06-07 08:21:40 --> Utf8 Class Initialized
INFO - 2019-06-07 08:21:40 --> URI Class Initialized
INFO - 2019-06-07 08:21:40 --> Router Class Initialized
INFO - 2019-06-07 08:21:40 --> Output Class Initialized
INFO - 2019-06-07 08:21:40 --> Security Class Initialized
DEBUG - 2019-06-07 08:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 08:21:40 --> Input Class Initialized
INFO - 2019-06-07 08:21:40 --> Language Class Initialized
ERROR - 2019-06-07 08:21:40 --> 404 Page Not Found: /index
INFO - 2019-06-07 08:21:44 --> Config Class Initialized
INFO - 2019-06-07 08:21:44 --> Hooks Class Initialized
DEBUG - 2019-06-07 08:21:44 --> UTF-8 Support Enabled
INFO - 2019-06-07 08:21:44 --> Utf8 Class Initialized
INFO - 2019-06-07 08:21:44 --> URI Class Initialized
INFO - 2019-06-07 08:21:44 --> Router Class Initialized
INFO - 2019-06-07 08:21:44 --> Output Class Initialized
INFO - 2019-06-07 08:21:44 --> Security Class Initialized
DEBUG - 2019-06-07 08:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 08:21:44 --> Input Class Initialized
INFO - 2019-06-07 08:21:44 --> Language Class Initialized
ERROR - 2019-06-07 08:21:44 --> 404 Page Not Found: /index
INFO - 2019-06-07 08:21:47 --> Config Class Initialized
INFO - 2019-06-07 08:21:47 --> Hooks Class Initialized
DEBUG - 2019-06-07 08:21:47 --> UTF-8 Support Enabled
INFO - 2019-06-07 08:21:47 --> Utf8 Class Initialized
INFO - 2019-06-07 08:21:47 --> URI Class Initialized
INFO - 2019-06-07 08:21:47 --> Router Class Initialized
INFO - 2019-06-07 08:21:47 --> Output Class Initialized
INFO - 2019-06-07 08:21:47 --> Security Class Initialized
DEBUG - 2019-06-07 08:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 08:21:47 --> Input Class Initialized
INFO - 2019-06-07 08:21:47 --> Language Class Initialized
ERROR - 2019-06-07 08:21:47 --> 404 Page Not Found: /index
INFO - 2019-06-07 08:21:47 --> Config Class Initialized
INFO - 2019-06-07 08:21:47 --> Hooks Class Initialized
DEBUG - 2019-06-07 08:21:47 --> UTF-8 Support Enabled
INFO - 2019-06-07 08:21:47 --> Utf8 Class Initialized
INFO - 2019-06-07 08:21:47 --> URI Class Initialized
INFO - 2019-06-07 08:21:47 --> Router Class Initialized
INFO - 2019-06-07 08:21:47 --> Output Class Initialized
INFO - 2019-06-07 08:21:47 --> Security Class Initialized
DEBUG - 2019-06-07 08:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 08:21:47 --> Input Class Initialized
INFO - 2019-06-07 08:21:47 --> Language Class Initialized
ERROR - 2019-06-07 08:21:47 --> 404 Page Not Found: /index
INFO - 2019-06-07 08:21:48 --> Config Class Initialized
INFO - 2019-06-07 08:21:48 --> Hooks Class Initialized
DEBUG - 2019-06-07 08:21:48 --> UTF-8 Support Enabled
INFO - 2019-06-07 08:21:48 --> Utf8 Class Initialized
INFO - 2019-06-07 08:21:48 --> URI Class Initialized
INFO - 2019-06-07 08:21:48 --> Router Class Initialized
INFO - 2019-06-07 08:21:48 --> Output Class Initialized
INFO - 2019-06-07 08:21:48 --> Security Class Initialized
DEBUG - 2019-06-07 08:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 08:21:48 --> Input Class Initialized
INFO - 2019-06-07 08:21:48 --> Language Class Initialized
ERROR - 2019-06-07 08:21:48 --> 404 Page Not Found: /index
INFO - 2019-06-07 08:21:48 --> Config Class Initialized
INFO - 2019-06-07 08:21:48 --> Hooks Class Initialized
DEBUG - 2019-06-07 08:21:48 --> UTF-8 Support Enabled
INFO - 2019-06-07 08:21:48 --> Utf8 Class Initialized
INFO - 2019-06-07 08:21:48 --> URI Class Initialized
INFO - 2019-06-07 08:21:48 --> Router Class Initialized
INFO - 2019-06-07 08:21:48 --> Output Class Initialized
INFO - 2019-06-07 08:21:48 --> Security Class Initialized
DEBUG - 2019-06-07 08:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 08:21:48 --> Input Class Initialized
INFO - 2019-06-07 08:21:48 --> Language Class Initialized
ERROR - 2019-06-07 08:21:48 --> 404 Page Not Found: /index
INFO - 2019-06-07 08:21:48 --> Config Class Initialized
INFO - 2019-06-07 08:21:48 --> Hooks Class Initialized
DEBUG - 2019-06-07 08:21:48 --> UTF-8 Support Enabled
INFO - 2019-06-07 08:21:48 --> Utf8 Class Initialized
INFO - 2019-06-07 08:21:48 --> URI Class Initialized
INFO - 2019-06-07 08:21:48 --> Router Class Initialized
INFO - 2019-06-07 08:21:48 --> Output Class Initialized
INFO - 2019-06-07 08:21:48 --> Security Class Initialized
DEBUG - 2019-06-07 08:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 08:21:48 --> Input Class Initialized
INFO - 2019-06-07 08:21:48 --> Language Class Initialized
ERROR - 2019-06-07 08:21:48 --> 404 Page Not Found: /index
INFO - 2019-06-07 08:21:49 --> Config Class Initialized
INFO - 2019-06-07 08:21:49 --> Hooks Class Initialized
DEBUG - 2019-06-07 08:21:49 --> UTF-8 Support Enabled
INFO - 2019-06-07 08:21:49 --> Utf8 Class Initialized
INFO - 2019-06-07 08:21:49 --> URI Class Initialized
INFO - 2019-06-07 08:21:49 --> Router Class Initialized
INFO - 2019-06-07 08:21:49 --> Output Class Initialized
INFO - 2019-06-07 08:21:49 --> Security Class Initialized
DEBUG - 2019-06-07 08:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 08:21:49 --> Input Class Initialized
INFO - 2019-06-07 08:21:49 --> Language Class Initialized
ERROR - 2019-06-07 08:21:49 --> 404 Page Not Found: /index
INFO - 2019-06-07 08:21:49 --> Config Class Initialized
INFO - 2019-06-07 08:21:49 --> Hooks Class Initialized
DEBUG - 2019-06-07 08:21:49 --> UTF-8 Support Enabled
INFO - 2019-06-07 08:21:49 --> Utf8 Class Initialized
INFO - 2019-06-07 08:21:49 --> URI Class Initialized
INFO - 2019-06-07 08:21:49 --> Router Class Initialized
INFO - 2019-06-07 08:21:49 --> Output Class Initialized
INFO - 2019-06-07 08:21:49 --> Security Class Initialized
DEBUG - 2019-06-07 08:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 08:21:49 --> Input Class Initialized
INFO - 2019-06-07 08:21:49 --> Language Class Initialized
ERROR - 2019-06-07 08:21:49 --> 404 Page Not Found: /index
INFO - 2019-06-07 08:21:49 --> Config Class Initialized
INFO - 2019-06-07 08:21:49 --> Hooks Class Initialized
DEBUG - 2019-06-07 08:21:49 --> UTF-8 Support Enabled
INFO - 2019-06-07 08:21:49 --> Utf8 Class Initialized
INFO - 2019-06-07 08:21:49 --> URI Class Initialized
INFO - 2019-06-07 08:21:49 --> Router Class Initialized
INFO - 2019-06-07 08:21:49 --> Output Class Initialized
INFO - 2019-06-07 08:21:49 --> Security Class Initialized
DEBUG - 2019-06-07 08:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 08:21:49 --> Input Class Initialized
INFO - 2019-06-07 08:21:49 --> Language Class Initialized
ERROR - 2019-06-07 08:21:49 --> 404 Page Not Found: /index
INFO - 2019-06-07 09:14:17 --> Config Class Initialized
INFO - 2019-06-07 09:14:17 --> Hooks Class Initialized
DEBUG - 2019-06-07 09:14:17 --> UTF-8 Support Enabled
INFO - 2019-06-07 09:14:17 --> Utf8 Class Initialized
INFO - 2019-06-07 09:14:17 --> URI Class Initialized
DEBUG - 2019-06-07 09:14:17 --> No URI present. Default controller set.
INFO - 2019-06-07 09:14:17 --> Router Class Initialized
INFO - 2019-06-07 09:14:17 --> Output Class Initialized
INFO - 2019-06-07 09:14:17 --> Security Class Initialized
DEBUG - 2019-06-07 09:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 09:14:17 --> Input Class Initialized
INFO - 2019-06-07 09:14:17 --> Language Class Initialized
INFO - 2019-06-07 09:14:17 --> Language Class Initialized
INFO - 2019-06-07 09:14:17 --> Config Class Initialized
INFO - 2019-06-07 09:14:17 --> Loader Class Initialized
INFO - 2019-06-07 09:14:17 --> Helper loaded: form_helper
INFO - 2019-06-07 09:14:17 --> Helper loaded: url_helper
INFO - 2019-06-07 09:14:17 --> Helper loaded: cookie_helper
INFO - 2019-06-07 09:14:17 --> Database Driver Class Initialized
DEBUG - 2019-06-07 09:14:17 --> Template library initialized
INFO - 2019-06-07 09:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-07 09:14:17 --> Controller Class Initialized
DEBUG - 2019-06-07 09:14:17 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-07 09:14:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
ERROR - 2019-06-07 09:14:17 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 09:14:17 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 09:14:17 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 09:14:17 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 09:14:17 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 09:14:17 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 09:14:17 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 09:14:17 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 09:14:17 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 09:14:17 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 09:14:17 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 09:14:17 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 09:14:17 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 09:14:17 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 09:14:17 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 09:14:17 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 09:14:17 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 09:14:17 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 09:14:17 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 09:14:17 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 09:14:17 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 09:14:17 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
DEBUG - 2019-06-07 09:14:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-07 09:14:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-07 09:14:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-07 09:14:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-07 09:14:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-07 09:14:17 --> Final output sent to browser
DEBUG - 2019-06-07 09:14:17 --> Total execution time: 0.0785
INFO - 2019-06-07 09:15:17 --> Config Class Initialized
INFO - 2019-06-07 09:15:17 --> Hooks Class Initialized
DEBUG - 2019-06-07 09:15:17 --> UTF-8 Support Enabled
INFO - 2019-06-07 09:15:17 --> Utf8 Class Initialized
INFO - 2019-06-07 09:15:17 --> URI Class Initialized
INFO - 2019-06-07 09:15:17 --> Router Class Initialized
INFO - 2019-06-07 09:15:17 --> Output Class Initialized
INFO - 2019-06-07 09:15:17 --> Security Class Initialized
DEBUG - 2019-06-07 09:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 09:15:17 --> Input Class Initialized
INFO - 2019-06-07 09:15:17 --> Language Class Initialized
INFO - 2019-06-07 09:15:17 --> Language Class Initialized
INFO - 2019-06-07 09:15:17 --> Config Class Initialized
INFO - 2019-06-07 09:15:17 --> Loader Class Initialized
INFO - 2019-06-07 09:15:17 --> Helper loaded: form_helper
INFO - 2019-06-07 09:15:17 --> Helper loaded: url_helper
INFO - 2019-06-07 09:15:17 --> Helper loaded: cookie_helper
INFO - 2019-06-07 09:15:17 --> Database Driver Class Initialized
DEBUG - 2019-06-07 09:15:17 --> Template library initialized
INFO - 2019-06-07 09:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-07 09:15:17 --> Controller Class Initialized
DEBUG - 2019-06-07 09:15:17 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-07 09:15:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-06-07 09:15:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/gas.php
DEBUG - 2019-06-07 09:15:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-07 09:15:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-07 09:15:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-07 09:15:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-07 09:15:18 --> Final output sent to browser
DEBUG - 2019-06-07 09:15:18 --> Total execution time: 0.0527
INFO - 2019-06-07 09:15:19 --> Config Class Initialized
INFO - 2019-06-07 09:15:19 --> Hooks Class Initialized
DEBUG - 2019-06-07 09:15:19 --> UTF-8 Support Enabled
INFO - 2019-06-07 09:15:19 --> Utf8 Class Initialized
INFO - 2019-06-07 09:15:19 --> URI Class Initialized
INFO - 2019-06-07 09:15:19 --> Router Class Initialized
INFO - 2019-06-07 09:15:19 --> Output Class Initialized
INFO - 2019-06-07 09:15:19 --> Security Class Initialized
DEBUG - 2019-06-07 09:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 09:15:19 --> Input Class Initialized
INFO - 2019-06-07 09:15:19 --> Language Class Initialized
ERROR - 2019-06-07 09:15:19 --> 404 Page Not Found: /index
INFO - 2019-06-07 13:17:55 --> Config Class Initialized
INFO - 2019-06-07 13:17:55 --> Hooks Class Initialized
DEBUG - 2019-06-07 13:17:55 --> UTF-8 Support Enabled
INFO - 2019-06-07 13:17:55 --> Utf8 Class Initialized
INFO - 2019-06-07 13:17:55 --> URI Class Initialized
DEBUG - 2019-06-07 13:17:55 --> No URI present. Default controller set.
INFO - 2019-06-07 13:17:55 --> Router Class Initialized
INFO - 2019-06-07 13:17:55 --> Output Class Initialized
INFO - 2019-06-07 13:17:55 --> Security Class Initialized
DEBUG - 2019-06-07 13:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 13:17:55 --> Input Class Initialized
INFO - 2019-06-07 13:17:55 --> Language Class Initialized
INFO - 2019-06-07 13:17:55 --> Language Class Initialized
INFO - 2019-06-07 13:17:55 --> Config Class Initialized
INFO - 2019-06-07 13:17:55 --> Loader Class Initialized
INFO - 2019-06-07 13:17:55 --> Helper loaded: form_helper
INFO - 2019-06-07 13:17:55 --> Helper loaded: url_helper
INFO - 2019-06-07 13:17:55 --> Helper loaded: cookie_helper
INFO - 2019-06-07 13:17:55 --> Database Driver Class Initialized
DEBUG - 2019-06-07 13:17:55 --> Template library initialized
INFO - 2019-06-07 13:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-07 13:17:55 --> Controller Class Initialized
DEBUG - 2019-06-07 13:17:55 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-07 13:17:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
ERROR - 2019-06-07 13:17:55 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 13:17:55 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 13:17:55 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 13:17:55 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 13:17:55 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 13:17:55 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 13:17:55 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 13:17:55 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 13:17:55 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 13:17:55 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 13:17:55 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 13:17:55 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 13:17:55 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 13:17:55 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 13:17:55 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 13:17:55 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 13:17:55 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 13:17:55 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 13:17:55 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 13:17:55 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 13:17:55 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 13:17:55 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
DEBUG - 2019-06-07 13:17:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-07 13:17:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-07 13:17:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-07 13:17:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-07 13:17:55 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-07 13:17:55 --> Final output sent to browser
DEBUG - 2019-06-07 13:17:55 --> Total execution time: 0.0733
INFO - 2019-06-07 13:17:58 --> Config Class Initialized
INFO - 2019-06-07 13:17:58 --> Hooks Class Initialized
DEBUG - 2019-06-07 13:17:58 --> UTF-8 Support Enabled
INFO - 2019-06-07 13:17:58 --> Utf8 Class Initialized
INFO - 2019-06-07 13:17:58 --> URI Class Initialized
INFO - 2019-06-07 13:17:58 --> Router Class Initialized
INFO - 2019-06-07 13:17:58 --> Output Class Initialized
INFO - 2019-06-07 13:17:58 --> Security Class Initialized
DEBUG - 2019-06-07 13:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 13:17:58 --> Input Class Initialized
INFO - 2019-06-07 13:17:58 --> Language Class Initialized
ERROR - 2019-06-07 13:17:58 --> 404 Page Not Found: /index
INFO - 2019-06-07 18:57:35 --> Config Class Initialized
INFO - 2019-06-07 18:57:35 --> Hooks Class Initialized
DEBUG - 2019-06-07 18:57:35 --> UTF-8 Support Enabled
INFO - 2019-06-07 18:57:35 --> Utf8 Class Initialized
INFO - 2019-06-07 18:57:35 --> URI Class Initialized
DEBUG - 2019-06-07 18:57:35 --> No URI present. Default controller set.
INFO - 2019-06-07 18:57:35 --> Router Class Initialized
INFO - 2019-06-07 18:57:35 --> Output Class Initialized
INFO - 2019-06-07 18:57:35 --> Security Class Initialized
DEBUG - 2019-06-07 18:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 18:57:35 --> Input Class Initialized
INFO - 2019-06-07 18:57:35 --> Language Class Initialized
INFO - 2019-06-07 18:57:35 --> Language Class Initialized
INFO - 2019-06-07 18:57:35 --> Config Class Initialized
INFO - 2019-06-07 18:57:35 --> Loader Class Initialized
INFO - 2019-06-07 18:57:35 --> Helper loaded: form_helper
INFO - 2019-06-07 18:57:35 --> Helper loaded: url_helper
INFO - 2019-06-07 18:57:35 --> Helper loaded: cookie_helper
INFO - 2019-06-07 18:57:35 --> Database Driver Class Initialized
DEBUG - 2019-06-07 18:57:35 --> Template library initialized
INFO - 2019-06-07 18:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-07 18:57:35 --> Controller Class Initialized
DEBUG - 2019-06-07 18:57:35 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-07 18:57:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
ERROR - 2019-06-07 18:57:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 18:57:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 18:57:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 18:57:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 18:57:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 18:57:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 18:57:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 18:57:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 18:57:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 18:57:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 18:57:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 18:57:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 18:57:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 18:57:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 18:57:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 18:57:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 18:57:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 18:57:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 18:57:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 18:57:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 18:57:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-07 18:57:35 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
DEBUG - 2019-06-07 18:57:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-07 18:57:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-07 18:57:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-07 18:57:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-07 18:57:35 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-07 18:57:35 --> Final output sent to browser
DEBUG - 2019-06-07 18:57:35 --> Total execution time: 0.0722
INFO - 2019-06-07 18:57:36 --> Config Class Initialized
INFO - 2019-06-07 18:57:36 --> Hooks Class Initialized
DEBUG - 2019-06-07 18:57:36 --> UTF-8 Support Enabled
INFO - 2019-06-07 18:57:36 --> Utf8 Class Initialized
INFO - 2019-06-07 18:57:36 --> URI Class Initialized
INFO - 2019-06-07 18:57:36 --> Router Class Initialized
INFO - 2019-06-07 18:57:36 --> Output Class Initialized
INFO - 2019-06-07 18:57:36 --> Security Class Initialized
DEBUG - 2019-06-07 18:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 18:57:36 --> Input Class Initialized
INFO - 2019-06-07 18:57:36 --> Language Class Initialized
ERROR - 2019-06-07 18:57:36 --> 404 Page Not Found: /index
INFO - 2019-06-07 18:57:36 --> Config Class Initialized
INFO - 2019-06-07 18:57:36 --> Hooks Class Initialized
DEBUG - 2019-06-07 18:57:36 --> UTF-8 Support Enabled
INFO - 2019-06-07 18:57:36 --> Utf8 Class Initialized
INFO - 2019-06-07 18:57:36 --> URI Class Initialized
INFO - 2019-06-07 18:57:36 --> Router Class Initialized
INFO - 2019-06-07 18:57:36 --> Output Class Initialized
INFO - 2019-06-07 18:57:36 --> Security Class Initialized
DEBUG - 2019-06-07 18:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 18:57:36 --> Input Class Initialized
INFO - 2019-06-07 18:57:36 --> Language Class Initialized
ERROR - 2019-06-07 18:57:36 --> 404 Page Not Found: /index
INFO - 2019-06-07 18:57:37 --> Config Class Initialized
INFO - 2019-06-07 18:57:37 --> Hooks Class Initialized
DEBUG - 2019-06-07 18:57:37 --> UTF-8 Support Enabled
INFO - 2019-06-07 18:57:37 --> Utf8 Class Initialized
INFO - 2019-06-07 18:57:37 --> URI Class Initialized
INFO - 2019-06-07 18:57:37 --> Router Class Initialized
INFO - 2019-06-07 18:57:37 --> Output Class Initialized
INFO - 2019-06-07 18:57:37 --> Security Class Initialized
DEBUG - 2019-06-07 18:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 18:57:37 --> Input Class Initialized
INFO - 2019-06-07 18:57:37 --> Language Class Initialized
ERROR - 2019-06-07 18:57:37 --> 404 Page Not Found: /index
INFO - 2019-06-07 18:57:37 --> Config Class Initialized
INFO - 2019-06-07 18:57:37 --> Hooks Class Initialized
DEBUG - 2019-06-07 18:57:37 --> UTF-8 Support Enabled
INFO - 2019-06-07 18:57:37 --> Utf8 Class Initialized
INFO - 2019-06-07 18:57:37 --> URI Class Initialized
INFO - 2019-06-07 18:57:37 --> Router Class Initialized
INFO - 2019-06-07 18:57:37 --> Output Class Initialized
INFO - 2019-06-07 18:57:37 --> Security Class Initialized
DEBUG - 2019-06-07 18:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 18:57:37 --> Input Class Initialized
INFO - 2019-06-07 18:57:37 --> Language Class Initialized
ERROR - 2019-06-07 18:57:37 --> 404 Page Not Found: /index
INFO - 2019-06-07 18:57:37 --> Config Class Initialized
INFO - 2019-06-07 18:57:37 --> Hooks Class Initialized
DEBUG - 2019-06-07 18:57:37 --> UTF-8 Support Enabled
INFO - 2019-06-07 18:57:37 --> Utf8 Class Initialized
INFO - 2019-06-07 18:57:37 --> URI Class Initialized
INFO - 2019-06-07 18:57:37 --> Router Class Initialized
INFO - 2019-06-07 18:57:37 --> Output Class Initialized
INFO - 2019-06-07 18:57:37 --> Security Class Initialized
DEBUG - 2019-06-07 18:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 18:57:37 --> Input Class Initialized
INFO - 2019-06-07 18:57:37 --> Language Class Initialized
ERROR - 2019-06-07 18:57:37 --> 404 Page Not Found: /index
INFO - 2019-06-07 18:57:37 --> Config Class Initialized
INFO - 2019-06-07 18:57:37 --> Hooks Class Initialized
DEBUG - 2019-06-07 18:57:37 --> UTF-8 Support Enabled
INFO - 2019-06-07 18:57:37 --> Utf8 Class Initialized
INFO - 2019-06-07 18:57:37 --> URI Class Initialized
INFO - 2019-06-07 18:57:37 --> Router Class Initialized
INFO - 2019-06-07 18:57:37 --> Output Class Initialized
INFO - 2019-06-07 18:57:37 --> Security Class Initialized
DEBUG - 2019-06-07 18:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 18:57:37 --> Input Class Initialized
INFO - 2019-06-07 18:57:37 --> Language Class Initialized
ERROR - 2019-06-07 18:57:37 --> 404 Page Not Found: /index
INFO - 2019-06-07 18:57:38 --> Config Class Initialized
INFO - 2019-06-07 18:57:38 --> Hooks Class Initialized
DEBUG - 2019-06-07 18:57:38 --> UTF-8 Support Enabled
INFO - 2019-06-07 18:57:38 --> Utf8 Class Initialized
INFO - 2019-06-07 18:57:38 --> URI Class Initialized
INFO - 2019-06-07 18:57:38 --> Router Class Initialized
INFO - 2019-06-07 18:57:38 --> Output Class Initialized
INFO - 2019-06-07 18:57:38 --> Security Class Initialized
DEBUG - 2019-06-07 18:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 18:57:38 --> Input Class Initialized
INFO - 2019-06-07 18:57:38 --> Language Class Initialized
ERROR - 2019-06-07 18:57:38 --> 404 Page Not Found: /index
INFO - 2019-06-07 18:57:38 --> Config Class Initialized
INFO - 2019-06-07 18:57:38 --> Hooks Class Initialized
DEBUG - 2019-06-07 18:57:38 --> UTF-8 Support Enabled
INFO - 2019-06-07 18:57:38 --> Utf8 Class Initialized
INFO - 2019-06-07 18:57:38 --> URI Class Initialized
INFO - 2019-06-07 18:57:38 --> Router Class Initialized
INFO - 2019-06-07 18:57:38 --> Output Class Initialized
INFO - 2019-06-07 18:57:38 --> Security Class Initialized
DEBUG - 2019-06-07 18:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 18:57:38 --> Input Class Initialized
INFO - 2019-06-07 18:57:38 --> Language Class Initialized
ERROR - 2019-06-07 18:57:38 --> 404 Page Not Found: /index
INFO - 2019-06-07 18:57:38 --> Config Class Initialized
INFO - 2019-06-07 18:57:38 --> Hooks Class Initialized
DEBUG - 2019-06-07 18:57:38 --> UTF-8 Support Enabled
INFO - 2019-06-07 18:57:38 --> Utf8 Class Initialized
INFO - 2019-06-07 18:57:38 --> URI Class Initialized
INFO - 2019-06-07 18:57:38 --> Router Class Initialized
INFO - 2019-06-07 18:57:38 --> Output Class Initialized
INFO - 2019-06-07 18:57:38 --> Security Class Initialized
DEBUG - 2019-06-07 18:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 18:57:38 --> Input Class Initialized
INFO - 2019-06-07 18:57:38 --> Language Class Initialized
ERROR - 2019-06-07 18:57:38 --> 404 Page Not Found: /index
INFO - 2019-06-07 18:57:38 --> Config Class Initialized
INFO - 2019-06-07 18:57:38 --> Hooks Class Initialized
DEBUG - 2019-06-07 18:57:38 --> UTF-8 Support Enabled
INFO - 2019-06-07 18:57:38 --> Utf8 Class Initialized
INFO - 2019-06-07 18:57:38 --> URI Class Initialized
INFO - 2019-06-07 18:57:38 --> Router Class Initialized
INFO - 2019-06-07 18:57:38 --> Output Class Initialized
INFO - 2019-06-07 18:57:38 --> Security Class Initialized
DEBUG - 2019-06-07 18:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 18:57:38 --> Input Class Initialized
INFO - 2019-06-07 18:57:38 --> Language Class Initialized
ERROR - 2019-06-07 18:57:38 --> 404 Page Not Found: /index
INFO - 2019-06-07 18:57:39 --> Config Class Initialized
INFO - 2019-06-07 18:57:39 --> Hooks Class Initialized
DEBUG - 2019-06-07 18:57:39 --> UTF-8 Support Enabled
INFO - 2019-06-07 18:57:39 --> Utf8 Class Initialized
INFO - 2019-06-07 18:57:39 --> URI Class Initialized
INFO - 2019-06-07 18:57:39 --> Router Class Initialized
INFO - 2019-06-07 18:57:39 --> Output Class Initialized
INFO - 2019-06-07 18:57:39 --> Security Class Initialized
DEBUG - 2019-06-07 18:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 18:57:39 --> Input Class Initialized
INFO - 2019-06-07 18:57:39 --> Language Class Initialized
ERROR - 2019-06-07 18:57:39 --> 404 Page Not Found: /index
INFO - 2019-06-07 18:57:39 --> Config Class Initialized
INFO - 2019-06-07 18:57:39 --> Hooks Class Initialized
DEBUG - 2019-06-07 18:57:39 --> UTF-8 Support Enabled
INFO - 2019-06-07 18:57:39 --> Utf8 Class Initialized
INFO - 2019-06-07 18:57:39 --> URI Class Initialized
INFO - 2019-06-07 18:57:39 --> Router Class Initialized
INFO - 2019-06-07 18:57:39 --> Output Class Initialized
INFO - 2019-06-07 18:57:39 --> Security Class Initialized
DEBUG - 2019-06-07 18:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-07 18:57:39 --> Input Class Initialized
INFO - 2019-06-07 18:57:39 --> Language Class Initialized
ERROR - 2019-06-07 18:57:39 --> 404 Page Not Found: /index
