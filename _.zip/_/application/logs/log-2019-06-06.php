<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-06-06 04:44:23 --> Config Class Initialized
INFO - 2019-06-06 04:44:23 --> Hooks Class Initialized
DEBUG - 2019-06-06 04:44:23 --> UTF-8 Support Enabled
INFO - 2019-06-06 04:44:23 --> Utf8 Class Initialized
INFO - 2019-06-06 04:44:23 --> URI Class Initialized
DEBUG - 2019-06-06 04:44:23 --> No URI present. Default controller set.
INFO - 2019-06-06 04:44:23 --> Router Class Initialized
INFO - 2019-06-06 04:44:23 --> Output Class Initialized
INFO - 2019-06-06 04:44:23 --> Security Class Initialized
DEBUG - 2019-06-06 04:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 04:44:23 --> Input Class Initialized
INFO - 2019-06-06 04:44:23 --> Language Class Initialized
INFO - 2019-06-06 04:44:23 --> Language Class Initialized
INFO - 2019-06-06 04:44:23 --> Config Class Initialized
INFO - 2019-06-06 04:44:23 --> Loader Class Initialized
INFO - 2019-06-06 04:44:23 --> Helper loaded: form_helper
INFO - 2019-06-06 04:44:23 --> Helper loaded: url_helper
INFO - 2019-06-06 04:44:23 --> Helper loaded: cookie_helper
INFO - 2019-06-06 04:44:23 --> Database Driver Class Initialized
DEBUG - 2019-06-06 04:44:23 --> Template library initialized
INFO - 2019-06-06 04:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-06 04:44:23 --> Controller Class Initialized
DEBUG - 2019-06-06 04:44:23 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-06 04:44:23 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
ERROR - 2019-06-06 04:44:23 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 04:44:23 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 04:44:23 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 04:44:23 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 04:44:23 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 04:44:23 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 04:44:23 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 04:44:23 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 04:44:23 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 04:44:23 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 04:44:23 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 04:44:23 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 04:44:23 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 04:44:23 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 04:44:23 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 04:44:23 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 04:44:23 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 04:44:23 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 04:44:23 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 04:44:23 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 04:44:23 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 04:44:23 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
DEBUG - 2019-06-06 04:44:23 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-06 04:44:23 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-06 04:44:23 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-06 04:44:23 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-06 04:44:23 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-06 04:44:24 --> Final output sent to browser
DEBUG - 2019-06-06 04:44:24 --> Total execution time: 0.0722
INFO - 2019-06-06 04:44:26 --> Config Class Initialized
INFO - 2019-06-06 04:44:26 --> Hooks Class Initialized
DEBUG - 2019-06-06 04:44:26 --> UTF-8 Support Enabled
INFO - 2019-06-06 04:44:26 --> Utf8 Class Initialized
INFO - 2019-06-06 04:44:26 --> URI Class Initialized
INFO - 2019-06-06 04:44:26 --> Router Class Initialized
INFO - 2019-06-06 04:44:26 --> Output Class Initialized
INFO - 2019-06-06 04:44:26 --> Security Class Initialized
DEBUG - 2019-06-06 04:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 04:44:26 --> Input Class Initialized
INFO - 2019-06-06 04:44:26 --> Language Class Initialized
ERROR - 2019-06-06 04:44:26 --> 404 Page Not Found: /index
INFO - 2019-06-06 04:44:26 --> Config Class Initialized
INFO - 2019-06-06 04:44:26 --> Hooks Class Initialized
DEBUG - 2019-06-06 04:44:26 --> UTF-8 Support Enabled
INFO - 2019-06-06 04:44:26 --> Utf8 Class Initialized
INFO - 2019-06-06 04:44:26 --> URI Class Initialized
INFO - 2019-06-06 04:44:26 --> Router Class Initialized
INFO - 2019-06-06 04:44:26 --> Output Class Initialized
INFO - 2019-06-06 04:44:26 --> Security Class Initialized
DEBUG - 2019-06-06 04:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 04:44:26 --> Input Class Initialized
INFO - 2019-06-06 04:44:26 --> Language Class Initialized
ERROR - 2019-06-06 04:44:26 --> 404 Page Not Found: /index
INFO - 2019-06-06 04:44:27 --> Config Class Initialized
INFO - 2019-06-06 04:44:27 --> Hooks Class Initialized
DEBUG - 2019-06-06 04:44:27 --> UTF-8 Support Enabled
INFO - 2019-06-06 04:44:27 --> Utf8 Class Initialized
INFO - 2019-06-06 04:44:27 --> URI Class Initialized
INFO - 2019-06-06 04:44:27 --> Router Class Initialized
INFO - 2019-06-06 04:44:27 --> Output Class Initialized
INFO - 2019-06-06 04:44:27 --> Security Class Initialized
DEBUG - 2019-06-06 04:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 04:44:27 --> Input Class Initialized
INFO - 2019-06-06 04:44:27 --> Language Class Initialized
ERROR - 2019-06-06 04:44:27 --> 404 Page Not Found: /index
INFO - 2019-06-06 04:44:27 --> Config Class Initialized
INFO - 2019-06-06 04:44:27 --> Hooks Class Initialized
DEBUG - 2019-06-06 04:44:27 --> UTF-8 Support Enabled
INFO - 2019-06-06 04:44:27 --> Utf8 Class Initialized
INFO - 2019-06-06 04:44:27 --> URI Class Initialized
INFO - 2019-06-06 04:44:27 --> Router Class Initialized
INFO - 2019-06-06 04:44:27 --> Output Class Initialized
INFO - 2019-06-06 04:44:27 --> Security Class Initialized
DEBUG - 2019-06-06 04:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 04:44:27 --> Input Class Initialized
INFO - 2019-06-06 04:44:27 --> Language Class Initialized
ERROR - 2019-06-06 04:44:27 --> 404 Page Not Found: /index
INFO - 2019-06-06 04:44:28 --> Config Class Initialized
INFO - 2019-06-06 04:44:28 --> Hooks Class Initialized
DEBUG - 2019-06-06 04:44:28 --> UTF-8 Support Enabled
INFO - 2019-06-06 04:44:28 --> Utf8 Class Initialized
INFO - 2019-06-06 04:44:28 --> URI Class Initialized
INFO - 2019-06-06 04:44:28 --> Router Class Initialized
INFO - 2019-06-06 04:44:28 --> Output Class Initialized
INFO - 2019-06-06 04:44:28 --> Security Class Initialized
DEBUG - 2019-06-06 04:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 04:44:28 --> Input Class Initialized
INFO - 2019-06-06 04:44:28 --> Language Class Initialized
ERROR - 2019-06-06 04:44:28 --> 404 Page Not Found: /index
INFO - 2019-06-06 04:44:28 --> Config Class Initialized
INFO - 2019-06-06 04:44:28 --> Hooks Class Initialized
DEBUG - 2019-06-06 04:44:28 --> UTF-8 Support Enabled
INFO - 2019-06-06 04:44:28 --> Utf8 Class Initialized
INFO - 2019-06-06 04:44:28 --> URI Class Initialized
INFO - 2019-06-06 04:44:28 --> Router Class Initialized
INFO - 2019-06-06 04:44:28 --> Output Class Initialized
INFO - 2019-06-06 04:44:28 --> Security Class Initialized
DEBUG - 2019-06-06 04:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 04:44:28 --> Input Class Initialized
INFO - 2019-06-06 04:44:28 --> Language Class Initialized
ERROR - 2019-06-06 04:44:28 --> 404 Page Not Found: /index
INFO - 2019-06-06 04:44:29 --> Config Class Initialized
INFO - 2019-06-06 04:44:29 --> Hooks Class Initialized
DEBUG - 2019-06-06 04:44:29 --> UTF-8 Support Enabled
INFO - 2019-06-06 04:44:29 --> Utf8 Class Initialized
INFO - 2019-06-06 04:44:29 --> URI Class Initialized
INFO - 2019-06-06 04:44:29 --> Router Class Initialized
INFO - 2019-06-06 04:44:29 --> Output Class Initialized
INFO - 2019-06-06 04:44:29 --> Security Class Initialized
DEBUG - 2019-06-06 04:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 04:44:29 --> Input Class Initialized
INFO - 2019-06-06 04:44:29 --> Language Class Initialized
ERROR - 2019-06-06 04:44:29 --> 404 Page Not Found: /index
INFO - 2019-06-06 04:44:29 --> Config Class Initialized
INFO - 2019-06-06 04:44:29 --> Hooks Class Initialized
DEBUG - 2019-06-06 04:44:29 --> UTF-8 Support Enabled
INFO - 2019-06-06 04:44:29 --> Utf8 Class Initialized
INFO - 2019-06-06 04:44:29 --> URI Class Initialized
INFO - 2019-06-06 04:44:29 --> Router Class Initialized
INFO - 2019-06-06 04:44:29 --> Output Class Initialized
INFO - 2019-06-06 04:44:29 --> Security Class Initialized
DEBUG - 2019-06-06 04:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 04:44:29 --> Input Class Initialized
INFO - 2019-06-06 04:44:29 --> Language Class Initialized
ERROR - 2019-06-06 04:44:29 --> 404 Page Not Found: /index
INFO - 2019-06-06 04:44:30 --> Config Class Initialized
INFO - 2019-06-06 04:44:30 --> Hooks Class Initialized
DEBUG - 2019-06-06 04:44:30 --> UTF-8 Support Enabled
INFO - 2019-06-06 04:44:30 --> Utf8 Class Initialized
INFO - 2019-06-06 04:44:30 --> URI Class Initialized
INFO - 2019-06-06 04:44:30 --> Router Class Initialized
INFO - 2019-06-06 04:44:30 --> Output Class Initialized
INFO - 2019-06-06 04:44:30 --> Security Class Initialized
DEBUG - 2019-06-06 04:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 04:44:30 --> Input Class Initialized
INFO - 2019-06-06 04:44:30 --> Language Class Initialized
ERROR - 2019-06-06 04:44:30 --> 404 Page Not Found: /index
INFO - 2019-06-06 04:44:30 --> Config Class Initialized
INFO - 2019-06-06 04:44:30 --> Hooks Class Initialized
DEBUG - 2019-06-06 04:44:30 --> UTF-8 Support Enabled
INFO - 2019-06-06 04:44:30 --> Utf8 Class Initialized
INFO - 2019-06-06 04:44:30 --> URI Class Initialized
INFO - 2019-06-06 04:44:30 --> Router Class Initialized
INFO - 2019-06-06 04:44:30 --> Output Class Initialized
INFO - 2019-06-06 04:44:30 --> Security Class Initialized
DEBUG - 2019-06-06 04:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 04:44:30 --> Input Class Initialized
INFO - 2019-06-06 04:44:30 --> Language Class Initialized
ERROR - 2019-06-06 04:44:30 --> 404 Page Not Found: /index
INFO - 2019-06-06 04:44:30 --> Config Class Initialized
INFO - 2019-06-06 04:44:30 --> Hooks Class Initialized
DEBUG - 2019-06-06 04:44:30 --> UTF-8 Support Enabled
INFO - 2019-06-06 04:44:30 --> Utf8 Class Initialized
INFO - 2019-06-06 04:44:30 --> URI Class Initialized
INFO - 2019-06-06 04:44:30 --> Router Class Initialized
INFO - 2019-06-06 04:44:30 --> Output Class Initialized
INFO - 2019-06-06 04:44:30 --> Security Class Initialized
DEBUG - 2019-06-06 04:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 04:44:30 --> Input Class Initialized
INFO - 2019-06-06 04:44:30 --> Language Class Initialized
ERROR - 2019-06-06 04:44:30 --> 404 Page Not Found: /index
INFO - 2019-06-06 04:44:31 --> Config Class Initialized
INFO - 2019-06-06 04:44:31 --> Hooks Class Initialized
DEBUG - 2019-06-06 04:44:31 --> UTF-8 Support Enabled
INFO - 2019-06-06 04:44:31 --> Utf8 Class Initialized
INFO - 2019-06-06 04:44:31 --> URI Class Initialized
INFO - 2019-06-06 04:44:31 --> Router Class Initialized
INFO - 2019-06-06 04:44:31 --> Output Class Initialized
INFO - 2019-06-06 04:44:31 --> Security Class Initialized
DEBUG - 2019-06-06 04:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 04:44:31 --> Input Class Initialized
INFO - 2019-06-06 04:44:31 --> Language Class Initialized
ERROR - 2019-06-06 04:44:31 --> 404 Page Not Found: /index
INFO - 2019-06-06 06:47:22 --> Config Class Initialized
INFO - 2019-06-06 06:47:22 --> Hooks Class Initialized
DEBUG - 2019-06-06 06:47:22 --> UTF-8 Support Enabled
INFO - 2019-06-06 06:47:22 --> Utf8 Class Initialized
INFO - 2019-06-06 06:47:22 --> URI Class Initialized
INFO - 2019-06-06 06:47:22 --> Router Class Initialized
INFO - 2019-06-06 06:47:22 --> Output Class Initialized
INFO - 2019-06-06 06:47:22 --> Security Class Initialized
DEBUG - 2019-06-06 06:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 06:47:22 --> Input Class Initialized
INFO - 2019-06-06 06:47:22 --> Language Class Initialized
INFO - 2019-06-06 06:47:22 --> Language Class Initialized
INFO - 2019-06-06 06:47:22 --> Config Class Initialized
INFO - 2019-06-06 06:47:22 --> Loader Class Initialized
INFO - 2019-06-06 06:47:22 --> Helper loaded: form_helper
INFO - 2019-06-06 06:47:22 --> Helper loaded: url_helper
INFO - 2019-06-06 06:47:22 --> Helper loaded: cookie_helper
INFO - 2019-06-06 06:47:22 --> Database Driver Class Initialized
DEBUG - 2019-06-06 06:47:22 --> Template library initialized
INFO - 2019-06-06 06:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-06 06:47:22 --> Controller Class Initialized
DEBUG - 2019-06-06 06:47:22 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-06 06:47:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-06-06 06:47:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/pay-casino.php
DEBUG - 2019-06-06 06:47:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-06 06:47:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-06 06:47:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-06 06:47:22 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-06 06:47:22 --> Final output sent to browser
DEBUG - 2019-06-06 06:47:22 --> Total execution time: 0.0494
INFO - 2019-06-06 06:47:47 --> Config Class Initialized
INFO - 2019-06-06 06:47:47 --> Hooks Class Initialized
DEBUG - 2019-06-06 06:47:47 --> UTF-8 Support Enabled
INFO - 2019-06-06 06:47:47 --> Utf8 Class Initialized
INFO - 2019-06-06 06:47:47 --> URI Class Initialized
INFO - 2019-06-06 06:47:47 --> Router Class Initialized
INFO - 2019-06-06 06:47:47 --> Output Class Initialized
INFO - 2019-06-06 06:47:47 --> Security Class Initialized
DEBUG - 2019-06-06 06:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 06:47:47 --> Input Class Initialized
INFO - 2019-06-06 06:47:47 --> Language Class Initialized
ERROR - 2019-06-06 06:47:47 --> 404 Page Not Found: /index
INFO - 2019-06-06 06:47:51 --> Config Class Initialized
INFO - 2019-06-06 06:47:51 --> Hooks Class Initialized
DEBUG - 2019-06-06 06:47:51 --> UTF-8 Support Enabled
INFO - 2019-06-06 06:47:51 --> Utf8 Class Initialized
INFO - 2019-06-06 06:47:51 --> URI Class Initialized
DEBUG - 2019-06-06 06:47:51 --> No URI present. Default controller set.
INFO - 2019-06-06 06:47:51 --> Router Class Initialized
INFO - 2019-06-06 06:47:51 --> Output Class Initialized
INFO - 2019-06-06 06:47:51 --> Security Class Initialized
DEBUG - 2019-06-06 06:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 06:47:51 --> Input Class Initialized
INFO - 2019-06-06 06:47:51 --> Language Class Initialized
INFO - 2019-06-06 06:47:51 --> Language Class Initialized
INFO - 2019-06-06 06:47:51 --> Config Class Initialized
INFO - 2019-06-06 06:47:51 --> Loader Class Initialized
INFO - 2019-06-06 06:47:51 --> Helper loaded: form_helper
INFO - 2019-06-06 06:47:51 --> Helper loaded: url_helper
INFO - 2019-06-06 06:47:51 --> Helper loaded: cookie_helper
INFO - 2019-06-06 06:47:51 --> Database Driver Class Initialized
DEBUG - 2019-06-06 06:47:51 --> Template library initialized
INFO - 2019-06-06 06:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-06 06:47:51 --> Controller Class Initialized
DEBUG - 2019-06-06 06:47:51 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-06 06:47:51 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
ERROR - 2019-06-06 06:47:51 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:47:51 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:47:51 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:47:51 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:47:51 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:47:51 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:47:51 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:47:51 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:47:51 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:47:51 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:47:51 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:47:51 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:47:51 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:47:51 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:47:51 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:47:51 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:47:51 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:47:51 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:47:51 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:47:51 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:47:51 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:47:51 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
DEBUG - 2019-06-06 06:47:51 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-06 06:47:51 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-06 06:47:51 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-06 06:47:51 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-06 06:47:51 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-06 06:47:52 --> Final output sent to browser
DEBUG - 2019-06-06 06:47:52 --> Total execution time: 0.0689
INFO - 2019-06-06 06:48:15 --> Config Class Initialized
INFO - 2019-06-06 06:48:15 --> Hooks Class Initialized
DEBUG - 2019-06-06 06:48:15 --> UTF-8 Support Enabled
INFO - 2019-06-06 06:48:15 --> Utf8 Class Initialized
INFO - 2019-06-06 06:48:15 --> URI Class Initialized
INFO - 2019-06-06 06:48:15 --> Config Class Initialized
INFO - 2019-06-06 06:48:15 --> Hooks Class Initialized
DEBUG - 2019-06-06 06:48:15 --> UTF-8 Support Enabled
INFO - 2019-06-06 06:48:15 --> Utf8 Class Initialized
INFO - 2019-06-06 06:48:15 --> URI Class Initialized
INFO - 2019-06-06 06:48:15 --> Router Class Initialized
INFO - 2019-06-06 06:48:15 --> Router Class Initialized
INFO - 2019-06-06 06:48:15 --> Output Class Initialized
INFO - 2019-06-06 06:48:15 --> Security Class Initialized
DEBUG - 2019-06-06 06:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 06:48:15 --> Input Class Initialized
INFO - 2019-06-06 06:48:15 --> Language Class Initialized
ERROR - 2019-06-06 06:48:15 --> 404 Page Not Found: /index
INFO - 2019-06-06 06:48:15 --> Output Class Initialized
INFO - 2019-06-06 06:48:15 --> Security Class Initialized
DEBUG - 2019-06-06 06:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 06:48:15 --> Input Class Initialized
INFO - 2019-06-06 06:48:15 --> Language Class Initialized
ERROR - 2019-06-06 06:48:15 --> 404 Page Not Found: /index
INFO - 2019-06-06 06:48:15 --> Config Class Initialized
INFO - 2019-06-06 06:48:15 --> Hooks Class Initialized
DEBUG - 2019-06-06 06:48:15 --> UTF-8 Support Enabled
INFO - 2019-06-06 06:48:15 --> Utf8 Class Initialized
INFO - 2019-06-06 06:48:15 --> URI Class Initialized
INFO - 2019-06-06 06:48:15 --> Router Class Initialized
INFO - 2019-06-06 06:48:15 --> Output Class Initialized
INFO - 2019-06-06 06:48:15 --> Security Class Initialized
DEBUG - 2019-06-06 06:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 06:48:15 --> Input Class Initialized
INFO - 2019-06-06 06:48:15 --> Language Class Initialized
ERROR - 2019-06-06 06:48:15 --> 404 Page Not Found: /index
INFO - 2019-06-06 06:51:30 --> Config Class Initialized
INFO - 2019-06-06 06:51:30 --> Hooks Class Initialized
DEBUG - 2019-06-06 06:51:30 --> UTF-8 Support Enabled
INFO - 2019-06-06 06:51:30 --> Utf8 Class Initialized
INFO - 2019-06-06 06:51:30 --> URI Class Initialized
DEBUG - 2019-06-06 06:51:30 --> No URI present. Default controller set.
INFO - 2019-06-06 06:51:30 --> Router Class Initialized
INFO - 2019-06-06 06:51:30 --> Output Class Initialized
INFO - 2019-06-06 06:51:30 --> Security Class Initialized
DEBUG - 2019-06-06 06:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 06:51:30 --> Input Class Initialized
INFO - 2019-06-06 06:51:30 --> Language Class Initialized
INFO - 2019-06-06 06:51:30 --> Language Class Initialized
INFO - 2019-06-06 06:51:30 --> Config Class Initialized
INFO - 2019-06-06 06:51:30 --> Loader Class Initialized
INFO - 2019-06-06 06:51:30 --> Helper loaded: form_helper
INFO - 2019-06-06 06:51:30 --> Helper loaded: url_helper
INFO - 2019-06-06 06:51:30 --> Helper loaded: cookie_helper
INFO - 2019-06-06 06:51:30 --> Database Driver Class Initialized
DEBUG - 2019-06-06 06:51:30 --> Template library initialized
INFO - 2019-06-06 06:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-06 06:51:30 --> Controller Class Initialized
DEBUG - 2019-06-06 06:51:30 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-06 06:51:30 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
ERROR - 2019-06-06 06:51:30 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:51:30 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:51:30 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:51:30 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:51:30 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:51:30 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:51:30 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:51:30 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:51:30 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:51:30 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:51:30 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:51:30 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:51:30 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:51:30 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:51:30 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:51:30 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:51:30 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:51:30 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:51:30 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:51:30 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:51:30 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 06:51:30 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
DEBUG - 2019-06-06 06:51:30 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-06 06:51:30 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-06 06:51:30 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-06 06:51:30 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-06 06:51:30 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-06 06:51:30 --> Final output sent to browser
DEBUG - 2019-06-06 06:51:30 --> Total execution time: 0.0650
INFO - 2019-06-06 09:44:32 --> Config Class Initialized
INFO - 2019-06-06 09:44:32 --> Hooks Class Initialized
DEBUG - 2019-06-06 09:44:32 --> UTF-8 Support Enabled
INFO - 2019-06-06 09:44:32 --> Utf8 Class Initialized
INFO - 2019-06-06 09:44:32 --> URI Class Initialized
DEBUG - 2019-06-06 09:44:32 --> No URI present. Default controller set.
INFO - 2019-06-06 09:44:32 --> Router Class Initialized
INFO - 2019-06-06 09:44:32 --> Output Class Initialized
INFO - 2019-06-06 09:44:32 --> Security Class Initialized
DEBUG - 2019-06-06 09:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 09:44:32 --> Input Class Initialized
INFO - 2019-06-06 09:44:32 --> Language Class Initialized
INFO - 2019-06-06 09:44:32 --> Language Class Initialized
INFO - 2019-06-06 09:44:32 --> Config Class Initialized
INFO - 2019-06-06 09:44:32 --> Loader Class Initialized
INFO - 2019-06-06 09:44:32 --> Helper loaded: form_helper
INFO - 2019-06-06 09:44:32 --> Helper loaded: url_helper
INFO - 2019-06-06 09:44:32 --> Helper loaded: cookie_helper
INFO - 2019-06-06 09:44:32 --> Database Driver Class Initialized
DEBUG - 2019-06-06 09:44:32 --> Template library initialized
INFO - 2019-06-06 09:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-06 09:44:32 --> Controller Class Initialized
DEBUG - 2019-06-06 09:44:32 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-06 09:44:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
ERROR - 2019-06-06 09:44:32 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 09:44:32 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 09:44:32 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 09:44:32 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 09:44:32 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 09:44:32 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 09:44:32 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 09:44:32 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 09:44:32 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 09:44:32 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 09:44:32 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 09:44:32 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 09:44:32 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 09:44:32 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 09:44:32 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 09:44:32 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 09:44:32 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 09:44:32 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 09:44:32 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 09:44:32 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 09:44:32 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 09:44:32 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
DEBUG - 2019-06-06 09:44:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-06 09:44:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-06 09:44:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-06 09:44:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-06 09:44:32 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-06 09:44:33 --> Final output sent to browser
DEBUG - 2019-06-06 09:44:33 --> Total execution time: 0.0656
INFO - 2019-06-06 12:29:37 --> Config Class Initialized
INFO - 2019-06-06 12:29:37 --> Hooks Class Initialized
DEBUG - 2019-06-06 12:29:37 --> UTF-8 Support Enabled
INFO - 2019-06-06 12:29:37 --> Utf8 Class Initialized
INFO - 2019-06-06 12:29:37 --> URI Class Initialized
DEBUG - 2019-06-06 12:29:37 --> No URI present. Default controller set.
INFO - 2019-06-06 12:29:37 --> Router Class Initialized
INFO - 2019-06-06 12:29:37 --> Output Class Initialized
INFO - 2019-06-06 12:29:37 --> Security Class Initialized
DEBUG - 2019-06-06 12:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 12:29:37 --> Input Class Initialized
INFO - 2019-06-06 12:29:37 --> Language Class Initialized
INFO - 2019-06-06 12:29:37 --> Language Class Initialized
INFO - 2019-06-06 12:29:37 --> Config Class Initialized
INFO - 2019-06-06 12:29:37 --> Loader Class Initialized
INFO - 2019-06-06 12:29:37 --> Helper loaded: form_helper
INFO - 2019-06-06 12:29:37 --> Helper loaded: url_helper
INFO - 2019-06-06 12:29:37 --> Helper loaded: cookie_helper
INFO - 2019-06-06 12:29:37 --> Database Driver Class Initialized
DEBUG - 2019-06-06 12:29:37 --> Template library initialized
INFO - 2019-06-06 12:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-06 12:29:37 --> Controller Class Initialized
DEBUG - 2019-06-06 12:29:37 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-06 12:29:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
ERROR - 2019-06-06 12:29:37 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:37 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:37 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:37 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:37 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:37 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:37 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:37 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:37 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:37 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:37 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:37 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:37 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:37 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:37 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:37 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:37 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:37 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:37 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:37 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:37 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:37 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
DEBUG - 2019-06-06 12:29:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-06 12:29:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-06 12:29:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-06 12:29:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-06 12:29:37 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-06 12:29:37 --> Final output sent to browser
DEBUG - 2019-06-06 12:29:37 --> Total execution time: 0.0717
INFO - 2019-06-06 12:29:38 --> Config Class Initialized
INFO - 2019-06-06 12:29:38 --> Hooks Class Initialized
DEBUG - 2019-06-06 12:29:38 --> UTF-8 Support Enabled
INFO - 2019-06-06 12:29:38 --> Utf8 Class Initialized
INFO - 2019-06-06 12:29:38 --> URI Class Initialized
DEBUG - 2019-06-06 12:29:38 --> No URI present. Default controller set.
INFO - 2019-06-06 12:29:38 --> Router Class Initialized
INFO - 2019-06-06 12:29:38 --> Output Class Initialized
INFO - 2019-06-06 12:29:38 --> Security Class Initialized
DEBUG - 2019-06-06 12:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 12:29:38 --> Input Class Initialized
INFO - 2019-06-06 12:29:38 --> Language Class Initialized
INFO - 2019-06-06 12:29:38 --> Language Class Initialized
INFO - 2019-06-06 12:29:38 --> Config Class Initialized
INFO - 2019-06-06 12:29:38 --> Loader Class Initialized
INFO - 2019-06-06 12:29:38 --> Helper loaded: form_helper
INFO - 2019-06-06 12:29:38 --> Helper loaded: url_helper
INFO - 2019-06-06 12:29:38 --> Helper loaded: cookie_helper
INFO - 2019-06-06 12:29:38 --> Database Driver Class Initialized
DEBUG - 2019-06-06 12:29:38 --> Template library initialized
INFO - 2019-06-06 12:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-06 12:29:38 --> Controller Class Initialized
DEBUG - 2019-06-06 12:29:38 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-06 12:29:38 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
ERROR - 2019-06-06 12:29:38 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:38 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:38 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:38 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:38 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:38 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:38 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:38 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:38 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:38 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:38 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:38 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:38 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:38 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:38 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:38 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:38 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:38 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:38 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:38 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:38 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:38 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
DEBUG - 2019-06-06 12:29:38 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-06 12:29:38 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-06 12:29:38 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-06 12:29:38 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-06 12:29:38 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-06 12:29:38 --> Final output sent to browser
DEBUG - 2019-06-06 12:29:38 --> Total execution time: 0.0651
INFO - 2019-06-06 12:29:52 --> Config Class Initialized
INFO - 2019-06-06 12:29:52 --> Hooks Class Initialized
DEBUG - 2019-06-06 12:29:52 --> UTF-8 Support Enabled
INFO - 2019-06-06 12:29:52 --> Utf8 Class Initialized
INFO - 2019-06-06 12:29:52 --> URI Class Initialized
DEBUG - 2019-06-06 12:29:52 --> No URI present. Default controller set.
INFO - 2019-06-06 12:29:52 --> Router Class Initialized
INFO - 2019-06-06 12:29:52 --> Output Class Initialized
INFO - 2019-06-06 12:29:52 --> Security Class Initialized
DEBUG - 2019-06-06 12:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 12:29:52 --> Input Class Initialized
INFO - 2019-06-06 12:29:52 --> Language Class Initialized
INFO - 2019-06-06 12:29:52 --> Language Class Initialized
INFO - 2019-06-06 12:29:52 --> Config Class Initialized
INFO - 2019-06-06 12:29:52 --> Loader Class Initialized
INFO - 2019-06-06 12:29:52 --> Helper loaded: form_helper
INFO - 2019-06-06 12:29:52 --> Helper loaded: url_helper
INFO - 2019-06-06 12:29:52 --> Helper loaded: cookie_helper
INFO - 2019-06-06 12:29:52 --> Database Driver Class Initialized
DEBUG - 2019-06-06 12:29:52 --> Template library initialized
INFO - 2019-06-06 12:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-06 12:29:52 --> Controller Class Initialized
DEBUG - 2019-06-06 12:29:52 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-06 12:29:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
ERROR - 2019-06-06 12:29:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 12:29:52 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
DEBUG - 2019-06-06 12:29:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-06 12:29:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-06 12:29:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-06 12:29:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-06 12:29:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-06 12:29:52 --> Final output sent to browser
DEBUG - 2019-06-06 12:29:52 --> Total execution time: 0.0850
INFO - 2019-06-06 16:49:05 --> Config Class Initialized
INFO - 2019-06-06 16:49:05 --> Hooks Class Initialized
DEBUG - 2019-06-06 16:49:05 --> UTF-8 Support Enabled
INFO - 2019-06-06 16:49:05 --> Utf8 Class Initialized
INFO - 2019-06-06 16:49:05 --> URI Class Initialized
DEBUG - 2019-06-06 16:49:05 --> No URI present. Default controller set.
INFO - 2019-06-06 16:49:05 --> Router Class Initialized
INFO - 2019-06-06 16:49:05 --> Output Class Initialized
INFO - 2019-06-06 16:49:05 --> Security Class Initialized
DEBUG - 2019-06-06 16:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 16:49:05 --> Input Class Initialized
INFO - 2019-06-06 16:49:05 --> Language Class Initialized
INFO - 2019-06-06 16:49:05 --> Language Class Initialized
INFO - 2019-06-06 16:49:05 --> Config Class Initialized
INFO - 2019-06-06 16:49:05 --> Loader Class Initialized
INFO - 2019-06-06 16:49:05 --> Helper loaded: form_helper
INFO - 2019-06-06 16:49:05 --> Helper loaded: url_helper
INFO - 2019-06-06 16:49:05 --> Helper loaded: cookie_helper
INFO - 2019-06-06 16:49:05 --> Database Driver Class Initialized
DEBUG - 2019-06-06 16:49:05 --> Template library initialized
INFO - 2019-06-06 16:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-06 16:49:05 --> Controller Class Initialized
DEBUG - 2019-06-06 16:49:05 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-06 16:49:05 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
ERROR - 2019-06-06 16:49:05 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 16:49:05 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 16:49:05 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 16:49:05 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 16:49:05 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 16:49:05 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 16:49:05 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 16:49:05 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 16:49:05 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 16:49:05 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 16:49:05 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 16:49:05 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 16:49:05 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 16:49:05 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 16:49:05 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 16:49:05 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 16:49:05 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 16:49:05 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 16:49:05 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 16:49:05 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 16:49:05 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-06 16:49:05 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
DEBUG - 2019-06-06 16:49:05 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-06 16:49:05 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-06 16:49:05 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-06 16:49:05 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-06 16:49:05 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-06 16:49:06 --> Final output sent to browser
DEBUG - 2019-06-06 16:49:06 --> Total execution time: 0.0756
INFO - 2019-06-06 16:49:07 --> Config Class Initialized
INFO - 2019-06-06 16:49:07 --> Hooks Class Initialized
DEBUG - 2019-06-06 16:49:07 --> UTF-8 Support Enabled
INFO - 2019-06-06 16:49:07 --> Utf8 Class Initialized
INFO - 2019-06-06 16:49:07 --> URI Class Initialized
INFO - 2019-06-06 16:49:07 --> Router Class Initialized
INFO - 2019-06-06 16:49:07 --> Output Class Initialized
INFO - 2019-06-06 16:49:07 --> Security Class Initialized
DEBUG - 2019-06-06 16:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 16:49:07 --> Input Class Initialized
INFO - 2019-06-06 16:49:07 --> Language Class Initialized
ERROR - 2019-06-06 16:49:07 --> 404 Page Not Found: /index
INFO - 2019-06-06 16:49:07 --> Config Class Initialized
INFO - 2019-06-06 16:49:07 --> Hooks Class Initialized
DEBUG - 2019-06-06 16:49:07 --> UTF-8 Support Enabled
INFO - 2019-06-06 16:49:07 --> Utf8 Class Initialized
INFO - 2019-06-06 16:49:07 --> URI Class Initialized
INFO - 2019-06-06 16:49:07 --> Router Class Initialized
INFO - 2019-06-06 16:49:07 --> Output Class Initialized
INFO - 2019-06-06 16:49:07 --> Security Class Initialized
DEBUG - 2019-06-06 16:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 16:49:07 --> Input Class Initialized
INFO - 2019-06-06 16:49:07 --> Language Class Initialized
ERROR - 2019-06-06 16:49:07 --> 404 Page Not Found: /index
INFO - 2019-06-06 16:49:07 --> Config Class Initialized
INFO - 2019-06-06 16:49:07 --> Hooks Class Initialized
DEBUG - 2019-06-06 16:49:07 --> UTF-8 Support Enabled
INFO - 2019-06-06 16:49:07 --> Utf8 Class Initialized
INFO - 2019-06-06 16:49:07 --> URI Class Initialized
INFO - 2019-06-06 16:49:07 --> Router Class Initialized
INFO - 2019-06-06 16:49:07 --> Output Class Initialized
INFO - 2019-06-06 16:49:07 --> Security Class Initialized
DEBUG - 2019-06-06 16:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 16:49:07 --> Input Class Initialized
INFO - 2019-06-06 16:49:07 --> Language Class Initialized
ERROR - 2019-06-06 16:49:07 --> 404 Page Not Found: /index
INFO - 2019-06-06 16:49:07 --> Config Class Initialized
INFO - 2019-06-06 16:49:07 --> Hooks Class Initialized
DEBUG - 2019-06-06 16:49:07 --> UTF-8 Support Enabled
INFO - 2019-06-06 16:49:07 --> Utf8 Class Initialized
INFO - 2019-06-06 16:49:07 --> URI Class Initialized
INFO - 2019-06-06 16:49:07 --> Router Class Initialized
INFO - 2019-06-06 16:49:07 --> Output Class Initialized
INFO - 2019-06-06 16:49:07 --> Security Class Initialized
DEBUG - 2019-06-06 16:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 16:49:07 --> Input Class Initialized
INFO - 2019-06-06 16:49:07 --> Language Class Initialized
ERROR - 2019-06-06 16:49:07 --> 404 Page Not Found: /index
INFO - 2019-06-06 16:49:08 --> Config Class Initialized
INFO - 2019-06-06 16:49:08 --> Hooks Class Initialized
DEBUG - 2019-06-06 16:49:08 --> UTF-8 Support Enabled
INFO - 2019-06-06 16:49:08 --> Utf8 Class Initialized
INFO - 2019-06-06 16:49:08 --> URI Class Initialized
INFO - 2019-06-06 16:49:08 --> Router Class Initialized
INFO - 2019-06-06 16:49:08 --> Output Class Initialized
INFO - 2019-06-06 16:49:08 --> Security Class Initialized
DEBUG - 2019-06-06 16:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 16:49:08 --> Input Class Initialized
INFO - 2019-06-06 16:49:08 --> Language Class Initialized
ERROR - 2019-06-06 16:49:08 --> 404 Page Not Found: /index
INFO - 2019-06-06 16:49:08 --> Config Class Initialized
INFO - 2019-06-06 16:49:08 --> Hooks Class Initialized
DEBUG - 2019-06-06 16:49:08 --> UTF-8 Support Enabled
INFO - 2019-06-06 16:49:08 --> Utf8 Class Initialized
INFO - 2019-06-06 16:49:08 --> URI Class Initialized
INFO - 2019-06-06 16:49:08 --> Router Class Initialized
INFO - 2019-06-06 16:49:08 --> Output Class Initialized
INFO - 2019-06-06 16:49:08 --> Security Class Initialized
DEBUG - 2019-06-06 16:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 16:49:08 --> Input Class Initialized
INFO - 2019-06-06 16:49:08 --> Language Class Initialized
ERROR - 2019-06-06 16:49:08 --> 404 Page Not Found: /index
INFO - 2019-06-06 16:49:08 --> Config Class Initialized
INFO - 2019-06-06 16:49:08 --> Hooks Class Initialized
DEBUG - 2019-06-06 16:49:08 --> UTF-8 Support Enabled
INFO - 2019-06-06 16:49:08 --> Utf8 Class Initialized
INFO - 2019-06-06 16:49:08 --> URI Class Initialized
INFO - 2019-06-06 16:49:08 --> Router Class Initialized
INFO - 2019-06-06 16:49:08 --> Output Class Initialized
INFO - 2019-06-06 16:49:08 --> Security Class Initialized
DEBUG - 2019-06-06 16:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 16:49:08 --> Input Class Initialized
INFO - 2019-06-06 16:49:08 --> Language Class Initialized
ERROR - 2019-06-06 16:49:08 --> 404 Page Not Found: /index
INFO - 2019-06-06 16:49:08 --> Config Class Initialized
INFO - 2019-06-06 16:49:08 --> Hooks Class Initialized
DEBUG - 2019-06-06 16:49:08 --> UTF-8 Support Enabled
INFO - 2019-06-06 16:49:08 --> Utf8 Class Initialized
INFO - 2019-06-06 16:49:08 --> URI Class Initialized
INFO - 2019-06-06 16:49:08 --> Router Class Initialized
INFO - 2019-06-06 16:49:08 --> Output Class Initialized
INFO - 2019-06-06 16:49:08 --> Security Class Initialized
DEBUG - 2019-06-06 16:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 16:49:08 --> Input Class Initialized
INFO - 2019-06-06 16:49:08 --> Language Class Initialized
ERROR - 2019-06-06 16:49:08 --> 404 Page Not Found: /index
INFO - 2019-06-06 16:49:09 --> Config Class Initialized
INFO - 2019-06-06 16:49:09 --> Hooks Class Initialized
DEBUG - 2019-06-06 16:49:09 --> UTF-8 Support Enabled
INFO - 2019-06-06 16:49:09 --> Utf8 Class Initialized
INFO - 2019-06-06 16:49:09 --> URI Class Initialized
INFO - 2019-06-06 16:49:09 --> Router Class Initialized
INFO - 2019-06-06 16:49:09 --> Output Class Initialized
INFO - 2019-06-06 16:49:09 --> Security Class Initialized
DEBUG - 2019-06-06 16:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 16:49:09 --> Input Class Initialized
INFO - 2019-06-06 16:49:09 --> Language Class Initialized
ERROR - 2019-06-06 16:49:09 --> 404 Page Not Found: /index
INFO - 2019-06-06 16:49:09 --> Config Class Initialized
INFO - 2019-06-06 16:49:09 --> Hooks Class Initialized
DEBUG - 2019-06-06 16:49:09 --> UTF-8 Support Enabled
INFO - 2019-06-06 16:49:09 --> Utf8 Class Initialized
INFO - 2019-06-06 16:49:09 --> URI Class Initialized
INFO - 2019-06-06 16:49:09 --> Router Class Initialized
INFO - 2019-06-06 16:49:09 --> Output Class Initialized
INFO - 2019-06-06 16:49:09 --> Security Class Initialized
DEBUG - 2019-06-06 16:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 16:49:09 --> Input Class Initialized
INFO - 2019-06-06 16:49:09 --> Language Class Initialized
ERROR - 2019-06-06 16:49:09 --> 404 Page Not Found: /index
INFO - 2019-06-06 16:49:09 --> Config Class Initialized
INFO - 2019-06-06 16:49:09 --> Hooks Class Initialized
DEBUG - 2019-06-06 16:49:09 --> UTF-8 Support Enabled
INFO - 2019-06-06 16:49:09 --> Utf8 Class Initialized
INFO - 2019-06-06 16:49:09 --> URI Class Initialized
INFO - 2019-06-06 16:49:09 --> Router Class Initialized
INFO - 2019-06-06 16:49:09 --> Output Class Initialized
INFO - 2019-06-06 16:49:09 --> Security Class Initialized
DEBUG - 2019-06-06 16:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 16:49:09 --> Input Class Initialized
INFO - 2019-06-06 16:49:09 --> Language Class Initialized
ERROR - 2019-06-06 16:49:09 --> 404 Page Not Found: /index
INFO - 2019-06-06 16:49:09 --> Config Class Initialized
INFO - 2019-06-06 16:49:09 --> Hooks Class Initialized
DEBUG - 2019-06-06 16:49:09 --> UTF-8 Support Enabled
INFO - 2019-06-06 16:49:09 --> Utf8 Class Initialized
INFO - 2019-06-06 16:49:09 --> URI Class Initialized
INFO - 2019-06-06 16:49:09 --> Router Class Initialized
INFO - 2019-06-06 16:49:09 --> Output Class Initialized
INFO - 2019-06-06 16:49:09 --> Security Class Initialized
DEBUG - 2019-06-06 16:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-06 16:49:09 --> Input Class Initialized
INFO - 2019-06-06 16:49:09 --> Language Class Initialized
ERROR - 2019-06-06 16:49:09 --> 404 Page Not Found: /index
