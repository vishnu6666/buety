<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-06-02 06:00:17 --> Config Class Initialized
INFO - 2019-06-02 06:00:17 --> Hooks Class Initialized
DEBUG - 2019-06-02 06:00:17 --> UTF-8 Support Enabled
INFO - 2019-06-02 06:00:17 --> Utf8 Class Initialized
INFO - 2019-06-02 06:00:17 --> URI Class Initialized
DEBUG - 2019-06-02 06:00:17 --> No URI present. Default controller set.
INFO - 2019-06-02 06:00:17 --> Router Class Initialized
INFO - 2019-06-02 06:00:17 --> Output Class Initialized
INFO - 2019-06-02 06:00:17 --> Security Class Initialized
DEBUG - 2019-06-02 06:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-02 06:00:17 --> Input Class Initialized
INFO - 2019-06-02 06:00:17 --> Language Class Initialized
INFO - 2019-06-02 06:00:17 --> Language Class Initialized
INFO - 2019-06-02 06:00:17 --> Config Class Initialized
INFO - 2019-06-02 06:00:17 --> Loader Class Initialized
INFO - 2019-06-02 06:00:17 --> Helper loaded: form_helper
INFO - 2019-06-02 06:00:17 --> Helper loaded: url_helper
INFO - 2019-06-02 06:00:17 --> Helper loaded: cookie_helper
INFO - 2019-06-02 06:00:17 --> Database Driver Class Initialized
DEBUG - 2019-06-02 06:00:17 --> Template library initialized
INFO - 2019-06-02 06:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-02 06:00:17 --> Controller Class Initialized
DEBUG - 2019-06-02 06:00:17 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-02 06:00:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-06-02 06:00:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-02 06:00:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-02 06:00:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-02 06:00:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-02 06:00:17 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-02 06:00:17 --> Final output sent to browser
DEBUG - 2019-06-02 06:00:17 --> Total execution time: 0.0539
INFO - 2019-06-02 06:00:17 --> Config Class Initialized
INFO - 2019-06-02 06:00:17 --> Hooks Class Initialized
DEBUG - 2019-06-02 06:00:17 --> UTF-8 Support Enabled
INFO - 2019-06-02 06:00:17 --> Utf8 Class Initialized
INFO - 2019-06-02 06:00:17 --> URI Class Initialized
INFO - 2019-06-02 06:00:17 --> Router Class Initialized
INFO - 2019-06-02 06:00:17 --> Output Class Initialized
INFO - 2019-06-02 06:00:17 --> Security Class Initialized
DEBUG - 2019-06-02 06:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-02 06:00:17 --> Input Class Initialized
INFO - 2019-06-02 06:00:17 --> Language Class Initialized
ERROR - 2019-06-02 06:00:17 --> 404 Page Not Found: /index
INFO - 2019-06-02 16:50:39 --> Config Class Initialized
INFO - 2019-06-02 16:50:39 --> Hooks Class Initialized
DEBUG - 2019-06-02 16:50:39 --> UTF-8 Support Enabled
INFO - 2019-06-02 16:50:39 --> Utf8 Class Initialized
INFO - 2019-06-02 16:50:39 --> URI Class Initialized
DEBUG - 2019-06-02 16:50:39 --> No URI present. Default controller set.
INFO - 2019-06-02 16:50:39 --> Router Class Initialized
INFO - 2019-06-02 16:50:39 --> Output Class Initialized
INFO - 2019-06-02 16:50:39 --> Security Class Initialized
DEBUG - 2019-06-02 16:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-02 16:50:39 --> Input Class Initialized
INFO - 2019-06-02 16:50:39 --> Language Class Initialized
INFO - 2019-06-02 16:50:39 --> Language Class Initialized
INFO - 2019-06-02 16:50:39 --> Config Class Initialized
INFO - 2019-06-02 16:50:39 --> Loader Class Initialized
INFO - 2019-06-02 16:50:39 --> Helper loaded: form_helper
INFO - 2019-06-02 16:50:39 --> Helper loaded: url_helper
INFO - 2019-06-02 16:50:39 --> Helper loaded: cookie_helper
INFO - 2019-06-02 16:50:39 --> Database Driver Class Initialized
DEBUG - 2019-06-02 16:50:39 --> Template library initialized
INFO - 2019-06-02 16:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-02 16:50:39 --> Controller Class Initialized
DEBUG - 2019-06-02 16:50:39 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-02 16:50:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-06-02 16:50:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-02 16:50:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-02 16:50:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-02 16:50:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-02 16:50:39 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-02 16:50:39 --> Final output sent to browser
DEBUG - 2019-06-02 16:50:39 --> Total execution time: 0.0465
INFO - 2019-06-02 16:50:40 --> Config Class Initialized
INFO - 2019-06-02 16:50:40 --> Hooks Class Initialized
DEBUG - 2019-06-02 16:50:40 --> UTF-8 Support Enabled
INFO - 2019-06-02 16:50:40 --> Utf8 Class Initialized
INFO - 2019-06-02 16:50:40 --> URI Class Initialized
INFO - 2019-06-02 16:50:40 --> Router Class Initialized
INFO - 2019-06-02 16:50:40 --> Output Class Initialized
INFO - 2019-06-02 16:50:40 --> Security Class Initialized
DEBUG - 2019-06-02 16:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-02 16:50:40 --> Input Class Initialized
INFO - 2019-06-02 16:50:40 --> Language Class Initialized
ERROR - 2019-06-02 16:50:40 --> 404 Page Not Found: /index
INFO - 2019-06-02 16:50:40 --> Config Class Initialized
INFO - 2019-06-02 16:50:40 --> Hooks Class Initialized
DEBUG - 2019-06-02 16:50:40 --> UTF-8 Support Enabled
INFO - 2019-06-02 16:50:40 --> Utf8 Class Initialized
INFO - 2019-06-02 16:50:40 --> URI Class Initialized
INFO - 2019-06-02 16:50:40 --> Router Class Initialized
INFO - 2019-06-02 16:50:40 --> Output Class Initialized
INFO - 2019-06-02 16:50:40 --> Security Class Initialized
DEBUG - 2019-06-02 16:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-02 16:50:40 --> Input Class Initialized
INFO - 2019-06-02 16:50:40 --> Language Class Initialized
ERROR - 2019-06-02 16:50:40 --> 404 Page Not Found: /index
INFO - 2019-06-02 16:50:41 --> Config Class Initialized
INFO - 2019-06-02 16:50:41 --> Hooks Class Initialized
DEBUG - 2019-06-02 16:50:41 --> UTF-8 Support Enabled
INFO - 2019-06-02 16:50:41 --> Utf8 Class Initialized
INFO - 2019-06-02 16:50:41 --> URI Class Initialized
INFO - 2019-06-02 16:50:41 --> Router Class Initialized
INFO - 2019-06-02 16:50:41 --> Output Class Initialized
INFO - 2019-06-02 16:50:41 --> Security Class Initialized
DEBUG - 2019-06-02 16:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-02 16:50:41 --> Input Class Initialized
INFO - 2019-06-02 16:50:41 --> Language Class Initialized
ERROR - 2019-06-02 16:50:41 --> 404 Page Not Found: /index
INFO - 2019-06-02 16:50:41 --> Config Class Initialized
INFO - 2019-06-02 16:50:41 --> Hooks Class Initialized
DEBUG - 2019-06-02 16:50:41 --> UTF-8 Support Enabled
INFO - 2019-06-02 16:50:41 --> Utf8 Class Initialized
INFO - 2019-06-02 16:50:41 --> URI Class Initialized
INFO - 2019-06-02 16:50:41 --> Router Class Initialized
INFO - 2019-06-02 16:50:41 --> Output Class Initialized
INFO - 2019-06-02 16:50:41 --> Security Class Initialized
DEBUG - 2019-06-02 16:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-02 16:50:41 --> Input Class Initialized
INFO - 2019-06-02 16:50:41 --> Language Class Initialized
ERROR - 2019-06-02 16:50:41 --> 404 Page Not Found: /index
INFO - 2019-06-02 16:50:41 --> Config Class Initialized
INFO - 2019-06-02 16:50:41 --> Hooks Class Initialized
DEBUG - 2019-06-02 16:50:41 --> UTF-8 Support Enabled
INFO - 2019-06-02 16:50:41 --> Utf8 Class Initialized
INFO - 2019-06-02 16:50:41 --> URI Class Initialized
INFO - 2019-06-02 16:50:41 --> Router Class Initialized
INFO - 2019-06-02 16:50:41 --> Output Class Initialized
INFO - 2019-06-02 16:50:41 --> Security Class Initialized
DEBUG - 2019-06-02 16:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-02 16:50:41 --> Input Class Initialized
INFO - 2019-06-02 16:50:41 --> Language Class Initialized
ERROR - 2019-06-02 16:50:41 --> 404 Page Not Found: /index
INFO - 2019-06-02 16:50:42 --> Config Class Initialized
INFO - 2019-06-02 16:50:42 --> Hooks Class Initialized
DEBUG - 2019-06-02 16:50:42 --> UTF-8 Support Enabled
INFO - 2019-06-02 16:50:42 --> Utf8 Class Initialized
INFO - 2019-06-02 16:50:42 --> URI Class Initialized
INFO - 2019-06-02 16:50:42 --> Router Class Initialized
INFO - 2019-06-02 16:50:42 --> Output Class Initialized
INFO - 2019-06-02 16:50:42 --> Security Class Initialized
DEBUG - 2019-06-02 16:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-02 16:50:42 --> Input Class Initialized
INFO - 2019-06-02 16:50:42 --> Language Class Initialized
ERROR - 2019-06-02 16:50:42 --> 404 Page Not Found: /index
INFO - 2019-06-02 16:50:42 --> Config Class Initialized
INFO - 2019-06-02 16:50:42 --> Hooks Class Initialized
DEBUG - 2019-06-02 16:50:42 --> UTF-8 Support Enabled
INFO - 2019-06-02 16:50:42 --> Utf8 Class Initialized
INFO - 2019-06-02 16:50:42 --> URI Class Initialized
INFO - 2019-06-02 16:50:42 --> Router Class Initialized
INFO - 2019-06-02 16:50:42 --> Output Class Initialized
INFO - 2019-06-02 16:50:42 --> Security Class Initialized
DEBUG - 2019-06-02 16:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-02 16:50:42 --> Input Class Initialized
INFO - 2019-06-02 16:50:42 --> Language Class Initialized
ERROR - 2019-06-02 16:50:42 --> 404 Page Not Found: /index
INFO - 2019-06-02 16:50:42 --> Config Class Initialized
INFO - 2019-06-02 16:50:42 --> Hooks Class Initialized
DEBUG - 2019-06-02 16:50:42 --> UTF-8 Support Enabled
INFO - 2019-06-02 16:50:42 --> Utf8 Class Initialized
INFO - 2019-06-02 16:50:42 --> URI Class Initialized
INFO - 2019-06-02 16:50:42 --> Router Class Initialized
INFO - 2019-06-02 16:50:42 --> Output Class Initialized
INFO - 2019-06-02 16:50:42 --> Security Class Initialized
DEBUG - 2019-06-02 16:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-02 16:50:42 --> Input Class Initialized
INFO - 2019-06-02 16:50:42 --> Language Class Initialized
ERROR - 2019-06-02 16:50:42 --> 404 Page Not Found: /index
INFO - 2019-06-02 16:50:42 --> Config Class Initialized
INFO - 2019-06-02 16:50:42 --> Hooks Class Initialized
DEBUG - 2019-06-02 16:50:42 --> UTF-8 Support Enabled
INFO - 2019-06-02 16:50:42 --> Utf8 Class Initialized
INFO - 2019-06-02 16:50:42 --> URI Class Initialized
INFO - 2019-06-02 16:50:42 --> Router Class Initialized
INFO - 2019-06-02 16:50:42 --> Output Class Initialized
INFO - 2019-06-02 16:50:42 --> Security Class Initialized
DEBUG - 2019-06-02 16:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-02 16:50:42 --> Input Class Initialized
INFO - 2019-06-02 16:50:42 --> Language Class Initialized
ERROR - 2019-06-02 16:50:42 --> 404 Page Not Found: /index
INFO - 2019-06-02 16:50:43 --> Config Class Initialized
INFO - 2019-06-02 16:50:43 --> Hooks Class Initialized
DEBUG - 2019-06-02 16:50:43 --> UTF-8 Support Enabled
INFO - 2019-06-02 16:50:43 --> Utf8 Class Initialized
INFO - 2019-06-02 16:50:43 --> URI Class Initialized
INFO - 2019-06-02 16:50:43 --> Router Class Initialized
INFO - 2019-06-02 16:50:43 --> Output Class Initialized
INFO - 2019-06-02 16:50:43 --> Security Class Initialized
DEBUG - 2019-06-02 16:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-02 16:50:43 --> Input Class Initialized
INFO - 2019-06-02 16:50:43 --> Language Class Initialized
ERROR - 2019-06-02 16:50:43 --> 404 Page Not Found: /index
INFO - 2019-06-02 16:50:43 --> Config Class Initialized
INFO - 2019-06-02 16:50:43 --> Hooks Class Initialized
DEBUG - 2019-06-02 16:50:43 --> UTF-8 Support Enabled
INFO - 2019-06-02 16:50:43 --> Utf8 Class Initialized
INFO - 2019-06-02 16:50:43 --> URI Class Initialized
INFO - 2019-06-02 16:50:43 --> Router Class Initialized
INFO - 2019-06-02 16:50:43 --> Output Class Initialized
INFO - 2019-06-02 16:50:43 --> Security Class Initialized
DEBUG - 2019-06-02 16:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-02 16:50:43 --> Input Class Initialized
INFO - 2019-06-02 16:50:43 --> Language Class Initialized
ERROR - 2019-06-02 16:50:43 --> 404 Page Not Found: /index
INFO - 2019-06-02 16:50:43 --> Config Class Initialized
INFO - 2019-06-02 16:50:43 --> Hooks Class Initialized
DEBUG - 2019-06-02 16:50:43 --> UTF-8 Support Enabled
INFO - 2019-06-02 16:50:43 --> Utf8 Class Initialized
INFO - 2019-06-02 16:50:43 --> URI Class Initialized
INFO - 2019-06-02 16:50:43 --> Router Class Initialized
INFO - 2019-06-02 16:50:43 --> Output Class Initialized
INFO - 2019-06-02 16:50:43 --> Security Class Initialized
DEBUG - 2019-06-02 16:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-02 16:50:43 --> Input Class Initialized
INFO - 2019-06-02 16:50:43 --> Language Class Initialized
ERROR - 2019-06-02 16:50:43 --> 404 Page Not Found: /index
INFO - 2019-06-02 17:14:07 --> Config Class Initialized
INFO - 2019-06-02 17:14:07 --> Hooks Class Initialized
DEBUG - 2019-06-02 17:14:07 --> UTF-8 Support Enabled
INFO - 2019-06-02 17:14:07 --> Utf8 Class Initialized
INFO - 2019-06-02 17:14:07 --> URI Class Initialized
DEBUG - 2019-06-02 17:14:07 --> No URI present. Default controller set.
INFO - 2019-06-02 17:14:07 --> Router Class Initialized
INFO - 2019-06-02 17:14:07 --> Output Class Initialized
INFO - 2019-06-02 17:14:07 --> Security Class Initialized
DEBUG - 2019-06-02 17:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-02 17:14:07 --> Input Class Initialized
INFO - 2019-06-02 17:14:07 --> Language Class Initialized
INFO - 2019-06-02 17:14:07 --> Language Class Initialized
INFO - 2019-06-02 17:14:07 --> Config Class Initialized
INFO - 2019-06-02 17:14:07 --> Loader Class Initialized
INFO - 2019-06-02 17:14:07 --> Helper loaded: form_helper
INFO - 2019-06-02 17:14:07 --> Helper loaded: url_helper
INFO - 2019-06-02 17:14:07 --> Helper loaded: cookie_helper
INFO - 2019-06-02 17:14:07 --> Database Driver Class Initialized
DEBUG - 2019-06-02 17:14:07 --> Template library initialized
INFO - 2019-06-02 17:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-02 17:14:07 --> Controller Class Initialized
DEBUG - 2019-06-02 17:14:07 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-02 17:14:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-06-02 17:14:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-02 17:14:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-02 17:14:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-02 17:14:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-02 17:14:07 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-02 17:14:12 --> Final output sent to browser
DEBUG - 2019-06-02 17:14:12 --> Total execution time: 0.0514
INFO - 2019-06-02 17:14:59 --> Config Class Initialized
INFO - 2019-06-02 17:14:59 --> Hooks Class Initialized
DEBUG - 2019-06-02 17:14:59 --> UTF-8 Support Enabled
INFO - 2019-06-02 17:14:59 --> Utf8 Class Initialized
INFO - 2019-06-02 17:14:59 --> URI Class Initialized
INFO - 2019-06-02 17:14:59 --> Router Class Initialized
INFO - 2019-06-02 17:14:59 --> Output Class Initialized
INFO - 2019-06-02 17:14:59 --> Security Class Initialized
DEBUG - 2019-06-02 17:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-02 17:14:59 --> Input Class Initialized
INFO - 2019-06-02 17:14:59 --> Language Class Initialized
ERROR - 2019-06-02 17:14:59 --> 404 Page Not Found: /index
INFO - 2019-06-02 17:15:01 --> Config Class Initialized
INFO - 2019-06-02 17:15:01 --> Hooks Class Initialized
DEBUG - 2019-06-02 17:15:01 --> UTF-8 Support Enabled
INFO - 2019-06-02 17:15:01 --> Utf8 Class Initialized
INFO - 2019-06-02 17:15:01 --> URI Class Initialized
INFO - 2019-06-02 17:15:01 --> Router Class Initialized
INFO - 2019-06-02 17:15:01 --> Output Class Initialized
INFO - 2019-06-02 17:15:01 --> Security Class Initialized
DEBUG - 2019-06-02 17:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-02 17:15:01 --> Input Class Initialized
INFO - 2019-06-02 17:15:01 --> Language Class Initialized
ERROR - 2019-06-02 17:15:01 --> 404 Page Not Found: /index
INFO - 2019-06-02 17:15:04 --> Config Class Initialized
INFO - 2019-06-02 17:15:04 --> Hooks Class Initialized
DEBUG - 2019-06-02 17:15:04 --> UTF-8 Support Enabled
INFO - 2019-06-02 17:15:04 --> Utf8 Class Initialized
INFO - 2019-06-02 17:15:04 --> URI Class Initialized
INFO - 2019-06-02 17:15:04 --> Router Class Initialized
INFO - 2019-06-02 17:15:04 --> Output Class Initialized
INFO - 2019-06-02 17:15:04 --> Security Class Initialized
DEBUG - 2019-06-02 17:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-02 17:15:04 --> Input Class Initialized
INFO - 2019-06-02 17:15:04 --> Language Class Initialized
ERROR - 2019-06-02 17:15:04 --> 404 Page Not Found: /index
INFO - 2019-06-02 17:15:15 --> Config Class Initialized
INFO - 2019-06-02 17:15:15 --> Hooks Class Initialized
DEBUG - 2019-06-02 17:15:15 --> UTF-8 Support Enabled
INFO - 2019-06-02 17:15:15 --> Utf8 Class Initialized
INFO - 2019-06-02 17:15:15 --> URI Class Initialized
INFO - 2019-06-02 17:15:15 --> Router Class Initialized
INFO - 2019-06-02 17:15:15 --> Output Class Initialized
INFO - 2019-06-02 17:15:15 --> Security Class Initialized
DEBUG - 2019-06-02 17:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-02 17:15:15 --> Input Class Initialized
INFO - 2019-06-02 17:15:15 --> Language Class Initialized
ERROR - 2019-06-02 17:15:15 --> 404 Page Not Found: /index
INFO - 2019-06-02 17:15:19 --> Config Class Initialized
INFO - 2019-06-02 17:15:19 --> Hooks Class Initialized
DEBUG - 2019-06-02 17:15:19 --> UTF-8 Support Enabled
INFO - 2019-06-02 17:15:19 --> Utf8 Class Initialized
INFO - 2019-06-02 17:15:19 --> URI Class Initialized
DEBUG - 2019-06-02 17:15:19 --> No URI present. Default controller set.
INFO - 2019-06-02 17:15:19 --> Router Class Initialized
INFO - 2019-06-02 17:15:19 --> Output Class Initialized
INFO - 2019-06-02 17:15:19 --> Security Class Initialized
DEBUG - 2019-06-02 17:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-02 17:15:19 --> Input Class Initialized
INFO - 2019-06-02 17:15:19 --> Language Class Initialized
INFO - 2019-06-02 17:15:19 --> Language Class Initialized
INFO - 2019-06-02 17:15:19 --> Config Class Initialized
INFO - 2019-06-02 17:15:19 --> Loader Class Initialized
INFO - 2019-06-02 17:15:19 --> Helper loaded: form_helper
INFO - 2019-06-02 17:15:19 --> Helper loaded: url_helper
INFO - 2019-06-02 17:15:19 --> Helper loaded: cookie_helper
INFO - 2019-06-02 17:15:19 --> Database Driver Class Initialized
DEBUG - 2019-06-02 17:15:19 --> Template library initialized
INFO - 2019-06-02 17:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-02 17:15:19 --> Controller Class Initialized
DEBUG - 2019-06-02 17:15:19 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-02 17:15:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-06-02 17:15:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-02 17:15:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-02 17:15:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-02 17:15:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-02 17:15:19 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-02 17:15:26 --> Final output sent to browser
DEBUG - 2019-06-02 17:15:26 --> Total execution time: 0.0481
INFO - 2019-06-02 17:15:27 --> Config Class Initialized
INFO - 2019-06-02 17:15:27 --> Hooks Class Initialized
DEBUG - 2019-06-02 17:15:27 --> UTF-8 Support Enabled
INFO - 2019-06-02 17:15:27 --> Utf8 Class Initialized
INFO - 2019-06-02 17:15:27 --> URI Class Initialized
INFO - 2019-06-02 17:15:27 --> Router Class Initialized
INFO - 2019-06-02 17:15:27 --> Output Class Initialized
INFO - 2019-06-02 17:15:27 --> Security Class Initialized
DEBUG - 2019-06-02 17:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-02 17:15:27 --> Input Class Initialized
INFO - 2019-06-02 17:15:27 --> Language Class Initialized
ERROR - 2019-06-02 17:15:27 --> 404 Page Not Found: /index
INFO - 2019-06-02 17:15:27 --> Config Class Initialized
INFO - 2019-06-02 17:15:27 --> Hooks Class Initialized
DEBUG - 2019-06-02 17:15:27 --> UTF-8 Support Enabled
INFO - 2019-06-02 17:15:27 --> Utf8 Class Initialized
INFO - 2019-06-02 17:15:27 --> URI Class Initialized
INFO - 2019-06-02 17:15:27 --> Router Class Initialized
INFO - 2019-06-02 17:15:27 --> Output Class Initialized
INFO - 2019-06-02 17:15:27 --> Security Class Initialized
DEBUG - 2019-06-02 17:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-02 17:15:27 --> Input Class Initialized
INFO - 2019-06-02 17:15:27 --> Language Class Initialized
ERROR - 2019-06-02 17:15:27 --> 404 Page Not Found: /index
INFO - 2019-06-02 17:15:28 --> Config Class Initialized
INFO - 2019-06-02 17:15:28 --> Hooks Class Initialized
DEBUG - 2019-06-02 17:15:28 --> UTF-8 Support Enabled
INFO - 2019-06-02 17:15:28 --> Utf8 Class Initialized
INFO - 2019-06-02 17:15:28 --> URI Class Initialized
INFO - 2019-06-02 17:15:28 --> Router Class Initialized
INFO - 2019-06-02 17:15:28 --> Output Class Initialized
INFO - 2019-06-02 17:15:28 --> Security Class Initialized
DEBUG - 2019-06-02 17:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-02 17:15:28 --> Input Class Initialized
INFO - 2019-06-02 17:15:28 --> Language Class Initialized
ERROR - 2019-06-02 17:15:28 --> 404 Page Not Found: /index
