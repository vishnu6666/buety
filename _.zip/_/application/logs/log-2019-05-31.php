<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-05-31 07:45:03 --> Config Class Initialized
INFO - 2019-05-31 07:45:03 --> Hooks Class Initialized
DEBUG - 2019-05-31 07:45:03 --> UTF-8 Support Enabled
INFO - 2019-05-31 07:45:03 --> Utf8 Class Initialized
INFO - 2019-05-31 07:45:03 --> URI Class Initialized
DEBUG - 2019-05-31 07:45:03 --> No URI present. Default controller set.
INFO - 2019-05-31 07:45:03 --> Router Class Initialized
INFO - 2019-05-31 07:45:03 --> Output Class Initialized
INFO - 2019-05-31 07:45:03 --> Security Class Initialized
DEBUG - 2019-05-31 07:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 07:45:03 --> Input Class Initialized
INFO - 2019-05-31 07:45:03 --> Language Class Initialized
INFO - 2019-05-31 07:45:03 --> Language Class Initialized
INFO - 2019-05-31 07:45:03 --> Config Class Initialized
INFO - 2019-05-31 07:45:03 --> Loader Class Initialized
INFO - 2019-05-31 07:45:03 --> Helper loaded: form_helper
INFO - 2019-05-31 07:45:03 --> Helper loaded: url_helper
INFO - 2019-05-31 07:45:03 --> Helper loaded: cookie_helper
INFO - 2019-05-31 07:45:04 --> Database Driver Class Initialized
DEBUG - 2019-05-31 07:45:04 --> Template library initialized
INFO - 2019-05-31 07:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-31 07:45:04 --> Controller Class Initialized
DEBUG - 2019-05-31 07:45:04 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-31 07:45:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-31 07:45:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-31 07:45:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-31 07:45:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-31 07:45:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-31 07:45:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-31 07:45:05 --> Final output sent to browser
DEBUG - 2019-05-31 07:45:05 --> Total execution time: 0.0525
INFO - 2019-05-31 07:45:13 --> Config Class Initialized
INFO - 2019-05-31 07:45:13 --> Hooks Class Initialized
DEBUG - 2019-05-31 07:45:13 --> UTF-8 Support Enabled
INFO - 2019-05-31 07:45:13 --> Utf8 Class Initialized
INFO - 2019-05-31 07:45:13 --> URI Class Initialized
INFO - 2019-05-31 07:45:13 --> Router Class Initialized
INFO - 2019-05-31 07:45:13 --> Output Class Initialized
INFO - 2019-05-31 07:45:13 --> Security Class Initialized
DEBUG - 2019-05-31 07:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 07:45:13 --> Input Class Initialized
INFO - 2019-05-31 07:45:13 --> Language Class Initialized
ERROR - 2019-05-31 07:45:13 --> 404 Page Not Found: /index
INFO - 2019-05-31 07:45:13 --> Config Class Initialized
INFO - 2019-05-31 07:45:13 --> Hooks Class Initialized
DEBUG - 2019-05-31 07:45:13 --> UTF-8 Support Enabled
INFO - 2019-05-31 07:45:13 --> Utf8 Class Initialized
INFO - 2019-05-31 07:45:13 --> URI Class Initialized
INFO - 2019-05-31 07:45:13 --> Router Class Initialized
INFO - 2019-05-31 07:45:13 --> Output Class Initialized
INFO - 2019-05-31 07:45:13 --> Security Class Initialized
DEBUG - 2019-05-31 07:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 07:45:13 --> Input Class Initialized
INFO - 2019-05-31 07:45:13 --> Language Class Initialized
ERROR - 2019-05-31 07:45:13 --> 404 Page Not Found: /index
INFO - 2019-05-31 07:45:14 --> Config Class Initialized
INFO - 2019-05-31 07:45:14 --> Hooks Class Initialized
DEBUG - 2019-05-31 07:45:14 --> UTF-8 Support Enabled
INFO - 2019-05-31 07:45:14 --> Utf8 Class Initialized
INFO - 2019-05-31 07:45:14 --> URI Class Initialized
INFO - 2019-05-31 07:45:14 --> Router Class Initialized
INFO - 2019-05-31 07:45:14 --> Output Class Initialized
INFO - 2019-05-31 07:45:14 --> Security Class Initialized
DEBUG - 2019-05-31 07:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 07:45:14 --> Input Class Initialized
INFO - 2019-05-31 07:45:14 --> Language Class Initialized
ERROR - 2019-05-31 07:45:14 --> 404 Page Not Found: /index
INFO - 2019-05-31 07:45:15 --> Config Class Initialized
INFO - 2019-05-31 07:45:15 --> Hooks Class Initialized
DEBUG - 2019-05-31 07:45:15 --> UTF-8 Support Enabled
INFO - 2019-05-31 07:45:15 --> Utf8 Class Initialized
INFO - 2019-05-31 07:45:15 --> URI Class Initialized
INFO - 2019-05-31 07:45:15 --> Router Class Initialized
INFO - 2019-05-31 07:45:15 --> Output Class Initialized
INFO - 2019-05-31 07:45:15 --> Security Class Initialized
DEBUG - 2019-05-31 07:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 07:45:15 --> Input Class Initialized
INFO - 2019-05-31 07:45:15 --> Language Class Initialized
ERROR - 2019-05-31 07:45:15 --> 404 Page Not Found: /index
INFO - 2019-05-31 07:45:26 --> Config Class Initialized
INFO - 2019-05-31 07:45:26 --> Hooks Class Initialized
DEBUG - 2019-05-31 07:45:26 --> UTF-8 Support Enabled
INFO - 2019-05-31 07:45:26 --> Utf8 Class Initialized
INFO - 2019-05-31 07:45:26 --> URI Class Initialized
INFO - 2019-05-31 07:45:26 --> Router Class Initialized
INFO - 2019-05-31 07:45:26 --> Output Class Initialized
INFO - 2019-05-31 07:45:26 --> Security Class Initialized
DEBUG - 2019-05-31 07:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 07:45:26 --> Input Class Initialized
INFO - 2019-05-31 07:45:26 --> Language Class Initialized
INFO - 2019-05-31 07:45:26 --> Language Class Initialized
INFO - 2019-05-31 07:45:26 --> Config Class Initialized
INFO - 2019-05-31 07:45:26 --> Loader Class Initialized
INFO - 2019-05-31 07:45:26 --> Helper loaded: form_helper
INFO - 2019-05-31 07:45:26 --> Helper loaded: url_helper
INFO - 2019-05-31 07:45:26 --> Helper loaded: cookie_helper
INFO - 2019-05-31 07:45:26 --> Database Driver Class Initialized
DEBUG - 2019-05-31 07:45:26 --> Template library initialized
INFO - 2019-05-31 07:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-31 07:45:26 --> Controller Class Initialized
DEBUG - 2019-05-31 07:45:26 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-31 07:45:26 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-31 07:45:26 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/mobile.php
DEBUG - 2019-05-31 07:45:26 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-31 07:45:26 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-31 07:45:26 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-31 07:45:26 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-31 07:45:28 --> Final output sent to browser
DEBUG - 2019-05-31 07:45:28 --> Total execution time: 0.0471
INFO - 2019-05-31 07:45:28 --> Config Class Initialized
INFO - 2019-05-31 07:45:28 --> Hooks Class Initialized
DEBUG - 2019-05-31 07:45:28 --> UTF-8 Support Enabled
INFO - 2019-05-31 07:45:28 --> Utf8 Class Initialized
INFO - 2019-05-31 07:45:28 --> URI Class Initialized
INFO - 2019-05-31 07:45:28 --> Config Class Initialized
INFO - 2019-05-31 07:45:28 --> Hooks Class Initialized
DEBUG - 2019-05-31 07:45:28 --> UTF-8 Support Enabled
INFO - 2019-05-31 07:45:28 --> Utf8 Class Initialized
INFO - 2019-05-31 07:45:28 --> URI Class Initialized
INFO - 2019-05-31 07:45:28 --> Router Class Initialized
INFO - 2019-05-31 07:45:28 --> Output Class Initialized
INFO - 2019-05-31 07:45:28 --> Security Class Initialized
DEBUG - 2019-05-31 07:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 07:45:28 --> Input Class Initialized
INFO - 2019-05-31 07:45:28 --> Language Class Initialized
ERROR - 2019-05-31 07:45:28 --> 404 Page Not Found: /index
INFO - 2019-05-31 07:45:28 --> Router Class Initialized
INFO - 2019-05-31 07:45:28 --> Output Class Initialized
INFO - 2019-05-31 07:45:28 --> Security Class Initialized
DEBUG - 2019-05-31 07:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 07:45:28 --> Input Class Initialized
INFO - 2019-05-31 07:45:28 --> Language Class Initialized
ERROR - 2019-05-31 07:45:28 --> 404 Page Not Found: /index
INFO - 2019-05-31 07:45:29 --> Config Class Initialized
INFO - 2019-05-31 07:45:29 --> Hooks Class Initialized
DEBUG - 2019-05-31 07:45:29 --> UTF-8 Support Enabled
INFO - 2019-05-31 07:45:29 --> Utf8 Class Initialized
INFO - 2019-05-31 07:45:29 --> URI Class Initialized
INFO - 2019-05-31 07:45:29 --> Router Class Initialized
INFO - 2019-05-31 07:45:29 --> Output Class Initialized
INFO - 2019-05-31 07:45:29 --> Security Class Initialized
DEBUG - 2019-05-31 07:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 07:45:29 --> Input Class Initialized
INFO - 2019-05-31 07:45:29 --> Language Class Initialized
ERROR - 2019-05-31 07:45:29 --> 404 Page Not Found: /index
INFO - 2019-05-31 10:09:54 --> Config Class Initialized
INFO - 2019-05-31 10:09:54 --> Hooks Class Initialized
DEBUG - 2019-05-31 10:09:54 --> UTF-8 Support Enabled
INFO - 2019-05-31 10:09:54 --> Utf8 Class Initialized
INFO - 2019-05-31 10:09:54 --> URI Class Initialized
INFO - 2019-05-31 10:09:54 --> Router Class Initialized
INFO - 2019-05-31 10:09:54 --> Output Class Initialized
INFO - 2019-05-31 10:09:54 --> Security Class Initialized
DEBUG - 2019-05-31 10:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 10:09:54 --> Input Class Initialized
INFO - 2019-05-31 10:09:54 --> Language Class Initialized
INFO - 2019-05-31 10:09:54 --> Language Class Initialized
INFO - 2019-05-31 10:09:54 --> Config Class Initialized
INFO - 2019-05-31 10:09:54 --> Loader Class Initialized
INFO - 2019-05-31 10:09:54 --> Helper loaded: form_helper
INFO - 2019-05-31 10:09:54 --> Helper loaded: url_helper
INFO - 2019-05-31 10:09:54 --> Helper loaded: cookie_helper
INFO - 2019-05-31 10:09:54 --> Database Driver Class Initialized
DEBUG - 2019-05-31 10:09:54 --> Template library initialized
INFO - 2019-05-31 10:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-31 10:09:54 --> Controller Class Initialized
DEBUG - 2019-05-31 10:09:54 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-31 10:09:54 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-31 10:09:54 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/insurance.php
DEBUG - 2019-05-31 10:09:54 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-31 10:09:54 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-31 10:09:54 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-31 10:09:54 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-31 10:09:54 --> Final output sent to browser
DEBUG - 2019-05-31 10:09:54 --> Total execution time: 0.0523
INFO - 2019-05-31 10:09:55 --> Config Class Initialized
INFO - 2019-05-31 10:09:55 --> Hooks Class Initialized
DEBUG - 2019-05-31 10:09:55 --> UTF-8 Support Enabled
INFO - 2019-05-31 10:09:55 --> Utf8 Class Initialized
INFO - 2019-05-31 10:09:55 --> URI Class Initialized
INFO - 2019-05-31 10:09:55 --> Router Class Initialized
INFO - 2019-05-31 10:09:55 --> Output Class Initialized
INFO - 2019-05-31 10:09:55 --> Security Class Initialized
DEBUG - 2019-05-31 10:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 10:09:55 --> Input Class Initialized
INFO - 2019-05-31 10:09:55 --> Language Class Initialized
ERROR - 2019-05-31 10:09:55 --> 404 Page Not Found: /index
INFO - 2019-05-31 10:09:55 --> Config Class Initialized
INFO - 2019-05-31 10:09:55 --> Hooks Class Initialized
DEBUG - 2019-05-31 10:09:55 --> UTF-8 Support Enabled
INFO - 2019-05-31 10:09:55 --> Utf8 Class Initialized
INFO - 2019-05-31 10:09:55 --> URI Class Initialized
INFO - 2019-05-31 10:09:55 --> Config Class Initialized
INFO - 2019-05-31 10:09:55 --> Hooks Class Initialized
INFO - 2019-05-31 10:09:55 --> Router Class Initialized
INFO - 2019-05-31 10:09:55 --> Output Class Initialized
INFO - 2019-05-31 10:09:55 --> Security Class Initialized
DEBUG - 2019-05-31 10:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 10:09:55 --> Input Class Initialized
INFO - 2019-05-31 10:09:55 --> Language Class Initialized
ERROR - 2019-05-31 10:09:55 --> 404 Page Not Found: /index
DEBUG - 2019-05-31 10:09:55 --> UTF-8 Support Enabled
INFO - 2019-05-31 10:09:55 --> Utf8 Class Initialized
INFO - 2019-05-31 10:09:55 --> URI Class Initialized
INFO - 2019-05-31 10:09:55 --> Router Class Initialized
INFO - 2019-05-31 10:09:55 --> Output Class Initialized
INFO - 2019-05-31 10:09:55 --> Security Class Initialized
DEBUG - 2019-05-31 10:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 10:09:55 --> Input Class Initialized
INFO - 2019-05-31 10:09:55 --> Language Class Initialized
ERROR - 2019-05-31 10:09:55 --> 404 Page Not Found: /index
INFO - 2019-05-31 10:09:58 --> Config Class Initialized
INFO - 2019-05-31 10:09:58 --> Hooks Class Initialized
DEBUG - 2019-05-31 10:09:58 --> UTF-8 Support Enabled
INFO - 2019-05-31 10:09:58 --> Utf8 Class Initialized
INFO - 2019-05-31 10:09:58 --> URI Class Initialized
INFO - 2019-05-31 10:09:58 --> Router Class Initialized
INFO - 2019-05-31 10:09:58 --> Output Class Initialized
INFO - 2019-05-31 10:09:58 --> Security Class Initialized
DEBUG - 2019-05-31 10:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 10:09:58 --> Input Class Initialized
INFO - 2019-05-31 10:09:58 --> Language Class Initialized
INFO - 2019-05-31 10:09:58 --> Language Class Initialized
INFO - 2019-05-31 10:09:58 --> Config Class Initialized
INFO - 2019-05-31 10:09:58 --> Loader Class Initialized
INFO - 2019-05-31 10:09:58 --> Helper loaded: form_helper
INFO - 2019-05-31 10:09:58 --> Helper loaded: url_helper
INFO - 2019-05-31 10:09:58 --> Helper loaded: cookie_helper
INFO - 2019-05-31 10:09:58 --> Database Driver Class Initialized
DEBUG - 2019-05-31 10:09:58 --> Template library initialized
INFO - 2019-05-31 10:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-31 10:09:58 --> Controller Class Initialized
DEBUG - 2019-05-31 10:09:58 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-31 10:09:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-31 10:09:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/dth.php
DEBUG - 2019-05-31 10:09:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-31 10:09:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-31 10:09:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-31 10:09:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-31 10:09:58 --> Final output sent to browser
DEBUG - 2019-05-31 10:09:58 --> Total execution time: 0.0497
INFO - 2019-05-31 10:09:59 --> Config Class Initialized
INFO - 2019-05-31 10:09:59 --> Hooks Class Initialized
DEBUG - 2019-05-31 10:09:59 --> UTF-8 Support Enabled
INFO - 2019-05-31 10:09:59 --> Utf8 Class Initialized
INFO - 2019-05-31 10:09:59 --> URI Class Initialized
INFO - 2019-05-31 10:09:59 --> Config Class Initialized
INFO - 2019-05-31 10:09:59 --> Hooks Class Initialized
DEBUG - 2019-05-31 10:09:59 --> UTF-8 Support Enabled
INFO - 2019-05-31 10:09:59 --> Utf8 Class Initialized
INFO - 2019-05-31 10:09:59 --> URI Class Initialized
INFO - 2019-05-31 10:09:59 --> Router Class Initialized
INFO - 2019-05-31 10:09:59 --> Router Class Initialized
INFO - 2019-05-31 10:09:59 --> Output Class Initialized
INFO - 2019-05-31 10:09:59 --> Security Class Initialized
DEBUG - 2019-05-31 10:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 10:09:59 --> Input Class Initialized
INFO - 2019-05-31 10:09:59 --> Language Class Initialized
ERROR - 2019-05-31 10:09:59 --> 404 Page Not Found: /index
INFO - 2019-05-31 10:09:59 --> Output Class Initialized
INFO - 2019-05-31 10:09:59 --> Security Class Initialized
DEBUG - 2019-05-31 10:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 10:09:59 --> Input Class Initialized
INFO - 2019-05-31 10:09:59 --> Language Class Initialized
ERROR - 2019-05-31 10:09:59 --> 404 Page Not Found: /index
INFO - 2019-05-31 10:09:59 --> Config Class Initialized
INFO - 2019-05-31 10:09:59 --> Hooks Class Initialized
DEBUG - 2019-05-31 10:09:59 --> UTF-8 Support Enabled
INFO - 2019-05-31 10:09:59 --> Utf8 Class Initialized
INFO - 2019-05-31 10:09:59 --> URI Class Initialized
INFO - 2019-05-31 10:09:59 --> Router Class Initialized
INFO - 2019-05-31 10:09:59 --> Output Class Initialized
INFO - 2019-05-31 10:09:59 --> Security Class Initialized
DEBUG - 2019-05-31 10:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 10:09:59 --> Input Class Initialized
INFO - 2019-05-31 10:09:59 --> Language Class Initialized
ERROR - 2019-05-31 10:09:59 --> 404 Page Not Found: /index
INFO - 2019-05-31 13:07:04 --> Config Class Initialized
INFO - 2019-05-31 13:07:04 --> Hooks Class Initialized
DEBUG - 2019-05-31 13:07:04 --> UTF-8 Support Enabled
INFO - 2019-05-31 13:07:04 --> Utf8 Class Initialized
INFO - 2019-05-31 13:07:04 --> URI Class Initialized
DEBUG - 2019-05-31 13:07:04 --> No URI present. Default controller set.
INFO - 2019-05-31 13:07:04 --> Router Class Initialized
INFO - 2019-05-31 13:07:04 --> Output Class Initialized
INFO - 2019-05-31 13:07:04 --> Security Class Initialized
DEBUG - 2019-05-31 13:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 13:07:04 --> Input Class Initialized
INFO - 2019-05-31 13:07:04 --> Language Class Initialized
INFO - 2019-05-31 13:07:04 --> Language Class Initialized
INFO - 2019-05-31 13:07:04 --> Config Class Initialized
INFO - 2019-05-31 13:07:04 --> Loader Class Initialized
INFO - 2019-05-31 13:07:04 --> Helper loaded: form_helper
INFO - 2019-05-31 13:07:04 --> Helper loaded: url_helper
INFO - 2019-05-31 13:07:04 --> Helper loaded: cookie_helper
INFO - 2019-05-31 13:07:04 --> Database Driver Class Initialized
DEBUG - 2019-05-31 13:07:04 --> Template library initialized
INFO - 2019-05-31 13:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-31 13:07:04 --> Controller Class Initialized
DEBUG - 2019-05-31 13:07:04 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-31 13:07:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-31 13:07:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-31 13:07:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-31 13:07:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-31 13:07:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-31 13:07:04 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-31 13:07:04 --> Final output sent to browser
DEBUG - 2019-05-31 13:07:04 --> Total execution time: 0.0504
INFO - 2019-05-31 13:07:04 --> Config Class Initialized
INFO - 2019-05-31 13:07:04 --> Hooks Class Initialized
DEBUG - 2019-05-31 13:07:04 --> UTF-8 Support Enabled
INFO - 2019-05-31 13:07:04 --> Utf8 Class Initialized
INFO - 2019-05-31 13:07:04 --> URI Class Initialized
INFO - 2019-05-31 13:07:04 --> Router Class Initialized
INFO - 2019-05-31 13:07:04 --> Output Class Initialized
INFO - 2019-05-31 13:07:04 --> Security Class Initialized
DEBUG - 2019-05-31 13:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 13:07:04 --> Input Class Initialized
INFO - 2019-05-31 13:07:04 --> Language Class Initialized
ERROR - 2019-05-31 13:07:04 --> 404 Page Not Found: /index
INFO - 2019-05-31 15:52:27 --> Config Class Initialized
INFO - 2019-05-31 15:52:27 --> Hooks Class Initialized
DEBUG - 2019-05-31 15:52:27 --> UTF-8 Support Enabled
INFO - 2019-05-31 15:52:27 --> Utf8 Class Initialized
INFO - 2019-05-31 15:52:27 --> URI Class Initialized
INFO - 2019-05-31 15:52:27 --> Router Class Initialized
INFO - 2019-05-31 15:52:27 --> Output Class Initialized
INFO - 2019-05-31 15:52:28 --> Security Class Initialized
DEBUG - 2019-05-31 15:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 15:52:28 --> Input Class Initialized
INFO - 2019-05-31 15:52:28 --> Language Class Initialized
INFO - 2019-05-31 15:52:28 --> Language Class Initialized
INFO - 2019-05-31 15:52:28 --> Config Class Initialized
INFO - 2019-05-31 15:52:28 --> Loader Class Initialized
INFO - 2019-05-31 15:52:28 --> Helper loaded: form_helper
INFO - 2019-05-31 15:52:28 --> Helper loaded: url_helper
INFO - 2019-05-31 15:52:28 --> Helper loaded: cookie_helper
INFO - 2019-05-31 15:52:28 --> Database Driver Class Initialized
DEBUG - 2019-05-31 15:52:28 --> Template library initialized
INFO - 2019-05-31 15:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-31 15:52:28 --> Controller Class Initialized
DEBUG - 2019-05-31 15:52:28 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-31 15:52:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-31 15:52:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/electricity.php
DEBUG - 2019-05-31 15:52:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-31 15:52:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-31 15:52:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-31 15:52:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-31 15:52:28 --> Config Class Initialized
INFO - 2019-05-31 15:52:28 --> Hooks Class Initialized
DEBUG - 2019-05-31 15:52:28 --> UTF-8 Support Enabled
INFO - 2019-05-31 15:52:28 --> Utf8 Class Initialized
INFO - 2019-05-31 15:52:28 --> URI Class Initialized
INFO - 2019-05-31 15:52:28 --> Router Class Initialized
INFO - 2019-05-31 15:52:28 --> Output Class Initialized
INFO - 2019-05-31 15:52:28 --> Security Class Initialized
DEBUG - 2019-05-31 15:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 15:52:28 --> Input Class Initialized
INFO - 2019-05-31 15:52:28 --> Language Class Initialized
INFO - 2019-05-31 15:52:28 --> Language Class Initialized
INFO - 2019-05-31 15:52:28 --> Config Class Initialized
INFO - 2019-05-31 15:52:28 --> Loader Class Initialized
INFO - 2019-05-31 15:52:28 --> Helper loaded: form_helper
INFO - 2019-05-31 15:52:28 --> Helper loaded: url_helper
INFO - 2019-05-31 15:52:28 --> Helper loaded: cookie_helper
INFO - 2019-05-31 15:52:28 --> Database Driver Class Initialized
DEBUG - 2019-05-31 15:52:28 --> Template library initialized
INFO - 2019-05-31 15:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-31 15:52:28 --> Controller Class Initialized
DEBUG - 2019-05-31 15:52:28 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-31 15:52:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-31 15:52:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/dth.php
DEBUG - 2019-05-31 15:52:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-31 15:52:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-31 15:52:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-31 15:52:28 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-31 15:52:29 --> Final output sent to browser
DEBUG - 2019-05-31 15:52:29 --> Total execution time: 0.0556
INFO - 2019-05-31 15:52:29 --> Config Class Initialized
INFO - 2019-05-31 15:52:29 --> Hooks Class Initialized
DEBUG - 2019-05-31 15:52:29 --> UTF-8 Support Enabled
INFO - 2019-05-31 15:52:29 --> Utf8 Class Initialized
INFO - 2019-05-31 15:52:29 --> URI Class Initialized
INFO - 2019-05-31 15:52:29 --> Router Class Initialized
INFO - 2019-05-31 15:52:29 --> Output Class Initialized
INFO - 2019-05-31 15:52:29 --> Security Class Initialized
DEBUG - 2019-05-31 15:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 15:52:29 --> Input Class Initialized
INFO - 2019-05-31 15:52:29 --> Language Class Initialized
INFO - 2019-05-31 15:52:29 --> Language Class Initialized
INFO - 2019-05-31 15:52:29 --> Config Class Initialized
INFO - 2019-05-31 15:52:29 --> Loader Class Initialized
INFO - 2019-05-31 15:52:29 --> Helper loaded: form_helper
INFO - 2019-05-31 15:52:29 --> Helper loaded: url_helper
INFO - 2019-05-31 15:52:29 --> Helper loaded: cookie_helper
INFO - 2019-05-31 15:52:29 --> Database Driver Class Initialized
DEBUG - 2019-05-31 15:52:29 --> Template library initialized
INFO - 2019-05-31 15:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-31 15:52:29 --> Controller Class Initialized
DEBUG - 2019-05-31 15:52:29 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-31 15:52:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-31 15:52:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/electricity.php
DEBUG - 2019-05-31 15:52:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-31 15:52:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-31 15:52:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-31 15:52:29 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-31 15:52:29 --> Final output sent to browser
DEBUG - 2019-05-31 15:52:29 --> Total execution time: 0.0499
INFO - 2019-05-31 15:52:30 --> Config Class Initialized
INFO - 2019-05-31 15:52:30 --> Hooks Class Initialized
DEBUG - 2019-05-31 15:52:30 --> UTF-8 Support Enabled
INFO - 2019-05-31 15:52:30 --> Utf8 Class Initialized
INFO - 2019-05-31 15:52:30 --> URI Class Initialized
INFO - 2019-05-31 15:52:30 --> Router Class Initialized
INFO - 2019-05-31 15:52:30 --> Output Class Initialized
INFO - 2019-05-31 15:52:30 --> Security Class Initialized
DEBUG - 2019-05-31 15:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 15:52:30 --> Input Class Initialized
INFO - 2019-05-31 15:52:30 --> Language Class Initialized
ERROR - 2019-05-31 15:52:30 --> 404 Page Not Found: /index
INFO - 2019-05-31 15:52:30 --> Config Class Initialized
INFO - 2019-05-31 15:52:30 --> Hooks Class Initialized
DEBUG - 2019-05-31 15:52:30 --> UTF-8 Support Enabled
INFO - 2019-05-31 15:52:30 --> Utf8 Class Initialized
INFO - 2019-05-31 15:52:30 --> URI Class Initialized
INFO - 2019-05-31 15:52:30 --> Config Class Initialized
INFO - 2019-05-31 15:52:30 --> Hooks Class Initialized
DEBUG - 2019-05-31 15:52:30 --> UTF-8 Support Enabled
INFO - 2019-05-31 15:52:30 --> Utf8 Class Initialized
INFO - 2019-05-31 15:52:30 --> URI Class Initialized
INFO - 2019-05-31 15:52:30 --> Router Class Initialized
INFO - 2019-05-31 15:52:30 --> Output Class Initialized
INFO - 2019-05-31 15:52:30 --> Security Class Initialized
DEBUG - 2019-05-31 15:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 15:52:30 --> Input Class Initialized
INFO - 2019-05-31 15:52:30 --> Language Class Initialized
ERROR - 2019-05-31 15:52:30 --> 404 Page Not Found: /index
INFO - 2019-05-31 15:52:30 --> Router Class Initialized
INFO - 2019-05-31 15:52:30 --> Output Class Initialized
INFO - 2019-05-31 15:52:30 --> Security Class Initialized
DEBUG - 2019-05-31 15:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 15:52:30 --> Input Class Initialized
INFO - 2019-05-31 15:52:30 --> Language Class Initialized
ERROR - 2019-05-31 15:52:30 --> 404 Page Not Found: /index
INFO - 2019-05-31 15:52:49 --> Config Class Initialized
INFO - 2019-05-31 15:52:49 --> Hooks Class Initialized
DEBUG - 2019-05-31 15:52:49 --> UTF-8 Support Enabled
INFO - 2019-05-31 15:52:49 --> Utf8 Class Initialized
INFO - 2019-05-31 15:52:49 --> URI Class Initialized
DEBUG - 2019-05-31 15:52:49 --> No URI present. Default controller set.
INFO - 2019-05-31 15:52:49 --> Router Class Initialized
INFO - 2019-05-31 15:52:49 --> Output Class Initialized
INFO - 2019-05-31 15:52:49 --> Security Class Initialized
DEBUG - 2019-05-31 15:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 15:52:49 --> Input Class Initialized
INFO - 2019-05-31 15:52:49 --> Language Class Initialized
INFO - 2019-05-31 15:52:49 --> Language Class Initialized
INFO - 2019-05-31 15:52:49 --> Config Class Initialized
INFO - 2019-05-31 15:52:49 --> Loader Class Initialized
INFO - 2019-05-31 15:52:49 --> Helper loaded: form_helper
INFO - 2019-05-31 15:52:49 --> Helper loaded: url_helper
INFO - 2019-05-31 15:52:49 --> Helper loaded: cookie_helper
INFO - 2019-05-31 15:52:49 --> Database Driver Class Initialized
DEBUG - 2019-05-31 15:52:49 --> Template library initialized
INFO - 2019-05-31 15:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-31 15:52:49 --> Controller Class Initialized
DEBUG - 2019-05-31 15:52:49 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-31 15:52:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-31 15:52:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-31 15:52:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-31 15:52:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-31 15:52:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-31 15:52:49 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-31 15:52:50 --> Final output sent to browser
DEBUG - 2019-05-31 15:52:50 --> Total execution time: 0.0719
INFO - 2019-05-31 15:52:51 --> Config Class Initialized
INFO - 2019-05-31 15:52:51 --> Hooks Class Initialized
DEBUG - 2019-05-31 15:52:51 --> UTF-8 Support Enabled
INFO - 2019-05-31 15:52:51 --> Utf8 Class Initialized
INFO - 2019-05-31 15:52:51 --> URI Class Initialized
INFO - 2019-05-31 15:52:51 --> Router Class Initialized
INFO - 2019-05-31 15:52:51 --> Output Class Initialized
INFO - 2019-05-31 15:52:51 --> Security Class Initialized
DEBUG - 2019-05-31 15:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 15:52:51 --> Input Class Initialized
INFO - 2019-05-31 15:52:51 --> Language Class Initialized
ERROR - 2019-05-31 15:52:51 --> 404 Page Not Found: /index
INFO - 2019-05-31 15:52:51 --> Config Class Initialized
INFO - 2019-05-31 15:52:51 --> Hooks Class Initialized
DEBUG - 2019-05-31 15:52:51 --> UTF-8 Support Enabled
INFO - 2019-05-31 15:52:51 --> Utf8 Class Initialized
INFO - 2019-05-31 15:52:51 --> URI Class Initialized
INFO - 2019-05-31 15:52:51 --> Router Class Initialized
INFO - 2019-05-31 15:52:51 --> Output Class Initialized
INFO - 2019-05-31 15:52:51 --> Security Class Initialized
DEBUG - 2019-05-31 15:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 15:52:51 --> Input Class Initialized
INFO - 2019-05-31 15:52:51 --> Language Class Initialized
ERROR - 2019-05-31 15:52:51 --> 404 Page Not Found: /index
INFO - 2019-05-31 15:52:51 --> Config Class Initialized
INFO - 2019-05-31 15:52:51 --> Hooks Class Initialized
DEBUG - 2019-05-31 15:52:51 --> UTF-8 Support Enabled
INFO - 2019-05-31 15:52:51 --> Utf8 Class Initialized
INFO - 2019-05-31 15:52:51 --> URI Class Initialized
INFO - 2019-05-31 15:52:51 --> Router Class Initialized
INFO - 2019-05-31 15:52:51 --> Output Class Initialized
INFO - 2019-05-31 15:52:51 --> Security Class Initialized
DEBUG - 2019-05-31 15:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 15:52:51 --> Input Class Initialized
INFO - 2019-05-31 15:52:51 --> Language Class Initialized
ERROR - 2019-05-31 15:52:51 --> 404 Page Not Found: /index
INFO - 2019-05-31 15:52:51 --> Config Class Initialized
INFO - 2019-05-31 15:52:51 --> Hooks Class Initialized
DEBUG - 2019-05-31 15:52:51 --> UTF-8 Support Enabled
INFO - 2019-05-31 15:52:51 --> Utf8 Class Initialized
INFO - 2019-05-31 15:52:51 --> URI Class Initialized
INFO - 2019-05-31 15:52:51 --> Router Class Initialized
INFO - 2019-05-31 15:52:51 --> Output Class Initialized
INFO - 2019-05-31 15:52:51 --> Security Class Initialized
DEBUG - 2019-05-31 15:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 15:52:51 --> Input Class Initialized
INFO - 2019-05-31 15:52:51 --> Language Class Initialized
ERROR - 2019-05-31 15:52:51 --> 404 Page Not Found: /index
INFO - 2019-05-31 15:52:52 --> Config Class Initialized
INFO - 2019-05-31 15:52:52 --> Hooks Class Initialized
DEBUG - 2019-05-31 15:52:52 --> UTF-8 Support Enabled
INFO - 2019-05-31 15:52:52 --> Utf8 Class Initialized
INFO - 2019-05-31 15:52:52 --> URI Class Initialized
INFO - 2019-05-31 15:52:52 --> Router Class Initialized
INFO - 2019-05-31 15:52:52 --> Output Class Initialized
INFO - 2019-05-31 15:52:52 --> Security Class Initialized
DEBUG - 2019-05-31 15:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 15:52:52 --> Input Class Initialized
INFO - 2019-05-31 15:52:52 --> Language Class Initialized
ERROR - 2019-05-31 15:52:52 --> 404 Page Not Found: /index
INFO - 2019-05-31 15:52:52 --> Config Class Initialized
INFO - 2019-05-31 15:52:52 --> Hooks Class Initialized
DEBUG - 2019-05-31 15:52:52 --> UTF-8 Support Enabled
INFO - 2019-05-31 15:52:52 --> Utf8 Class Initialized
INFO - 2019-05-31 15:52:52 --> URI Class Initialized
INFO - 2019-05-31 15:52:52 --> Router Class Initialized
INFO - 2019-05-31 15:52:52 --> Output Class Initialized
INFO - 2019-05-31 15:52:52 --> Security Class Initialized
DEBUG - 2019-05-31 15:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 15:52:52 --> Input Class Initialized
INFO - 2019-05-31 15:52:52 --> Language Class Initialized
ERROR - 2019-05-31 15:52:52 --> 404 Page Not Found: /index
INFO - 2019-05-31 15:52:52 --> Config Class Initialized
INFO - 2019-05-31 15:52:52 --> Hooks Class Initialized
DEBUG - 2019-05-31 15:52:52 --> UTF-8 Support Enabled
INFO - 2019-05-31 15:52:52 --> Utf8 Class Initialized
INFO - 2019-05-31 15:52:52 --> URI Class Initialized
INFO - 2019-05-31 15:52:52 --> Router Class Initialized
INFO - 2019-05-31 15:52:52 --> Output Class Initialized
INFO - 2019-05-31 15:52:52 --> Security Class Initialized
DEBUG - 2019-05-31 15:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 15:52:52 --> Input Class Initialized
INFO - 2019-05-31 15:52:52 --> Language Class Initialized
ERROR - 2019-05-31 15:52:52 --> 404 Page Not Found: /index
INFO - 2019-05-31 15:52:52 --> Config Class Initialized
INFO - 2019-05-31 15:52:52 --> Hooks Class Initialized
DEBUG - 2019-05-31 15:52:52 --> UTF-8 Support Enabled
INFO - 2019-05-31 15:52:52 --> Utf8 Class Initialized
INFO - 2019-05-31 15:52:52 --> URI Class Initialized
INFO - 2019-05-31 15:52:52 --> Router Class Initialized
INFO - 2019-05-31 15:52:52 --> Output Class Initialized
INFO - 2019-05-31 15:52:52 --> Security Class Initialized
DEBUG - 2019-05-31 15:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 15:52:52 --> Input Class Initialized
INFO - 2019-05-31 15:52:52 --> Language Class Initialized
ERROR - 2019-05-31 15:52:52 --> 404 Page Not Found: /index
INFO - 2019-05-31 15:52:53 --> Config Class Initialized
INFO - 2019-05-31 15:52:53 --> Hooks Class Initialized
DEBUG - 2019-05-31 15:52:53 --> UTF-8 Support Enabled
INFO - 2019-05-31 15:52:53 --> Utf8 Class Initialized
INFO - 2019-05-31 15:52:53 --> URI Class Initialized
INFO - 2019-05-31 15:52:53 --> Router Class Initialized
INFO - 2019-05-31 15:52:53 --> Output Class Initialized
INFO - 2019-05-31 15:52:53 --> Security Class Initialized
DEBUG - 2019-05-31 15:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 15:52:53 --> Input Class Initialized
INFO - 2019-05-31 15:52:53 --> Language Class Initialized
ERROR - 2019-05-31 15:52:53 --> 404 Page Not Found: /index
INFO - 2019-05-31 15:52:53 --> Config Class Initialized
INFO - 2019-05-31 15:52:53 --> Hooks Class Initialized
DEBUG - 2019-05-31 15:52:53 --> UTF-8 Support Enabled
INFO - 2019-05-31 15:52:53 --> Utf8 Class Initialized
INFO - 2019-05-31 15:52:53 --> URI Class Initialized
INFO - 2019-05-31 15:52:53 --> Router Class Initialized
INFO - 2019-05-31 15:52:53 --> Output Class Initialized
INFO - 2019-05-31 15:52:53 --> Security Class Initialized
DEBUG - 2019-05-31 15:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 15:52:53 --> Input Class Initialized
INFO - 2019-05-31 15:52:53 --> Language Class Initialized
ERROR - 2019-05-31 15:52:53 --> 404 Page Not Found: /index
INFO - 2019-05-31 15:52:53 --> Config Class Initialized
INFO - 2019-05-31 15:52:53 --> Hooks Class Initialized
DEBUG - 2019-05-31 15:52:53 --> UTF-8 Support Enabled
INFO - 2019-05-31 15:52:53 --> Utf8 Class Initialized
INFO - 2019-05-31 15:52:53 --> URI Class Initialized
INFO - 2019-05-31 15:52:53 --> Router Class Initialized
INFO - 2019-05-31 15:52:53 --> Output Class Initialized
INFO - 2019-05-31 15:52:53 --> Security Class Initialized
DEBUG - 2019-05-31 15:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 15:52:53 --> Input Class Initialized
INFO - 2019-05-31 15:52:53 --> Language Class Initialized
ERROR - 2019-05-31 15:52:53 --> 404 Page Not Found: /index
INFO - 2019-05-31 15:52:53 --> Config Class Initialized
INFO - 2019-05-31 15:52:53 --> Hooks Class Initialized
DEBUG - 2019-05-31 15:52:53 --> UTF-8 Support Enabled
INFO - 2019-05-31 15:52:53 --> Utf8 Class Initialized
INFO - 2019-05-31 15:52:53 --> URI Class Initialized
INFO - 2019-05-31 15:52:53 --> Router Class Initialized
INFO - 2019-05-31 15:52:53 --> Output Class Initialized
INFO - 2019-05-31 15:52:53 --> Security Class Initialized
DEBUG - 2019-05-31 15:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 15:52:53 --> Input Class Initialized
INFO - 2019-05-31 15:52:53 --> Language Class Initialized
ERROR - 2019-05-31 15:52:53 --> 404 Page Not Found: /index
INFO - 2019-05-31 18:22:45 --> Config Class Initialized
INFO - 2019-05-31 18:22:45 --> Hooks Class Initialized
DEBUG - 2019-05-31 18:22:45 --> UTF-8 Support Enabled
INFO - 2019-05-31 18:22:45 --> Utf8 Class Initialized
INFO - 2019-05-31 18:22:45 --> URI Class Initialized
DEBUG - 2019-05-31 18:22:45 --> No URI present. Default controller set.
INFO - 2019-05-31 18:22:45 --> Router Class Initialized
INFO - 2019-05-31 18:22:45 --> Output Class Initialized
INFO - 2019-05-31 18:22:45 --> Security Class Initialized
DEBUG - 2019-05-31 18:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 18:22:45 --> Input Class Initialized
INFO - 2019-05-31 18:22:45 --> Language Class Initialized
INFO - 2019-05-31 18:22:45 --> Language Class Initialized
INFO - 2019-05-31 18:22:45 --> Config Class Initialized
INFO - 2019-05-31 18:22:45 --> Loader Class Initialized
INFO - 2019-05-31 18:22:45 --> Helper loaded: form_helper
INFO - 2019-05-31 18:22:45 --> Helper loaded: url_helper
INFO - 2019-05-31 18:22:45 --> Helper loaded: cookie_helper
INFO - 2019-05-31 18:22:45 --> Database Driver Class Initialized
DEBUG - 2019-05-31 18:22:45 --> Template library initialized
INFO - 2019-05-31 18:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-05-31 18:22:45 --> Controller Class Initialized
DEBUG - 2019-05-31 18:22:45 --> Paystore MX_Controller Initialized
DEBUG - 2019-05-31 18:22:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-05-31 18:22:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-05-31 18:22:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-05-31 18:22:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-05-31 18:22:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-05-31 18:22:45 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-05-31 18:22:45 --> Final output sent to browser
DEBUG - 2019-05-31 18:22:45 --> Total execution time: 0.0467
INFO - 2019-05-31 18:22:46 --> Config Class Initialized
INFO - 2019-05-31 18:22:46 --> Hooks Class Initialized
DEBUG - 2019-05-31 18:22:46 --> UTF-8 Support Enabled
INFO - 2019-05-31 18:22:46 --> Utf8 Class Initialized
INFO - 2019-05-31 18:22:46 --> URI Class Initialized
INFO - 2019-05-31 18:22:46 --> Router Class Initialized
INFO - 2019-05-31 18:22:46 --> Output Class Initialized
INFO - 2019-05-31 18:22:46 --> Security Class Initialized
DEBUG - 2019-05-31 18:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 18:22:46 --> Input Class Initialized
INFO - 2019-05-31 18:22:46 --> Language Class Initialized
ERROR - 2019-05-31 18:22:46 --> 404 Page Not Found: /index
INFO - 2019-05-31 18:22:47 --> Config Class Initialized
INFO - 2019-05-31 18:22:47 --> Hooks Class Initialized
DEBUG - 2019-05-31 18:22:47 --> UTF-8 Support Enabled
INFO - 2019-05-31 18:22:47 --> Utf8 Class Initialized
INFO - 2019-05-31 18:22:47 --> URI Class Initialized
INFO - 2019-05-31 18:22:47 --> Router Class Initialized
INFO - 2019-05-31 18:22:47 --> Output Class Initialized
INFO - 2019-05-31 18:22:47 --> Security Class Initialized
DEBUG - 2019-05-31 18:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 18:22:47 --> Input Class Initialized
INFO - 2019-05-31 18:22:47 --> Language Class Initialized
ERROR - 2019-05-31 18:22:47 --> 404 Page Not Found: /index
INFO - 2019-05-31 18:22:47 --> Config Class Initialized
INFO - 2019-05-31 18:22:47 --> Hooks Class Initialized
DEBUG - 2019-05-31 18:22:47 --> UTF-8 Support Enabled
INFO - 2019-05-31 18:22:47 --> Utf8 Class Initialized
INFO - 2019-05-31 18:22:47 --> URI Class Initialized
INFO - 2019-05-31 18:22:47 --> Router Class Initialized
INFO - 2019-05-31 18:22:47 --> Output Class Initialized
INFO - 2019-05-31 18:22:47 --> Security Class Initialized
DEBUG - 2019-05-31 18:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 18:22:47 --> Input Class Initialized
INFO - 2019-05-31 18:22:47 --> Language Class Initialized
ERROR - 2019-05-31 18:22:47 --> 404 Page Not Found: /index
INFO - 2019-05-31 18:22:47 --> Config Class Initialized
INFO - 2019-05-31 18:22:47 --> Hooks Class Initialized
DEBUG - 2019-05-31 18:22:47 --> UTF-8 Support Enabled
INFO - 2019-05-31 18:22:47 --> Utf8 Class Initialized
INFO - 2019-05-31 18:22:47 --> URI Class Initialized
INFO - 2019-05-31 18:22:47 --> Router Class Initialized
INFO - 2019-05-31 18:22:47 --> Output Class Initialized
INFO - 2019-05-31 18:22:47 --> Security Class Initialized
DEBUG - 2019-05-31 18:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 18:22:47 --> Input Class Initialized
INFO - 2019-05-31 18:22:47 --> Language Class Initialized
ERROR - 2019-05-31 18:22:47 --> 404 Page Not Found: /index
INFO - 2019-05-31 18:22:47 --> Config Class Initialized
INFO - 2019-05-31 18:22:47 --> Hooks Class Initialized
DEBUG - 2019-05-31 18:22:47 --> UTF-8 Support Enabled
INFO - 2019-05-31 18:22:47 --> Utf8 Class Initialized
INFO - 2019-05-31 18:22:47 --> URI Class Initialized
INFO - 2019-05-31 18:22:47 --> Router Class Initialized
INFO - 2019-05-31 18:22:47 --> Output Class Initialized
INFO - 2019-05-31 18:22:47 --> Security Class Initialized
DEBUG - 2019-05-31 18:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 18:22:47 --> Input Class Initialized
INFO - 2019-05-31 18:22:47 --> Language Class Initialized
ERROR - 2019-05-31 18:22:47 --> 404 Page Not Found: /index
INFO - 2019-05-31 18:22:48 --> Config Class Initialized
INFO - 2019-05-31 18:22:48 --> Hooks Class Initialized
DEBUG - 2019-05-31 18:22:48 --> UTF-8 Support Enabled
INFO - 2019-05-31 18:22:48 --> Utf8 Class Initialized
INFO - 2019-05-31 18:22:48 --> URI Class Initialized
INFO - 2019-05-31 18:22:48 --> Router Class Initialized
INFO - 2019-05-31 18:22:48 --> Output Class Initialized
INFO - 2019-05-31 18:22:48 --> Security Class Initialized
DEBUG - 2019-05-31 18:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 18:22:48 --> Input Class Initialized
INFO - 2019-05-31 18:22:48 --> Language Class Initialized
ERROR - 2019-05-31 18:22:48 --> 404 Page Not Found: /index
INFO - 2019-05-31 18:22:48 --> Config Class Initialized
INFO - 2019-05-31 18:22:48 --> Hooks Class Initialized
DEBUG - 2019-05-31 18:22:48 --> UTF-8 Support Enabled
INFO - 2019-05-31 18:22:48 --> Utf8 Class Initialized
INFO - 2019-05-31 18:22:48 --> URI Class Initialized
INFO - 2019-05-31 18:22:48 --> Router Class Initialized
INFO - 2019-05-31 18:22:48 --> Output Class Initialized
INFO - 2019-05-31 18:22:48 --> Security Class Initialized
DEBUG - 2019-05-31 18:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 18:22:48 --> Input Class Initialized
INFO - 2019-05-31 18:22:48 --> Language Class Initialized
ERROR - 2019-05-31 18:22:48 --> 404 Page Not Found: /index
INFO - 2019-05-31 18:22:48 --> Config Class Initialized
INFO - 2019-05-31 18:22:48 --> Hooks Class Initialized
DEBUG - 2019-05-31 18:22:48 --> UTF-8 Support Enabled
INFO - 2019-05-31 18:22:48 --> Utf8 Class Initialized
INFO - 2019-05-31 18:22:48 --> URI Class Initialized
INFO - 2019-05-31 18:22:48 --> Router Class Initialized
INFO - 2019-05-31 18:22:48 --> Output Class Initialized
INFO - 2019-05-31 18:22:48 --> Security Class Initialized
DEBUG - 2019-05-31 18:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 18:22:48 --> Input Class Initialized
INFO - 2019-05-31 18:22:48 --> Language Class Initialized
ERROR - 2019-05-31 18:22:48 --> 404 Page Not Found: /index
INFO - 2019-05-31 18:22:48 --> Config Class Initialized
INFO - 2019-05-31 18:22:48 --> Hooks Class Initialized
DEBUG - 2019-05-31 18:22:48 --> UTF-8 Support Enabled
INFO - 2019-05-31 18:22:48 --> Utf8 Class Initialized
INFO - 2019-05-31 18:22:48 --> URI Class Initialized
INFO - 2019-05-31 18:22:48 --> Router Class Initialized
INFO - 2019-05-31 18:22:48 --> Output Class Initialized
INFO - 2019-05-31 18:22:48 --> Security Class Initialized
DEBUG - 2019-05-31 18:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 18:22:48 --> Input Class Initialized
INFO - 2019-05-31 18:22:48 --> Language Class Initialized
ERROR - 2019-05-31 18:22:48 --> 404 Page Not Found: /index
INFO - 2019-05-31 18:22:49 --> Config Class Initialized
INFO - 2019-05-31 18:22:49 --> Hooks Class Initialized
DEBUG - 2019-05-31 18:22:49 --> UTF-8 Support Enabled
INFO - 2019-05-31 18:22:49 --> Utf8 Class Initialized
INFO - 2019-05-31 18:22:49 --> URI Class Initialized
INFO - 2019-05-31 18:22:49 --> Router Class Initialized
INFO - 2019-05-31 18:22:49 --> Output Class Initialized
INFO - 2019-05-31 18:22:49 --> Security Class Initialized
DEBUG - 2019-05-31 18:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 18:22:49 --> Input Class Initialized
INFO - 2019-05-31 18:22:49 --> Language Class Initialized
ERROR - 2019-05-31 18:22:49 --> 404 Page Not Found: /index
INFO - 2019-05-31 18:22:49 --> Config Class Initialized
INFO - 2019-05-31 18:22:49 --> Hooks Class Initialized
DEBUG - 2019-05-31 18:22:49 --> UTF-8 Support Enabled
INFO - 2019-05-31 18:22:49 --> Utf8 Class Initialized
INFO - 2019-05-31 18:22:49 --> URI Class Initialized
INFO - 2019-05-31 18:22:49 --> Router Class Initialized
INFO - 2019-05-31 18:22:49 --> Output Class Initialized
INFO - 2019-05-31 18:22:49 --> Security Class Initialized
DEBUG - 2019-05-31 18:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 18:22:49 --> Input Class Initialized
INFO - 2019-05-31 18:22:49 --> Language Class Initialized
ERROR - 2019-05-31 18:22:49 --> 404 Page Not Found: /index
INFO - 2019-05-31 18:22:49 --> Config Class Initialized
INFO - 2019-05-31 18:22:49 --> Hooks Class Initialized
DEBUG - 2019-05-31 18:22:49 --> UTF-8 Support Enabled
INFO - 2019-05-31 18:22:49 --> Utf8 Class Initialized
INFO - 2019-05-31 18:22:49 --> URI Class Initialized
INFO - 2019-05-31 18:22:49 --> Router Class Initialized
INFO - 2019-05-31 18:22:49 --> Output Class Initialized
INFO - 2019-05-31 18:22:49 --> Security Class Initialized
DEBUG - 2019-05-31 18:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-31 18:22:49 --> Input Class Initialized
INFO - 2019-05-31 18:22:49 --> Language Class Initialized
ERROR - 2019-05-31 18:22:49 --> 404 Page Not Found: /index
