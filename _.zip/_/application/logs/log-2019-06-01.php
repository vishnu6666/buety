<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-06-01 07:25:52 --> Config Class Initialized
INFO - 2019-06-01 07:25:52 --> Hooks Class Initialized
DEBUG - 2019-06-01 07:25:52 --> UTF-8 Support Enabled
INFO - 2019-06-01 07:25:52 --> Utf8 Class Initialized
INFO - 2019-06-01 07:25:52 --> URI Class Initialized
DEBUG - 2019-06-01 07:25:52 --> No URI present. Default controller set.
INFO - 2019-06-01 07:25:52 --> Router Class Initialized
INFO - 2019-06-01 07:25:52 --> Output Class Initialized
INFO - 2019-06-01 07:25:52 --> Security Class Initialized
DEBUG - 2019-06-01 07:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-01 07:25:52 --> Input Class Initialized
INFO - 2019-06-01 07:25:52 --> Language Class Initialized
INFO - 2019-06-01 07:25:52 --> Language Class Initialized
INFO - 2019-06-01 07:25:52 --> Config Class Initialized
INFO - 2019-06-01 07:25:52 --> Loader Class Initialized
INFO - 2019-06-01 07:25:52 --> Helper loaded: form_helper
INFO - 2019-06-01 07:25:52 --> Helper loaded: url_helper
INFO - 2019-06-01 07:25:52 --> Helper loaded: cookie_helper
INFO - 2019-06-01 07:25:52 --> Database Driver Class Initialized
DEBUG - 2019-06-01 07:25:52 --> Template library initialized
INFO - 2019-06-01 07:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-01 07:25:52 --> Controller Class Initialized
DEBUG - 2019-06-01 07:25:52 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-01 07:25:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-06-01 07:25:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-01 07:25:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-01 07:25:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-01 07:25:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-01 07:25:52 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-01 07:25:53 --> Final output sent to browser
DEBUG - 2019-06-01 07:25:53 --> Total execution time: 0.0668
INFO - 2019-06-01 07:25:54 --> Config Class Initialized
INFO - 2019-06-01 07:25:54 --> Hooks Class Initialized
DEBUG - 2019-06-01 07:25:54 --> UTF-8 Support Enabled
INFO - 2019-06-01 07:25:54 --> Utf8 Class Initialized
INFO - 2019-06-01 07:25:54 --> URI Class Initialized
INFO - 2019-06-01 07:25:54 --> Router Class Initialized
INFO - 2019-06-01 07:25:54 --> Output Class Initialized
INFO - 2019-06-01 07:25:54 --> Security Class Initialized
DEBUG - 2019-06-01 07:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-01 07:25:54 --> Input Class Initialized
INFO - 2019-06-01 07:25:54 --> Language Class Initialized
ERROR - 2019-06-01 07:25:54 --> 404 Page Not Found: /index
INFO - 2019-06-01 07:25:55 --> Config Class Initialized
INFO - 2019-06-01 07:25:55 --> Hooks Class Initialized
DEBUG - 2019-06-01 07:25:55 --> UTF-8 Support Enabled
INFO - 2019-06-01 07:25:55 --> Utf8 Class Initialized
INFO - 2019-06-01 07:25:55 --> URI Class Initialized
INFO - 2019-06-01 07:25:55 --> Router Class Initialized
INFO - 2019-06-01 07:25:55 --> Output Class Initialized
INFO - 2019-06-01 07:25:55 --> Security Class Initialized
DEBUG - 2019-06-01 07:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-01 07:25:55 --> Input Class Initialized
INFO - 2019-06-01 07:25:55 --> Language Class Initialized
ERROR - 2019-06-01 07:25:55 --> 404 Page Not Found: /index
INFO - 2019-06-01 07:25:56 --> Config Class Initialized
INFO - 2019-06-01 07:25:56 --> Hooks Class Initialized
DEBUG - 2019-06-01 07:25:56 --> UTF-8 Support Enabled
INFO - 2019-06-01 07:25:56 --> Utf8 Class Initialized
INFO - 2019-06-01 07:25:56 --> URI Class Initialized
INFO - 2019-06-01 07:25:56 --> Router Class Initialized
INFO - 2019-06-01 07:25:56 --> Output Class Initialized
INFO - 2019-06-01 07:25:56 --> Security Class Initialized
DEBUG - 2019-06-01 07:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-01 07:25:56 --> Input Class Initialized
INFO - 2019-06-01 07:25:56 --> Language Class Initialized
ERROR - 2019-06-01 07:25:56 --> 404 Page Not Found: /index
INFO - 2019-06-01 07:25:56 --> Config Class Initialized
INFO - 2019-06-01 07:25:56 --> Hooks Class Initialized
DEBUG - 2019-06-01 07:25:56 --> UTF-8 Support Enabled
INFO - 2019-06-01 07:25:56 --> Utf8 Class Initialized
INFO - 2019-06-01 07:25:56 --> URI Class Initialized
INFO - 2019-06-01 07:25:56 --> Router Class Initialized
INFO - 2019-06-01 07:25:56 --> Output Class Initialized
INFO - 2019-06-01 07:25:56 --> Security Class Initialized
DEBUG - 2019-06-01 07:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-01 07:25:56 --> Input Class Initialized
INFO - 2019-06-01 07:25:56 --> Language Class Initialized
ERROR - 2019-06-01 07:25:56 --> 404 Page Not Found: /index
INFO - 2019-06-01 07:25:57 --> Config Class Initialized
INFO - 2019-06-01 07:25:57 --> Hooks Class Initialized
DEBUG - 2019-06-01 07:25:57 --> UTF-8 Support Enabled
INFO - 2019-06-01 07:25:57 --> Utf8 Class Initialized
INFO - 2019-06-01 07:25:57 --> URI Class Initialized
INFO - 2019-06-01 07:25:57 --> Router Class Initialized
INFO - 2019-06-01 07:25:57 --> Output Class Initialized
INFO - 2019-06-01 07:25:57 --> Security Class Initialized
DEBUG - 2019-06-01 07:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-01 07:25:57 --> Input Class Initialized
INFO - 2019-06-01 07:25:57 --> Language Class Initialized
ERROR - 2019-06-01 07:25:57 --> 404 Page Not Found: /index
INFO - 2019-06-01 07:25:57 --> Config Class Initialized
INFO - 2019-06-01 07:25:57 --> Hooks Class Initialized
DEBUG - 2019-06-01 07:25:57 --> UTF-8 Support Enabled
INFO - 2019-06-01 07:25:57 --> Utf8 Class Initialized
INFO - 2019-06-01 07:25:57 --> URI Class Initialized
INFO - 2019-06-01 07:25:57 --> Router Class Initialized
INFO - 2019-06-01 07:25:57 --> Output Class Initialized
INFO - 2019-06-01 07:25:57 --> Security Class Initialized
DEBUG - 2019-06-01 07:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-01 07:25:57 --> Input Class Initialized
INFO - 2019-06-01 07:25:57 --> Language Class Initialized
ERROR - 2019-06-01 07:25:57 --> 404 Page Not Found: /index
INFO - 2019-06-01 07:25:57 --> Config Class Initialized
INFO - 2019-06-01 07:25:57 --> Hooks Class Initialized
DEBUG - 2019-06-01 07:25:57 --> UTF-8 Support Enabled
INFO - 2019-06-01 07:25:57 --> Utf8 Class Initialized
INFO - 2019-06-01 07:25:57 --> URI Class Initialized
INFO - 2019-06-01 07:25:57 --> Router Class Initialized
INFO - 2019-06-01 07:25:57 --> Output Class Initialized
INFO - 2019-06-01 07:25:57 --> Security Class Initialized
DEBUG - 2019-06-01 07:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-01 07:25:57 --> Input Class Initialized
INFO - 2019-06-01 07:25:57 --> Language Class Initialized
ERROR - 2019-06-01 07:25:57 --> 404 Page Not Found: /index
INFO - 2019-06-01 07:25:58 --> Config Class Initialized
INFO - 2019-06-01 07:25:58 --> Hooks Class Initialized
DEBUG - 2019-06-01 07:25:58 --> UTF-8 Support Enabled
INFO - 2019-06-01 07:25:58 --> Utf8 Class Initialized
INFO - 2019-06-01 07:25:58 --> URI Class Initialized
INFO - 2019-06-01 07:25:58 --> Router Class Initialized
INFO - 2019-06-01 07:25:58 --> Output Class Initialized
INFO - 2019-06-01 07:25:58 --> Security Class Initialized
DEBUG - 2019-06-01 07:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-01 07:25:58 --> Input Class Initialized
INFO - 2019-06-01 07:25:58 --> Language Class Initialized
ERROR - 2019-06-01 07:25:58 --> 404 Page Not Found: /index
INFO - 2019-06-01 07:25:58 --> Config Class Initialized
INFO - 2019-06-01 07:25:58 --> Hooks Class Initialized
DEBUG - 2019-06-01 07:25:58 --> UTF-8 Support Enabled
INFO - 2019-06-01 07:25:58 --> Utf8 Class Initialized
INFO - 2019-06-01 07:25:58 --> URI Class Initialized
INFO - 2019-06-01 07:25:58 --> Router Class Initialized
INFO - 2019-06-01 07:25:58 --> Output Class Initialized
INFO - 2019-06-01 07:25:58 --> Security Class Initialized
DEBUG - 2019-06-01 07:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-01 07:25:58 --> Input Class Initialized
INFO - 2019-06-01 07:25:58 --> Language Class Initialized
ERROR - 2019-06-01 07:25:58 --> 404 Page Not Found: /index
INFO - 2019-06-01 07:25:59 --> Config Class Initialized
INFO - 2019-06-01 07:25:59 --> Hooks Class Initialized
DEBUG - 2019-06-01 07:25:59 --> UTF-8 Support Enabled
INFO - 2019-06-01 07:25:59 --> Utf8 Class Initialized
INFO - 2019-06-01 07:25:59 --> URI Class Initialized
INFO - 2019-06-01 07:25:59 --> Router Class Initialized
INFO - 2019-06-01 07:25:59 --> Output Class Initialized
INFO - 2019-06-01 07:25:59 --> Security Class Initialized
DEBUG - 2019-06-01 07:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-01 07:25:59 --> Input Class Initialized
INFO - 2019-06-01 07:25:59 --> Language Class Initialized
ERROR - 2019-06-01 07:25:59 --> 404 Page Not Found: /index
INFO - 2019-06-01 07:25:59 --> Config Class Initialized
INFO - 2019-06-01 07:25:59 --> Hooks Class Initialized
DEBUG - 2019-06-01 07:25:59 --> UTF-8 Support Enabled
INFO - 2019-06-01 07:25:59 --> Utf8 Class Initialized
INFO - 2019-06-01 07:25:59 --> URI Class Initialized
INFO - 2019-06-01 07:25:59 --> Router Class Initialized
INFO - 2019-06-01 07:25:59 --> Output Class Initialized
INFO - 2019-06-01 07:25:59 --> Security Class Initialized
DEBUG - 2019-06-01 07:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-01 07:25:59 --> Input Class Initialized
INFO - 2019-06-01 07:25:59 --> Language Class Initialized
ERROR - 2019-06-01 07:25:59 --> 404 Page Not Found: /index
INFO - 2019-06-01 07:26:00 --> Config Class Initialized
INFO - 2019-06-01 07:26:00 --> Hooks Class Initialized
DEBUG - 2019-06-01 07:26:00 --> UTF-8 Support Enabled
INFO - 2019-06-01 07:26:00 --> Utf8 Class Initialized
INFO - 2019-06-01 07:26:00 --> URI Class Initialized
INFO - 2019-06-01 07:26:00 --> Router Class Initialized
INFO - 2019-06-01 07:26:00 --> Output Class Initialized
INFO - 2019-06-01 07:26:00 --> Security Class Initialized
DEBUG - 2019-06-01 07:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-01 07:26:00 --> Input Class Initialized
INFO - 2019-06-01 07:26:00 --> Language Class Initialized
ERROR - 2019-06-01 07:26:00 --> 404 Page Not Found: /index
