<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-06-08 03:55:27 --> Config Class Initialized
INFO - 2019-06-08 03:55:27 --> Hooks Class Initialized
DEBUG - 2019-06-08 03:55:27 --> UTF-8 Support Enabled
INFO - 2019-06-08 03:55:27 --> Utf8 Class Initialized
INFO - 2019-06-08 03:55:27 --> URI Class Initialized
DEBUG - 2019-06-08 03:55:27 --> No URI present. Default controller set.
INFO - 2019-06-08 03:55:27 --> Router Class Initialized
INFO - 2019-06-08 03:55:27 --> Output Class Initialized
INFO - 2019-06-08 03:55:27 --> Security Class Initialized
DEBUG - 2019-06-08 03:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-08 03:55:27 --> Input Class Initialized
INFO - 2019-06-08 03:55:27 --> Language Class Initialized
INFO - 2019-06-08 03:55:27 --> Language Class Initialized
INFO - 2019-06-08 03:55:27 --> Config Class Initialized
INFO - 2019-06-08 03:55:27 --> Loader Class Initialized
INFO - 2019-06-08 03:55:27 --> Helper loaded: form_helper
INFO - 2019-06-08 03:55:27 --> Helper loaded: url_helper
INFO - 2019-06-08 03:55:27 --> Helper loaded: cookie_helper
INFO - 2019-06-08 03:55:27 --> Database Driver Class Initialized
DEBUG - 2019-06-08 03:55:27 --> Template library initialized
INFO - 2019-06-08 03:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-08 03:55:27 --> Controller Class Initialized
DEBUG - 2019-06-08 03:55:27 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-08 03:55:27 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
ERROR - 2019-06-08 03:55:27 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 03:55:27 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 03:55:27 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 03:55:27 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 03:55:27 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 03:55:27 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 03:55:27 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 03:55:27 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 03:55:27 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 03:55:27 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 03:55:27 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 03:55:27 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 03:55:27 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 03:55:27 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 03:55:27 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 03:55:27 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 03:55:27 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 03:55:27 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 03:55:27 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 03:55:27 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 03:55:27 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 03:55:27 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
DEBUG - 2019-06-08 03:55:27 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-08 03:55:27 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-08 03:55:27 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-08 03:55:27 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-08 03:55:27 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-08 03:55:27 --> Final output sent to browser
DEBUG - 2019-06-08 03:55:27 --> Total execution time: 0.0809
INFO - 2019-06-08 03:55:27 --> Config Class Initialized
INFO - 2019-06-08 03:55:27 --> Hooks Class Initialized
DEBUG - 2019-06-08 03:55:27 --> UTF-8 Support Enabled
INFO - 2019-06-08 03:55:27 --> Utf8 Class Initialized
INFO - 2019-06-08 03:55:27 --> URI Class Initialized
INFO - 2019-06-08 03:55:27 --> Router Class Initialized
INFO - 2019-06-08 03:55:27 --> Output Class Initialized
INFO - 2019-06-08 03:55:27 --> Security Class Initialized
DEBUG - 2019-06-08 03:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-08 03:55:27 --> Input Class Initialized
INFO - 2019-06-08 03:55:27 --> Language Class Initialized
ERROR - 2019-06-08 03:55:27 --> 404 Page Not Found: /index
INFO - 2019-06-08 05:25:24 --> Config Class Initialized
INFO - 2019-06-08 05:25:24 --> Hooks Class Initialized
DEBUG - 2019-06-08 05:25:24 --> UTF-8 Support Enabled
INFO - 2019-06-08 05:25:24 --> Utf8 Class Initialized
INFO - 2019-06-08 05:25:24 --> URI Class Initialized
DEBUG - 2019-06-08 05:25:24 --> No URI present. Default controller set.
INFO - 2019-06-08 05:25:24 --> Router Class Initialized
INFO - 2019-06-08 05:25:24 --> Output Class Initialized
INFO - 2019-06-08 05:25:24 --> Security Class Initialized
DEBUG - 2019-06-08 05:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-08 05:25:24 --> Input Class Initialized
INFO - 2019-06-08 05:25:24 --> Language Class Initialized
INFO - 2019-06-08 05:25:24 --> Language Class Initialized
INFO - 2019-06-08 05:25:24 --> Config Class Initialized
INFO - 2019-06-08 05:25:24 --> Loader Class Initialized
INFO - 2019-06-08 05:25:24 --> Helper loaded: form_helper
INFO - 2019-06-08 05:25:24 --> Helper loaded: url_helper
INFO - 2019-06-08 05:25:24 --> Helper loaded: cookie_helper
INFO - 2019-06-08 05:25:24 --> Database Driver Class Initialized
DEBUG - 2019-06-08 05:25:24 --> Template library initialized
INFO - 2019-06-08 05:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-08 05:25:24 --> Controller Class Initialized
DEBUG - 2019-06-08 05:25:24 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-08 05:25:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
DEBUG - 2019-06-08 05:25:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-08 05:25:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-08 05:25:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-08 05:25:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-08 05:25:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-08 05:25:24 --> Config Class Initialized
INFO - 2019-06-08 05:25:24 --> Hooks Class Initialized
DEBUG - 2019-06-08 05:25:24 --> UTF-8 Support Enabled
INFO - 2019-06-08 05:25:24 --> Utf8 Class Initialized
INFO - 2019-06-08 05:25:24 --> URI Class Initialized
DEBUG - 2019-06-08 05:25:24 --> No URI present. Default controller set.
INFO - 2019-06-08 05:25:24 --> Router Class Initialized
INFO - 2019-06-08 05:25:24 --> Output Class Initialized
INFO - 2019-06-08 05:25:24 --> Security Class Initialized
DEBUG - 2019-06-08 05:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-08 05:25:24 --> Input Class Initialized
INFO - 2019-06-08 05:25:24 --> Language Class Initialized
INFO - 2019-06-08 05:25:24 --> Language Class Initialized
INFO - 2019-06-08 05:25:24 --> Config Class Initialized
INFO - 2019-06-08 05:25:24 --> Loader Class Initialized
INFO - 2019-06-08 05:25:24 --> Helper loaded: form_helper
INFO - 2019-06-08 05:25:24 --> Helper loaded: url_helper
INFO - 2019-06-08 05:25:24 --> Helper loaded: cookie_helper
INFO - 2019-06-08 05:25:24 --> Database Driver Class Initialized
DEBUG - 2019-06-08 05:25:24 --> Template library initialized
INFO - 2019-06-08 05:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-08 05:25:24 --> Controller Class Initialized
DEBUG - 2019-06-08 05:25:24 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-08 05:25:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 05:25:24 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
DEBUG - 2019-06-08 05:25:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-08 05:25:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-08 05:25:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-08 05:25:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-08 05:25:24 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-08 05:25:24 --> Final output sent to browser
DEBUG - 2019-06-08 05:25:24 --> Total execution time: 0.0646
INFO - 2019-06-08 05:25:25 --> Final output sent to browser
DEBUG - 2019-06-08 05:25:25 --> Total execution time: 0.0705
INFO - 2019-06-08 05:25:32 --> Config Class Initialized
INFO - 2019-06-08 05:25:32 --> Hooks Class Initialized
DEBUG - 2019-06-08 05:25:32 --> UTF-8 Support Enabled
INFO - 2019-06-08 05:25:32 --> Utf8 Class Initialized
INFO - 2019-06-08 05:25:32 --> URI Class Initialized
INFO - 2019-06-08 05:25:32 --> Router Class Initialized
INFO - 2019-06-08 05:25:32 --> Output Class Initialized
INFO - 2019-06-08 05:25:32 --> Security Class Initialized
DEBUG - 2019-06-08 05:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-08 05:25:32 --> Input Class Initialized
INFO - 2019-06-08 05:25:32 --> Language Class Initialized
ERROR - 2019-06-08 05:25:32 --> 404 Page Not Found: /index
INFO - 2019-06-08 05:25:46 --> Config Class Initialized
INFO - 2019-06-08 05:25:46 --> Hooks Class Initialized
DEBUG - 2019-06-08 05:25:46 --> UTF-8 Support Enabled
INFO - 2019-06-08 05:25:46 --> Utf8 Class Initialized
INFO - 2019-06-08 05:25:46 --> URI Class Initialized
INFO - 2019-06-08 05:25:46 --> Router Class Initialized
INFO - 2019-06-08 05:25:46 --> Output Class Initialized
INFO - 2019-06-08 05:25:47 --> Security Class Initialized
DEBUG - 2019-06-08 05:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-08 05:25:47 --> Input Class Initialized
INFO - 2019-06-08 05:25:47 --> Language Class Initialized
INFO - 2019-06-08 05:25:47 --> Language Class Initialized
INFO - 2019-06-08 05:25:47 --> Config Class Initialized
INFO - 2019-06-08 05:25:47 --> Loader Class Initialized
INFO - 2019-06-08 05:25:47 --> Helper loaded: form_helper
INFO - 2019-06-08 05:25:47 --> Helper loaded: url_helper
INFO - 2019-06-08 05:25:47 --> Helper loaded: cookie_helper
INFO - 2019-06-08 05:25:47 --> Database Driver Class Initialized
DEBUG - 2019-06-08 05:25:47 --> Template library initialized
INFO - 2019-06-08 05:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-08 05:25:47 --> Controller Class Initialized
DEBUG - 2019-06-08 05:25:47 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-08 05:25:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-06-08 05:25:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/pay-casino.php
DEBUG - 2019-06-08 05:25:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-08 05:25:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-08 05:25:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-08 05:25:47 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-08 05:25:47 --> Final output sent to browser
DEBUG - 2019-06-08 05:25:47 --> Total execution time: 0.0545
INFO - 2019-06-08 06:45:11 --> Config Class Initialized
INFO - 2019-06-08 06:45:11 --> Hooks Class Initialized
DEBUG - 2019-06-08 06:45:11 --> UTF-8 Support Enabled
INFO - 2019-06-08 06:45:11 --> Utf8 Class Initialized
INFO - 2019-06-08 06:45:11 --> URI Class Initialized
DEBUG - 2019-06-08 06:45:11 --> No URI present. Default controller set.
INFO - 2019-06-08 06:45:11 --> Router Class Initialized
INFO - 2019-06-08 06:45:11 --> Output Class Initialized
INFO - 2019-06-08 06:45:11 --> Security Class Initialized
DEBUG - 2019-06-08 06:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-08 06:45:11 --> Input Class Initialized
INFO - 2019-06-08 06:45:11 --> Language Class Initialized
INFO - 2019-06-08 06:45:11 --> Language Class Initialized
INFO - 2019-06-08 06:45:11 --> Config Class Initialized
INFO - 2019-06-08 06:45:11 --> Loader Class Initialized
INFO - 2019-06-08 06:45:11 --> Helper loaded: form_helper
INFO - 2019-06-08 06:45:11 --> Helper loaded: url_helper
INFO - 2019-06-08 06:45:11 --> Helper loaded: cookie_helper
INFO - 2019-06-08 06:45:11 --> Database Driver Class Initialized
DEBUG - 2019-06-08 06:45:11 --> Template library initialized
INFO - 2019-06-08 06:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-08 06:45:11 --> Controller Class Initialized
DEBUG - 2019-06-08 06:45:11 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-08 06:45:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
ERROR - 2019-06-08 06:45:11 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:11 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:11 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:11 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:11 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:11 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:11 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:11 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:11 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:11 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:11 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:11 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:11 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:11 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:11 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:11 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:11 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:11 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:11 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:11 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:11 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:11 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
DEBUG - 2019-06-08 06:45:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-08 06:45:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-08 06:45:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-08 06:45:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-08 06:45:11 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-08 06:45:12 --> Final output sent to browser
DEBUG - 2019-06-08 06:45:12 --> Total execution time: 0.0721
INFO - 2019-06-08 06:45:14 --> Config Class Initialized
INFO - 2019-06-08 06:45:14 --> Hooks Class Initialized
DEBUG - 2019-06-08 06:45:14 --> UTF-8 Support Enabled
INFO - 2019-06-08 06:45:14 --> Utf8 Class Initialized
INFO - 2019-06-08 06:45:14 --> URI Class Initialized
DEBUG - 2019-06-08 06:45:14 --> No URI present. Default controller set.
INFO - 2019-06-08 06:45:14 --> Router Class Initialized
INFO - 2019-06-08 06:45:14 --> Output Class Initialized
INFO - 2019-06-08 06:45:14 --> Security Class Initialized
DEBUG - 2019-06-08 06:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-08 06:45:14 --> Input Class Initialized
INFO - 2019-06-08 06:45:14 --> Language Class Initialized
INFO - 2019-06-08 06:45:14 --> Language Class Initialized
INFO - 2019-06-08 06:45:14 --> Config Class Initialized
INFO - 2019-06-08 06:45:14 --> Loader Class Initialized
INFO - 2019-06-08 06:45:14 --> Helper loaded: form_helper
INFO - 2019-06-08 06:45:14 --> Helper loaded: url_helper
INFO - 2019-06-08 06:45:14 --> Helper loaded: cookie_helper
INFO - 2019-06-08 06:45:14 --> Database Driver Class Initialized
DEBUG - 2019-06-08 06:45:14 --> Template library initialized
INFO - 2019-06-08 06:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-08 06:45:14 --> Controller Class Initialized
DEBUG - 2019-06-08 06:45:14 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-08 06:45:14 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
ERROR - 2019-06-08 06:45:14 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:14 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:14 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:14 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:14 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:14 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:14 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:14 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:14 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:14 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:14 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:14 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:14 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:14 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:14 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:14 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:14 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:14 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:14 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:14 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:14 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:45:14 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
DEBUG - 2019-06-08 06:45:14 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-08 06:45:14 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-08 06:45:14 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-08 06:45:14 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-08 06:45:14 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-08 06:45:14 --> Final output sent to browser
DEBUG - 2019-06-08 06:45:14 --> Total execution time: 0.0791
INFO - 2019-06-08 06:45:18 --> Config Class Initialized
INFO - 2019-06-08 06:45:18 --> Hooks Class Initialized
DEBUG - 2019-06-08 06:45:18 --> UTF-8 Support Enabled
INFO - 2019-06-08 06:45:18 --> Utf8 Class Initialized
INFO - 2019-06-08 06:45:18 --> URI Class Initialized
INFO - 2019-06-08 06:45:18 --> Router Class Initialized
INFO - 2019-06-08 06:45:18 --> Output Class Initialized
INFO - 2019-06-08 06:45:18 --> Security Class Initialized
DEBUG - 2019-06-08 06:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-08 06:45:18 --> Input Class Initialized
INFO - 2019-06-08 06:45:18 --> Language Class Initialized
ERROR - 2019-06-08 06:45:18 --> 404 Page Not Found: /index
INFO - 2019-06-08 06:58:58 --> Config Class Initialized
INFO - 2019-06-08 06:58:58 --> Hooks Class Initialized
DEBUG - 2019-06-08 06:58:58 --> UTF-8 Support Enabled
INFO - 2019-06-08 06:58:58 --> Utf8 Class Initialized
INFO - 2019-06-08 06:58:58 --> URI Class Initialized
DEBUG - 2019-06-08 06:58:58 --> No URI present. Default controller set.
INFO - 2019-06-08 06:58:58 --> Router Class Initialized
INFO - 2019-06-08 06:58:58 --> Output Class Initialized
INFO - 2019-06-08 06:58:58 --> Security Class Initialized
DEBUG - 2019-06-08 06:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-08 06:58:58 --> Input Class Initialized
INFO - 2019-06-08 06:58:58 --> Language Class Initialized
INFO - 2019-06-08 06:58:58 --> Language Class Initialized
INFO - 2019-06-08 06:58:58 --> Config Class Initialized
INFO - 2019-06-08 06:58:58 --> Loader Class Initialized
INFO - 2019-06-08 06:58:58 --> Helper loaded: form_helper
INFO - 2019-06-08 06:58:58 --> Helper loaded: url_helper
INFO - 2019-06-08 06:58:58 --> Helper loaded: cookie_helper
INFO - 2019-06-08 06:58:58 --> Database Driver Class Initialized
DEBUG - 2019-06-08 06:58:58 --> Template library initialized
INFO - 2019-06-08 06:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-08 06:58:58 --> Controller Class Initialized
DEBUG - 2019-06-08 06:58:58 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-08 06:58:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
ERROR - 2019-06-08 06:58:58 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:58:58 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:58:58 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:58:58 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:58:58 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:58:58 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:58:58 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:58:58 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:58:58 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:58:58 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:58:58 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:58:58 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:58:58 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:58:58 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:58:58 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:58:58 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:58:58 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:58:58 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:58:58 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:58:58 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:58:58 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
ERROR - 2019-06-08 06:58:58 --> Severity: Notice --> Undefined index: subcategory_image /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php 168
DEBUG - 2019-06-08 06:58:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/paystore.php
DEBUG - 2019-06-08 06:58:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-08 06:58:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-08 06:58:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-08 06:58:58 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-08 06:59:02 --> Final output sent to browser
DEBUG - 2019-06-08 06:59:02 --> Total execution time: 0.0657
INFO - 2019-06-08 06:59:30 --> Config Class Initialized
INFO - 2019-06-08 06:59:30 --> Hooks Class Initialized
DEBUG - 2019-06-08 06:59:30 --> UTF-8 Support Enabled
INFO - 2019-06-08 06:59:30 --> Utf8 Class Initialized
INFO - 2019-06-08 06:59:30 --> URI Class Initialized
INFO - 2019-06-08 06:59:30 --> Router Class Initialized
INFO - 2019-06-08 06:59:30 --> Output Class Initialized
INFO - 2019-06-08 06:59:30 --> Security Class Initialized
DEBUG - 2019-06-08 06:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-08 06:59:30 --> Input Class Initialized
INFO - 2019-06-08 06:59:30 --> Language Class Initialized
INFO - 2019-06-08 06:59:30 --> Language Class Initialized
INFO - 2019-06-08 06:59:30 --> Config Class Initialized
INFO - 2019-06-08 06:59:30 --> Loader Class Initialized
INFO - 2019-06-08 06:59:30 --> Helper loaded: form_helper
INFO - 2019-06-08 06:59:30 --> Helper loaded: url_helper
INFO - 2019-06-08 06:59:30 --> Helper loaded: cookie_helper
INFO - 2019-06-08 06:59:30 --> Database Driver Class Initialized
DEBUG - 2019-06-08 06:59:30 --> Template library initialized
INFO - 2019-06-08 06:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-08 06:59:30 --> Controller Class Initialized
DEBUG - 2019-06-08 06:59:30 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-08 06:59:30 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-06-08 06:59:30 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/dth.php
DEBUG - 2019-06-08 06:59:30 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-08 06:59:30 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-08 06:59:30 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-08 06:59:30 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-08 06:59:35 --> Final output sent to browser
DEBUG - 2019-06-08 06:59:35 --> Total execution time: 0.0559
INFO - 2019-06-08 06:59:38 --> Config Class Initialized
INFO - 2019-06-08 06:59:38 --> Hooks Class Initialized
DEBUG - 2019-06-08 06:59:38 --> UTF-8 Support Enabled
INFO - 2019-06-08 06:59:38 --> Utf8 Class Initialized
INFO - 2019-06-08 06:59:38 --> URI Class Initialized
INFO - 2019-06-08 06:59:38 --> Router Class Initialized
INFO - 2019-06-08 06:59:38 --> Output Class Initialized
INFO - 2019-06-08 06:59:38 --> Security Class Initialized
DEBUG - 2019-06-08 06:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-08 06:59:38 --> Input Class Initialized
INFO - 2019-06-08 06:59:38 --> Language Class Initialized
INFO - 2019-06-08 06:59:38 --> Language Class Initialized
INFO - 2019-06-08 06:59:38 --> Config Class Initialized
INFO - 2019-06-08 06:59:38 --> Loader Class Initialized
INFO - 2019-06-08 06:59:38 --> Helper loaded: form_helper
INFO - 2019-06-08 06:59:38 --> Helper loaded: url_helper
INFO - 2019-06-08 06:59:38 --> Helper loaded: cookie_helper
INFO - 2019-06-08 06:59:38 --> Database Driver Class Initialized
DEBUG - 2019-06-08 06:59:38 --> Template library initialized
INFO - 2019-06-08 06:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-08 06:59:38 --> Controller Class Initialized
DEBUG - 2019-06-08 06:59:38 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-08 06:59:38 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-06-08 06:59:38 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/landline.php
DEBUG - 2019-06-08 06:59:38 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-08 06:59:38 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-08 06:59:38 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-08 06:59:38 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-08 06:59:41 --> Final output sent to browser
DEBUG - 2019-06-08 06:59:41 --> Total execution time: 0.0634
INFO - 2019-06-08 06:59:50 --> Config Class Initialized
INFO - 2019-06-08 06:59:50 --> Hooks Class Initialized
DEBUG - 2019-06-08 06:59:50 --> UTF-8 Support Enabled
INFO - 2019-06-08 06:59:50 --> Utf8 Class Initialized
INFO - 2019-06-08 06:59:50 --> URI Class Initialized
INFO - 2019-06-08 06:59:50 --> Router Class Initialized
INFO - 2019-06-08 06:59:50 --> Output Class Initialized
INFO - 2019-06-08 06:59:50 --> Security Class Initialized
DEBUG - 2019-06-08 06:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-08 06:59:50 --> Input Class Initialized
INFO - 2019-06-08 06:59:50 --> Language Class Initialized
INFO - 2019-06-08 06:59:50 --> Language Class Initialized
INFO - 2019-06-08 06:59:50 --> Config Class Initialized
INFO - 2019-06-08 06:59:50 --> Loader Class Initialized
INFO - 2019-06-08 06:59:50 --> Helper loaded: form_helper
INFO - 2019-06-08 06:59:50 --> Helper loaded: url_helper
INFO - 2019-06-08 06:59:50 --> Helper loaded: cookie_helper
INFO - 2019-06-08 06:59:50 --> Database Driver Class Initialized
DEBUG - 2019-06-08 06:59:50 --> Template library initialized
INFO - 2019-06-08 06:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-08 06:59:50 --> Controller Class Initialized
DEBUG - 2019-06-08 06:59:50 --> Paystore MX_Controller Initialized
DEBUG - 2019-06-08 06:59:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/models/Paystore_model.php
DEBUG - 2019-06-08 06:59:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/modules/paystore/views/landline.php
DEBUG - 2019-06-08 06:59:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/navigation.php
DEBUG - 2019-06-08 06:59:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/sidebar.php
DEBUG - 2019-06-08 06:59:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/widgets/footer.php
DEBUG - 2019-06-08 06:59:50 --> File loaded: /var/sentora/hostdata/zadmin/public_html/beta_paystoreonline_com/application/views/layouts/master.php
INFO - 2019-06-08 06:59:52 --> Final output sent to browser
DEBUG - 2019-06-08 06:59:52 --> Total execution time: 0.0543
INFO - 2019-06-08 07:00:20 --> Config Class Initialized
INFO - 2019-06-08 07:00:20 --> Hooks Class Initialized
DEBUG - 2019-06-08 07:00:20 --> UTF-8 Support Enabled
INFO - 2019-06-08 07:00:20 --> Utf8 Class Initialized
INFO - 2019-06-08 07:00:20 --> URI Class Initialized
INFO - 2019-06-08 07:00:20 --> Router Class Initialized
INFO - 2019-06-08 07:00:20 --> Output Class Initialized
INFO - 2019-06-08 07:00:20 --> Security Class Initialized
DEBUG - 2019-06-08 07:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-08 07:00:20 --> Input Class Initialized
INFO - 2019-06-08 07:00:20 --> Language Class Initialized
ERROR - 2019-06-08 07:00:20 --> 404 Page Not Found: /index
