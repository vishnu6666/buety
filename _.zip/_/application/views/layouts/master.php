
<!DOCTYPE html>
<html lang="en">

<!--------------------------------------------
/*********************************************/
/*   created by Magictechnolabs Pvt Ltd.     */
/*********************************************/
---------------------------------------------->

<head>
  <!-- Meta tags -->
  <title><?php echo $this->template->title->default("Default title"); ?></title>
  <meta name="keywords" content="Photosnap a Photography Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
  Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <?php echo $this->template->meta; ?> 
  <!-- stylesheets -->

  <link rel="stylesheet" href="<?php echo base_url('Assets/NewDesign/css/bootstrap.min.css');?>">
  <link rel="stylesheet" href="<?php echo base_url('Assets/NewDesign/font/css/font-awesome.css');?>">
  <link rel="stylesheet" href="<?php echo base_url('Assets/NewDesign/css/style.css');?>">
  <!--  <link rel="stylesheet" href="<?php echo base_url('Assets/NewDesign/css/customstyle.css');?>"> -->
  <link rel="stylesheet" href="<?php echo base_url('Assets/NewDesign/css/responsive.css');?>">
  <link rel="stylesheet" href="<?php echo base_url('Assets/NewDesign/css/owl.carousel.css');?>">
  <link rel="stylesheet" href="<?php echo base_url('Assets/NewDesign/css/owl.theme.default.css');?>">
  <!--    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">-->
  <link rel="icon" href="<?php echo base_url('Assets/NewDesign/images/fevicon.png');?>" type="image/png" sizes="32x32">
  <link href="https://fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">

  <!-- jQuery library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

  <?php echo $this->template->stylesheet; ?>

  <style type="text/css">
  .model_size {
    max-width: 100%;
  }
  .more_model {
    display: none;
    position: fixed;
    left: 50%;
    right: 0;
    top: 243px!important;
    background-color: #fff;
    padding: 0;
    max-height: 70%;
    width: 20%;
    margin: auto;
    overflow-y: auto;
    border-radius: 2px;
    will-change: top, opacity;

  }
  .z-depth-4, .more_model {
    -webkit-box-shadow: 0 8px 10px 1px rgba(0,0,0,0.14), 0 3px 14px 2px rgba(0,0,0,0.12), 0 5px 5px -3px rgba(0,0,0,0.3);
    box-shadow: 0 8px 10px 1px rgba(0,0,0,0.14), 0 3px 14px 2px rgba(0,0,0,0.12), 0 5px 5px -3px rgba(0,0,0,0.3);
  }
  .more_model .modal-content {
    padding: 24px;
  }
  .modal-overlay {
    position: fixed;
    z-index: 999;
    top: -25%;
    left: 0;
    bottom: 0;
    right: 0;
    height: 125%;
    width: 100%;
    background: #000;
    display: none;
    will-change: opacity;
  }
</style>

</head>

<body>

  <div class="container-fluid"><!--- start container-fluid--->

    <?php echo $this->template->widget("navigation"); ?>

    <div class="col-xl-12 middleSection"><!--- strat middleSection--->

      <?php echo $this->template->widget("sidebar"); ?>

      <?php echo $this->template->content; ?> 

      <?php echo $this->template->widget("footer"); ?>

      <script src="<?php echo base_url('Assets/NewDesign/js/jquery.min.js');?>"></script>
      <script src="<?php echo base_url('Assets/NewDesign/js/bootstrap.js');?>"></script>
      <script src="<?php echo base_url('Assets/NewDesign/js/wow.min.js');?>"></script>
      <script src="<?php echo base_url('Assets/NewDesign/js/owl.carousel.min.js');?>"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
      <script src="<?php echo base_url('Assets/NewDesign/js/sidebar.js');?>"></script>
      <script src="<?php echo base_url('Assets/angular/angular.min.js');?>"></script>
    <!-- <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
      <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script> -->
      <?php echo $this->template->javascript; ?>

    </div>
  </body>
  </html>

  <script>

    $(document).ready(function(){
      toggelOption = false;
      $('#main').css('paddingLeft', '280px');
      $('#mySidebar').css('width', '280px');
    });

    $("#slide-toggle").click(function(){
      if(toggelOption === false){
        $("#mySidebar").animate({
          width: "toggle",
          fadeToggle: "hide"
        });
        $('#main').css('paddingLeft', '0px');
//            $('#mySidebar').hide(1000);

toggelOption = true;
}else{
  $("#mySidebar").animate({
    width: "toggle",
    fadeToggle: "show"
  });


  $('#main').css('paddingLeft', '280px');
//            $('#mySidebar').css('width', '280px');
//            $('#mySidebar').show(1000);

toggelOption = false;
}
});

// end menu js
</script>

<script type="text/javascript">
  $(".button-collapse").sideNav();

  $('.button-collapse').sideNav({
     // menuWidth: 300, // Default is 300
      edge: 'right', // Choose the horizontal origin
      // closeOnClick: true, // Closes side-nav on <a> clicks, useful for Angular/Meteor
      // draggable: true, // Choose whether you can drag to open on touch screens,
    //  onOpen: function(el) {  }, // A function to be called when sideNav is opened
    //  onClose: function(el) {  }, // A function to be called when sideNav is closed
  }
  );
  
  $('#hide_sidebar_login').click(function(){
    $('#hide_sidebar').sideNav('destroy');
  });
  $('#hide_sidebar_signup').click(function(){
    $('#hide_sidebar').sideNav('destroy');
  });         
</script>

<script>
  $('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    responsiveClass:true,
    responsive:{
      0:{
        items:1,
        nav:true
      },
      600:{
        items:3,
        nav:false
      },
      1000:{
        items:6,
        nav:true,
        loop:false
      }
    }
  })
</script>


























































