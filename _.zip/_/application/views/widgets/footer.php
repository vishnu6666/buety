                <div class="col-xl-12 footerSection paddingLeftRight">
                    <div class="row">
                        <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                            <h2 class=" color2"> Pay Store Online</h2>
                            <p class=" color2">CopyRight © 2019 Paystoreonline.com <br>All right reserved.</p>
                        </div>
                        <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 footerMenu">
                            <h5 class="color2"> Services</h5>
                            <ul>
                                <li><a href="">Pay Bills</a></li>
                                <li><a href="">Air Booking</a></li>
                                <li><a href="">Railway booking</a></li>
                                <li><a href="">Bus Booking</a></li>
                                <li><a href="">DTH & Mobile Recharge</a></li>
                                <li><a href="">Money transfer</a></li>
                            </ul>
                        </div>
                        <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 footerMenu">
                            <h5 class="color2"> Contact Us</h5>
                            <ul>
                                <li><span>Address</span> <p>: Paystore Online Solutions Ltd, P.o.box 20503, Dar-es-Salaam, Tanzania </p></li>
                                <li><span>Email</span> <p>:info@paystoreonline.com</p></li>
                                <li><span>Call</span> <p>: +255 682 232943</p></li>
                            </ul>
                        </div>
                        <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                            <h5 class=" color2"> Social Media</h5>

                        </div>
                    </div>
                </div>

           </div><!--- end main--->
        </div><!--- end middleSection--->

    </div>
