<div id="mySidebar" style="width: 280px;"><!--- strat mySidebar--->
	<ul>
		<li><a href="#"><svg class="sidebar_svg" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 129 129" xmlns:xlink="http://www.w3.org/1999/xlink" enable-background="new 0 0 129 129">
			<g>
				<path d="m57.4,122.2c0.5,0.2 1,0.3 1.5,0.3 1.3,0 2.6-0.6 3.4-1.8l42.9-62c0.9-1.2 1-2.9 0.3-4.2-0.7-1.3-2.1-2.2-3.6-2.2l-26.6-.2 7.7-40.8c0.4-1.8-0.6-3.7-2.3-4.5-1.7-0.8-3.7-0.3-4.9,1.2l-45.5,57.3c-1,1.2-1.2,2.9-0.5,4.3 0.7,1.4 2.1,2.3 3.7,2.3l29.4,.2-7.9,45.6c-0.4,1.9 0.6,3.8 2.4,4.5zm-15.5-58.4l30-37.8-5.6,29.5c-0.2,1.2 0.1,2.4 0.9,3.4 0.8,0.9 1.9,1.5 3.1,1.5l23.7,.1-27.9,40.4 5.5-32.2c0.2-1.2-0.1-2.4-0.9-3.3-0.7-0.9-1.8-1.4-3-1.4l-25.8-.2z"></path>
			</g></svg> Recharge &amp; Bill Pay</a>
		</li>
		<li> <a href="#"><span><img class="sidebar_svg" src="http://beta.paystoreonline.com/Assets/NewDesign/images/bank_transfer.png"></span> Transfer to Bank</a></li>
		<li> <a href="#"><span><img class="sidebar_svg" src="http://beta.paystoreonline.com/Assets/NewDesign/images/offer_deal.png"></span> Offer &amp; Deals</a></li>
		<li> <a href="#"><span><img class="sidebar_svg" src="http://beta.paystoreonline.com/Assets/NewDesign/images/local_store.png"></span> Local Store</a></li>
		<li> <a href="#"><span><i class="fa fa-home" aria-hidden="true"></i></span> Redeem Payback Point</a></li>
		<li> <a href="#"><span><img class="sidebar_svg" src="http://beta.paystoreonline.com/Assets/NewDesign/images/wallet_transfer.png"></span> Wallet Transfer</a></li>
		<li> <a href="http://payment.paystoreonline.com"><span><img class="sidebar_svg" src="http://beta.paystoreonline.com/Assets/NewDesign/images/payment_getway.png"></span> Payment Gateway</a></li>

	</ul>
</div>


