<div class="row">
 <header class="col-xl-12 topHeader bgColor1"><!--- start Header--->
  <div class="row">
    <div class="col-xl-6 col-gl-6 col-md-6 col-sm-7 ">
      <div class="menuAndLogo">
        <i id="slide-toggle" class="fa fa-bars" aria-hidden="true"></i><span class="logo"><a href="<?php echo base_url();?>">
          <img src="<?php echo base_url('Assets/NewDesign/images/logo11.png');?>" class="img-fluid"/><span>PayStore</span></a></span>
        </div>
      </div>
      <div class="col-xl-6 col-gl-6 col-md-6 col-sm-5 LoginAndSignUp">
        <ul>
          <?php if($this->session->userdata('logged_in') != '1'){?><li><a href="" data-toggle="modal" data-target="#ModalLogin">Login</a></li> 
          <li><a href="" data-toggle="modal" data-target="#signUpLogin">Sign Up</a></li><?php }?>
          <li><a href="" data-activates="slide-out" class="button_radius button-collapse" tabindex="-1"><i class="fa fa-user"></i></a></li>
        </ul>
      </div>
    </div>
  </header><!--- end Header--->



  <!--- Start SideNav--->
  <mbk-side-bar  id="slide-out" class="side-nav">
   <span _ngcontent-c7="">
    <div _ngcontent-c7="" class="cmrgtmnu rightmenuwrpr tleft">

     <div _ngcontent-c7="" class="col-md-12 whitebg ucur bluebgdark2 twhite spleft20 spright20 sptop20 spbottom24">
      <div _ngcontent-c7="" class="dpTable wdFull sptop15 spbottom22">
    <?php if($this->session->userdata('logged_in') != '1'){?>
      <span _ngcontent-c7="" class="dpTbCellMid">
        <div _ngcontent-c7="" class="brad50 whitebg ulgo"><img src="http://beta.paystoreonline.com/Assets/NewDesign/images/logo_sidebar.png" class="img-fluid sptop2"></div>
      </span> 
      <span _ngcontent-c7="" class="dpTbCellMid pad7 pleft ">
        <p _ngcontent-c7="" class="Ucase ft15 fw500 ln23">PAYSTORE</p>
        <p _ngcontent-c7="" class="Ucase ft13">Paisa Bana Powerful</p>
      </span> <?php }else{?>
      <div _ngcontent-c7="" class="dpTable wdFull sptop35 spleft20 spbottom18" style="padding-right: 14px;"><span _ngcontent-c7="" class="dpTbCellMid"><div _ngcontent-c7="" class="brad50 whitebg ulgo"><i _ngcontent-c7="" class="mg mg_icouser ft20 ln40 sptop2 gradbg7_bf"></i></div></span><span _ngcontent-c7="" class="dpTbCellMid pad20 pleft "><p _ngcontent-c7="" class="ellipsis width180 ft15"> <?php echo $this->session->userdata('fname').' '.$this->session->userdata('lname'); ?></p><p _ngcontent-c7="" class="ellipsis width180 ft12"><?php echo $this->session->userdata('email'); ?></p><p _ngcontent-c7="" class="ellipsis width180 ft12"><?php echo $this->session->userdata('mobile_number'); ?></p></span></div>
    <?php }?>
    </div>
    <div _ngcontent-c7="" class="row">
    <?php if($this->session->userdata('logged_in') != '1'){?>
     <div _ngcontent-c7="" class="col-md-6 spright5">
      <button _ngcontent-c7="" class="cmat btn bt36 btn-primary wdFull bfancy nobdr gradbg7 mat-flat-button mat-primary" data-toggle="modal" data-target="#ModalLogin" id="hide_sidebar_login" type="button">
       <span class="mat-button-wrapper">Login</span>
       <div class="mat-button-ripple mat-ripple" matripple=""></div>
       <div class="mat-button-focus-overlay"></div>
     </button>
   </div>
   <div _ngcontent-c7="" class="col-md-6 spleft5">
    <button _ngcontent-c7="" class="cmat btn bt36 btn-white wdFull bfancy nobg mat-flat-button mat-primary hideS"  data-toggle="modal" data-target="#signUpLogin" id="hide_sidebar_signup" type="button">
     <span class="mat-button-wrapper">Signup</span>
     <div class="mat-button-ripple mat-ripple" matripple=""></div>
     <div class="mat-button-focus-overlay"></div>
   </button>
 </div>
<?php }else{?>

 <div _ngcontent-c7="" class="col-md-12 spright5">
      <button _ngcontent-c7="" class="cmat btn bt36 btn-primary wdFull bfancy nobdr gradbg7 mat-flat-button mat-primary" data-toggle="modal" data-target="#ModalUpdateKYC" id="hide_sidebar_login" type="button">
       <span class="mat-button-wrapper">Update KYC</span>
       <div class="mat-button-ripple mat-ripple" matripple=""></div>
       <div class="mat-button-focus-overlay"></div>
     </button>
   </div>
 <?php }?>
</div>
</div>

<div _ngcontent-c7="" class="col-md-12 spleft0 spright0">
  <ul _ngcontent-c7="" class="list_stype layernav nolisttype smtop16 spleft20 spright20">
   <li _ngcontent-c7=""><a class="list_margin" href="/"><i  class="ft17 icon_margin fa fa-home dpInBLockMid"></i><span _ngcontent-c7="" class="fw600 dpInBLockMid ft13">Home</span></a></li>
   <li _ngcontent-c7=""><a class="list_margin"><i  class="ft17 icon_margin fa fa-home dpInBLockMid"></i><span _ngcontent-c7="" class="fw600 dpInBLockMid ft13">Upgrade Wallet</span></a></li>
   <li _ngcontent-c7=""><a class="list_margin" href="/redeem-voucher"><i  class="ft17 icon_margin fa fa-home dpInBLockMid"></i><span _ngcontent-c7="" class="fw600 dpInBLockMid ft13">Redeem Voucher</span></a></li>
   <li _ngcontent-c7=""><a class="list_margin" href="/help"><i  class="ft17 icon_margin fa fa-home dpInBLockMid"></i><span _ngcontent-c7="" class="fw600 dpInBLockMid ft13">Help</span></a></li>
   <li _ngcontent-c7=""><a class="list_margin" href="/press"><i  class="ft17 icon_margin fa fa-home dpInBLockMid"></i><span _ngcontent-c7="" class="fw600 dpInBLockMid ft13">Press</span></a></li>
   <?php if($this->session->userdata('logged_in') == '1'){?>
   <li _ngcontent-c7=""><a class="list_margin" href="<?php echo  base_url('api/logout')?>"><i  class="ft17 icon_margin fa fa-home dpInBLockMid"></i><span _ngcontent-c7="" class="fw600 dpInBLockMid ft13" >Logout</span></a></li>
 <?php }?>
 </ul>
</div>
</div>
</span>
</mbk-side-bar>
<!--- End SideNav--->



<!-- Strat Modal Login -->
<div class="loginModel">
  <div class="modal fade " id="ModalLogin" >
    <div class="modal-dialog modal-dialog-centered modal-lg" >
      <div class="modal-content">
        <button type="button" class="close" data-dismiss="modal" >&times;</button>
        <div class="modal-body ">

          <div class="row">
            <div class="col-xl-5  col-lg-5 d-none d-lg-block loginSlider">
              <div id="demo" class="carousel slide" data-ride="carousel">

                <!-- Indicators -->
                <ul class="carousel-indicators">
                  <li data-target="#demo" data-slide-to="0" class="active"></li>
                  <li data-target="#demo" data-slide-to="1"></li>
                  <li data-target="#demo" data-slide-to="2"></li>
                </ul>

                <!-- The slideshow -->
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img src="<?php echo base_url('Assets/NewDesign/images/imgLogin1.png');?>" class="img-fluid" alt="login1" title="login1"/>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                  </div>
                  <div class="carousel-item ">
                    <img src="<?php echo base_url('Assets/NewDesign/images/imgLogin2.png');?>" class="img-fluid" alt="login2" title="login2"/>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                  </div>
                  <div class="carousel-item">
                    <img src="<?php echo base_url('Assets/NewDesign/images/imgLogin3.png');?>" class="img-fluid" alt="login3" title="login3"/>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                  </div>
                </div>


              </div>
            </div>
            <div class="col-xl-7 col-md-12 col-lg-7 loginInpitModal">
              <div class="loginOTP" id="loginOTP">
                <h1>Login</h1>
                <label>Enter Mobile Number</label>
                <form>
                  <div class="form-group">
                    <input type="text" class="form-control inputBox" id="mobile_no" name="mobile_no" placeholder="Mobile No (+91)"/>
                    <p class="p12 text-center color7"><span name="errorphone" style="margin-right: 148px;color: red;" id="errorphone"
                     data-valmsg-for="phone_number" data-valmsg-replace="true"><?php echo form_error('errorphone'); ?></span>
                   </p>
                 </div>
                 <button class="btn goButtob" type="button" onclick="login()">Get OTP</button>
               </form>
               <div class="loginInpitModalPera">
                <p>New to PayStore <span id="LoginHide"> Create Wallet</span></p>
              </div>
            </div>

            <div class="Verify_otp_login" id="Verify_otp_login" style="display: none;">
              <h1>Login</h1>
              <label>Enter OTP</label>
              <form>
                <div class="form-group">
                  <div class="pull-right"><a href="javascript:void(0);" class="resend_otp_login">Resent OTP</a></div>
                  <input type="password" class="form-control inputBox" id="otp" name="otp" placeholder="Enter OTP"/>
                  <p class="p12 text-center color7"><span name="errorOtpLogin" style="margin-right: 148px;color: red;" id="errorOtpLogin"
                   data-valmsg-for="errorOtpLogin" data-valmsg-replace="true"><?php echo form_error('errorOtpLogin'); ?></span>
                 </p>
               </div>
               <button class="btn goButtob" type="button" onclick="otp_check_login()" style="width: 131px;">Submit OTP</button>
             </form>
             <div class="loginInpitModalPera">
              <p>New to PayStore <span id="LoginHideOtp"> Create Wallet</span></p>
            </div>
          </div>

          <div class="signUpOTP" style="display: none;">
            <h1>Sign Up</h1>
            <label>Enter Mobile Number</label>
            <form action="<?php echo base_url('api/signup'); ?>" method="post">
              <div class="form-group">
                <input type="text" class="form-control inputBox" id="mobile_no_lsignup" name="mobile_no_lsignup" placeholder="Mobile No (+91)" />
                <p  class="p12 text-center color7"><span name="errorphone_lsignup" id="errorphone_lsignup"
                 data-valmsg-for="phone_number"  style="margin-right: 148px;color: red;" data-valmsg-replace="true"><?php echo form_error('errorphone_signup'); ?></span>
               </p>
             </div>
             <label>Enter Email ID(Optional)</label>
             <div class="form-group">
              <input type="email" class="form-control inputBox" id="email_lsignup" name="email_lsignup"  placeholder="Enter Email ID(Optional)" />
            </div>
            <button class="btn goButtob" type="button" onclick="login_signup()">Get OTP</button>
          </form>
          <div class="loginInpitModalPera" style="margin-bottom: -9px;">
            <p>Already have a PayStore Wallet? <span  id="SignUpHide"> Login Now</span></p>
          </div>
        </div> 


        <div class="Verify_otp_lsignup" id="Verify_otp_lsignup" style="display: none;">
          <h1>Sign Up</h1>
          <label>Enter OTP</label>
          <form>
            <div class="form-group">
              <div class="pull-right"><a href="javascript:void(0);" class="resend_otp_signup">Resent OTP</a></div>
              <input type="password" class="form-control inputBox" id="otp_check_lsignup" name="otp_check_lsignup" placeholder="Enter OTP"/>
              <p class="p12 text-center color7"><span name="errorotplSignup" id="errorotplSignup"
               data-valmsg-for="otp_check_lsignup" style="margin-right: 148px;color: red;" data-valmsg-replace="true"><?php echo form_error('errorotplSignup'); ?></span>
             </p>
           </div>
           <button class="btn goButtob" type="button" onclick="otpCheck_lsignup()" style="width: 131px;">Submit OTP</button>
         </form>
         <div class="loginInpitModalPera">
          <p>New to PayStore <span id="SignUpHideOtp"> Login Now</span></p>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
</div>
</div>
</div>
<!-- end Modal Login -->



<!-- Strat Modal SIGNUP -->
<div class="loginModel">
  <div class="modal fade " id="signUpLogin" >
    <div class="modal-dialog modal-dialog-centered modal-lg" >
      <div class="modal-content">
        <button type="button" class="close" data-dismiss="modal" >&times;</button>
        <div class="modal-body ">

          <div class="row">
            <div class="col-xl-5  col-lg-5 d-none d-lg-block loginSlider">
              <div id="demo" class="carousel slide" data-ride="carousel">

                <!-- Indicators -->
                <ul class="carousel-indicators">
                  <li data-target="#demo" data-slide-to="0" class="active"></li>
                  <li data-target="#demo" data-slide-to="1"></li>
                  <li data-target="#demo" data-slide-to="2"></li>
                </ul>

                <!-- The slideshow -->
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img src="<?php echo base_url('Assets/NewDesign/images/imgLogin1.png');?>" class="img-fluid" alt="login1" title="login1"/>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                  </div>
                  <div class="carousel-item ">
                    <img src="<?php echo base_url('Assets/NewDesign/images/imgLogin2.png');?>" class="img-fluid" alt="login2" title="login2"/>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                  </div>
                  <div class="carousel-item">
                    <img src="<?php echo base_url('Assets/NewDesign/images/imgLogin3.png');?>" class="img-fluid" alt="login3" title="login3"/>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                  </div>
                </div>


              </div>
            </div>
            <div class="col-xl-7  col-lg-7 col-md-12 loginInpitModal">
              <div class="loginOTP" style="display: none;">
                <h1>Login</h1>
                <label>Enter Mobile Number</label>
                <form>
                  <div class="form-group">
                    <input type="text" class="form-control inputBox" id="mobile_no_slogin" placeholder="Mobile No (+91)"  />
                    <p class="p12 text-center color7"><span name="errorSlogin" id="errorSlogin"
                     data-valmsg-for="mobile_no" style="margin-right: 148px;color: red;" data-valmsg-replace="true"><?php echo form_error('errorSlogin'); ?></span>
                   </p>
                 </div>
                 <button class="btn goButtob" type="button" onclick="signnup_login()">Get OTP</button>
               </form>
               <div class="loginInpitModalPera">
                <p>New to PayStore <span id="LoginHide1"> Create Wallet</span></p>
              </div>
            </div>

            <div class="Verify_otp_slogin" id="Verify_otp_slogin" style="display: none;">
              <h1>Login</h1>
              <label>Enter OTP</label>
              <form>
                <div class="form-group">
                  <div class="pull-right"><a href="javascript:void(0);" class="resend_otp_login">Resent OTP</a></div>
                  <input type="password" class="form-control inputBox" id="otp_check_slogin" name="otp_check_slogin" placeholder="Enter OTP"/>
                  <p class="p12 text-center color7"><span name="errorOtpsLogin" id="errorOtpsLogin"
                   data-valmsg-for="otp_check_slogin" style="margin-right: 148px;color: red;" data-valmsg-replace="true"><?php echo form_error('errorOtpsLogin'); ?></span>
                 </p>
               </div>
               <button class="btn goButtob" type="button" onclick="otpcheckSlogin()" style="width: 131px;">Submit OTP</button>
             </form>
             <div class="loginInpitModalPera">
              <p>New to PayStore <span id="LoginHide1Otp"> Create Wallet</span></p>
            </div>
          </div>

          <div class="signUpOTP">
            <h1>Sign Up</h1>
            <label>Enter Mobile Number</label>
            <form>
              <div class="form-group">
                <input type="text" class="form-control inputBox" name="mobile_no_signup" id="mobile_no_signup" placeholder="Mobile No (+91)"  />
                <p class="p12 text-center color7"><span name="errorphone_signup" id="errorphone_signup"
                 data-valmsg-for="phone_number"  style="margin-right: 148px;color: red;" data-valmsg-replace="true"><?php echo form_error('errorphone_signup'); ?></span>
               </p>
             </div>

             <label>Enter Email ID(Optional)</label>
             <div class="form-group">
              <input type="Email" class="form-control inputBox" name="email_signup"  id="email_signup" placeholder="Enter Email ID(Optional)"  />
            </div>
            <button class="btn goButtob" type="button" onclick="signup()">Get OTP</button>
          </form>
          <div class="loginInpitModalPera" style="margin-bottom: -9px;">
            <p>Already have a PayStore Wallet? <span  id="SignUpHide1"> Login Now</span></p>
          </div>
        </div>

        <div class="Verify_otp_signup" id="Verify_otp_signup" style="display: none;">
          <h1>Sign Up</h1>
          <label>Enter OTP</label>
          <form>
            <div class="form-group">
              <div class="pull-right"><a href="javascript:void(0);" class="resend_otp_signup">Resent OTP</a></div>
              <input type="password" class="form-control inputBox" id="otp_check_signup" name="otp_check_signup" placeholder="Enter OTP"/>
              <p class="p12 text-center color7"><span name="errorotpSignup" id="errorotpSignup"
               data-valmsg-for="otp_check_signup" style="margin-right: 148px;color: red;" data-valmsg-replace="true"><?php echo form_error('errorotpSignup'); ?></span>
             </p>
           </div>
           <button class="btn goButtob" type="button" onclick="otpCheckSignup()" style="width: 131px;">Submit OTP</button>
         </form>
         <div class="loginInpitModalPera">
          <p>New to PayStore <span id="SignUpHide1Otp"> Login Now</span></p>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
</div>
</div>
</div>
<!-- end Modal SIGNUP -->


<script type="text/javascript">

  $(document).ready(function(){
    $('.more_model').modal();
  });

  $("#LoginHide").click(function(){
    $(".signUpOTP").show();
    $(".loginOTP").hide();

  });

  $("#SignUpHide").click(function(){
    $(".signUpOTP").hide();
    $(".loginOTP").show();
  });

  $("#LoginHide1").click(function(){
    $(".signUpOTP").show();
    $(".loginOTP").hide();

  });

  $("#SignUpHide1").click(function(){
    $(".signUpOTP").hide();
    $(".loginOTP").show();
  });


  $("#LoginHideOtp").click(function(){
    $(".signUpOTP").show();
    $(".Verify_otp_login").hide();

  });

  $("#SignUpHideOtp").click(function(){
    $(".Verify_otp_lsignup").hide();
    $(".loginOTP").show();
  });

  $("#LoginHide1Otp").click(function(){
    $(".signUpOTP").show();
    $(".Verify_otp_slogin").hide();

  });

  $("#SignUpHide1Otp").click(function(){
    $(".Verify_otp_signup").hide();
    $(".loginOTP").show();
  });
</script>

<script>
  function otpCheckSignup() {
  var otp_check_signup = $("#otp_check_signup").val();
  var numpattern = /^[0-9]*$/;
  var a = 0;
  if (otp_check_signup == '') {
    $("#errorotpSignup").text('Enter the OTP Code.');
    $("#errorotpSignup").css("display", "block");
    a = 0
  }

  if (a == 0) {
    $.ajax
    ({
      type: "POST",
      data: {otp_check_signup: otp_check_signup},
      url: "<?php echo base_url('api/otp_check_signup');?>",
      success: function (result) {
        if (result == 2) {
          window.location.href = "<?php echo base_url('paystore'); ?>";
        }
        else if (result == 1) {
          swal({
            title: "",
            text: "Please Enter Valid OTP",
            icon: "warning",
            confirmButtonColor: 'error'
          })
        }
      }
    });
  }
  else {
    return false;
  }
}

  function signup() {
    var mobile_no_signup = $("#mobile_no_signup").val();
    var email_signup = $("#email_signup").val();
    /*alert(mobile_no_signup);
    alert(email_signup);*/
    var numpattern = /^[0-9]*$/;
    var a = 0;
    if (mobile_no_signup == '') {
      $("#errorphone_signup").text('Enter the mobile number.');
      $("#errorphone_signup").css("display", "block");
      a = 1
    }
    else {
      if (!mobile_no_signup.match(numpattern)) {
        $("#errorphone_signup").text('Enter Only number.');
        $("#errorphone_signup").css("display", "block");
        a = 1;
      }
      else {
        if (mobile_no_signup.length < 8 || mobile_no_signup.length > 10) {
          $("#errorphone_signup").text('Please enter valid mobile number.');
          $("#errorphone_signup").css("display", "block");
          a = 1;
        }
        else {
          $("#errorphone_signup").text('');
          $("#errorphone_signup").css("display", "none");
          a = 0;
        }
      }
    }
    if (a == 0) {
      /*var datavalues = {
        'oldNumber' : Cookies.get('oldMobile'),
        'mobileNumber' : mobileNumber,
        'password' : password,
        'email' : email
      };*/
      $.ajax
      ({
        type: "POST",
        data: {email_signup: email_signup, mobile_no_signup: mobile_no_signup},
        url: "<?php echo base_url('api/signup');?>",
        success: function (result) {
          if (result == 4) {
            swal({
              title: "",
              text: "Already Register,Please Login",
              icon: "warning",
              confirmButtonColor: 'error'
            })
          }
          else if (result == 1) {
            $(".Verify_otp_signup").show();
            $(".signUpOTP").hide();
                    // $(".loginOTP").hide();
                  }

                }
              });
    }
    else {
      return false;
    }
  }

  function login() {
    var mobile_no = $("#mobile_no").val();
    var numpattern = /^[0-9]*$/;
    var a = 0;
    if (mobile_no == '') {
      $("#errorphone").text('Enter the mobile number.');
      $("#errorphone").css("display", "block");
      a = 1
    }
    else {
      if (!mobile_no.match(numpattern)) {
        $("#errorphone").text('Enter Only number.');
        $("#errorphone").css("display", "block");
        a = 1;
      }
      else {
        if (mobile_no.length < 8 || mobile_no.length > 10) {
          $("#errorphone").text('Please enter valid mobile number.');
          $("#errorphone").css("display", "block");
          a = 1;
        }
        else {
          $("#errorphone").text('');
          $("#errorphone").css("display", "none");
          a = 0;
        }
      }
    }
    if (a == 0) {
      $.ajax
      ({
        type: "POST",
        data: {mobile_no: mobile_no},
        url: "<?php echo base_url('api/login'); ?>",
        success: function (result) {
          if (result == 1) {
            swal({
              title: "",
              text: "Please Register Your Number",
              icon: "warning",
              confirmButtonColor: 'error'
            })
          }
          else if (result == 3) {
            $(".Verify_otp_login").show();
            $(".loginOTP").hide();
                    // $(".signUpOTP").hide();
                  }
                }
              });
    }
    else {
      return false;
    }
  }

  function otp_check_login() {
    var otp = $("#otp").val();
    var numpattern = /^[0-9]*$/;
    var a = 0;
    if (otp == '') {
      $("#errorOtpLogin").text('Enter the OTP Code.');
      $("#errorOtpLogin").css("display", "block");
      a = 0
    }

    if (a == 0) {
      $.ajax
      ({
        type: "POST",
        data: { otp: otp},
        url: "<?php echo base_url('api/otp_check_login');?>",
        success: function (result) {
          if (result == 2) {
            window.location.href = "<?php echo site_url(); ?>";
          }
          else if (result == 1) {
            swal({
              title: "",
              text: "Please Enter Valid OTP",
              icon: "warning",
              confirmButtonColor: 'error'
            })
          }
        }
      });
    }
    else {
      return false;
    }
  }

</script>

<script>

  function signnup_login() {
    var mobile_no = $("#mobile_no_slogin").val();
    var numpattern = /^[0-9]*$/;
    var a = 0;
    if (mobile_no == '') {
      $("#errorSlogin").text('Enter the mobile number.');
      $("#errorSlogin").css("display", "block");
      a = 1
    }
    else {
      if (!mobile_no.match(numpattern)) {
        $("#errorSlogin").text('Enter Only number.');
        $("#errorSlogin").css("display", "block");
        a = 1;
      }
      else {
        if (mobile_no.length < 8 || mobile_no.length > 10) {
          $("#errorSlogin").text('Please enter valid mobile number.');
          $("#errorSlogin").css("display", "block");
          a = 1;
        }
        else {
          $("#errorSlogin").text('');
          $("#errorSlogin").css("display", "none");
          a = 0;
        }
      }
    }
    if (a == 0) {
      $.ajax
      ({
        type: "POST",
        data: {mobile_no: mobile_no},
        url: "<?php echo base_url('api/login'); ?>",
        success: function (result) {
          if (result == 1) {
            swal({
              title: "",
              text: "Please Register Your Number",
              icon: "warning",
              confirmButtonColor: 'error'
            })
          }
          else if (result == 3) {
            $(".Verify_otp_slogin").show();
            $(".loginOTP").hide();
                    // $(".signUpOTP").hide();
                  }
                }
              });
    }
    else {
      return false;
    }
  }
</script>


<script>


  function login_signup() {
    var mobile_no_signup = $("#mobile_no_lsignup").val();
    var email_signup = $("#email_lsignup").val();
    var numpattern = /^[0-9]*$/;
    var a = 0;
    if (mobile_no_signup == '') {
      $("#errorphone_lsignup").text('Enter the mobile number.');
      $("#errorphone_lsignup").css("display", "block");
      a = 1
    }
    else {
      if (!mobile_no_signup.match(numpattern)) {
        $("#errorphone_lsignup").text('Enter Only number.');
        $("#errorphone_lsignup").css("display", "block");
        a = 1;
      }
      else {
        if (mobile_no_signup.length < 8 || mobile_no_signup.length > 10) {
          $("#errorphone_lsignup").text('Please enter valid mobile number.');
          $("#errorphone_lsignup").css("display", "block");
          a = 1;
        }
        else {
          $("#errorphone_lsignup").text('');
          $("#errorphone_lsignup").css("display", "none");
          a = 0;
        }
      }
    }
    if (a == 0) {
      $.ajax
      ({
        type: "POST",
        data: {email_signup: email_signup, mobile_no_signup: mobile_no_signup},
        url: "<?php echo base_url('api/signup');?>",
        success: function (result) {
         if (result == 4) {
          swal({
            title: "",
            text: "Already Register,Please Login",
            icon: "warning",
            confirmButtonColor: 'error'
          })
        }
        else if (result == 1) {
          $(".Verify_otp_lsignup").show();
          $(".signUpOTP").hide();
        }
      }
    });
    }
    else {
      return false;
    }
  }



  function otpcheckSlogin() {
    var otp = $("#otp_check_slogin").val();
    var numpattern = /^[0-9]*$/;
    var a = 0;
    if (otp == '') {
      $("#errorOtpsLogin").text('Enter the OTP Code.');
      $("#errorOtpsLogin").css("display", "block");
      a = 0
    }

    if (a == 0) {
      $.ajax
      ({
        type: "POST",
        data: { otp: otp},
        url: "<?php echo base_url('api/otp_check_login');?>",
        success: function (result) {
          if (result == 2) {
            window.location.href = "<?php echo site_url(); ?>";
          }
          else if (result == 1) {
            swal({
              title: "",
              text: "Please Enter Valid OTP",
              icon: "warning",
              confirmButtonColor: 'error'
            })
          }
        }
      });
    }
    else {
      return false;
    }
  }
</script>
<script type="text/javascript">
function otpCheck_lsignup() {
  var otp_check_signup = $("#otp_check_lsignup").val();
  var numpattern = /^[0-9]*$/;
  var a = 0;
  if (otp_check_signup == '') {
    $("#errorotplSignup").text('Enter the OTP Code.');
    $("#errorotplSignup").css("display", "block");
    a = 0
  }

  if (a == 0) {
    $.ajax
    ({
      type: "POST",
      data: {otp_check_signup: otp_check_signup},
      url: "<?php echo base_url('api/otp_check_signup');?>",
      success: function (result) {
        if (result == 2) {
          window.location.href = "<?php echo site_url(); ?>";
        }
        else if (result == 1) {
          swal({
            title: "",
            text: "Please Enter Valid OTP",
            icon: "warning",
            confirmButtonColor: 'error'
          })
        }
      }
    });
  }
  else {
    return false;
  }
}

$(document).ready(function() {
  $('.resend_otp_login').click(function() {
   $.ajax
   ({
    type: "POST",
    url: "<?php echo base_url('api/resendOtpLogin');?>",
    success: function (result)
    {
      if(result==1)
      {
        swal({
          title: "",
          text: "Otp Is Send To Phone.",
          confirmButtonColor: 'error'
        })
      }
      else
      {
        swal({
          title: "",
          text: "Otp Is Not Send.",
          icon: "warning",
          confirmButtonColor: 'error'
        }).then(function () {

        });
      }
    }
  });
 });
});

$(document).ready(function() {
  $('.resend_otp_signup').click(function() {
    $.ajax
    ({
      type: "POST",
      url: "<?php echo base_url('api/resendOtpSignup');?>",
      success: function (result)
      {
        if(result==1)
        {
          swal({
            title: "",
            text: "Otp Is Send To Phone.",
            confirmButtonColor: 'error'
          })
        }
        else
        {
          swal({
            title: "",
            text: "Otp Is Not Send.",
            icon: "warning",
            confirmButtonColor: 'error'
          }).then(function () {

          });
        }
      }
    });
  });
});
</script>