var validated = 0;
function validationFunction(inputId,inputFieldName,spanId,type) {

    if(type == 'required'){
        var inputVal = $('#'+inputId).val();
        if (inputVal === "") {
            $("#"+spanId).html(inputFieldName+" is required");
            $("#"+spanId).css("display", "block");
            validated = 0;
        } else {
            $("#"+spanId).html("");
            $("#"+spanId).css("display", "none");
            validated = 1;
        }

    }else if(type == 'mobile'){

        var mobileNumber = $('#'+inputId).val();
        if (mobileNumber === "") {
            $("#"+spanId).html(inputFieldName+" is required");
            $("#"+spanId).css("display", "block");
            validated = 0;
        } else if (mobileNumber !== "") {
            var mobileRes = mobileNumber.match(/^[0-9+]{10,13}$/);
            if (mobileRes === null) {
                $("#"+spanId).css("display", "block");
                $("#"+spanId).text('Please enter valid '+inputFieldName+'.');
                validated = 0;
            } else {
                $("#"+spanId).css("display", "none");
                validated = 1;
            }
        } else {
            $("#"+spanId).css("display", "none");
            validated = 1;
        }

    }else if(type == 'email'){

        var email = $('#'+inputId).val();

        if (email !== "") {
            var emailRes = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            if (!(emailRes.test(email))) {
                $("#"+spanId).css("display", "block");
                $("#"+spanId).text('Please enter valid '+inputFieldName+'.');
                validated = 0;
            } else {
                $("#"+spanId).css("display", "none");
                validated = 1;
            }
        } else {
            $("#"+spanId).css("display", "none");
            validated = 1;
        }

    }else if(type == 'password'){

        var password = $('#'+inputId).val();
        if (password === "") {
            $("#"+spanId).html(inputFieldName+" is required");
            $("#"+spanId).css("display", "block");
            validated = 0;
        } else if (password !== "") {
            var passwordRes = password.match(/^(?=.*\d)(?=.*[a-zA-Z])[0-9a-zA-Z]{4,}$/);
            if (passwordRes === null) {
                $("#"+spanId).css("display", "block");
                $("#"+spanId).text('Inclusion of alpha numerical and should be minimum length of four character.');
                validated = 0;
            } else {
                $("#"+spanId).css("display", "none");
                validated = 1;
            }
        } else {
            $("#"+spanId).css("display", "none");
            validated = 1;
        }
    }else if(type == 'name'){

        var name = $('#'+inputId).val();
        if (name !== "") {
            var nameRes = name.match(/^([a-zA-Z]+\s)*[a-zA-Z]+$/);
            if (nameRes === null) {
                $("#"+spanId).css("display", "block");
                $("#"+spanId).text('Only characters are allowed.');
                validated = 0;
            } else {
                $("#"+spanId).css("display", "none");
                validated = 1;
            }
        } else {
            $("#"+spanId).css("display", "none");
            validated = 1;
        }
    }
}